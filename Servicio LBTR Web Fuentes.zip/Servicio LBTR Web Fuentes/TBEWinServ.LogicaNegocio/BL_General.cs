using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading;
using System.Xml;
using System.Xml.XPath;
using System.Configuration;
using TBEWinServ.Utilitarios;
using TBEWinServ.AccesoDatos;
using TBEWinServ.EntidadesNegocio.Generales;
using TBEWinServ.EntidadesNegocio.Transferencia;
using TBEWinServ.EntidadesNegocio.CompraVenta;

namespace TBEWinServ.LogicaNegocio
{
    public class BL_General
    {
        private string strHashcode = null;

        public bool errorEnDAO = false;

        public BL_General(string prmHashcode) 
        {
            strHashcode = prmHashcode;
        }

        public string InterpretarCaracteresEspecialesXML(String prmCadena)
        {
            if (!String.IsNullOrEmpty(prmCadena))
            {
                prmCadena = prmCadena.Replace("&", "&amp;");
                prmCadena = prmCadena.Replace("<", "&lt;");
                prmCadena = prmCadena.Replace(">", "&gt;");
                prmCadena = prmCadena.Replace("'", "&apos;");
                prmCadena = prmCadena.Replace("\"", "&quot;");
            }

            return prmCadena;
        }

        public static void InicializarListaCaracteresNoValidos() 
        {
            CaracterNoValido oCaracter = null;

            Globales.LstCaracteresNoValidos.Clear();

            oCaracter = new CaracterNoValido();
            oCaracter.Car = "�"; oCaracter.Hex = "F7"; oCaracter.CarReemp = "/"; oCaracter.HexReemp = "2F";
            Globales.LstCaracteresNoValidos.Add(oCaracter);

            oCaracter = new CaracterNoValido();
            oCaracter.Car = "�"; oCaracter.Hex = "BF"; oCaracter.CarReemp = "?"; oCaracter.HexReemp = "3F";
            Globales.LstCaracteresNoValidos.Add(oCaracter);

            oCaracter = new CaracterNoValido();
            oCaracter.Car = "�"; oCaracter.Hex = "B4"; oCaracter.CarReemp = "`"; oCaracter.HexReemp = "60";
            Globales.LstCaracteresNoValidos.Add(oCaracter);

            oCaracter = new CaracterNoValido();
            oCaracter.Car = "�"; oCaracter.Hex = "AB"; oCaracter.CarReemp = "<"; oCaracter.HexReemp = "3C";
            Globales.LstCaracteresNoValidos.Add(oCaracter);

            oCaracter = new CaracterNoValido();
            oCaracter.Car = "�"; oCaracter.Hex = "BB"; oCaracter.CarReemp = ">"; oCaracter.HexReemp = "3E";
            Globales.LstCaracteresNoValidos.Add(oCaracter);

            oCaracter = new CaracterNoValido();
            oCaracter.Car = "�"; oCaracter.Hex = "C0"; oCaracter.CarReemp = "A"; oCaracter.HexReemp = "41";
            Globales.LstCaracteresNoValidos.Add(oCaracter);

            oCaracter = new CaracterNoValido();
            oCaracter.Car = "�"; oCaracter.Hex = "C1"; oCaracter.CarReemp = "A"; oCaracter.HexReemp = "41";
            Globales.LstCaracteresNoValidos.Add(oCaracter);

            oCaracter = new CaracterNoValido();
            oCaracter.Car = "�"; oCaracter.Hex = "C2"; oCaracter.CarReemp = "A"; oCaracter.HexReemp = "41";
            Globales.LstCaracteresNoValidos.Add(oCaracter);

            oCaracter = new CaracterNoValido();
            oCaracter.Car = "�"; oCaracter.Hex = "C3"; oCaracter.CarReemp = "A"; oCaracter.HexReemp = "41";
            Globales.LstCaracteresNoValidos.Add(oCaracter);

            oCaracter = new CaracterNoValido();
            oCaracter.Car = "�"; oCaracter.Hex = "C4"; oCaracter.CarReemp = "A"; oCaracter.HexReemp = "41";
            Globales.LstCaracteresNoValidos.Add(oCaracter);

            oCaracter = new CaracterNoValido();
            oCaracter.Car = "�"; oCaracter.Hex = "C5"; oCaracter.CarReemp = "A"; oCaracter.HexReemp = "41";
            Globales.LstCaracteresNoValidos.Add(oCaracter);

            oCaracter = new CaracterNoValido();
            oCaracter.Car = "�"; oCaracter.Hex = "E0"; oCaracter.CarReemp = "a"; oCaracter.HexReemp = "61";
            Globales.LstCaracteresNoValidos.Add(oCaracter);

            oCaracter = new CaracterNoValido();
            oCaracter.Car = "�"; oCaracter.Hex = "E1"; oCaracter.CarReemp = "a"; oCaracter.HexReemp = "61";
            Globales.LstCaracteresNoValidos.Add(oCaracter);

            oCaracter = new CaracterNoValido();
            oCaracter.Car = "�"; oCaracter.Hex = "E2"; oCaracter.CarReemp = "a"; oCaracter.HexReemp = "61";
            Globales.LstCaracteresNoValidos.Add(oCaracter);

            oCaracter = new CaracterNoValido();
            oCaracter.Car = "�"; oCaracter.Hex = "E3"; oCaracter.CarReemp = "a"; oCaracter.HexReemp = "61";
            Globales.LstCaracteresNoValidos.Add(oCaracter);

            oCaracter = new CaracterNoValido();
            oCaracter.Car = "�"; oCaracter.Hex = "E4"; oCaracter.CarReemp = "a"; oCaracter.HexReemp = "61";
            Globales.LstCaracteresNoValidos.Add(oCaracter);

            oCaracter = new CaracterNoValido();
            oCaracter.Car = "�"; oCaracter.Hex = "E5"; oCaracter.CarReemp = "a"; oCaracter.HexReemp = "61";
            Globales.LstCaracteresNoValidos.Add(oCaracter);

            /*oCaracter = new CaracterNoValido();
            oCaracter.Car = "�"; oCaracter.Hex = "C6"; oCaracter.CarReemp = "AE"; oCaracter.HexReemp = "4145";
            Globales.LstCaracteresNoValidos.Add(oCaracter);*/

            /*oCaracter = new CaracterNoValido();
            oCaracter.Car = "�"; oCaracter.Hex = "E6"; oCaracter.CarReemp = "ae"; oCaracter.HexReemp = "6165";
            Globales.LstCaracteresNoValidos.Add(oCaracter);*/

            oCaracter = new CaracterNoValido();
            oCaracter.Car = "�"; oCaracter.Hex = "DF"; oCaracter.CarReemp = "B"; oCaracter.HexReemp = "42";
            Globales.LstCaracteresNoValidos.Add(oCaracter);

            oCaracter = new CaracterNoValido();
            oCaracter.Car = "�"; oCaracter.Hex = "A9"; oCaracter.CarReemp = "c"; oCaracter.HexReemp = "63";
            Globales.LstCaracteresNoValidos.Add(oCaracter);

            oCaracter = new CaracterNoValido();
            oCaracter.Car = "�"; oCaracter.Hex = "C7"; oCaracter.CarReemp = "C"; oCaracter.HexReemp = "43";
            Globales.LstCaracteresNoValidos.Add(oCaracter);

            oCaracter = new CaracterNoValido();
            oCaracter.Car = "�"; oCaracter.Hex = "E7"; oCaracter.CarReemp = "c"; oCaracter.HexReemp = "63";
            Globales.LstCaracteresNoValidos.Add(oCaracter);

            oCaracter = new CaracterNoValido();
            oCaracter.Car = "�"; oCaracter.Hex = "D0"; oCaracter.CarReemp = "D"; oCaracter.HexReemp = "44";
            Globales.LstCaracteresNoValidos.Add(oCaracter);

            oCaracter = new CaracterNoValido();
            oCaracter.Car = "�"; oCaracter.Hex = "A3"; oCaracter.CarReemp = "L"; oCaracter.HexReemp = "4C";
            Globales.LstCaracteresNoValidos.Add(oCaracter);

            oCaracter = new CaracterNoValido();
            oCaracter.Car = "�"; oCaracter.Hex = "C8"; oCaracter.CarReemp = "E"; oCaracter.HexReemp = "45";
            Globales.LstCaracteresNoValidos.Add(oCaracter);

            oCaracter = new CaracterNoValido();
            oCaracter.Car = "�"; oCaracter.Hex = "C9"; oCaracter.CarReemp = "E"; oCaracter.HexReemp = "45";
            Globales.LstCaracteresNoValidos.Add(oCaracter);

            oCaracter = new CaracterNoValido();
            oCaracter.Car = "�"; oCaracter.Hex = "CA"; oCaracter.CarReemp = "E"; oCaracter.HexReemp = "45";
            Globales.LstCaracteresNoValidos.Add(oCaracter);

            oCaracter = new CaracterNoValido();
            oCaracter.Car = "�"; oCaracter.Hex = "CB"; oCaracter.CarReemp = "E"; oCaracter.HexReemp = "45";
            Globales.LstCaracteresNoValidos.Add(oCaracter);

            oCaracter = new CaracterNoValido();
            oCaracter.Car = "�"; oCaracter.Hex = "E8"; oCaracter.CarReemp = "e"; oCaracter.HexReemp = "65";
            Globales.LstCaracteresNoValidos.Add(oCaracter);

            oCaracter = new CaracterNoValido();
            oCaracter.Car = "�"; oCaracter.Hex = "E9"; oCaracter.CarReemp = "e"; oCaracter.HexReemp = "65";
            Globales.LstCaracteresNoValidos.Add(oCaracter);

            oCaracter = new CaracterNoValido();
            oCaracter.Car = "�"; oCaracter.Hex = "EA"; oCaracter.CarReemp = "e"; oCaracter.HexReemp = "65";
            Globales.LstCaracteresNoValidos.Add(oCaracter);

            oCaracter = new CaracterNoValido();
            oCaracter.Car = "�"; oCaracter.Hex = "EB"; oCaracter.CarReemp = "e"; oCaracter.HexReemp = "65";
            Globales.LstCaracteresNoValidos.Add(oCaracter);

            oCaracter = new CaracterNoValido();
            oCaracter.Car = "�"; oCaracter.Hex = "A1"; oCaracter.CarReemp = "i"; oCaracter.HexReemp = "69";
            Globales.LstCaracteresNoValidos.Add(oCaracter);

            oCaracter = new CaracterNoValido();
            oCaracter.Car = "�"; oCaracter.Hex = "CC"; oCaracter.CarReemp = "I"; oCaracter.HexReemp = "69";
            Globales.LstCaracteresNoValidos.Add(oCaracter);

            oCaracter = new CaracterNoValido();
            oCaracter.Car = "�"; oCaracter.Hex = "CD"; oCaracter.CarReemp = "I"; oCaracter.HexReemp = "69";
            Globales.LstCaracteresNoValidos.Add(oCaracter);

            oCaracter = new CaracterNoValido();
            oCaracter.Car = "�"; oCaracter.Hex = "CE"; oCaracter.CarReemp = "I"; oCaracter.HexReemp = "69";
            Globales.LstCaracteresNoValidos.Add(oCaracter);

            oCaracter = new CaracterNoValido();
            oCaracter.Car = "�"; oCaracter.Hex = "CF"; oCaracter.CarReemp = "I"; oCaracter.HexReemp = "69";
            Globales.LstCaracteresNoValidos.Add(oCaracter);

            oCaracter = new CaracterNoValido();
            oCaracter.Car = "�"; oCaracter.Hex = "EC"; oCaracter.CarReemp = "i"; oCaracter.HexReemp = "69";
            Globales.LstCaracteresNoValidos.Add(oCaracter);

            oCaracter = new CaracterNoValido();
            oCaracter.Car = "�"; oCaracter.Hex = "ED"; oCaracter.CarReemp = "i"; oCaracter.HexReemp = "69";
            Globales.LstCaracteresNoValidos.Add(oCaracter);

            oCaracter = new CaracterNoValido();
            oCaracter.Car = "�"; oCaracter.Hex = "EE"; oCaracter.CarReemp = "i"; oCaracter.HexReemp = "69";
            Globales.LstCaracteresNoValidos.Add(oCaracter);

            oCaracter = new CaracterNoValido();
            oCaracter.Car = "�"; oCaracter.Hex = "EF"; oCaracter.CarReemp = "i"; oCaracter.HexReemp = "69";
            Globales.LstCaracteresNoValidos.Add(oCaracter);

            oCaracter = new CaracterNoValido();
            oCaracter.Car = "�"; oCaracter.Hex = "D1"; oCaracter.CarReemp = "N"; oCaracter.HexReemp = "4E";
            Globales.LstCaracteresNoValidos.Add(oCaracter);

            oCaracter = new CaracterNoValido();
            oCaracter.Car = "�"; oCaracter.Hex = "F1"; oCaracter.CarReemp = "n"; oCaracter.HexReemp = "6E";
            Globales.LstCaracteresNoValidos.Add(oCaracter);

            oCaracter = new CaracterNoValido();
            oCaracter.Car = "�"; oCaracter.Hex = "D2"; oCaracter.CarReemp = "O"; oCaracter.HexReemp = "4F";
            Globales.LstCaracteresNoValidos.Add(oCaracter);

            oCaracter = new CaracterNoValido();
            oCaracter.Car = "�"; oCaracter.Hex = "D3"; oCaracter.CarReemp = "O"; oCaracter.HexReemp = "4F";
            Globales.LstCaracteresNoValidos.Add(oCaracter);

            oCaracter = new CaracterNoValido();
            oCaracter.Car = "�"; oCaracter.Hex = "D4"; oCaracter.CarReemp = "O"; oCaracter.HexReemp = "4F";
            Globales.LstCaracteresNoValidos.Add(oCaracter);

            oCaracter = new CaracterNoValido();
            oCaracter.Car = "�"; oCaracter.Hex = "D5"; oCaracter.CarReemp = "O"; oCaracter.HexReemp = "4F";
            Globales.LstCaracteresNoValidos.Add(oCaracter);

            oCaracter = new CaracterNoValido();
            oCaracter.Car = "�"; oCaracter.Hex = "D6"; oCaracter.CarReemp = "O"; oCaracter.HexReemp = "4F";
            Globales.LstCaracteresNoValidos.Add(oCaracter);

            oCaracter = new CaracterNoValido();
            oCaracter.Car = "�"; oCaracter.Hex = "F2"; oCaracter.CarReemp = "o"; oCaracter.HexReemp = "6F";
            Globales.LstCaracteresNoValidos.Add(oCaracter);

            oCaracter = new CaracterNoValido();
            oCaracter.Car = "�"; oCaracter.Hex = "F3"; oCaracter.CarReemp = "o"; oCaracter.HexReemp = "6F";
            Globales.LstCaracteresNoValidos.Add(oCaracter);

            oCaracter = new CaracterNoValido();
            oCaracter.Car = "�"; oCaracter.Hex = "F4"; oCaracter.CarReemp = "o"; oCaracter.HexReemp = "6F";
            Globales.LstCaracteresNoValidos.Add(oCaracter);

            oCaracter = new CaracterNoValido();
            oCaracter.Car = "�"; oCaracter.Hex = "F5"; oCaracter.CarReemp = "o"; oCaracter.HexReemp = "6F";
            Globales.LstCaracteresNoValidos.Add(oCaracter);

            oCaracter = new CaracterNoValido();
            oCaracter.Car = "�"; oCaracter.Hex = "F6"; oCaracter.CarReemp = "o"; oCaracter.HexReemp = "6F";
            Globales.LstCaracteresNoValidos.Add(oCaracter);

            oCaracter = new CaracterNoValido();
            oCaracter.Car = "�"; oCaracter.Hex = "B5"; oCaracter.CarReemp = "u"; oCaracter.HexReemp = "75";
            Globales.LstCaracteresNoValidos.Add(oCaracter);

            oCaracter = new CaracterNoValido();
            oCaracter.Car = "�"; oCaracter.Hex = "D9"; oCaracter.CarReemp = "U"; oCaracter.HexReemp = "55";
            Globales.LstCaracteresNoValidos.Add(oCaracter);

            oCaracter = new CaracterNoValido();
            oCaracter.Car = "�"; oCaracter.Hex = "DA"; oCaracter.CarReemp = "U"; oCaracter.HexReemp = "55";
            Globales.LstCaracteresNoValidos.Add(oCaracter);

            oCaracter = new CaracterNoValido();
            oCaracter.Car = "�"; oCaracter.Hex = "DB"; oCaracter.CarReemp = "U"; oCaracter.HexReemp = "55";
            Globales.LstCaracteresNoValidos.Add(oCaracter);

            oCaracter = new CaracterNoValido();
            oCaracter.Car = "�"; oCaracter.Hex = "DC"; oCaracter.CarReemp = "U"; oCaracter.HexReemp = "55";
            Globales.LstCaracteresNoValidos.Add(oCaracter);

            oCaracter = new CaracterNoValido();
            oCaracter.Car = "�"; oCaracter.Hex = "F9"; oCaracter.CarReemp = "u"; oCaracter.HexReemp = "75";
            Globales.LstCaracteresNoValidos.Add(oCaracter);

            oCaracter = new CaracterNoValido();
            oCaracter.Car = "�"; oCaracter.Hex = "FA"; oCaracter.CarReemp = "u"; oCaracter.HexReemp = "75";
            Globales.LstCaracteresNoValidos.Add(oCaracter);

            oCaracter = new CaracterNoValido();
            oCaracter.Car = "�"; oCaracter.Hex = "FB"; oCaracter.CarReemp = "u"; oCaracter.HexReemp = "75";
            Globales.LstCaracteresNoValidos.Add(oCaracter);

            oCaracter = new CaracterNoValido();
            oCaracter.Car = "�"; oCaracter.Hex = "FC"; oCaracter.CarReemp = "u"; oCaracter.HexReemp = "75";
            Globales.LstCaracteresNoValidos.Add(oCaracter);

            oCaracter = new CaracterNoValido();
            oCaracter.Car = "�"; oCaracter.Hex = "DD"; oCaracter.CarReemp = "Y"; oCaracter.HexReemp = "59";
            Globales.LstCaracteresNoValidos.Add(oCaracter);

            oCaracter = new CaracterNoValido();
            oCaracter.Car = "�"; oCaracter.Hex = "FD"; oCaracter.CarReemp = "y"; oCaracter.HexReemp = "79";
            Globales.LstCaracteresNoValidos.Add(oCaracter);

            oCaracter = new CaracterNoValido();
            oCaracter.Car = "�"; oCaracter.Hex = "FF"; oCaracter.CarReemp = "y"; oCaracter.HexReemp = "79";
            Globales.LstCaracteresNoValidos.Add(oCaracter);

        }

        public string ValidarContenidoString(String prmTextoClaro, String strCaracteresValidos) 
        {
            if (String.IsNullOrEmpty(prmTextoClaro)) return "";
            if (String.IsNullOrEmpty(strCaracteresValidos)) return prmTextoClaro;

            String strTextoEnHex = "";

            try
            {
                //Esto ser� un parametro en la BD
                //String strCaracteresValidos = " !\"#$%&()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^`abcdefghijklmnopqrstuvwxyz{|}~";

                //Se coloca en una lista generica para realizar la busqueda m�s rapida
                List<String> lstCaracteresValidos = new List<string>();
                for (int i = 0; i < strCaracteresValidos.Length; i++)
                {
                    lstCaracteresValidos.Add(Utilitario.ToHexadecimal(strCaracteresValidos.Substring(i, 1)));
                }

                //Convertimos de texto claro a formato Hexadecimal
                strTextoEnHex = Utilitario.ToHexadecimal(prmTextoClaro);

                //Validamos que cada valor hexadecimal se encuentre en la lista
                //de lo contrario, se reemplaza
                String strHex = "";
                for (int i = 0; i < strTextoEnHex.Length; i += 2)
                {
                    strHex = strTextoEnHex.Substring(i, 2);

                    if (!lstCaracteresValidos.Contains(strHex))
                    {
                        strTextoEnHex = strTextoEnHex.Remove(i, 2);

                        CaracterNoValido oCar = Globales.LstCaracteresNoValidos.Find(delegate(CaracterNoValido oCarBus) { return oCarBus.Hex == strHex; });
                        if (oCar != null)
                        {
                            strTextoEnHex = strTextoEnHex.Insert(i, oCar.HexReemp);//Reemplazando (mapeo)
                        }
                        else
                        {
                            strTextoEnHex = strTextoEnHex.Insert(i, "20");//Reemplazando con espacio en blanco
                        }
                    }
                }

                //Convertimos de Hexadecimal a texto claro
                strTextoEnHex = Utilitario.ToStringFromHexadecimal(strTextoEnHex);

            }
            catch (Exception ex)
            {
                strTextoEnHex = prmTextoClaro;

                LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.ENVIO_TRANSFERENCIAS, strHashcode,
                    "BL_General.ValidarContenidoString",
                    "Error al validar el valor del campo: " + ex.Message + ". " + ex.StackTrace, false);
            }

            return strTextoEnHex;
        }

        public BE_ErrorApiSeguridad ObtenerErrorApiSeguridad(String prmNombreFuncion,  String prmCodigoError,
                                                                out String prmMensajeError)
        {
            prmMensajeError = null;
            BE_ErrorApiSeguridad oErrorApi = null;

            if (!String.IsNullOrEmpty(Globales.RUTA_XML_ERRORES_APISEG))
            {
                if (File.Exists(Globales.RUTA_XML_ERRORES_APISEG))
                {
                    try
                    {
                        XPathDocument xpathDoc;
                        XPathNavigator xmlNav;

                        XPathNavigator xmlNodoBusqueda;
                        xpathDoc = new XPathDocument(Globales.RUTA_XML_ERRORES_APISEG);
                        xmlNav = xpathDoc.CreateNavigator();

                        //Obtencion de la funcion
                        xmlNodoBusqueda = xmlNav.SelectSingleNode("/Errores/Particulares/Funcion[@Nombre='" + prmNombreFuncion + "']");

                        if (xmlNodoBusqueda != null)
                        {
                            xmlNodoBusqueda = xmlNodoBusqueda.SelectSingleNode("./Error[@Codigo='" + prmCodigoError + "']");

                            if (xmlNodoBusqueda != null)
                            {
                                //Se lee el nodo error encontrado
                                oErrorApi = LeerNodoErrorApiSeguridad(xmlNodoBusqueda, out prmMensajeError);
                                if (oErrorApi != null)
                                {
                                    oErrorApi.FuncionApiOrigen = prmNombreFuncion;
                                    oErrorApi.TipoError = TipoErrorApiSeguridad.Particular;
                                }
                            }
                            else
                            { 
                                //Como no se encontro en los errores particulares de la funcion especificada
                                //se buscara en los errores genericos
                                xmlNodoBusqueda = xmlNav.SelectSingleNode("/Errores/Generales/Error[@Codigo='" + prmCodigoError + "']");

                                if (xmlNodoBusqueda != null)
                                {
                                    //Se lee el nodo error encontrado
                                    oErrorApi = LeerNodoErrorApiSeguridad(xmlNodoBusqueda, out prmMensajeError);
                                    if (oErrorApi != null)
                                    {
                                        oErrorApi.TipoError = TipoErrorApiSeguridad.General;
                                    }
                                }
                                else
                                {
                                    prmMensajeError = "No se encontro el codigo de error [" + prmCodigoError + "] retornado por la funcion [" + prmNombreFuncion + "] en el archivo XML de errores de api de seguridad.";
                                }

                            }
                        }
                        else
                        {
                            prmMensajeError = "No se encontro la funcion [" + prmNombreFuncion + "] en el archivo XML de errores de api de seguridad.";
                        }
                    }
                    catch (Exception ex)
                    {
                        prmMensajeError = "Error: " + ex.Message + ". " + ex.StackTrace;                        
                    }
                }
                else
                {
                    prmMensajeError = "No existe el archivo XML especificado como listado errores API Seguridad.";
                }
            }
            else
            {
                prmMensajeError = "No se ha establecido la ruta del archivo XML listado errores API Seguridad.";
            }

            if (!String.IsNullOrEmpty(prmMensajeError))
            {
                prmMensajeError = "Excepcion en la busqueda del Error retornado por el API de Seguridad en el Archivo XML: " + prmMensajeError;
                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SEGURIDAD, strHashcode,
                    "BL_General.ObtenerErrorApiSeguridad",
                    prmMensajeError, true);
            }

            return oErrorApi;
        }

        private BE_ErrorApiSeguridad LeerNodoErrorApiSeguridad(XPathNavigator prmNodo, out String prmMensajeError)
        {
            prmMensajeError = null;
            BE_ErrorApiSeguridad oErrorApi = null;
            XPathNavigator prmNodoPropiedad = null;

            try
            {
                oErrorApi = new BE_ErrorApiSeguridad();
                oErrorApi.CodigoError = prmNodo.GetAttribute("Codigo", "");
                
                prmNodoPropiedad = prmNodo.SelectSingleNode("./Descripcion");
                //prmNodo.
                if (prmNodoPropiedad != null) oErrorApi.DescripcionError = prmNodoPropiedad.Value;

                prmNodoPropiedad = prmNodo.SelectSingleNode("./AccionTomar");
                if (prmNodoPropiedad != null) oErrorApi.AccionATomar = prmNodoPropiedad.Value;

                prmNodoPropiedad = prmNodo.SelectSingleNode("./Origen");
                if (prmNodoPropiedad != null) oErrorApi.Origen = prmNodoPropiedad.Value;

                prmNodoPropiedad = prmNodo.SelectSingleNode("./Nivel");
                if (prmNodoPropiedad != null) oErrorApi.Nivel = prmNodoPropiedad.Value;

                String strRequiereReconexion = prmNodo.GetAttribute("RequiereReconexion", "");
                if (String.IsNullOrEmpty(strRequiereReconexion)) strRequiereReconexion = "false";
                strRequiereReconexion = strRequiereReconexion.ToLower();
                if (strRequiereReconexion.Equals("true")) oErrorApi.RequiereReconexion = true;//por defecto es false
            }
            catch (Exception ex)
            {
                oErrorApi = null;
                prmMensajeError = "Error al leer el nodo de error de api de seguridad encontrado: " + ex.Message + ". " + ex.StackTrace;
            }

            return oErrorApi;       
        }
             
        public string ObtenerValorConfiguracion(string prmNombreParametro) 
        {
            errorEnDAO = false;
            string strValor = null;

            DA_General oDAGeneral = new DA_General(strHashcode);
            strValor = oDAGeneral.Obtener_Config(Constantes.PARAM_CODIGO_AGRUPACION, prmNombreParametro);

            if (String.IsNullOrEmpty(strValor)) strValor = "";

            if (oDAGeneral.Excepcion != null)
            {
                errorEnDAO = true;
            }

            return strValor;
        }

        public string ObtenerValorParametro(string prmCodigo)
        {
            errorEnDAO = false;
            string strValor = null;

            DA_General oDAGeneral = new DA_General(strHashcode);
            strValor = oDAGeneral.Obtener_Param(prmCodigo);

            if (String.IsNullOrEmpty(strValor)) strValor = "";

            if (oDAGeneral.Excepcion != null)
            {
                errorEnDAO = true;
            }

            return strValor;
        }

        public static Dictionary<string, string> ObtenerListaConfig() {
            Dictionary<string, string> dicConfig = new Dictionary<string, string>();
            DA_General oDAGeneral = new DA_General(Globales.HASHCODE_thrInicioFinDia);

            string strValor = null;

            strValor = oDAGeneral.Obtener_Config(Constantes.PARAM_CODIGO_AGRUPACION, Constantes.PARAM_CODIGO_HORAINI);

            if (!String.IsNullOrEmpty(strValor)) 
            {
                dicConfig.Add(Constantes.PARAM_CODIGO_HORAINI, strValor);            
            }

            strValor = oDAGeneral.Obtener_Config(Constantes.PARAM_CODIGO_AGRUPACION, Constantes.PARAM_CODIGO_HORAFIN1);

            if (!String.IsNullOrEmpty(strValor))
            {
                dicConfig.Add(Constantes.PARAM_CODIGO_HORAFIN1, strValor);
            }

            strValor = oDAGeneral.Obtener_Config(Constantes.PARAM_CODIGO_AGRUPACION, Constantes.PARAM_CODIGO_HORAFIN2);

            if (!String.IsNullOrEmpty(strValor))
            {
                dicConfig.Add(Constantes.PARAM_CODIGO_HORAFIN2, strValor);
            }

            return dicConfig;        
        }

        public void ActualizarConfig(string prmCodAgrupacion, string prmCodigo, string prmValor) {
            
            LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.SERVICIO_WINDOWS, strHashcode, 
                "BL_General.ActualizarConfig",
                "Se procede a actualizar el parametro de configuracion. CodAgrupacion: " + prmCodAgrupacion +
                "; Codigo: " + prmCodigo + "; Valor: " + prmValor, false);

            errorEnDAO = false;
            DA_General oDAGeneral = new DA_General(Globales.HASHCODE_thrInicioFinDia);
            oDAGeneral.Actualizar_Config(prmCodAgrupacion, prmCodigo, prmValor);

            if (oDAGeneral.Excepcion != null)
            {
                errorEnDAO = true;
            }
        }

        public void InsertarLogError(string prmIdOperacion, string prmDescripcion, bool prmIncluirEnUltimoGrupo)
        {
            //Por defecto es error
            InsertarLogError(prmIdOperacion, prmDescripcion, TipoError.ERROR, prmIncluirEnUltimoGrupo);
        }

        public void InsertarLogError(string prmIdOperacion, string prmDescripcion, string prmTipoError, bool prmIncluirEnUltimoGrupo) 
        {
            if (!String.IsNullOrEmpty(Globales.CADENA_CONEXION))
            {
                DA_General oDAGen = new DA_General(strHashcode);
                oDAGen.Insertar_Log_Error(prmIdOperacion, prmDescripcion, prmTipoError, prmIncluirEnUltimoGrupo);
            }
        }

        public string Obtener_Estado_Equivalente(string prmEstadoBCRP, String prmTipoEstadoBCRP) 
        {
            errorEnDAO = false;
            DA_General oDAGen = new DA_General(strHashcode);
            string strEstadoCiti = oDAGen.Obtener_Estado_Equivalente(prmEstadoBCRP, prmTipoEstadoBCRP);

            if (oDAGen != null)
            {
                errorEnDAO = true;
            }
            else
            {
                if (String.IsNullOrEmpty(strEstadoCiti))
                {
                    LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS, strHashcode, "BL_General.Obtener_Estado_Equivalente",
                        "El estado (" + prmEstadoBCRP + ") no tiene relacion en la tabla de equivalencias de estados.", true);
                }
            }

            return strEstadoCiti;
        }

        public static bool EsFechaLaborable(DateTime prmFecha) 
        {
            String strOmitirFeriado = ConfigurationManager.AppSettings["LOGON_EN_FERIADO"];

            if (!String.IsNullOrEmpty(strOmitirFeriado))
            {
                if (strOmitirFeriado.ToLower().Equals("true"))
                {
                    return true;
                }
            }

            if (prmFecha.DayOfWeek == DayOfWeek.Saturday || prmFecha.DayOfWeek == DayOfWeek.Sunday)
            {
                return false;
            }
            else 
            {
                DA_General oDAGen = new DA_General(Globales.HASHCODE_thrInicioFinDia);
                if (oDAGen.EsFeriado(prmFecha)) return false;
            }

            return true;        
        }
               
        public static int f_modulo11(string prmCuenta)
        {
            int li_return = 1;
            int li_xx, li_factor;
            int ll_adding = 0;

            li_factor = 2;

            try
            {
                //Recorre caracter por caracter de derecha a izquiera desde la penultima posicion
                for (li_xx = (prmCuenta.Length) - 2; li_xx >= 0; li_xx--)
                {
                    ll_adding = ll_adding + (int.Parse(prmCuenta.Substring(li_xx, 1)) * li_factor);
                    //si el factor llega a siete entonces retorna y se resetea la variable a 1 
                    if (li_factor == 7) li_factor = 1;
                    li_factor++;
                }

                /*a 11 se le resta el valor obtenido de la anterior iteracion for 
                que es dividido entre once la cual da el resto de esa division a traves
                de la funcion mod*/
                li_factor = 11 - (ll_adding % 11); //li_factor = 11 - Mod ( ll_adding, 11 );

                /* el resultado si es mayor a nueve no cumple este modulo 11*/
                if (li_factor > 9)
                {
                    li_return = -1;
                }// Si el resultado es diferente del primer valor de la derecha no cumple con el modulo 11
                else if (li_factor != int.Parse(prmCuenta.Substring(prmCuenta.Length - 1, 1)))
                {
                    li_return = -1;
                }

            }
            catch
            {
                li_return = -1;
            }

            return li_return;
        }

        public List<BE_Banco> ObtenerBancos(BE_Banco prmBanco) 
        {
            errorEnDAO = false;
            DA_General oDAGen = new DA_General(strHashcode);
            List<BE_Banco> lstBancos = oDAGen.Obtener_Bancos(prmBanco);

            if (oDAGen.Excepcion != null)
            {
                errorEnDAO = true;
            }

            return lstBancos;
        }

        public bool Actualizar_Transferencia(BE_Transferencia prmTransf)
        {
            bool blnActualizarPaylink = false;
            DA_Transferencia daTransf = new DA_Transferencia(strHashcode);

            if (String.IsNullOrEmpty(Globales.CADENA_CONEXION))
            {
                return false;
            }

            //Con respecto al estado, actualizar el valor fecha de En Espera, Enviado, Aceptado, Anulado
            switch (prmTransf.Estado)
            {
                case Estados.REGISTRADO_BCRP:
                    prmTransf.FechaRegistradoBCRP = DateTime.Now;
                    break;
                case Estados.PENDIENTE_EN_ESPERA:
                    prmTransf.FechaEnEspera = DateTime.Now;
                    blnActualizarPaylink = true;
                    break;
                case Estados.ENVIADO:
                    prmTransf.FechaEnviado = DateTime.Now;
                    break;
                case Estados.REENVIADO:
                    prmTransf.FechaReEnviado = DateTime.Now;
                    break;
                case Estados.PROCESADO:
                    prmTransf.FechaAceptado = DateTime.Now;
                    blnActualizarPaylink = true;
                    break;
                case Estados.ANULADO:
                    prmTransf.FechaAnulado = DateTime.Now;
                    blnActualizarPaylink = true;
                    break;
                case Estados.ERROR_TRX:
                    prmTransf.FechaErrorTrx = DateTime.Now;
                    blnActualizarPaylink = true;
                    break;
                default:
                    break;
            }

            if (daTransf.Actualizar_Transferencia(prmTransf) == false)
            {
                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.ENVIO_TRANSFERENCIAS, strHashcode,
                    "BL_General.Actualizar_Transferencia",
                    "No se pudo actualizar la informacion de la transferencia [" + prmTransf.TRANSACT + 
                    "] al estado [" + prmTransf.Estado + "]", false);

                (new BL_General(strHashcode)).InsertarLogError(prmTransf.TRANSACT + prmTransf.SEC,
                    "Error al actualizar la informacion de la operacion TRANSACT [" + prmTransf.TRANSACT + 
                    "] al estado [" + prmTransf.Estado + "]", false);

                return false;
            }
            else
            {
                if (blnActualizarPaylink)
                {
                    string strCodigoPaylink = daTransf.Obtener_Codigo_Paylink(prmTransf.TRANSACT, prmTransf.SEC);

                    if (!String.IsNullOrEmpty(strCodigoPaylink))
                    {
                        if (!daTransf.Actualizar_Operacion_Paylink(strCodigoPaylink, prmTransf.Estado))
                        {
                            LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.ENVIO_TRANSFERENCIAS, strHashcode,
                                "BL_General.Actualizar_Transferencia",
                                "No se pudo actualizar la operacion paylink [" + strCodigoPaylink +
                                "] a estado tbe [" + prmTransf.Estado + "] basado en la operacion " + 
                                prmTransf.TRANSACT + "-" + prmTransf.SEC, false);
                        }
                        else
                        {
                            LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.ENVIO_TRANSFERENCIAS, strHashcode,
                                "BL_General.Actualizar_Transferencia",
                                "Se actualizo la operacion paylink " + strCodigoPaylink, false);
                        }
                    }
                }
            }

            LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.ENVIO_TRANSFERENCIAS, strHashcode,
                "BL_General.Actualizar_Transferencia",
                "Se actualizo la informacion de la transferencia.", false);

            return true;
        }

        public bool Actualizar_CompraVenta(BE_CompraVentaSalidas prmBE_CompraVentaSalidas)
        {
            DA_CompraVenta_Salidas daSalidasCompraVenta = new DA_CompraVenta_Salidas(strHashcode);

            if (String.IsNullOrEmpty(Globales.CADENA_CONEXION))
            {
                return false;
            }

            switch (prmBE_CompraVentaSalidas.ESTADO_LBTR)
            {
                case EstadosCompraVenta.PENDIENTE_EN_ESPERA:
                    prmBE_CompraVentaSalidas.FECHA_ENVIO_ESPERA = DateTime.Now;
                    break;
                case EstadosCompraVenta.PROCESADO:
                    prmBE_CompraVentaSalidas.FECHA_PROCESO_ENVIADO = DateTime.Now;
                    break;
                case EstadosCompraVenta.ANULADO:
                    prmBE_CompraVentaSalidas.FECHA_ENVIADO_ANULADO= DateTime.Now;
                    break;
                case EstadosCompraVenta.ERROR_TRX:
                    prmBE_CompraVentaSalidas.FECHA_ENVIADO_ERROR = DateTime.Now;
                    break;
                default:
                    break;
            }

            switch (prmBE_CompraVentaSalidas.ESTADO_ENVIO)
            {
                case EstadosCompraVenta.REGISTRADO:
                    prmBE_CompraVentaSalidas.FECHA_CARGADO = DateTime.Now;
                    break;
                case EstadosCompraVenta.ENVIADO:
                    prmBE_CompraVentaSalidas.FECHA_REGISTRADO_BCRP = DateTime.Now;
                    break;
                default:
                    break;
            }

        if (daSalidasCompraVenta.Actualizar_CompraVentaSalidas(prmBE_CompraVentaSalidas) == false)
           {
            LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SALIDAS_COMPRAVENTA, strHashcode,
                    "BL_General.Actualizar_CompraVentaSalidas",
                    "No se pudo actualizar la informacion de la Operacion de Compra Venta [" + prmBE_CompraVentaSalidas.ID_LBTR_SALIDAS +
                    "] al ESTADO_LBTR [" + prmBE_CompraVentaSalidas.ESTADO_LBTR + "]", false);

                (new BL_General(strHashcode)).InsertarLogError(prmBE_CompraVentaSalidas.ID_LBTR_SALIDAS.ToString(),
                    "Error al actualizar la informacion de la operacion ID [" + prmBE_CompraVentaSalidas.ID_LBTR_SALIDAS +
                    "] y con NumRefOrigen [" + prmBE_CompraVentaSalidas .NUM_REF_ORIGEN + "] al ESTADO_LBTR [" + prmBE_CompraVentaSalidas.ESTADO_LBTR + "]", false);

                return false;
            }

            LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.SALIDAS_COMPRAVENTA, strHashcode,
                "BL_General.Actualizar_CompraVentaSalidas",
                "Se actualizo la informacion de la Operacion de Compra Venta.", false);

         return true;
        }

        public void ActualizarParam(string prmCodigo, string prmValor)
        {
            LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.SERVICIO_WINDOWS, strHashcode,
                "BL_General.ActualizarParametros",
                "Se procede a actualizar el parametro. Codigo: " + prmCodigo + "; Valor: " + prmValor, false);

            errorEnDAO = false;
            DA_General oDAGeneral = new DA_General(strHashcode);
            oDAGeneral.Actualizar_Param(prmCodigo, prmValor);

            if (oDAGeneral.Excepcion != null)
            {
                errorEnDAO = true;
            }
        }

        public static Dictionary<string, string> ObtenerListaConfigBCosmos()
        {
            Dictionary<string, string> dicConfig = new Dictionary<string, string>();
            DA_General oDAGeneral = new DA_General(Globales.HASHCODE_thrInicioFinDiaBCosmos);

            string strValor = null;

            strValor = oDAGeneral.Obtener_Config(Constantes.PARAM_CODIGO_AGRUPACION, Constantes.PARAM_CODIGO_BCOSMOS_HORAINI);

            if (!String.IsNullOrEmpty(strValor))
            {
                dicConfig.Add(Constantes.PARAM_CODIGO_BCOSMOS_HORAINI, strValor);
            }

            strValor = oDAGeneral.Obtener_Config(Constantes.PARAM_CODIGO_AGRUPACION, Constantes.PARAM_CODIGO_BCOSMOS_HORAFIN1);

            if (!String.IsNullOrEmpty(strValor))
            {
                dicConfig.Add(Constantes.PARAM_CODIGO_BCOSMOS_HORAFIN1, strValor);
            }

            strValor = oDAGeneral.Obtener_Config(Constantes.PARAM_CODIGO_AGRUPACION, Constantes.PARAM_CODIGO_BCOSMOS_HORAFIN2);

            if (!String.IsNullOrEmpty(strValor))
            {
                dicConfig.Add(Constantes.PARAM_CODIGO_BCOSMOS_HORAFIN2, strValor);
            }

            return dicConfig;
        }
    }
}
