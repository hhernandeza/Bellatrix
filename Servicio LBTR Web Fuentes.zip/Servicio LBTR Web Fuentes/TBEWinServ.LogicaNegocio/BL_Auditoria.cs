using System;
using System.Collections.Generic;
using System.Configuration;
using System.Text;
using System.Xml;
using System.IO;
using System.Threading;
using TBEWinServ.AccesoDatos;
using TBEWinServ.EntidadesNegocio.Transferencia;
using TBEWinServ.EntidadesNegocio.OperacionesRecibidas;
using TBEWinServ.EntidadesNegocio.ConsultasBCRP;
using TBEWinServ.EntidadesNegocio.Generales;
using TBEWinServ.EntidadesNegocio.Auditoria;
using TBEWinServ.Utilitarios;

namespace TBEWinServ.LogicaNegocio
{
    public class BL_Auditoria
    {
        private string strHashcode = null;

        public BL_Auditoria(string prmHashcode) 
        {
            strHashcode = prmHashcode;
        }

        /// <summary>
        /// Retorna el codigo del registro de auditoria insertado para luego asociar la transferencia
        /// </summary>
        /// <param name="prmTipoOperacionBCRP">Utilizar TipoOperacionBCRP</param>
        /// <param name="prmTrama">Trama en crudo</param>
        /// <param name="prmTramaEnClaro">Trama en claro, solo para transferencia</param>
        /// <param name="prmKPriCiti">Indice de la llave privada del Citibank</param>
        /// <param name="prmKPubBanco">Indice de la llave publica del otro banco</param>
        /// <param name="prmKPubBCRP">Indice de la llave publica del BCRP</param>
        /// <returns>El codigo de auditoria insertado en la tabla</returns>
        public string RegistrarAuditoria(string prmTipoOperacionBCRP, string prmTrama, string prmTramaEnClaro,
                                        string prmCodBancoOri, string prmCodBancoDest,
                                        int? prmKPriCiti, int? prmKPubBanco, int? prmKPubBCRP, string prmFirma)
        {
            string strCodTramaAuditoria = null;
            DA_Auditoria oDAAudit = new DA_Auditoria(strHashcode);
            BE_Auditoria oBEAudit = new BE_Auditoria();

            oBEAudit.CodTramaAuditoria = Utilitario.GenerarCodigo(20);
            oBEAudit.FecOperacion = DateTime.Now;
            oBEAudit.TipoOperacion = prmTipoOperacionBCRP;
            oBEAudit.Trama = prmTrama;
            oBEAudit.TramaEnClaro = prmTramaEnClaro;
            oBEAudit.CodBancoOri = prmCodBancoOri;
            oBEAudit.CodBancoDest = prmCodBancoDest;
            oBEAudit.IndiceKPriCiti = prmKPriCiti;
            oBEAudit.IndiceKPubBanco = prmKPubBanco;
            oBEAudit.IndiceKPubBCRP = prmKPubBCRP;
            oBEAudit.Firma = prmFirma;

            if (oDAAudit.Registrar_Auditoria(oBEAudit))
            {
                LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.REGISTRO_AUDITORIA, strHashcode,
                    "BL_Auditoria.RegistrarAuditoria",
                    "Se registro la trama de auditoria asociado a la transferencia.", false);

                strCodTramaAuditoria = oBEAudit.CodTramaAuditoria;
            }
            else
            {
                Thread.Sleep(1000);

                strCodTramaAuditoria = null;

                oBEAudit.CodTramaAuditoria = Utilitario.GenerarCodigo(20);

                if (oDAAudit.Registrar_Auditoria(oBEAudit))
                {
                    LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.REGISTRO_AUDITORIA, strHashcode,
                        "BL_Auditoria.RegistrarAuditoria",
                        "Se registro la trama de auditoria asociado a la transferencia (en 2do intento).", false);

                    strCodTramaAuditoria = oBEAudit.CodTramaAuditoria;
                }
                else
                {
                    LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.REGISTRO_AUDITORIA, strHashcode,
                        "BL_Auditoria.RegistrarAuditoria",
                        "No se pudo registrar la trama de auditoria para el tipo de operacion (" + prmTipoOperacionBCRP + ")", 
                        false);
                }

            }

            return strCodTramaAuditoria;
        }

        public int ConsultarAuditoria(string prmIdConsulta, string prmTipoOperacion, string prmEstados,
                                        string prmFechaIni, string prmFechaFin, string prmCodBanco,
                                        string prmCodConcepto, bool blnUsarLlavesActuales)
        {
            LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.CONSULTA_AUDITORIA, strHashcode,
                "BL_Auditoria.ConsultarAuditoria",
                "Inicia el proceso de ConsultarAuditoria.", false);

            int nRetorno = 0;
            string strMsjError = null;

            if (BL_ConectividadBD.ProbarConexionSybase(Globales.CADENA_CONEXION))
            {
                BE_Auditoria oParamAudit = new BE_Auditoria();
                oParamAudit.TipoOperacion = prmTipoOperacion;

                if (prmTipoOperacion == TipoOperacion.AvisoAfectacionOpeRec)
                    oParamAudit.CodBancoOri = prmCodBanco;
                else if (prmTipoOperacion == TipoOperacion.Transferencias)
                    oParamAudit.CodBancoDest = prmCodBanco;

                try
                {
                    oParamAudit.FecOperacionIni = new DateTime(int.Parse(prmFechaIni.Substring(0, 4)),
                                                                int.Parse(prmFechaIni.Substring(4, 2)),
                                                                int.Parse(prmFechaIni.Substring(6, 2)));
                    oParamAudit.FecOperacionFin = new DateTime(int.Parse(prmFechaFin.Substring(0, 4)),
                                                                int.Parse(prmFechaFin.Substring(4, 2)),
                                                                int.Parse(prmFechaFin.Substring(6, 2)),
                                                                23, 59, 59
                                                                );
                }
                catch
                {
                    strMsjError = "El formato de fecha es incorrecto.";
                }

                if (String.IsNullOrEmpty(strMsjError))
                {

                    List<BE_Auditoria> lstAuditoria = (new DA_Auditoria(strHashcode)).Consultar_Auditoria(oParamAudit);

                    if (lstAuditoria != null)
                    {
                        DA_ConsultasBCRP oDAConsultas = new DA_ConsultasBCRP(strHashcode);

                        foreach (BE_Auditoria oAuditoria in lstAuditoria)
                        {
                            string strMensajeErrorRegistro = "";
                            BE_Transferencia oTransferencia = null;
                            BE_OperacionRecibidaConsulta oOpeRecCons = null;
                            string strTmpError = "";

                            if (prmTipoOperacion == TipoOperacion.AvisoAfectacionOpeRec)
                            {                                
                                oOpeRecCons = this.ObtenerOpeRecibidaConsulta(prmIdConsulta, oAuditoria,
                                                                                out strTmpError, blnUsarLlavesActuales);
                                if (!String.IsNullOrEmpty(strTmpError))
                                {
                                    strMensajeErrorRegistro = strTmpError;
                                }

                                if (oOpeRecCons != null)
                                {
                                    if ((prmCodConcepto.Equals("") || oOpeRecCons.CodConcepto.Equals(prmCodConcepto)) &&
                                        prmEstados.Contains("," + oOpeRecCons.Estado + ","))
                                    {
                                        oOpeRecCons.IdConsulta = prmIdConsulta;
                                        oOpeRecCons.FecConsulta = DateTime.Today.ToString("yyyyMMdd");
                                        oOpeRecCons.CodTramaAuditoria = oAuditoria.CodTramaAuditoria;
                                        oOpeRecCons.TipoConsulta = prmTipoOperacion;
                                        if (!oDAConsultas.Insertar_ConsultaOperacion(oOpeRecCons))
                                        {
                                            if (!String.IsNullOrEmpty(strMensajeErrorRegistro)) strMensajeErrorRegistro += "\r\n";
                                            strMensajeErrorRegistro += "error al insertar en la tabla final de consulta.";
                                        }
                                    }
                                }
                            }
                            else if (prmTipoOperacion == TipoOperacion.Transferencias)
                            {
                                oTransferencia = this.ObtenerTransferenciaConsulta(prmIdConsulta, oAuditoria, out strTmpError);
                                if (!String.IsNullOrEmpty(strTmpError))
                                {
                                    strMensajeErrorRegistro += strTmpError;
                                }

                                if (oTransferencia != null)
                                {
                                    if (prmCodConcepto.Equals("") || oTransferencia.CodConcepto.Equals(prmCodConcepto))
                                    {
                                        oTransferencia.IdConsulta = prmIdConsulta;
                                        oTransferencia.FecConsulta = DateTime.Today.ToString("yyyyMMdd");
                                        oTransferencia.CodTramaAuditoria = oAuditoria.CodTramaAuditoria;
                                        if (!oDAConsultas.Insertar_ConsultaTransferencia(oTransferencia))
                                        {
                                            if (!String.IsNullOrEmpty(strMensajeErrorRegistro)) strMensajeErrorRegistro += "\r\n";
                                            strMensajeErrorRegistro += "error al insertar en la tabla final de consulta.";
                                        }
                                    }
                                }
                            }

                            if (!String.IsNullOrEmpty(strMensajeErrorRegistro))
                            {
                                strMensajeErrorRegistro = "\r\nError para la trama " + oAuditoria.CodTramaAuditoria + "\r\n[" + strMensajeErrorRegistro + "]";
                            }

                            strMsjError += strMensajeErrorRegistro;
                        }

                        nRetorno = 1;
                    }
                    else
                    {
                        strMsjError = "Error al obtener datos de la base de datos para consulta auditoria. Revisar el log.";
                    }
                }
            }
            else
            {
                strMsjError = "No hay conectividad con la base de datos.";
            }

            if (!String.IsNullOrEmpty(strMsjError))
            {
                (new BL_General(strHashcode)).InsertarLogError(prmIdConsulta, strMsjError, true);

                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.CONSULTA_AUDITORIA, strHashcode,
                    "BL_Auditoria.ConsultarAuditoria",
                    strMsjError, true);
            }

            LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.CONSULTA_AUDITORIA, strHashcode,
                "BL_Auditoria.ConsultarAuditoria",
                "Finaliza el proceso de ConsultarAuditoria.", false);

            return nRetorno;
        }

        public void ActualizarAuditoria(String prmCodTramaAuditoria, String prmTrama)
        {
            DA_Auditoria oDAAuditoria = new DA_Auditoria(strHashcode);
            BE_Auditoria oAuditoria = new BE_Auditoria(prmCodTramaAuditoria);

            oAuditoria.Trama = prmTrama;

            if (oDAAuditoria.Actualizar_Auditoria(oAuditoria))
            {
                LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.TRAZA,
                    strHashcode,
                    "BL_Auditoria.ActualizarAuditoria", "Se actualizo la trama de auditoria.", false);
            }
            else
            {
                LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.TRAZA,
                    strHashcode,
                    "BL_Auditoria.ActualizarAuditoria", "No se actualizo la trama de auditoria.", false);
            }
        }

        private BE_OperacionRecibidaConsulta ObtenerOpeRecibidaConsulta(string prmIdConsulta, 
                                                                        BE_Auditoria prmAuditoria,
                                                                        out string prmMensajeError,
                                                                        bool blnUsarLlavesActuales)
        {
            BL_General oBLGen = new BL_General(strHashcode);
            BE_OperacionRecibidaConsulta oBEOpeRec = new BE_OperacionRecibidaConsulta();
            XmlReader reader = null;
            string strEstadoBCRP = null;
            string strDatosCliente = null;
            string strDataCliente = null;
            prmMensajeError = "";

            #region Lectura XML

            try
            {
                if (String.IsNullOrEmpty(prmAuditoria.Trama)) throw new Exception("El campo trama es vacio.");

                reader = XmlReader.Create(new StringReader(prmAuditoria.Trama));

                reader.MoveToContent();

                while (!reader.EOF)
                {
                    if (reader.NodeType == XmlNodeType.Element)
                    {
                        if (reader.Name.ToLower() == "codbancodestino")
                            oBEOpeRec.CodBancoDestino = reader.ReadString();
                        else if (reader.Name.ToLower() == "codbancoorigen")
                            oBEOpeRec.CodBancoOrigen = reader.ReadString();
                        else if (reader.Name.ToLower() == "codconcepto")
                            oBEOpeRec.CodConcepto = reader.ReadString();
                        else if (reader.Name.ToLower() == "codmoneda")
                            oBEOpeRec.CodMoneda = reader.ReadString();
                        else if (reader.Name.ToLower() == "codservicio")
                            oBEOpeRec.CodServicio = reader.ReadString();
                        else if (reader.Name.ToLower() == "cuentadestino")
                            oBEOpeRec.CuentaDestino = reader.ReadString();
                        else if (reader.Name.ToLower() == "cuentaorigen")
                            oBEOpeRec.CuentaOrigen = reader.ReadString();
                        else if (reader.Name.ToLower() == "datoscliente")
                        {
                            strDatosCliente = reader.ReadInnerXml();
                            if (!String.IsNullOrEmpty(strDatosCliente))
                            { 
                                //verificamos si contiene CDATA para removerlo
                                if (strDatosCliente.Contains("<![CDATA["))
                                {
                                    strDatosCliente = strDatosCliente.Replace("<![CDATA[", "");
                                    strDatosCliente = strDatosCliente.Replace("]]>", "");
                                }
                            }
                        }
                        else if (reader.Name.ToLower() == "estado")
                            strEstadoBCRP = reader.ReadString();
                        else if (reader.Name.ToLower() == "fechaliquidacion")
                        {
                            //esta guardado con en este formato: 2010-08-03T00:00:00-05:00
                            oBEOpeRec.FechaLiquidacion = reader.ReadString();
                            if (!String.IsNullOrEmpty(oBEOpeRec.FechaLiquidacion))
                            {
                                try
                                {
                                    oBEOpeRec.FechaLiquidacion = oBEOpeRec.FechaLiquidacion.Substring(0, 10);
                                    oBEOpeRec.FechaLiquidacion = oBEOpeRec.FechaLiquidacion.Replace("-", "");
                                }
                                catch { }
                            }
                        }
                        else if (reader.Name.ToLower() == "horaliquidacion")
                        {
                            //esta guardado de esta forma: 2010-08-03T16:29:39.031-05:00
                            oBEOpeRec.HoraLiquidacion = reader.ReadString();

                            if (!String.IsNullOrEmpty(oBEOpeRec.HoraLiquidacion))
                            {
                                try
                                {
                                    oBEOpeRec.HoraLiquidacion = oBEOpeRec.HoraLiquidacion.Substring(11, 8);
                                    oBEOpeRec.HoraLiquidacion = oBEOpeRec.HoraLiquidacion.Replace(":", "");
                                }
                                catch { }
                            }
                        }
                        else if (reader.Name.ToLower() == "instruccionespago")
                            oBEOpeRec.InstruccionesPago = reader.ReadString();
                        else if (reader.Name.ToLower() == "modalidad")
                            oBEOpeRec.Modalidad = reader.ReadString();
                        else if (reader.Name.ToLower() == "montodestino")
                            oBEOpeRec.MontoOperacionDestino = reader.ReadString();
                        else if (reader.Name.ToLower() == "montoorigen")
                            oBEOpeRec.MontoOperacion = reader.ReadString();
                        else if (reader.Name.ToLower() == "numreflbtr")
                            oBEOpeRec.NumRefLBTR = reader.ReadString();
                        else if (reader.Name.ToLower() == "numreflbtrenlace")
                            oBEOpeRec.NumRefEnlace = reader.ReadString();
                        else if (reader.Name.ToLower() == "numreforigen")
                            oBEOpeRec.NumRefOrigen = reader.ReadString();
                        else if (reader.Name.ToLower() == "tipocambio")
                            oBEOpeRec.TipoCambio = reader.ReadString();
                        else if (reader.Name.ToLower() == "tiporegistro")
                            oBEOpeRec.TipoRegistro = reader.ReadString();
                        else
                            reader.Read();
                    }
                    else
                        reader.Read();
                }

                reader.Close();
            }
            catch (Exception ex)
            {
                oBEOpeRec = null;

                prmMensajeError = "No se pudo cargar la trama con codigo " + prmAuditoria.CodTramaAuditoria + ". Revisar el formato XML. " + ex.Message + ". " + ex.StackTrace;
            }

            #endregion

            string strMensajeErrorValidDataCliente = "";

            try
            {
                if (oBEOpeRec != null)
                {
                    oBEOpeRec.Estado = (new BL_General(strHashcode)).Obtener_Estado_Equivalente(strEstadoBCRP, TipoEstado.Liquidacion);

                    if (!String.IsNullOrEmpty(strDatosCliente))
                    {
                        bool blnErrorBD = false;
                        bool esFirmaClienteValida = (new BL_SeguridadMsj(strHashcode)).ValidarFirmaDataCliente("", blnUsarLlavesActuales,
                                                                            prmAuditoria.TipoOperacion,
                                                                            strDatosCliente,
                                                                            prmAuditoria.CodBancoOri,
                                                                            out strDataCliente,
                                                                            prmAuditoria.FecOperacion,
                                                                            prmAuditoria.IndiceKPubBanco,
                                                                            prmAuditoria.IndiceKPriCiti,
                                                                            out strMensajeErrorValidDataCliente,
                                                                            out blnErrorBD);

                        if (!blnErrorBD)
                        {
                            if (!String.IsNullOrEmpty(strDataCliente))
                            {
                                oBEOpeRec.DatosCliente = BE_DatosCliente.ObtenerDataClienteDesdeXML(strDataCliente);
                            }
                        }
                        else
                        {
                            strMensajeErrorValidDataCliente += "\r\nSe produjo un problema de base de datos al realizar la validacion/descifrado de datos cliente de la operacion.";
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                oBEOpeRec = null;

                prmMensajeError = strMensajeErrorValidDataCliente + "\r\n\r\nError, " + ex.Message + ". " + ex.StackTrace;
            }

            return oBEOpeRec;
        }

        private BE_Transferencia ObtenerTransferenciaConsulta(string prmIdConsulta, 
                                                                BE_Auditoria prmAuditoria,
                                                                out string prmMensajeError)
        {
            BL_General oBLGen = new BL_General(strHashcode);
            BE_Transferencia oBETransf = new BE_Transferencia();
            XmlReader reader = null;
            string strDatosCliente = null;
            string strFechaLiquidacion = null;
            string strFechaRefLBTREnlace = null;
            string strMonto = null;
            string strPrioridad = null;
            prmMensajeError = "";

            #region Lectura XML

            try
            {
                if (String.IsNullOrEmpty(prmAuditoria.TramaEnClaro)) throw new Exception("El campo trama en claro de este registro es vacio.");

                reader = XmlReader.Create(new StringReader(prmAuditoria.TramaEnClaro));

                reader.MoveToContent();

                while (!reader.EOF)
                {
                    if (reader.NodeType == XmlNodeType.Element)
                    {
                        if (reader.Name.ToLower() == "codconcepto")
                            oBETransf.CodConcepto = reader.ReadString();
                        else if (reader.Name.ToLower() == "cuentadestino")
                            oBETransf.CuentaDestino = reader.ReadString();
                        else if (reader.Name.ToLower() == "cuentaorigen")
                            oBETransf.CuentaOrigen = reader.ReadString();
                        else if (reader.Name.ToLower() == "datoscliente")
                            strDatosCliente = reader.ReadInnerXml();
                        else if (reader.Name.ToLower() == "fechaliquidacion")
                            strFechaLiquidacion = reader.ReadString();
                        else if (reader.Name.ToLower() == "fechareflbtrenlace")
                            strFechaRefLBTREnlace = reader.ReadString();
                        else if (reader.Name.ToLower() == "instruccionespago")
                            oBETransf.InstruccionesPago = reader.ReadString();
                        else if (reader.Name.ToLower() == "modalidad")
                            oBETransf.Modalidad = reader.ReadString();
                        else if (reader.Name.ToLower() == "montooperacion")
                            strMonto = reader.ReadString();
                        else if (reader.Name.ToLower() == "numreflbtrenlace")
                            oBETransf.NumRefLBTREnlace = reader.ReadString();
                        else if (reader.Name.ToLower() == "numreforigen")
                            oBETransf.NumRefOrigen = reader.ReadString();
                        else if (reader.Name.ToLower() == "prioridad")
                            strPrioridad = reader.ReadString();
                        else
                            reader.Read();
                    }
                    else
                        reader.Read();
                }

                reader.Close();
            }
            catch (Exception ex)
            {
                oBETransf = null;

                prmMensajeError = "No se pudo cargar la trama con codigo " + prmAuditoria.CodTramaAuditoria + ". Revisar el formato XML. " + ex.Message + ". " + ex.StackTrace;
            }

            #endregion

            try
            {
                if (oBETransf != null)
                {
                    if (!String.IsNullOrEmpty(strFechaLiquidacion))
                    {
                        DateTime dtFecLiq = new DateTime(int.Parse(strFechaLiquidacion.Substring(0, 4)),
                                                                    int.Parse(strFechaLiquidacion.Substring(4, 2)),
                                                                    int.Parse(strFechaLiquidacion.Substring(6, 2)));
                        oBETransf.FechaLiquidacion = dtFecLiq;
                    }

                    if (!String.IsNullOrEmpty(strFechaRefLBTREnlace))
                    {
                        DateTime dtFecRef = new DateTime(int.Parse(strFechaRefLBTREnlace.Substring(0, 4)),
                                                                    int.Parse(strFechaRefLBTREnlace.Substring(4, 2)),
                                                                    int.Parse(strFechaRefLBTREnlace.Substring(6, 2)));
                        oBETransf.FecRefLBTREnlace = dtFecRef;
                    }

                    if (!String.IsNullOrEmpty(strMonto))
                    {
                        decimal decMonto = decimal.Parse(strMonto);
                        oBETransf.Monto = decMonto;
                    }

                    if (!String.IsNullOrEmpty(strPrioridad))
                    {
                        int nPrioridad = int.Parse(strPrioridad);
                        oBETransf.Prioridad = nPrioridad;
                    }

                    if (!String.IsNullOrEmpty(strDatosCliente))
                    {
                        BE_ContenidoDatosCliente oDatosCliente = null;

                        oDatosCliente = BE_DatosCliente.ObtenerContenidoDatosCliente(strDatosCliente);

                        oBETransf.DatosCliente = BE_DatosCliente.ObtenerDataClienteDesdeXML(oDatosCliente.DataClienteCifrada);
                    }
                    else
                    {
                        oBETransf.DatosCliente = new BE_DatosCliente();//vacio
                    }

                }
            }
            catch (Exception ex)
            {
                oBETransf = null;

                prmMensajeError = "Error, " + ex.Message + ". " + ex.StackTrace;
            }

            return oBETransf;
        }

    }
}
