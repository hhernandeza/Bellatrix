using System;
using System.Collections.Generic;
using System.Text;
using TBEWinServ.AccesoDatos;

namespace TBEWinServ.LogicaNegocio
{
    public class BL_ConectividadBD
    {        
        public static bool ProbarConexionSybase(string prmCadenaConexion) {
            if (String.IsNullOrEmpty(prmCadenaConexion)) return false;
            return DA_PruebaConectividad.ProbarConexionSybase(prmCadenaConexion);
        }

        public static bool ProbarConexionMSSQL(string prmCadenaConexion)
        {
            if (String.IsNullOrEmpty(prmCadenaConexion)) return false;
            return DA_PruebaConectividad.ProbarConexionMSSQL(prmCadenaConexion);
        }
    }
}
