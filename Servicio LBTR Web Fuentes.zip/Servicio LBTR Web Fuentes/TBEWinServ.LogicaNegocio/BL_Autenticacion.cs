using System;
using System.Collections.Generic;
using System.Text;
using TBEWinServ.Utilitarios;
using TBEWinServ.Componentes;

namespace TBEWinServ.LogicaNegocio
{
    public class BL_Autenticacion
    {
        private string strKsimCifrado = "";
        private string strPwdCifrado = "";
        private string strHashcode = "";

        public BL_Autenticacion(string prmHashcode) 
        {
            strHashcode = prmHashcode;
        }

        public string Logon() 
        {
            string strCodigoBancoCiti = (new BL_General(strHashcode)).ObtenerValorConfiguracion(Constantes.PARAM_CODIGO_CITIBANK);

            if (String.IsNullOrEmpty(strCodigoBancoCiti))
            {
                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS, strHashcode,
                    "BL_Autenticacion.Logon", "El parametro codigo de banco Citi no fue establecido.", true);
                return null;
            }
            else
            {
                if (Globales.MOSTRAR_SID_LOG_TRAZA)
                {
                    LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS, strHashcode,
                        "BL_Autenticacion.Logon", "Los parametros usados son: Codigo: [" + strCodigoBancoCiti + "], Password: [" + Globales.LBTR_PASSWORD + "]", false);
                }
            }

            string strFirma = (new BL_SeguridadMsj(strHashcode)).GenerarFirma(strCodigoBancoCiti, Globales.LBTR_PASSWORD, out strPwdCifrado, out strKsimCifrado);

            if (!String.IsNullOrEmpty(strFirma))
            {
                Globales.SID = null;
                return (new WS_LBTRAutenticacionService(strHashcode)).Logon(strCodigoBancoCiti, strPwdCifrado, strKsimCifrado, strFirma);
            }
            else
            {
                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS, strHashcode,
                    "BL_Autenticacion.Logon", "No se pudo realizar Logon debido a que la firma generada es NULL.", true);
                return null;
            }
        }

        public bool Logoff()
        {
            string strCodigoBancoCiti = (new BL_General(strHashcode)).ObtenerValorConfiguracion(Constantes.PARAM_CODIGO_CITIBANK);

            if (String.IsNullOrEmpty(strCodigoBancoCiti))
            {
                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS, strHashcode,
                    "BL_Autenticacion.Logoff", "El parametro codigo de banco Citi no fue establecido.", true);
                return false;
            }
            else
            {
                if (Globales.MOSTRAR_SID_LOG_TRAZA)
                {
                    LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS, strHashcode,
                        "BL_Autenticacion.Logoff", "Los parametros usados son: Codigo: [" + strCodigoBancoCiti + "], Password: [" + Globales.LBTR_PASSWORD + "]", false);
                }
            }

            string strFirma = (new BL_SeguridadMsj(strHashcode)).GenerarFirma(strCodigoBancoCiti, Globales.LBTR_PASSWORD, out strPwdCifrado, out strKsimCifrado);

            if (!String.IsNullOrEmpty(strFirma))
                return (new WS_LBTRAutenticacionService(strHashcode)).Logoff(strCodigoBancoCiti, strPwdCifrado, strKsimCifrado, strFirma);
            else
            {
                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS, strHashcode,
                    "BL_Autenticacion.Logoff", "No se pudo realizar Logoff debido a que la firma generada es NULL.", true);
                return false;
            }
        }
                
    }
}
