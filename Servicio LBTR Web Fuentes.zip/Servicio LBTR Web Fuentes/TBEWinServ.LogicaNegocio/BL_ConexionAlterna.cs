using System;
using System.Collections.Generic;
using System.Text;
using System.Configuration;
using System.IO;
using TBEWinServ.Utilitarios;
using TBEWinServ.ObjetosGlobales;
using TBEWinServ.EntidadesNegocio.Generales;
using TBEWinServ.AccesoDatos;
using System.Xml;

namespace TBEWinServ.LogicaNegocio
{
    public class BL_ConexionAlterna
    {
        private string strHashcode = "";

        public BL_ConexionAlterna(string prmHashcode) 
        {
            strHashcode = prmHashcode;
        }
                
        public bool GuardarPwdLogonBCRP(string prmPassword)
        {
            LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS, strHashcode,
                "BL_ConexionAlterna.GuardarPwdLogonBCRP",
                "[CONTINGENCIA] Se invoco a la funcion para establecer el password para inicio del dia en sistema LBTR del BCRP.", false);

            try
            {
                if (String.IsNullOrEmpty(Globales.CADENA_CONEXION))
                {
                    LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS, strHashcode,
                        "BL_ConexionAlterna.GuardarPwdLogonBCRP",
                        "[CONTINGENCIA] La cadena de conexion no esta establecida, no se puede guardar el password de logon en la base de datos.", true);
                    return false;
                }

                BL_SeguridadMsj oBlSeg = new BL_SeguridadMsj(strHashcode);
                Globales.THRINICIODIA_BLNAPIINVOCADO = true;
                Globales.THRINICIODIA_DTULTINVOCAPI = DateTime.Now;
                bool blnApiCorrecto = oBlSeg.VerificarConexionActual();
                Globales.THRINICIODIA_BLNAPIINVOCADO = false;

                if (blnApiCorrecto)
                {
                    int nCodigoRetorno = -1;
                    List<BE_Banco> lstBancos = null;
                    BE_Banco oBancoCiti = null;
                    BL_General oBLGen = new BL_General(strHashcode);
                    string strCodigoBancoCiti = oBLGen.ObtenerValorConfiguracion(Constantes.PARAM_CODIGO_CITIBANK);
                    string strPasswordCifrado = string.Empty;
                    string strKSimCifrado = string.Empty;
                                        
                    if (String.IsNullOrEmpty(strCodigoBancoCiti))
                    {
                        LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS, strHashcode,
                            "BL_ConexionAlterna.GuardarPwdLogonBCRP",
                            "[CONTINGENCIA] No se pudo obtener el parametro codigo de banco Citibank", true);
                        return false;
                    }

                    lstBancos = oBLGen.ObtenerBancos(new BE_Banco(strCodigoBancoCiti));

                    if (!oBLGen.errorEnDAO)
                    {
                        if (lstBancos.Count > 0)
                        {
                            oBancoCiti = lstBancos[0];
                        }
                        else
                        {
                            LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS, strHashcode,
                                "BL_ConexionAlterna.GuardarPwdLogonBCRP",
                                "[CONTINGENCIA] No se encontro el banco Citibank en la base de datos.", true);
                            return false;
                        }
                    }
                    else
                    {
                        LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS, strHashcode,
                            "BL_ConexionAlterna.GuardarPwdLogonBCRP",
                            "[CONTINGENCIA] Error al intentar obtener el banco Citibank de la base de datos.", false);
                        return false;
                    }

                    if (!oBancoCiti.IndiceKPub.HasValue)
                    {
                        LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS, strHashcode,
                            "BL_ConexionAlterna.GuardarPwdLogonBCRP",
                            "[CONTINGENCIA] El banco Citibank no tiene establecido el indice de clave publica.", true);
                        return false;
                    }

                    Globales.THRINICIODIA_BLNAPIINVOCADO = true;
                    Globales.THRINICIODIA_DTULTINVOCAPI = DateTime.Now;
                    nCodigoRetorno = ObjetosGlobalesApp.objAPISEG.fCifrarMensaje_3DES_RSA(prmPassword,
                                                                                                strCodigoBancoCiti,
                                                                                                oBancoCiti.IndiceKPub.Value,
                                                                                                ref strPasswordCifrado,
                                                                                                ref strKSimCifrado);
                    //hh72295:20161104:I: ADECUACION PARA RECUPERAR PASSWORD DESDE DB STBSEGDB Y DESENCRIPTAR CON HSM 
                    LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.SEGURIDAD,
                        strHashcode,
                        "BL_ConexionAlterna.GuardarPwdLogonBCRP",
                        "Se invoca el metodo fCifrarMensaje_3DES_RSA del api, con los siguientes parametros:" + "\r\n" +
                        "Codigo Inst. Destino: " + strCodigoBancoCiti + "\r\n" +
                        "Ind. Clave Publica Destino: " + oBancoCiti.IndiceKPub.Value.ToString() + "\r\n" +
                        "Pwd Cifrado retornado: " + strPasswordCifrado + "\r\n" +
                        "KSim Cifrado retornado: " + strKSimCifrado + "\r\n" +
                        "Tamanho KSim: " + strKSimCifrado.Length.ToString(), false);
                    //hh72295:20161104:F: ADECUACION PARA RECUPERAR PASSWORD DESDE DB STBSEGDB Y DESENCRIPTAR CON HSM 
                    Globales.THRINICIODIA_BLNAPIINVOCADO = false;

                    if (nCodigoRetorno == 0)
                    {
                        LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS, strHashcode,
                            "BL_ConexionAlterna.GuardarPwdLogonBCRP", 
                            "[CONTINGENCIA] Se pudo cifrar el password. Se procedera a grabarlo en la bd.", false);

                        string strXML = "<?xml version=\"1.0\" encoding=\"ISO-8859-1\"?><datos><pwd>{0}</pwd><ksim>{1}</ksim></datos>";
                        strXML = string.Format(strXML, strPasswordCifrado, strKSimCifrado);

                        BE_LBTR_PARAM oParam = new BE_LBTR_PARAM();
                        oParam.CodParam = Constantes.LBTR_PARAM_PWD_LOGON_BCRP;
                        oParam.Fecha = DateTime.Now.ToString("yyyyMMddHHmmss");
                        oParam.IndiceKPriCiti = oBancoCiti.IndiceKPub.Value;
                        oParam.Valor = strXML;
                        if ((new DA_LBTR_Param(strHashcode)).Actualizar_LBTR_Param(oParam))
                        {
                            LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS, strHashcode,
                                "BL_ConexionAlterna.GuardarPwdLogonBCRP",
                                "[CONTINGENCIA] Se grabo correctamente el password de logon en LBTR en la bd.", false);
                            return true;
                        }
                        else
                        {
                            LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS, strHashcode,
                                "BL_ConexionAlterna.GuardarPwdLogonBCRP",
                                "[CONTINGENCIA] No se pudo grabar correctamente el password de logon en LBTR en la bd.", false);
                            return false;
                        }
                        
                    }
                    else
                    {
                        string strMensajeError = oBlSeg.ManejarErrorApiSeguridad("fCifrarMensaje_3DES_RSA", nCodigoRetorno);
                        LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS, strHashcode,
                            "BL_ConexionAlterna.GuardarPwdLogonBCRP",
                            "[CONTINGENCIA] Error: " + strMensajeError, true);
                        return false;
                    }

                }
                else
                {
                    LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS, strHashcode,
                        "BL_ConexionAlterna.GuardarPwdLogonBCRP",
                        "[CONTINGENCIA] Problema con la instancia del Api de seguridad.", true);
                    return false;
                }
            }
            catch (Exception ex)
            {
                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS, strHashcode,
                    "BL_ConexionAlterna.GuardarPwdLogonBCRP",
                    "[CONTINGENCIA] Error al establecer el password de logon en LBTR BCRP: " + ex.Message + "\r\n" + ex.StackTrace, true);
                return false; 
            }

        }
                
        public string ObtenerPwdLogonBCRP()
        {
            string strContenido = "";
            BL_SeguridadMsj oBlSeg = new BL_SeguridadMsj(strHashcode);
            int nCodigoRetorno = -1;
            List<BE_Banco> lstBancos = null;
            BE_Banco oBancoCiti = null;
            BL_General oBLGen = new BL_General(strHashcode);
            string strCodigoBancoCiti = null;
            string strPwdCifrado = null;
            string strKsimCifrado = null;
            string strPwdDescifrado = null;

            try
            {
                if (!String.IsNullOrEmpty(Globales.CADENA_CONEXION))
                {
                    strCodigoBancoCiti = oBLGen.ObtenerValorConfiguracion(Constantes.PARAM_CODIGO_CITIBANK);
                    BE_LBTR_PARAM oParam = (new DA_LBTR_Param(strHashcode)).Obtener_LBTR_Param(Constantes.LBTR_PARAM_PWD_LOGON_BCRP);

                    if (oParam != null)
                    {
                        strContenido = oParam.Valor;
                    }

                    if (!String.IsNullOrEmpty(strContenido))
                    {

                        #region Lectura del XML que contiene el pwd y ksim cifrado

                        try
                        {
                            XmlReader reader = null;

                            reader = XmlReader.Create(new StringReader(strContenido));
                            reader.MoveToContent();

                            while (!reader.EOF)
                            {
                                if (reader.NodeType == XmlNodeType.Element)
                                {
                                    if (reader.Name.ToLower() == "pwd")
                                        strPwdCifrado = reader.ReadInnerXml();
                                    else if (reader.Name.ToLower() == "ksim")
                                        strKsimCifrado = reader.ReadInnerXml();
                                    else
                                        reader.Read();
                                }
                                else
                                {
                                    reader.Read();
                                }

                            }

                            reader.Close();
                        }
                        catch (Exception exml)
                        {
                            strPwdCifrado = null;
                            strKsimCifrado = null;
                            LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS, strHashcode,
                               "BL_ConexionAlterna.ObtenerPwdLogonBCRP",
                               "[CONTINGENCIA] El parametro Password para Inicio de Dia en BCRP de la tabla T_LBTR_PARAM no tiene un formato XML correcto: " + exml.Message, true);
                        }

                        #endregion

                        if (!String.IsNullOrEmpty(strPwdCifrado) && !String.IsNullOrEmpty(strKsimCifrado))
                        {
                            Globales.THRINICIODIA_BLNAPIINVOCADO = true;
                            Globales.THRINICIODIA_DTULTINVOCAPI = DateTime.Now;
                            bool blnApiCorrecto = oBlSeg.VerificarConexionActual();
                            Globales.THRINICIODIA_BLNAPIINVOCADO = false;

                            if (blnApiCorrecto)
                            {
                                #region Descifrado de Password

                                if (String.IsNullOrEmpty(strCodigoBancoCiti))
                                {
                                    LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS, strHashcode,
                                        "BL_ConexionAlterna.ObtenerPwdLogonBCRP",
                                        "[CONTINGENCIA] No se pudo obtener el parametro codigo de banco Citibank", true);
                                    return "";
                                }

                                lstBancos = oBLGen.ObtenerBancos(new BE_Banco(strCodigoBancoCiti));

                                if (!oBLGen.errorEnDAO)
                                {
                                    if (lstBancos.Count > 0)
                                    {
                                        oBancoCiti = lstBancos[0];
                                    }
                                    else
                                    {
                                        LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS, strHashcode,
                                            "BL_ConexionAlterna.ObtenerPwdLogonBCRP",
                                            "[CONTINGENCIA] No se encontro el banco Citibank en la base de datos.", true);
                                        return "";
                                    }
                                }
                                else
                                {
                                    LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS, strHashcode,
                                        "BL_ConexionAlterna.ObtenerPwdLogonBCRP",
                                        "[CONTINGENCIA] Error al intentar obtener el banco Citibank de la base de datos.", true);
                                    return "";
                                }

                                if (!oBancoCiti.IndiceKPri.HasValue)
                                {
                                    LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS, strHashcode,
                                        "BL_ConexionAlterna.ObtenerPwdLogonBCRP",
                                        "[CONTINGENCIA] El banco Citibank no tiene establecido el indice de clave privada.", true);
                                    return "";
                                }

                                Globales.THRINICIODIA_BLNAPIINVOCADO = true;
                                Globales.THRINICIODIA_DTULTINVOCAPI = DateTime.Now;
                                nCodigoRetorno = ObjetosGlobalesApp.objAPISEG.fDescifrarMensaje_3DES_RSA(strPwdCifrado,
                                                                                                            strKsimCifrado,
                                                                                                            strCodigoBancoCiti,
                                                                                                            oBancoCiti.IndiceKPri.Value,
                                                                                                            ref strPwdDescifrado);
                                //hh72295:20161104:I: ADECUACION PARA RECUPERAR PASSWORD DESDE DB STBSEGDB Y DESENCRIPTAR CON HSM
                                LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.SEGURIDAD,
                                       strHashcode,
                                       "BL_ConexionAlterna.ObtenerPwdLogonBCRP",
                                       "Se invoca el metodo fDescifrarMensaje_3DES_RSA del api, con los siguientes parametros:" + "\r\n" +
                                       "PwdCifrado logon LBTR: " + strPwdCifrado + "\r\n" +
                                       "KsimCifrado: " + strKsimCifrado + "\r\n" +
                                       "C�digo instituci�n: " + strCodigoBancoCiti + "\r\n" +
                                       "Ind. Clave Privada : " + oBancoCiti.IndiceKPri.Value + "\r\n", false);
                                //hh72295:20161104:F: ADECUACION PARA RECUPERAR PASSWORD DESDE DB STBSEGDB Y DESENCRIPTAR CON HSM
                                Globales.THRINICIODIA_BLNAPIINVOCADO = false;

                                if (nCodigoRetorno == 0)
                                {
                                    LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS, strHashcode,
                                        "BL_ConexionAlterna.ObtenerPwdLogonBCRP",
                                        "[CONTINGENCIA] Se pudo descifrar el password para el logon de inicio del dia en el sistema LBTR.", false);
                                    return strPwdDescifrado;
                                }
                                else
                                {
                                    string strMensajeError = oBlSeg.ManejarErrorApiSeguridad("fDescifrarMensaje_3DES_RSA", nCodigoRetorno);
                                    LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS, strHashcode,
                                        "BL_ConexionAlterna.ObtenerPwdLogonBCRP",
                                        "[CONTINGENCIA] No se pudo descifrar el password de contingencia para Inicio de dia en BCRP con la llave actual, se probara con la llave historica. Error retornado: " + strMensajeError, true);

                                    Globales.THRINICIODIA_BLNAPIINVOCADO = true;
                                    Globales.THRINICIODIA_DTULTINVOCAPI = DateTime.Now;
                                    nCodigoRetorno = ObjetosGlobalesApp.objAPISEG.fDescifrarMensaje_3DES_RSA_TH(strPwdCifrado,
                                                                                                            strKsimCifrado,
                                                                                                            strCodigoBancoCiti,
                                                                                                            oParam.IndiceKPriCiti.Value,
                                                                                                            oParam.Fecha,
                                                                                                            ref strPwdDescifrado);
                                    //hh72295:20161104:I: ADECUACION PARA RECUPERAR PASSWORD DESDE DB STBSEGDB Y DESENCRIPTAR CON HSM
                                    LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.SEGURIDAD,
                                        strHashcode,
                                        "BL_ConexionAlterna.ObtenerPwdLogonBCRP",
                                        "Se invoca el metodo fDescifrarMensaje_3DES_RSA_TH del api, con los siguientes parametros:" + "\r\n" +
                                        "PwdCifrado logon LBTR: " + strPwdCifrado + "\r\n" +
                                        "KsimCifrado: " + strKsimCifrado + "\r\n" +
                                        "C�digo instituci�n: " + strCodigoBancoCiti + "\r\n" +
                                        "Ind. Clave Privada : " + oParam.IndiceKPriCiti.Value + "\r\n" +
                                        "Fecha Ind. Clave Privada : " + oParam.Fecha, false);
                                    //hh72295:20161104:F: ADECUACION PARA RECUPERAR PASSWORD DESDE DB STBSEGDB Y DESENCRIPTAR CON HSM
                                    Globales.THRINICIODIA_BLNAPIINVOCADO = false;

                                    if (nCodigoRetorno == 0)
                                    {
                                        LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS, strHashcode,
                                            "BL_ConexionAlterna.ObtenerPwdLogonBCRP",
                                            "[CONTINGENCIA] Se pudo descifrar el password para el logon de inicio del dia en el sistema LBTR con la llave historica.", false);
                                        return strPwdDescifrado;
                                    }
                                    else
                                    {
                                        strMensajeError = oBlSeg.ManejarErrorApiSeguridad("fDescifrarMensaje_3DES_RSA_TH", nCodigoRetorno);
                                        LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS, strHashcode,
                                            "BL_ConexionAlterna.ObtenerPwdLogonBCRP",
                                            "[CONTINGENCIA] No se pudo descifrar el password de contingencia para Inicio de dia en BCRP con la llave historica. Error retornado: " + strMensajeError, true);
                                    }
                                }

                                #endregion
                            }
                            else
                            {
                                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS, strHashcode,
                                    "BL_ConexionAlterna.ObtenerPwdLogonBCRP",
                                    "[CONTINGENCIA] Problema con la instancia del Api de seguridad.", false);
                            }

                        }
                        else
                        {
                            LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS, strHashcode,
                               "BL_ConexionAlterna.ObtenerPwdLogonBCRP",
                               "[CONTINGENCIA] No se pudo leer correctamente los valores del parametro de contingencia Password para Inicio de Dia en BCRP (T_LBTR_PARAM).", true);
                        }

                    }
                    else
                    {
                        LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS, strHashcode,
                            "BL_ConexionAlterna.ObtenerPwdLogonBCRP",
                            "[CONTINGENCIA] El parametro Password para Inicio de Dia en BCRP de la tabla T_LBTR_PARAM no se encuentra registrado o se encuentra vacio.", true);
                    }
                }
                else
                {
                    LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS, strHashcode,
                        "BL_ConexionAlterna.ObtenerPwdLogonBCRP",
                        "[CONTINGENCIA] La cadena de conexion no esta establecida no se puede obtener el password de logon desde la base de datos.", true);
                }

            }
            catch (Exception ex)
            {
                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS, strHashcode,
                    "BL_ConexionAlterna.ObtenerPwdLogonBCRP",
                    "[CONTINGENCIA] Error al obtener el password para inicio de dia en BCRP: [" + ex.Message + "\r\n" + ex.StackTrace + "]",
                    true);
            }

            return "";
        }
                
    }
}
