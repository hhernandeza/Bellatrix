using System;
using System.Collections.Generic;
using System.Text;
using TBEWinServ.AccesoDatos;
using TBEWinServ.Utilitarios;

namespace TBEWinServ.LogicaNegocio
{
    public class BL_ConfirmacionBCosmos
    {
        private string strHashcode = "";

        public BL_ConfirmacionBCosmos(string prmHashcode) 
        {
            strHashcode = prmHashcode;
        }

        public void SincronizarConfirmacionBCosmos() 
        {
            if (!String.IsNullOrEmpty(Globales.CADENA_CONEXION))
            {
                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.CONFIRMACION_BCOSMOS, strHashcode,
                    "BL_ConfirmacionBCosmos.SincronizarConfirmacionBCosmos",
                    "Inicio Sincronizacion con BCOSMOS.", false);

                DA_General oDAGeneral = new DA_General(strHashcode);
                string strFlag1UsoAdes = oDAGeneral.Obtener_Param(Constantes.PARAM_CODIGO_BCOSMOS_FLAG1_USO_ADES);
                string strFlag2UsoAdes = oDAGeneral.Obtener_Param(Constantes.PARAM_CODIGO_BCOSMOS_FLAG2_USO_ADES);

                if (strFlag1UsoAdes.Trim() == "1" && strFlag2UsoAdes.Trim() == "1")
                {
                    DA_ConfirmacionBCosmos oDAConfBCosmos = new DA_ConfirmacionBCosmos(strHashcode);

                    bool blnEjecucion = oDAConfBCosmos.Sincronizar_ConfirmacionAbono_BCosmos();

                    //Si no se ejecuto y el error es por timeout
                    if (!blnEjecucion && oDAConfBCosmos.TimeoutException)
                    {
                        for (int i = 0; i < Globales.SYNCBCOSMOS_REINTENTOS; i++)
                        {
                            blnEjecucion = oDAConfBCosmos.Sincronizar_ConfirmacionAbono_BCosmos();

                            if (blnEjecucion)
                                break;
                            else
                            {
                                //si el error no es por timeout
                                if (!oDAConfBCosmos.TimeoutException) break;
                            }
                        }
                    }
                }
                else
                {
                    LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.CONFIRMACION_BCOSMOS, strHashcode,
                        "BL_ConfirmacionBCosmos.SincronizarConfirmacionBCosmos",
                        "La sincronizacion con BCOSMOS por ADES WEB se encuentra deshabilitado.", false);
                }

                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.CONFIRMACION_BCOSMOS, strHashcode,
                    "BL_ConfirmacionBCosmos.SincronizarConfirmacionBCosmos",
                    "Fin Sincronizacion con BCOSMOS.", false);
            }
        }
    }
}
