using System;
using System.Collections.Generic;
using System.Xml;
using System.IO;
using System.Text;
using System.Threading;
using TBEWinServ.Utilitarios;

namespace TBEWinServ.LogicaNegocio
{
    public class BL_Transaccion
    {

        #region Propiedades

        private TipoServicio _TipoServicio;

        public TipoServicio tipoServicio
        {
            get { return _TipoServicio; }
            set { _TipoServicio = value; }
        }

        private String strHashcode = "";

        private TBEMQWinServ.FachadaRemotingCliente.Servicio oTramaMQ = null;

        public TBEMQWinServ.FachadaRemotingCliente.Servicio TramaMQ
        {
            get { return oTramaMQ; }
            set { oTramaMQ = value; }
        }

        #endregion

        #region Constructor

        /// <summary>
        /// Clase que centraliza la ejecucion de servicios
        /// </summary>
        /// <param name="prmTipoServicio"></param>
        public BL_Transaccion(TipoServicio prmTipoServicio, String prmHashcode)
        {
            _TipoServicio = prmTipoServicio;
            strHashcode = prmHashcode;
        }

        #endregion
                
        #region Metodos de procesamiento de mensaje
        
        public void Procesar() 
        {
            try
            {
                switch (_TipoServicio)
                {
                    case TipoServicio.ENVIO_TRANSFERENCIAS:
                        BL_Transferencia oBLTransf = new BL_Transferencia(strHashcode);
                        oBLTransf.TransferirOperacionesPaylink();
                        break;
                    case TipoServicio.CONFIRMACION_ABONO:
                        BL_ConfirmacionAbono oBLConfAbono = new BL_ConfirmacionAbono(strHashcode);
                        oBLConfAbono.ConfirmarAbonoCliente();
                        break;
                    case TipoServicio.CONFIRMACION_BCOSMOS:
                        BL_ConfirmacionBCosmos oBLConfBCosmos = new BL_ConfirmacionBCosmos(strHashcode);
                        oBLConfBCosmos.SincronizarConfirmacionBCosmos();
                        break;
                    case TipoServicio.AVISO_AFECTACION:
                        BL_OperacionesRecibidas oBLAviAfect = new BL_OperacionesRecibidas(strHashcode);
                        oBLAviAfect.ProcesarOperacionesRecibidas();
                        break;
                    case TipoServicio.AVISO_AFECTACION_CONTING:
                        BL_OperacionesRecibidas oBLAviAfectConting = new BL_OperacionesRecibidas(strHashcode);
                        oBLAviAfectConting.ProcesarOperacionesRecibidasContingencia();
                        break;
                    case TipoServicio.ENVIO_OPERACION_BCOSMOS:
                        BL_EnvioBCosmos oBLEnvioBCosmos = new BL_EnvioBCosmos(strHashcode, oTramaMQ);
                        oBLEnvioBCosmos.ContabilizarOperaciones();
                        break;
                    case TipoServicio.SALIDAS_COMPRAVENTA:
                        BL_SalidasCompraVentaBCRP oBLSalidasCompraVentaBCRP = new BL_SalidasCompraVentaBCRP(strHashcode);
                        oBLSalidasCompraVentaBCRP.EnviarOperacionesCompraVentaAlBCRP();
                        break;
                    //hh72295:20170117:I: ADECUACION CITISCREENING EN OPERACIONES DE ENTRADA
                    case TipoServicio.ENVIO_OPERACION_CITISCREENING:
                        BL_EnvioCitiScreening oBL_EnvioCitiScreening = new BL_EnvioCitiScreening(strHashcode, oTramaMQ);
                        oBL_EnvioCitiScreening.ProcesarCitiscreening();
                        break;
                    //hh72295:20170117:F: ADECUACION CITISCREENING EN OPERACIONES DE ENTRADA
                }
            }
            catch (Exception ex)
            {
                LogWriter.EscribirLog(TipoLog.Resumido, _TipoServicio, strHashcode, 
                    "BL_Transaccion.Procesar", 
                    "Error, " + ex.Message + "\r\n" + ex.StackTrace, true);
            }
        }
                
        #endregion

    }
}
