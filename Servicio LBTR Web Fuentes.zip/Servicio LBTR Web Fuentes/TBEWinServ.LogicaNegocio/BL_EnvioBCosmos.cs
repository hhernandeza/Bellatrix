﻿using System;
using System.Collections.Generic;
using System.Text;
using TBEWinServ.AccesoDatos;
using TBEWinServ.Utilitarios;
using System.Globalization;
using TBEWinServ.EntidadesNegocio.EnvioBCosmos;
using TBEWinServ.EntidadesNegocio.ConfirmacionAbono;

namespace TBEWinServ.LogicaNegocio
{
    public class BL_EnvioBCosmos
    {
        private string strHashcode = null;
        TBEMQWinServ.FachadaRemotingCliente.Servicio oTramaMQ = null;

        public BL_EnvioBCosmos(string prmHashcode, TBEMQWinServ.FachadaRemotingCliente.Servicio prmTramaMQ) 
        {
            strHashcode = prmHashcode;
            oTramaMQ = prmTramaMQ;
        }

        public void AperturarBatch()
        {
            if (!String.IsNullOrEmpty(Globales.CADENA_CONEXION))
            {
                LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.ENVIO_OPERACION_BCOSMOS, strHashcode,
                "BL_EnvioBCosmos.AperturarBatch",
                "Inicio de apertura de batch en BCOSMOS por el servicio MQ.",
                NivelMensajeLog.NINGUNO);

                DA_General oDAGeneral = new DA_General(strHashcode);
                DA_EnvioBCosmos oDAEnvioBCosmos = new DA_EnvioBCosmos(strHashcode);

                Globales.MAIL_NOTIFICACION_PARA_BD = oDAGeneral.Obtener_Correo("0001");

                string strTrama = LlenarTramaAperturaOCierre(true);

                string strBatch = oDAGeneral.Obtener_Param(Constantes.PARAM_CODIGO_BCOSMOS_BATCH);

                if (strTrama.Length >= 56)
                {
                    string strRespBCosmos = ProcesarEnvioBCosmos(strTrama, Constantes.INDICADOR_APERTURA_BATCH);

                    if (strRespBCosmos != "")
                    {
                        if (strRespBCosmos == "000")
                        {
                            if (oDAGeneral.Actualizar_Param(Constantes.PARAM_CODIGO_BCOSMOS_ESTADO_BATCH, Constantes.INDICADOR_APERTURA_BATCH))
                            {
                                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.ENVIO_OPERACION_BCOSMOS, strHashcode,
                                "BL_EnvioBCosmos.AperturarBatch",
                                "Se realizo correctamente la apertura del batch [" + strBatch + "].",
                                NivelMensajeLog.NOTIFICACION);
                            }
                            else
                            {
                                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.ENVIO_OPERACION_BCOSMOS, strHashcode,
                                "BL_EnvioBCosmos.AperturarBatch",
                                "Ocurrio un problemas en base de datos al actualizar el estado de apertura del batch [" + strBatch + "].",
                                NivelMensajeLog.NOTIFICACION);
                            }
                        }
                        else if (strRespBCosmos == "050")
                        {
                            string strDescripcionError = oDAEnvioBCosmos.Obtener_Error_BCosmos(strRespBCosmos);

                            if (oDAGeneral.Actualizar_Param(Constantes.PARAM_CODIGO_BCOSMOS_ESTADO_BATCH, Constantes.INDICADOR_APERTURA_BATCH))
                            {
                                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.ENVIO_OPERACION_BCOSMOS, strHashcode,
                                "BL_EnvioBCosmos.AperturarBatch",
                                "Se realizo correctamente la apertura del batch [" + strBatch + "]. La respuesta de BCosmos fue [" + strDescripcionError + "].",
                                NivelMensajeLog.NOTIFICACION);
                            }
                            else
                            {
                                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.ENVIO_OPERACION_BCOSMOS, strHashcode,
                                "BL_EnvioBCosmos.AperturarBatch",
                                "Ocurrio un problemas en base de datos al actualizar el estado de apertura del batch [" + strBatch + "].",
                                NivelMensajeLog.NOTIFICACION);
                            }
                        }
                        else
                        {
                            string strDescripcionError = oDAEnvioBCosmos.Obtener_Error_BCosmos(strRespBCosmos);
                            LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.ENVIO_OPERACION_BCOSMOS, strHashcode,
                            "BL_EnvioBCosmos.AperturarBatch",
                            "No se puede aperturar el batch [" + strBatch + "]. La respuesta de BCosmos fue [" + strDescripcionError + "].",
                            NivelMensajeLog.NOTIFICACION);
                        }
                    }
                }
                else
                {
                    LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.ENVIO_OPERACION_BCOSMOS, strHashcode,
                    "BL_EnvioBCosmos.AperturarBatch",
                    "No se puede aperturar el batch [" + strBatch + "]. Revisar los valores de los datos en el mantenimiento de parametros.",
                    NivelMensajeLog.NOTIFICACION);
                }

                LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.ENVIO_OPERACION_BCOSMOS, strHashcode,
                "BL_EnvioBCosmos.AperturarBatch",
                "Fin de apertura de batch en BCOSMOS por el servicio MQ.",
                NivelMensajeLog.NINGUNO);
            }
        }

        public void CerrarBatch()
        {
            if (!String.IsNullOrEmpty(Globales.CADENA_CONEXION))
            {
                LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.ENVIO_OPERACION_BCOSMOS, strHashcode,
                "BL_EnvioBCosmos.CerrarBatch",
                "Inicio de cierre de batch en BCOSMOS por el servicio MQ.",
                NivelMensajeLog.NINGUNO);

                DA_General oDAGeneral = new DA_General(strHashcode);
                DA_EnvioBCosmos oDAEnvioBCosmos = new DA_EnvioBCosmos(strHashcode);

                //Obtener correo de notificacion
                Globales.MAIL_NOTIFICACION_PARA_BD = oDAGeneral.Obtener_Correo("0001");

                string strTrama = LlenarTramaAperturaOCierre(false);
                
                string strBatch = oDAGeneral.Obtener_Param(Constantes.PARAM_CODIGO_BCOSMOS_BATCH);

                if (strTrama.Length >= 56)
                {
                    string strRespBCosmos = ProcesarEnvioBCosmos(strTrama, Constantes.INDICADOR_CIERRE_BATCH);

                    if (strRespBCosmos != "")
                    {
                        if (strRespBCosmos == "000")
                        {
                            if (oDAGeneral.Actualizar_Param(Constantes.PARAM_CODIGO_BCOSMOS_ESTADO_BATCH, Constantes.INDICADOR_CIERRE_BATCH))
                            {
                                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.ENVIO_OPERACION_BCOSMOS, strHashcode,
                                "BL_EnvioBCosmos.CerrarBatch",
                                "Se realizo correctamente el cierre del batch [" + strBatch + "].",
                                NivelMensajeLog.NOTIFICACION);
                            }
                            else
                            {
                                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.ENVIO_OPERACION_BCOSMOS, strHashcode,
                                "BL_EnvioBCosmos.CerrarBatch",
                                "Ocurrio un problemas en base de datos al actualizar el estado de cierre del batch [" + strBatch + "].",
                                NivelMensajeLog.NOTIFICACION);
                            }
                        }
                        else if (strRespBCosmos == "059" || strRespBCosmos == "051")
                        {
                            string strDescripcionError = oDAEnvioBCosmos.Obtener_Error_BCosmos(strRespBCosmos);

                            if (oDAGeneral.Actualizar_Param(Constantes.PARAM_CODIGO_BCOSMOS_ESTADO_BATCH, Constantes.INDICADOR_CIERRE_BATCH))
                            {
                                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.ENVIO_OPERACION_BCOSMOS, strHashcode,
                                "BL_EnvioBCosmos.CerrarBatch",
                                "Se realizo correctamente el cierre del batch [" + strBatch + "]. La respuesta de BCosmos fue [" + strDescripcionError + "].",
                                NivelMensajeLog.NOTIFICACION);
                            }
                            else
                            {
                                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.ENVIO_OPERACION_BCOSMOS, strHashcode,
                                "BL_EnvioBCosmos.CerrarBatch",
                                "Ocurrio un problemas en base de datos al actualizar el estado de cierre del batch [" + strBatch + "].",
                                NivelMensajeLog.NOTIFICACION);
                            }
                        }
                        else
                        {
                            string strDescripcionError = oDAEnvioBCosmos.Obtener_Error_BCosmos(strRespBCosmos);
                            LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.ENVIO_OPERACION_BCOSMOS, strHashcode,
                            "BL_EnvioBCosmos.CerrarBatch",
                            "No se puede cerrar el batch [" + strBatch + "]. La respuesta de BCosmos fue [" + strDescripcionError + "].",
                            NivelMensajeLog.NOTIFICACION);
                        }
                    }
                }
                else
                {
                    LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.ENVIO_OPERACION_BCOSMOS, strHashcode,
                    "BL_EnvioBCosmos.CerrarBatch",
                    "No se puede cerrar el batch [" + strBatch + "]. Revisar los valores de los datos en el mantenimiento de parametros.",
                    NivelMensajeLog.NOTIFICACION);
                }

                LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.ENVIO_OPERACION_BCOSMOS, strHashcode,
                "BL_EnvioBCosmos.CerrarBatch",
                "Fin de cierre de batch en BCOSMOS por el servicio MQ.",
                NivelMensajeLog.NINGUNO);
            }
        }

        public void ContabilizarOperaciones()
        {
            #region Variables
            DA_General oDAGeneral = new DA_General(strHashcode);
            DA_EnvioBCosmos oDAEnvioBCosmos = new DA_EnvioBCosmos(strHashcode);
            List<BE_EnvioBCosmos> lstEnvioBCosmos = null;
            string strFechaActual = DateTime.Now.ToString("yyyyMMdd");
            string strRequerimientoId = "";
            string strRegistroIdDebito = "";
            string strRegistroIdCredito = "";
            string strRegistroIdTemp = "";
            Int64 nRegistroIdTemp = 0;
            string strEnviroment = "";
            string strBranch = "";
            string strOperador = "";
            string strProducto = "";            
            string strBatch = "";
            string strSencuencia = "".PadLeft(4,' ');
            string strNroCuentaDebito = "";
            string strNroCuentaCredito = "";
            string strCodMoneda = "";
            string strMontoMonedaLocal = "000000000000.00";
            string strSignoMonLocal = " ";           
            string strMontoMonedaExtranjera = "000000000000.00";
            string strSignoMonExtranjera = " ";
            string strIndicadorDebito = "0";
            string strIndicadorCredito = "1";
            string strFecha = "";
            string strTipoCambio = "000.0000";
            string strCodigoTransaccionDebito = "";
            string strCodigoTransaccionCredito = "";
            string strReferencia = "";
            string strAPA = "".PadLeft(6, ' ');
            string strCurrency = "".PadLeft(3, ' ');
            string strSpread = "".PadLeft(9, ' ');
            string strCollectionCode = "".PadLeft(10, ' ');
            string strCollectionName = "".PadLeft(30, ' ');
            string strTextoAdicional = "".PadLeft(127, ' ');
            string strFiller = "";
            string strTramaDebito = "";
            string strTramaCredito = "";
            string strGeneroAdes = "1";
            string strEstadoCredito = "1";
            string strEstadoDebito = "1";
            string strConfirmaAbono = "1";
            Int64 nFechaHora = -1;
            #endregion

            if (!String.IsNullOrEmpty(Globales.CADENA_CONEXION))
            {
                LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.ENVIO_OPERACION_BCOSMOS, strHashcode,
                "BL_EnvioBCosmos.ContabilizarOperaciones",
                "Inicio del envio de operaciones a BCOSMOS por MQ.",
                NivelMensajeLog.NINGUNO);

                Globales.MAIL_NOTIFICACION_PARA_BD = oDAGeneral.Obtener_Correo("0001");

                VerificarFlagEnvioBCosmosPorMQ();

                if (ObtenerOperacionesRecibidasAEnviarABCosmos(strFechaActual, ref lstEnvioBCosmos))
                {
                    if (VerificarEstadoDeBatch())
                    {
                        #region Actualizar estado de cierre de batch en la operacion

                        foreach (BE_EnvioBCosmos oBEEnvioBCosmos in lstEnvioBCosmos)
                        {
                            oDAEnvioBCosmos.Actualizar_Operaciones_Recibidas(oBEEnvioBCosmos.BcrpRefer, "");
                        }

                        #endregion

                        if (VerificarEnvioBCosmosPorMQ())
                        {
                            if (VerificarActualizacionTipoCambio())
                            {
                                if (VerificarConceptos())
                                {
                                    ActualizarAvisosCredito();
                                    EliminarAvisosCredito(strFechaActual);

                                    #region Obtener datos de trama configurables

                                    strRequerimientoId = oDAGeneral.Obtener_Param(Constantes.PARAM_CODIGO_BCOSMOS_REQUERIMIENTOID_OPERACION);//4
                                    strEnviroment = oDAGeneral.Obtener_Param(Constantes.PARAM_CODIGO_BCOSMOS_ENVIROMENT);//2
                                    strBranch = oDAGeneral.Obtener_Param(Constantes.PARAM_CODIGO_BCOSMOS_BRANCH);//3
                                    strOperador = oDAGeneral.Obtener_Param(Constantes.PARAM_CODIGO_BCOSMOS_OPERADOR).PadLeft(12, ' ');
                                    strProducto = oDAGeneral.Obtener_Param(Constantes.PARAM_CODIGO_BCOSMOS_PRODUCTO);//3
                                    strBatch = oDAGeneral.Obtener_Param(Constantes.PARAM_CODIGO_BCOSMOS_BATCH);//4
                                    strFecha = ObtenerFechaBCosmos();//8 

                                    #endregion

                                    foreach (BE_EnvioBCosmos oBEEnvioBCosmos in lstEnvioBCosmos)
                                    {
                                        #region Obtener datos de trama

                                        #region Obtener identificador de registro para asiento credito y debito

                                        strRegistroIdTemp = oDAGeneral.Obtener_Param(Constantes.PARAM_CODIGO_BCOSMOS_REGISTROID);
                                        strRegistroIdTemp = strRegistroIdTemp == null ? "" : strRegistroIdTemp;

                                        if (Int64.TryParse(strRegistroIdTemp, out nRegistroIdTemp))
                                        {
                                            nRegistroIdTemp++;

                                            strRegistroIdCredito = string.Format("TBE{0}", nRegistroIdTemp.ToString().Length > 17 ?
                                                                   nRegistroIdTemp.ToString().Substring(nRegistroIdTemp.ToString().Length - 17) :
                                                                   nRegistroIdTemp.ToString().PadLeft(17, '0'));

                                            nRegistroIdTemp++;

                                            strRegistroIdDebito = string.Format("TBE{0}", nRegistroIdTemp.ToString().Length > 17 ?
                                                                  nRegistroIdTemp.ToString().Substring(nRegistroIdTemp.ToString().Length - 17) :
                                                                  nRegistroIdTemp.ToString().PadLeft(17, '0'));

                                            if (!oDAGeneral.Actualizar_Param(Constantes.PARAM_CODIGO_BCOSMOS_REGISTROID, nRegistroIdTemp.ToString()))
                                            {
                                                LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.ENVIO_OPERACION_BCOSMOS, strHashcode,
                                                "BL_EnvioBCosmos.ContabilizarOperaciones",
                                                "No se puede enviar a BCosmos la operacion [" + oBEEnvioBCosmos.BcrpRefer +
                                                "] por problemas en base de datos. Se intentara enviar la operacion a BCosmos al restablecer la base de datos.",
                                                NivelMensajeLog.NOTIFICACION);
                                                break;
                                            }
                                        }
                                        else
                                        {
                                            LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.ENVIO_OPERACION_BCOSMOS, strHashcode,
                                            "BL_EnvioBCosmos.ContabilizarOperaciones",
                                            "No se puede enviar a BCosmos la operacion [" + oBEEnvioBCosmos.BcrpRefer +
                                            "]. Revisar en el mantenimiento de parametros el valor numerico del parametro con codigo [" + Constantes.PARAM_CODIGO_BCOSMOS_REGISTROID + "].",
                                            NivelMensajeLog.NOTIFICACION);
                                            break;
                                        }

                                        #endregion

                                        strReferencia = oBEEnvioBCosmos.BcrpRefer.Substring(5, 10);
                                        strNroCuentaCredito = oBEEnvioBCosmos.OperCta.PadLeft(25, '0');
                                        strNroCuentaDebito = oBEEnvioBCosmos.NroCta.PadLeft(25, '0');

                                        #region Obtener operacion soles o dolares

                                        if (oBEEnvioBCosmos.CodMoneda == "00")
                                        {
                                            strCodMoneda = oDAGeneral.Obtener_Param(Constantes.PARAM_CODIGO_BCOSMOS_MONEDASOL);
                                            strMontoMonedaLocal = oBEEnvioBCosmos.OperMonto.Contains(".") ?
                                                oBEEnvioBCosmos.OperMonto.PadLeft(15, '0') :
                                                oBEEnvioBCosmos.OperMonto.PadLeft(12, '0') + ".00";
                                            strMontoMonedaExtranjera = "000000000000.00";

                                            LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.ENVIO_OPERACION_BCOSMOS, strHashcode,
                                            "BL_EnvioBCosmos.ContabilizarOperaciones",
                                            "La operacion [" + oBEEnvioBCosmos.BcrpRefer + "] es en soles.",
                                            NivelMensajeLog.NINGUNO);
                                        }
                                        else
                                        {
                                            strCodMoneda = oDAGeneral.Obtener_Param(Constantes.PARAM_CODIGO_BCOSMOS_MONEDADOL);
                                            strMontoMonedaExtranjera = oBEEnvioBCosmos.OperMonto.Contains(".") ?
                                                oBEEnvioBCosmos.OperMonto.PadLeft(15, '0') :
                                                oBEEnvioBCosmos.OperMonto.PadLeft(12, '0') + ".00";
                                            strMontoMonedaLocal = "000000000000.00";

                                            LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.ENVIO_OPERACION_BCOSMOS, strHashcode,
                                            "BL_EnvioBCosmos.ContabilizarOperaciones",
                                            "La operacion [" + oBEEnvioBCosmos.BcrpRefer + "] es en dolares.",
                                            NivelMensajeLog.NINGUNO);
                                        }

                                        #endregion

                                        #region Obtener operacion con o sin afecto ITF

                                        if (oBEEnvioBCosmos.IndicadorItf == "N")//si es afecto ITF
                                        {
                                            strCodigoTransaccionDebito = oDAGeneral.Obtener_Param(Constantes.PARAM_CODIGO_BCOSMOS_TRX_DEBITO_CONAFECTO);
                                            strCodigoTransaccionCredito = oDAGeneral.Obtener_Param(Constantes.PARAM_CODIGO_BCOSMOS_TRX_CREDITO_CONAFECTO);

                                            LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.ENVIO_OPERACION_BCOSMOS, strHashcode,
                                            "BL_EnvioBCosmos.ContabilizarOperaciones",
                                            "La operacion [" + oBEEnvioBCosmos.BcrpRefer + "] si es afecto ITF.",
                                            NivelMensajeLog.NINGUNO);
                                        }
                                        else
                                        {
                                            strCodigoTransaccionDebito = oDAGeneral.Obtener_Param(Constantes.PARAM_CODIGO_BCOSMOS_TRX_DEBITO_SINAFECTO);
                                            strCodigoTransaccionCredito = oDAGeneral.Obtener_Param(Constantes.PARAM_CODIGO_BCOSMOS_TRX_CREDITO_SINAFECTO);

                                            LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.ENVIO_OPERACION_BCOSMOS, strHashcode,
                                            "BL_EnvioBCosmos.ContabilizarOperaciones",
                                            "La operacion [" + oBEEnvioBCosmos.BcrpRefer + "] no es afecto ITF.",
                                            NivelMensajeLog.NINGUNO);
                                        }

                                        #endregion

                                        #region Obtener texto adicional

                                        if (oBEEnvioBCosmos.TipoDocOrdenante == "06")
                                        {
                                            strTextoAdicional = ("De:" + oBEEnvioBCosmos.BcoOrig + "RUC" + oBEEnvioBCosmos.NumDocOrdenante).PadLeft(127, ' ');
                                        }
                                        else
                                        {
                                            strTextoAdicional = ("De:" + oBEEnvioBCosmos.BcoOrig + "RUC").PadLeft(127, ' ');
                                        }

                                        #endregion

                                        //hh72295:20170116:I: ADECUACION EN SERVICIO LBTR PARA ENVIAR INFORMACION ORDENANTE A BCOSMOS
                                        #region Obtener operacion Speed Collect

                                        //if (oDAEnvioBCosmos.Obtener_Operacion_Speed_Collect(oBEEnvioBCosmos.OperCtaTmp) == "1")
                                        //{
                                        //    strCollectionCode = oBEEnvioBCosmos.BcoOrig.PadLeft(10, ' ');

                                        //    if (oBEEnvioBCosmos.TipoDocOrdenante == "06")
                                        //    {
                                        //        strCollectionName = oBEEnvioBCosmos.NumDocOrdenante.PadLeft(30, ' ');
                                        //    }
                                        //    else
                                        //    {
                                        //        strCollectionName = "".PadLeft(30, ' ');
                                        //    }

                                        //    LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.ENVIO_OPERACION_BCOSMOS, strHashcode,
                                        //    "BL_EnvioBCosmos.ContabilizarOperaciones",
                                        //    "La operacion [" + oBEEnvioBCosmos.BcrpRefer + "] es Speed Collect.",
                                        //    NivelMensajeLog.NINGUNO);
                                        //}

                                        strCollectionCode = oBEEnvioBCosmos.BcoOrig.PadLeft(10, ' '); ;
                                        strCollectionName = oBEEnvioBCosmos.NumDocOrdenante.PadLeft(30, ' ');

                                        #endregion
                                        //hh72295:20170116:F: ADECUACION EN SERVICIO LBTR PARA ENVIAR INFORMACION ORDENANTE A BCOSMOS

                                        strTramaCredito = strRequerimientoId + strRegistroIdCredito + strEnviroment + strBranch +
                                                          strOperador + strProducto + strBatch + strSencuencia + strNroCuentaCredito +
                                                          strCodMoneda + strMontoMonedaLocal + strSignoMonLocal + strMontoMonedaExtranjera +
                                                          strSignoMonExtranjera + strIndicadorCredito + strFecha + strTipoCambio +
                                                          strCodigoTransaccionCredito + strReferencia + strAPA + strCurrency + strSpread +
                                                          strCollectionCode + strCollectionName + strTextoAdicional + strFiller;

                                        //hh72295:20170116:I: ADECUACION EN SERVICIO LBTR PARA ENVIAR INFORMACION ORDENANTE A BCOSMOS
                                        //strCollectionCode = "".PadLeft(10, ' ');
                                        //strCollectionName = "".PadLeft(30, ' ');
                                        //hh72295:20170116:F: ADECUACION EN SERVICIO LBTR PARA ENVIAR INFORMACION ORDENANTE A BCOSMOS

                                        strTramaDebito = strRequerimientoId + strRegistroIdDebito + strEnviroment + strBranch +
                                                         strOperador + strProducto + strBatch + strSencuencia + strNroCuentaDebito +
                                                         strCodMoneda + strMontoMonedaLocal + strSignoMonLocal + strMontoMonedaExtranjera +
                                                         strSignoMonExtranjera + strIndicadorDebito + strFecha + strTipoCambio +
                                                         strCodigoTransaccionDebito + strReferencia + strAPA + strCurrency + strSpread +
                                                         strCollectionCode + strCollectionName + strTextoAdicional + strFiller;

                                        LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.ENVIO_OPERACION_BCOSMOS, strHashcode,
                                        "BL_EnvioBCosmos.ContabilizarOperaciones",
                                        "Los datos de la trama de credito son: Identificador de Requerimiento [" + strRequerimientoId + "], Identificador de Registro [" + strRegistroIdCredito +
                                        "], Environment [" + strEnviroment + "], Branch [" + strBranch + "], Operador [" + strOperador + "], Product Code [" + strProducto +
                                        "], Batch [" + strBatch + "], Fecha [" + strFecha + "], Secuencia [" + strSencuencia + "], NroCuenta [" + strNroCuentaCredito + "], Moneda [" + strCodMoneda +
                                        "], Monto Moneda Local [" + strMontoMonedaLocal + "], Signo Moneda Local [" + strSignoMonLocal + "], Monto Moneda Extranjera [" + strMontoMonedaExtranjera +
                                        "], Signo Moneda Extranjero [" + strSignoMonExtranjera + "], Indicador de Credito [" + strIndicadorCredito + "], Tipo de Cambio [" + strTipoCambio +
                                        "], Codigo de Transaccion [" + strCodigoTransaccionCredito + "], Referencia [" + strReferencia + "], APA [" + strAPA + "], Currency [" + strCurrency +
                                        "], Spread [" + strSpread + "], Collection Code [" + strCollectionCode + "], Collection Name [" + strCollectionName + "], Texto Adicional [" + strTextoAdicional + "].",
                                        NivelMensajeLog.NINGUNO);

                                        LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.ENVIO_OPERACION_BCOSMOS, strHashcode,
                                        "BL_EnvioBCosmos.ContabilizarOperaciones",
                                        "Los datos de la trama de debito son: Identificador de Requerimiento [" + strRequerimientoId + "], Identificador de Registro [" + strRegistroIdDebito +
                                        "], Environment [" + strEnviroment + "], Branch [" + strBranch + "], Operador [" + strOperador + "], Product Code [" + strProducto +
                                        "], Batch [" + strBatch + "], Fecha [" + strFecha + "], Secuencia [" + strSencuencia + "], NroCuenta [" + strNroCuentaDebito + "], Moneda [" + strCodMoneda +
                                        "], Monto Moneda Local [" + strMontoMonedaLocal + "], Signo Moneda Local [" + strSignoMonLocal + "], Monto Moneda Extranjera [" + strMontoMonedaExtranjera +
                                        "], Signo Moneda Extranjero [" + strSignoMonExtranjera + "], Indicador de Credito [" + strIndicadorDebito + "], Tipo de Cambio [" + strTipoCambio +
                                        "], Codigo de Transaccion [" + strCodigoTransaccionDebito + "], Referencia [" + strReferencia + "], APA [" + strAPA + "], Currency [" + strCurrency +
                                        "], Spread [" + strSpread + "], Collection Code [" + strCollectionCode + "], Collection Name [" + strCollectionName + "], Texto Adicional [" + strTextoAdicional + "].",
                                        NivelMensajeLog.NINGUNO);

                                        #endregion

                                        ActualizarLogError(oBEEnvioBCosmos.BcrpRefer, oBEEnvioBCosmos.Fecha);

                                        #region Obtener datos de aviso de credito

                                        BE_AvisoCredito oBEAvisoCredito = new BE_AvisoCredito();
                                        oBEAvisoCredito.BcrpRef = strReferencia;
                                        oBEAvisoCredito.NroCta = oBEEnvioBCosmos.OperCtaTmp;
                                        oBEAvisoCredito.Moneda = strCodMoneda;
                                        oBEAvisoCredito.MonExt = Convert.ToDecimal(strMontoMonedaExtranjera);
                                        oBEAvisoCredito.MonLoc = Convert.ToDecimal(strMontoMonedaLocal);
                                        oBEAvisoCredito.BcoOrigen = oBEEnvioBCosmos.BcoOrig;
                                        oBEAvisoCredito.Base = oBEEnvioBCosmos.OperCtaTmp.Substring(1, 6);
                                        oBEAvisoCredito.Fecha = strFechaActual;

                                        #endregion

                                        if (InsertarAvisosCredito(oBEAvisoCredito))
                                        {

                                            #region Proceso de envio y respuesta por canal Net Remoting a servicio MQ Bcosmos

                                            nFechaHora = Convert.ToInt64(DateTime.Now.ToString("yyyyMMddHHmmss"));

                                            strEstadoCredito = "1";
                                            strEstadoDebito = "1";
                                            strConfirmaAbono = "1";

                                            LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.ENVIO_OPERACION_BCOSMOS, strHashcode,
                                            "BL_EnvioBCosmos.ContabilizarOperaciones",
                                            "Se intenta procesar el asiento credito de la operacion [" + oBEEnvioBCosmos.BcrpRefer + "].",
                                            NivelMensajeLog.NINGUNO);

                                            string strRespBCosmos = ProcesarEnvioBCosmos(strTramaCredito, oBEEnvioBCosmos.BcrpRefer);

                                            if (strRespBCosmos == "-1" || strRespBCosmos == "-2" ||
                                                strRespBCosmos == "-3" || strRespBCosmos == "-4" ||
                                                strRespBCosmos == "-5" || strRespBCosmos == "0")
                                            {
                                                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.ENVIO_OPERACION_BCOSMOS, strHashcode,
                                                        "BL_EnvioBCosmos.ContabilizarOperaciones",
                                                        "Sin exito el procesamiento de credito de la operacion [" + oBEEnvioBCosmos.BcrpRefer + "].",
                                                        NivelMensajeLog.NINGUNO);
                                            }
                                            else
                                            {
                                                #region Debito 
                                                ActualizarOperacionesAEnviarABCosmos(oBEEnvioBCosmos.BcrpRefer, strGeneroAdes, nFechaHora);

                                                if (strRespBCosmos.Length == 3)
                                                {
                                                    if (strRespBCosmos == "000")
                                                    {
                                                        EnviarEmailDeConfirmacionDeOperacion(oBEEnvioBCosmos.BcrpRefer);

                                                        LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.ENVIO_OPERACION_BCOSMOS, strHashcode,
                                                        "BL_EnvioBCosmos.ContabilizarOperaciones",
                                                        "Se proceso correctamente asiento credito enviado a BCOSMOS de la operacion [" + oBEEnvioBCosmos.BcrpRefer + "]. Se intenta procesar el asiento debito de la operacion",
                                                        NivelMensajeLog.NINGUNO);
                                                        
                                                        strRespBCosmos = ProcesarEnvioBCosmos(strTramaDebito, oBEEnvioBCosmos.BcrpRefer);

                                                        if (strRespBCosmos.Length == 3)
                                                        {
                                                            if (strRespBCosmos == "000")
                                                            {
                                                                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.ENVIO_OPERACION_BCOSMOS, strHashcode,
                                                                "BL_EnvioBCosmos.ContabilizarOperaciones",
                                                                "Se proceso correctamente asiento debito enviado a BCOSMOS de la operacion con referencia [" + oBEEnvioBCosmos.BcrpRefer + "].",
                                                                NivelMensajeLog.NINGUNO);
                                                            }
                                                            else
                                                            {
                                                                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.ENVIO_OPERACION_BCOSMOS, strHashcode,
                                                                "BL_EnvioBCosmos.ContabilizarOperaciones",
                                                                "No se obtuvo lo que se esperaba al procesar asiento debito enviado a BCOSMOS de la operacion [" + oBEEnvioBCosmos.BcrpRefer + "]. Regularizar asiento contable manualmente. Verificar log de errores.",
                                                                NivelMensajeLog.NINGUNO);

                                                                strEstadoDebito = "0";
                                                                strConfirmaAbono = "0";

                                                                InsertarLogError(strRespBCosmos, oBEEnvioBCosmos.BcrpRefer, strFechaActual, false);
                                                            }
                                                        }
                                                        else
                                                        {
                                                            LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.ENVIO_OPERACION_BCOSMOS, strHashcode,
                                                                "BL_EnvioBCosmos.ContabilizarOperaciones",
                                                                "Sin exito el procesamiento de debito de la operacion [" + oBEEnvioBCosmos.BcrpRefer + "].",
                                                                NivelMensajeLog.NINGUNO);

                                                            strEstadoDebito = "0";
                                                            strConfirmaAbono = "0";
                                                        }
                                                    }
                                                    else
                                                    {
                                                        LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.ENVIO_OPERACION_BCOSMOS, strHashcode,
                                                        "BL_EnvioBCosmos.ContabilizarOperaciones",
                                                        "No se obtuvo lo que se esperaba al procesar asiento credito enviado a BCOSMOS de la operacion [" + oBEEnvioBCosmos.BcrpRefer + "]. Verificar log de errores.",
                                                        NivelMensajeLog.NINGUNO);

                                                        strEstadoCredito = "0";
                                                        strEstadoDebito = "0";
                                                        strConfirmaAbono = "0";

                                                        InsertarLogError(strRespBCosmos, oBEEnvioBCosmos.BcrpRefer, strFechaActual, true);
                                                    }
                                                }
                                                else
                                                {
                                                    strEstadoCredito = "0";
                                                    strEstadoDebito = "0";
                                                    strConfirmaAbono = "0";
                                                }

                                                #endregion

                                                ActualizarOperacionesDevueltasPorBCosmos(oBEEnvioBCosmos.BcrpRefer, strEstadoDebito, strEstadoCredito, strConfirmaAbono);
                                            }

                                            #endregion

                                        }
                                    }

                                    ActualizarAvisosCredito();
                                }
                            }
                        }
                    }
                    else
                    {
                        #region Actualizar estado de cierre de batch en la operacion

                        strBatch = oDAGeneral.Obtener_Param(Constantes.PARAM_CODIGO_BCOSMOS_BATCH);

                        foreach (BE_EnvioBCosmos oBEEnvioBCosmos in lstEnvioBCosmos)
                        {
                            oDAEnvioBCosmos.Actualizar_Operaciones_Recibidas(oBEEnvioBCosmos.BcrpRefer, "Batch [" + strBatch + "] cerrado.");
                        }

                        #endregion
                    }
                }

                LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.ENVIO_OPERACION_BCOSMOS, strHashcode,
                "BL_EnvioBCosmos.ContabilizarOperaciones",
                "Fin del envio de operaciones a BCOSMOS por MQ.",
                NivelMensajeLog.NINGUNO);
            }
        }

        /// <summary>
        /// Permite insertar en tablas la trama para que luego
        /// sean enviadas al servicio MQ por NetRemoting y este
        /// retorne una respuesta de BCOSMOS
        /// </summary>
        /// <param name="strTrama">Trama</param>
        /// <param name="strIndicador">Identificador de la operacion</param>
        /// <returns>Respuesta de BCOSMOS</returns>
        private string ProcesarEnvioBCosmos(string strTrama, string strIndicador)
        {   
            string strRespBCosmos = strIndicador == Constantes.INDICADOR_APERTURA_BATCH || strIndicador == Constantes.INDICADOR_CIERRE_BATCH ? "" : "0";
            string mensajeRetornoMQ = "";
            string msgIdRetornoMQ = "";

            LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.ENVIO_OPERACION_BCOSMOS, strHashcode,
                "BL_EnvioBCosmos.ProcesarEnvioBCosmos", "Se intenta procesar la trama [" + strTrama + "].", NivelMensajeLog.NINGUNO);

            //1. Insertar a tmp_envio_mq
            DA_TransferenciaMQ oDATransferenciaMQ = new DA_TransferenciaMQ(strHashcode);
            BE_TramaMQ oBETramaMQ = new BE_TramaMQ();
            oBETramaMQ.OrigenToken = Constantes.INDICADOR_TRAMA_OUTPUT_MQ;
            oBETramaMQ.SistemaOrigen = Globales.SISTEMA_ORIGEN.ToString();
            oBETramaMQ.Trama = strTrama;
            oBETramaMQ.FechaOrigen = DateTime.Now;
            DA_TramaMQ oDATramaMQ = new DA_TramaMQ(strHashcode);
            Int64 nTokenId = oDATramaMQ.Insertar_TramaMQ(oBETramaMQ);

            if (nTokenId != -1)
            {
                LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.ENVIO_OPERACION_BCOSMOS, strHashcode,
                "BL_EnvioBCosmos.ProcesarEnvioBCosmos",
                "Se inserto correctamente en la tabla tmp_envio_mq token id out [" + nTokenId.ToString() + "].",
                NivelMensajeLog.NINGUNO);

                //2. Insertar a mae_transferencia_mq
                BE_TransferenciaMQ oTransferenciaMQ = new BE_TransferenciaMQ();
                oTransferenciaMQ.TokenId = nTokenId;
                oTransferenciaMQ.BcrpRefer = strIndicador == Constantes.INDICADOR_APERTURA_BATCH || strIndicador == Constantes.INDICADOR_CIERRE_BATCH ? "" : strIndicador;
                oTransferenciaMQ.FechaOrigen = DateTime.Now;
                oTransferenciaMQ.TramaInput = strTrama;
                oTransferenciaMQ.SistemaOrigen = Globales.SISTEMA_ORIGEN.ToString();
                Int64 nSecuen = oDATransferenciaMQ.Insertar_TransferenciaMQ(oTransferenciaMQ);

                if (nSecuen != -1)
                {
                    LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.ENVIO_OPERACION_BCOSMOS, strHashcode,
                    "BL_EnvioBCosmos.ProcesarEnvioBCosmos",
                    "Se inserto correctamente en la tabla de transferencias MQ la operacion [" + nTokenId.ToString() + "] con numero de secuencia [" + nSecuen.ToString() + "].",
                    NivelMensajeLog.NINGUNO);

                    //3. Consumir servicio MQ para envio de trama a BCOSMOS
                    if (ConsumirServicioMQ(nTokenId, out mensajeRetornoMQ, out msgIdRetornoMQ))
                    {
                        LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.ENVIO_OPERACION_BCOSMOS, strHashcode,
                            "BL_EnvioBCosmos.ProcesarEnvioBCosmos",
                            string.Format("Se envio correctamente a MQ BCosmos la trama con token [{0}] de tipo OUT y se recibio la trama IN {1}", nTokenId, mensajeRetornoMQ),
                            NivelMensajeLog.NINGUNO);

                        strRespBCosmos = mensajeRetornoMQ.Length >= 35 ? mensajeRetornoMQ.Substring(32, 3) : "";
                        oTransferenciaMQ.TramaOuput = mensajeRetornoMQ;
                        oTransferenciaMQ.RespBCosmos = strRespBCosmos;
                        
                        //5. Actualizar mae_transferencia_mq con respuesta de BCosmos
                        oTransferenciaMQ.Secuencia = nSecuen;
                        oTransferenciaMQ.FechaDestino = DateTime.Now;
                        oTransferenciaMQ.MessageId = msgIdRetornoMQ;

                        if (oDATransferenciaMQ.Actualizar_TransferenciaMQ(oTransferenciaMQ))
                        {
                            LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.ENVIO_OPERACION_BCOSMOS, strHashcode,
                            "BL_EnvioBCosmos.ProcesarEnvioBCosmos",
                            "Se actualizo correctamente la trama output [" + strTrama + "] de la operacion [" + nTokenId.ToString() +
                            "] con numero de secuencia [" + nSecuen.ToString() + "] en la tabla de transferencias MQ.",
                            NivelMensajeLog.NINGUNO);
                        }
                        else
                        {
                            LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.ENVIO_OPERACION_BCOSMOS, strHashcode,
                            "BL_EnvioBCosmos.ProcesarEnvioBCosmos",
                            "No se actualizo la trama output [" + strTrama + "] de la operacion [" + nTokenId.ToString() +
                            "] con numero de secuencia [" + nSecuen.ToString() + "] en la tabla de transferencias MQ.",
                            NivelMensajeLog.NINGUNO);
                        }
                    }
                    else
                    {
                        #region Notificaciones

                        if (strIndicador == Constantes.INDICADOR_APERTURA_BATCH)
                        {
                            LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.ENVIO_OPERACION_BCOSMOS, strHashcode,
                                "BL_EnvioBCosmos.ProcesarEnvioBCosmos",
                                string.Format("No se pudo aperturar el batch con token id {0}, respuesta Serv. Interfaces: ", nTokenId, mensajeRetornoMQ),
                                NivelMensajeLog.NOTIFICACION);
                        }
                        else if (strIndicador == Constantes.INDICADOR_CIERRE_BATCH)
                        {
                            LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.ENVIO_OPERACION_BCOSMOS, strHashcode,
                                "BL_EnvioBCosmos.ProcesarEnvioBCosmos",
                                string.Format("No se pudo cerrar el batch con token id {0}, respuesta Serv. Interfaces: ", nTokenId, mensajeRetornoMQ),
                                NivelMensajeLog.NOTIFICACION);
                        }
                        else
                        {
                            LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.ENVIO_OPERACION_BCOSMOS, strHashcode,
                                "BL_EnvioBCosmos.ProcesarEnvioBCosmos",
                                string.Format("La operacion {0} con token id {1}, no se pudo procesar, respuesta Serv. Interfaces: {2}", 
                                                strIndicador, nTokenId, mensajeRetornoMQ),
                                NivelMensajeLog.NOTIFICACION);
                            InsertarLogError(strIndicador, "Error al consumir servicio MQ");
                        }

                        #endregion
                    }
                }
                else
                {
                    LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.ENVIO_OPERACION_BCOSMOS, strHashcode,
                    "BL_EnvioBCosmos.ProcesarEnvioBCosmos",
                    "No se pudo insertar la trama de envio [" + strTrama + "] de la operacion [" + nTokenId.ToString() + 
                    "] en la tabla de transferencias MQ.",
                    NivelMensajeLog.NINGUNO);
                }
            }
            else
            {
                LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.ENVIO_OPERACION_BCOSMOS, strHashcode,
                    "BL_EnvioBCosmos.ProcesarEnvioBCosmos",
                    "No se pudo insertar la trama output [" + strTrama + "] en la tabla tmp_envio_mq.",
                    NivelMensajeLog.NINGUNO);
            }

            return strRespBCosmos;
        }

        /// <summary>
        /// Permite consumir el servicio MQ por medio de un canal NetRemoting
        /// </summary>
        /// <param name="nTokenId">Identificador de la trama</param>
        /// <param name="mensajeRetorno">Mensaje devuelto por el servicio Interfaces</param>
        /// <returns>True=Si accedio al metodo publicado por el canal NetRemoting</returns>
        private bool ConsumirServicioMQ(Int64 nTokenId, out string mensajeRetorno, out string msgId)
        {
            bool blnExito = false;
            mensajeRetorno = null;
            msgId = null;
            
            try
            {
                TBEMQWinServ.EntidadesNegocio.BE_TramaMQ oTramaRespuesta = new TBEMQWinServ.EntidadesNegocio.BE_TramaMQ();
                mensajeRetorno = oTramaMQ.EnviarMensajeMQSync(nTokenId, Constantes.SERV_INTERFACES_ID_CONFIG_MQBCOSMOS, ref oTramaRespuesta);

                if (String.IsNullOrEmpty(mensajeRetorno))
                {
                    blnExito = true;
                    mensajeRetorno = oTramaRespuesta.Trama;//Retorna la trama solo cuando sea exito
                    msgId = oTramaRespuesta.MsgId;
                }
                else
                {
                    //Pudo haber recuperado respuesta de BCosmos (trama de entrada) pero quizas no se pudo insertar en BD (tmp_envio_mq "in")
                    //Evaluamos esa condicion, si hubo retorno
                    if (oTramaRespuesta != null && !String.IsNullOrEmpty(oTramaRespuesta.Trama))
                    {
                        blnExito = true;
                        mensajeRetorno = oTramaRespuesta.Trama;
                        msgId = oTramaRespuesta.MsgId;
                    }
                    else
                    {
                        LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.ENVIO_OPERACION_BCOSMOS, strHashcode,
                            "BL_EnvioBCosmos.ConsumirServicioMQ",
                            "Fallo el envio a BCOSMOS de la operacion con token id [" + nTokenId.ToString() + "]: " + mensajeRetorno, NivelMensajeLog.NOTIFICACION);
                    }
                }
            }
            catch (Exception ex)
            {
                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.ENVIO_OPERACION_BCOSMOS, strHashcode,
                "BL_EnvioBCosmos.ConsumirServicioMQ",
                    "Error en el envio a BCOSMOS de la operacion con token [" + nTokenId.ToString() + "]:" + ex.Message,
                    NivelMensajeLog.ERROR);
            }

            return blnExito;
        }

        /// <summary>
        /// Se genera la trama de apertura o cierre de batch
        /// para los envios a BCOSMOS por MQ
        /// </summary>
        /// <param name="prmEsInicio">True si es inicio de batch</param>
        /// <returns>Trama de apertura o cierre</returns>
        private string LlenarTramaAperturaOCierre(bool prmEsInicio)
        {
            #region Variables
            DA_General oDAGeneral = new DA_General(strHashcode);
            string strRequerimientoId = "";
            string strTrama = "";
            string strRegistroId = "";
            string strRegistroIdTemp = "";
            Int64 nRegistroIdTemp = 0;
            string strEnviroment = "";
            string strBranch = "";
            string strOperador = "";
            string strProducto = "";
            string strFecha = "";
            string strBatch = "";
            string strFiller = "";          
            #endregion

            strRegistroIdTemp = oDAGeneral.Obtener_Param(Constantes.PARAM_CODIGO_BCOSMOS_REGISTROID);
            nRegistroIdTemp = 0;

            if (Int64.TryParse(strRegistroIdTemp, out nRegistroIdTemp))
            {
                nRegistroIdTemp++;

                if (oDAGeneral.Actualizar_Param(Constantes.PARAM_CODIGO_BCOSMOS_REGISTROID, nRegistroIdTemp.ToString()))
                {
                    if (prmEsInicio)
                        strRequerimientoId = oDAGeneral.Obtener_Param(Constantes.PARAM_CODIGO_BCOSMOS_REQUERIMIENTOID_APERTURA);//4
                    else
                        strRequerimientoId = oDAGeneral.Obtener_Param(Constantes.PARAM_CODIGO_BCOSMOS_REQUERIMIENTOID_CIERRE);//4

                    strRegistroId = nRegistroIdTemp.ToString().PadLeft(20, '0');//20
                    strEnviroment = oDAGeneral.Obtener_Param(Constantes.PARAM_CODIGO_BCOSMOS_ENVIROMENT);//2
                    strBranch = oDAGeneral.Obtener_Param(Constantes.PARAM_CODIGO_BCOSMOS_BRANCH);//3
                    strOperador = oDAGeneral.Obtener_Param(Constantes.PARAM_CODIGO_BCOSMOS_OPERADOR).PadLeft(12, ' ');//12
                    strProducto = oDAGeneral.Obtener_Param(Constantes.PARAM_CODIGO_BCOSMOS_PRODUCTO);//3
                    strFecha = ObtenerFechaBCosmos();//8 
                    strBatch = oDAGeneral.Obtener_Param(Constantes.PARAM_CODIGO_BCOSMOS_BATCH);//4

                    strTrama = strRequerimientoId + strRegistroId + strEnviroment + strBranch +
                               strOperador + strProducto + strFecha + strBatch + strFiller;

                    LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.ENVIO_OPERACION_BCOSMOS, strHashcode,
                    "BL_EnvioBCosmos.LlenarTramaAperturaOCierre",
                    "Los datos de la trama son: Identificador de Requerimiento [" + strRequerimientoId + "], Identificador de Registro [" + strRegistroId + 
                    "], Environment [" + strEnviroment + "], Branch [" + strBranch + "], Operador [" + strOperador + "], Product Code [" + strProducto +
                    "], Batch [" + strBatch + "], Fecha [" + strFecha + "].",
                    NivelMensajeLog.NINGUNO);
                }
                else
                {
                    LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.ENVIO_OPERACION_BCOSMOS, strHashcode,
                    "BL_EnvioBCosmos.LlenarTramaAperturaOCierre",
                    "No se puede actualizar el identificador de registro. Revisar en el mantenimiento de parametros el valor del parametro con codigo [" + Constantes.PARAM_CODIGO_BCOSMOS_REGISTROID + "].",
                    NivelMensajeLog.NINGUNO);
                }
            }
            else
            {
                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.ENVIO_OPERACION_BCOSMOS, strHashcode,
                "BL_EnvioBCosmos.LlenarTramaAperturaOCierre",
                "No se puede obtener el identificador de registro. Revisar en el mantenimiento de parametros el valor del parametro con codigo [" + Constantes.PARAM_CODIGO_BCOSMOS_REGISTROID + "].",
                NivelMensajeLog.ERROR);
            }

            return strTrama;
        }

        /// <summary>
        /// Obtener fecha configurable en T_PARAM en caso BCOSMOS
        /// no este actualizado a la fecha actual.
        /// Si BCOSMOS esta actualizado a la fecha actual se obtiene
        /// la fecha del servidor
        /// </summary>
        /// <returns>Fecha configurable o fecha actual</returns>
        private string ObtenerFechaBCosmos()
        {
            DA_General oDAGeneral = new DA_General(strHashcode);

            DateTime dtFecha = new DateTime();
            string strFlagUsoFecha = oDAGeneral.Obtener_Param(Constantes.PARAM_CODIGO_BCOSMOS_FLAGUSOFECHA);
            string strFecha = oDAGeneral.Obtener_Param(Constantes.PARAM_CODIGO_BCOSMOS_FECHA);

            if (strFlagUsoFecha.Trim() != "1" ||
                strFecha.Length != 8 ||
                !DateTime.TryParseExact(strFecha, "yyyyMMdd", new CultureInfo("en-GB"), DateTimeStyles.None, out dtFecha))
            {
                strFecha = DateTime.Now.ToString("yyyyMMdd");
            }

            return strFecha;
        }

        #region Avisos de Credito

        /// <summary>
        /// Antes de enviar la contabilidad a BCosmos se actualizan los avisos de credito
        /// </summary>
        private void ActualizarAvisosCredito()
        {
            DA_AvisoCredito oDAAvisoCredito = new DA_AvisoCredito(strHashcode);

            if (oDAAvisoCredito.Actualizar_Avisos_Credito())
            {
                LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.ENVIO_OPERACION_BCOSMOS, strHashcode,
                "BL_EnvioBCosmos.ActualizarAvisosCredito",
                "Se actualizaron correctamente los avisos de credito.",
                NivelMensajeLog.NINGUNO);
            }
            else
            {
                LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.ENVIO_OPERACION_BCOSMOS, strHashcode,
                "BL_EnvioBCosmos.ActualizarAvisosCredito",
                "No se puede actualizar los avisos de credito por problemas en la base de datos.",
                NivelMensajeLog.NINGUNO);
            }
        }

        /// <summary>
        /// Antes de enviar la contabilidad a BCosmos se eliminan los avisos de credito
        /// de fechas anteriores
        /// </summary>
        /// <param name="prmFecha">Fecha actual</param>
        private void EliminarAvisosCredito(string prmFecha)
        {
            DA_AvisoCredito oDAAvisoCredito = new DA_AvisoCredito(strHashcode);

            if (oDAAvisoCredito.Eliminar_Avisos_Credito_Anteriores(prmFecha))
            {
                LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.ENVIO_OPERACION_BCOSMOS, strHashcode,
                "BL_EnvioBCosmos.EliminarAvisosCredito",
                "Se eliminaron correctamente los avisos de credito anteriores.",
                NivelMensajeLog.NINGUNO);
            }
            else
            {
                LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.ENVIO_OPERACION_BCOSMOS, strHashcode,
                "BL_EnvioBCosmos.EliminarAvisosCredito",
                "No se puede eliminar los avisos de credito anteriores por problemas en la base de datos.",
                NivelMensajeLog.NINGUNO);
            }
        }

        /// <summary>
        /// Antes de enviar la contabilidad de una operacion se intenta
        /// insertar el aviso de credito, si falla no permitira enviar
        /// a BCosmos la operacion
        /// </summary>
        /// <param name="oBEAvisoCredito">Datos de avisos de credito</param>
        /// <returns>True=Envia operacion a BCosmos</returns>
        private bool InsertarAvisosCredito(BE_AvisoCredito oBEAvisoCredito)
        {
            DA_AvisoCredito oDAAvisoCredito = new DA_AvisoCredito(strHashcode);

            if (oDAAvisoCredito.Insertar_Aviso_Credito(oBEAvisoCredito))
            {
                LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.ENVIO_OPERACION_BCOSMOS, strHashcode,
                "BL_EnvioBCosmos.InsertarAvisosCredito",
                "Se inserto correctamente el aviso de credito de la operacion con referencia [" + oBEAvisoCredito.BcrpRef + "].",
                NivelMensajeLog.NINGUNO);

                return true;
            }
            else
            {
                LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.ENVIO_OPERACION_BCOSMOS, strHashcode,
                "BL_EnvioBCosmos.InsertarAvisosCredito",
                "No se puede enviar a BCOSMOS la operacion [" + oBEAvisoCredito.BcrpRef + 
                "] por problemas con la base de datos al insertar los avisos de credito.",
                NivelMensajeLog.NOTIFICACION);
            }

            return false;
        }

        #endregion

        #region Log Error

        /// <summary>
        /// Antes de enviar la contabilidad de una operacion se actualiza
        /// el log de errores referente a esa operacion
        /// </summary>
        /// <param name="prmBcrpRefer">Referencia de la operacion</param>
        /// <param name="prmFecha">Fecha actual</param>
        private void ActualizarLogError(string prmBcrpRefer, string prmFecha)
        {
            DA_ErroresOperaciones oDAErroresOperaciones = new DA_ErroresOperaciones(strHashcode);

            if (oDAErroresOperaciones.Actualizar_Log_Error(prmBcrpRefer, prmFecha))
            {
                LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.ENVIO_OPERACION_BCOSMOS, strHashcode,
                "BL_EnvioBCosmos.ActualizarLogError",
                "Se actualizo correctamente el log de errores de la operacion con referencia [" + prmBcrpRefer + "].",
                NivelMensajeLog.NINGUNO);
            }
            else
            {
                LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.ENVIO_OPERACION_BCOSMOS, strHashcode,
                "BL_EnvioBCosmos.ActualizarLogError",
                "No se puede actualizar el log de errores de la operacion con referencia [" + prmBcrpRefer + "].",
                NivelMensajeLog.NINGUNO);
            }
        }

        /// <summary>
        /// Si al enviar la trama de debito o credito de la operacion a BCosmos
        /// una o ambas fallan, se inserta en el log de errores la respuesta
        /// que retorna BCosmos
        /// </summary>
        /// <param name="prmRespBCosmos">Respuesta que retorna BCosmos</param>
        /// <param name="prmBcrpRefer">Referencia de la operacion</param>
        /// <param name="prmFecha">Fecha Actual</param>
        /// <param name="prmEsCredito">True=Si la trama es Credito / False=Si la trama es Debito</param>
        private void InsertarLogError(string prmRespBCosmos, string prmBcrpRefer, string prmFecha, bool prmEsCredito)
        {
            DA_EnvioBCosmos oDAEnvioBCosmos = new DA_EnvioBCosmos(strHashcode);
            DA_ErroresOperaciones oDAErroresOperaciones = new DA_ErroresOperaciones(strHashcode);

            string strDescripcionError = oDAEnvioBCosmos.Obtener_Error_BCosmos(prmRespBCosmos);

            string strMensajeError = string.Format("{0}_{1}", prmEsCredito ? "C" : "D", strDescripcionError);

            Int64 nCantidadErrores = oDAErroresOperaciones.Obtener_Cantidad_Log_Error(prmBcrpRefer);

            string strGrupo = nCantidadErrores > 0 ? "1" : "0";

            if (oDAErroresOperaciones.Insertar_Log_Error(prmBcrpRefer, prmFecha, strMensajeError, strGrupo))
            {
                LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.ENVIO_OPERACION_BCOSMOS, strHashcode,
                "BL_EnvioBCosmos.InsertarLogError",
                "Se inserto log de error al enviar a BCOSMOS la operacion con referencia [" + prmBcrpRefer + "].",
                NivelMensajeLog.NINGUNO);
            }
            else
            {
                LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.ENVIO_OPERACION_BCOSMOS, strHashcode,
                "BL_EnvioBCosmos.InsertarLogError",
                "No se puede insertar log de error al enviar a BCOSMOS la operacion con referencia [" + prmBcrpRefer + "].",
                NivelMensajeLog.NINGUNO);
            }
        }

        /// <summary>
        /// Si al enviar un asiento de la operacion a BCosmos
        /// existe una falla en comunicacion, se inserta en el log de errores la respuesta
        /// que retorna BCosmos
        /// </summary>
        /// <param name="prmBcrpRefer">Referencia de la operacion</param>
        /// <param name="prmFecha">Fecha Actual</param>
        /// <param name="strMensajeError">Mensaje de Error</param>
        private void InsertarLogError(string prmBcrpRefer, string strMensajeError)
        {
            DA_ErroresOperaciones oDAErroresOperaciones = new DA_ErroresOperaciones(strHashcode);

            Int64 nCantidadErrores = oDAErroresOperaciones.Obtener_Cantidad_Log_Error(prmBcrpRefer);

            string strGrupo = nCantidadErrores > 0 ? "1" : "0";

            if (oDAErroresOperaciones.Insertar_Log_Error(prmBcrpRefer, DateTime.Now.ToString("yyyyMMdd") , strMensajeError, strGrupo))
            {
                LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.ENVIO_OPERACION_BCOSMOS, strHashcode,
                "BL_EnvioBCosmos.InsertarLogError",
                "Se inserto log de error al enviar a BCOSMOS la operacion con referencia [" + prmBcrpRefer + "].",
                NivelMensajeLog.NINGUNO);
            }
            else
            {
                LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.ENVIO_OPERACION_BCOSMOS, strHashcode,
                "BL_EnvioBCosmos.InsertarLogError",
                "No se puede insertar log de error al enviar a BCOSMOS la operacion con referencia [" + prmBcrpRefer + "].",
                NivelMensajeLog.NINGUNO);
            }
        }
        #endregion

        #region Verificaciones

        private void VerificarFlagEnvioBCosmosPorMQ()
        {
            DA_General oDAGeneral = new DA_General(strHashcode);

            string strFlag1UsoAdes = oDAGeneral.Obtener_Param(Constantes.PARAM_CODIGO_BCOSMOS_FLAG1_USO_ADES);
            string strFlag2UsoAdes = oDAGeneral.Obtener_Param(Constantes.PARAM_CODIGO_BCOSMOS_FLAG2_USO_ADES);

            if ((strFlag1UsoAdes.Trim() == "1" && strFlag2UsoAdes.Trim() == "0") ||
                (strFlag1UsoAdes.Trim() == "0" && strFlag2UsoAdes.Trim() == "1"))
            {
                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.ENVIO_OPERACION_BCOSMOS, strHashcode,
                "BL_EnvioBCosmos.VerificarFlagEnvioBCosmosPorMQ",
                "Los flags de envio por ADES Web NO estan configurados correctamente. Actualizar los parámetros 0130 y 0131 en el mantenimiento de parámetros.",
                NivelMensajeLog.NOTIFICACION);
            }
        }

        /// <summary>
        /// Verifica si el envio de BCosmos se realiza por el servicio MQ
        /// o por ADES Web, para ello, se obtienen los flags en la tabla 
        /// T_PARAM, si estan ambos flags en "1" quiere
        /// decir que esta activo el envio por BCosmos por ADES Web.
        /// </summary>
        /// <returns>True=Envio a BCosmos por MQ esta activo</returns>
        private bool VerificarEnvioBCosmosPorMQ()
        {
            DA_General oDAGeneral = new DA_General(strHashcode);

            string strFlag1UsoAdes = oDAGeneral.Obtener_Param(Constantes.PARAM_CODIGO_BCOSMOS_FLAG1_USO_ADES);
            string strFlag2UsoAdes = oDAGeneral.Obtener_Param(Constantes.PARAM_CODIGO_BCOSMOS_FLAG2_USO_ADES);

            if (strFlag1UsoAdes.Trim() == "0" || strFlag2UsoAdes.Trim() == "0")
            {
                LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.ENVIO_OPERACION_BCOSMOS, strHashcode,
                "BL_EnvioBCosmos.VerificarEnvioBCosmosPorMQ",
                "El servicio de BCOSMOS por MQ se encuentra habilitado, se puede enviar la contabilidad a BCOSMOS.",
                NivelMensajeLog.NINGUNO);
                return true;
            }
            else
            {
                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.ENVIO_OPERACION_BCOSMOS, strHashcode,
                "BL_EnvioBCosmos.VerificarEnvioBCosmosPorMQ",
                "El servicio de BCOSMOS por MQ se encuentra deshabilitado. El envio de las operaciones a BCOSMOS se esta realizando por ADES WEB.",
                NivelMensajeLog.NOTIFICACION);
            }

            return false;
        }

        /// <summary>
        /// Verifica si un usuario esta modificando el tipo de cambio
        /// en BCosmos, para ello se obtienen un flag en la tabla
        /// T_PARAM, si esta el flag en "1" quiere decir que se
        /// esta actualizando el tipo de cambio y el servicio LBTR
        /// no enviara tramas a BCosmos por MQ
        /// </summary>
        /// <returns>True=Envio a BCosmos por MQ esta activo</returns>
        private bool VerificarActualizacionTipoCambio()
        {
            DA_EnvioBCosmos oDAEnvioBCosmos = new DA_EnvioBCosmos(strHashcode);

            bool blnActualizando = oDAEnvioBCosmos.Verificar_Tipo_Cambio_BCosmos();

            if (!blnActualizando)
            {
                LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.ENVIO_OPERACION_BCOSMOS, strHashcode,
                "BL_EnvioBCosmos.VerificarActualizacionTipoCambio",
                "El tipo de cambio de BCOSMOS no se esta actualizando por el momento, se puede enviar la contabilidad a BCOSMOS.",
                NivelMensajeLog.NINGUNO);
                return true;
            }
            else
            {
                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.ENVIO_OPERACION_BCOSMOS, strHashcode,
                "BL_EnvioBCosmos.VerificarActualizacionTipoCambio",
                "El servicio de BCOSMOS por MQ se encuentra deshabilitado. El tipo de cambio de BCOSMOS esta siendo actualizado.",
                NivelMensajeLog.NOTIFICACION);
            }

            return false;
        }

        /// <summary>
        /// Verifica que se haya realizado la apertura del batch
        /// en el servicio MQ. Si esta no se ha realizado el servicio
        /// LBTR no permitira enviar tramas a BCosmos
        /// </summary>
        /// <returns>True=Envio a BCosmos por MQ esta activo</returns>
        private bool VerificarEstadoDeBatch()
        {
            DA_General oDAGeneral = new DA_General(strHashcode);

            string strEstadoBatch = oDAGeneral.Obtener_Param(Constantes.PARAM_CODIGO_BCOSMOS_ESTADO_BATCH);

            if (strEstadoBatch == Constantes.INDICADOR_APERTURA_BATCH)
            {
                LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.ENVIO_OPERACION_BCOSMOS, strHashcode,
                "BL_EnvioBCosmos.VerificarEstadoDeBatch",
                "El batch se encuentra aperturado correctamente, se puede enviar la contabilidad a BCOSMOS.",
                NivelMensajeLog.NINGUNO);
                return true;
            }

            return false;
        }

        /// <summary>
        /// Verifica que existan conceptos que se envien a BCosmos
        /// y si estos tienen una cuenta tramite configurada 
        /// (la cuenta tramite permite generar la trama de debito)
        /// </summary>
        /// <returns>True=Envio a BCosmos por MQ esta activo</returns>
        private bool VerificarConceptos()
        {
            DA_EnvioBCosmos oDAEnvioBCosmos = new DA_EnvioBCosmos(strHashcode);

            if (oDAEnvioBCosmos.Verificar_Conceptos_BCosmos() > 0)
            {
                LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.ENVIO_OPERACION_BCOSMOS, strHashcode,
                "BL_EnvioBCosmos.VerificarConceptos",
                "Los conceptos se encuentran configurados correctamente, se puede enviar la contabilidad a BCOSMOS.",
                NivelMensajeLog.NINGUNO);
                return true;
            }
            else
            {
                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.ENVIO_OPERACION_BCOSMOS, strHashcode,
                "BL_EnvioBCosmos.VerificarConceptos",
                "No se puede enviar la contabilidad a BCOSMOS, ya que no existen conceptos configurados.",
                NivelMensajeLog.NOTIFICACION);
            }

            return false;
        }

        #endregion

        /// <summary>
        /// Permite obtener las operaciones recibidas listas para
        /// enviarse a contabilizar, para ello las operaciones
        /// tienen que tener el flag ADES=1 y GENEROADES=0
        /// </summary>
        /// <param name="prmFecha">Fecha actual</param>
        /// <param name="lstEnvioBCosmos">Lista de operaciones recibidas a contabilizar</param>
        /// <returns>True=Existen operaciones que recorrer</returns>
        public bool ObtenerOperacionesRecibidasAEnviarABCosmos(string prmFecha, ref List<BE_EnvioBCosmos> lstEnvioBCosmos)
        {
            DA_EnvioBCosmos oDAEnvioBCosmos = new DA_EnvioBCosmos(strHashcode);
            DA_General oDAGeneral = new DA_General(strHashcode);
            DA_ErroresOperaciones oDAErroresOperaciones = new DA_ErroresOperaciones(strHashcode);
            String strparametriFlag = string.Empty;

            //TODO: jr72296 estas operaciones deben marcarse como error.
            List<BE_EnvioBCosmos> lstEnvioBCosmosCustomer = new List<BE_EnvioBCosmos>();

            lstEnvioBCosmos = oDAEnvioBCosmos.Obtener_Operaciones_A_Enviar_BCosmos(prmFecha);

            if (lstEnvioBCosmos == null)
            {
                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.ENVIO_OPERACION_BCOSMOS, strHashcode,
                "BL_EnvioBCosmos.ObtenerOperacionesRecibidasAEnviarABCosmos",
                "No se obtuvo operaciones pendientes de contabilizar por problemas en la base de datos.",
                NivelMensajeLog.NOTIFICACION);
            }
            else if (lstEnvioBCosmos.Count == 0)
            {
                LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.ENVIO_OPERACION_BCOSMOS, strHashcode,
                "BL_EnvioBCosmos.ObtenerOperacionesRecibidasAEnviarABCosmos",
                "No existen operaciones pendientes de contabilizar.",
                NivelMensajeLog.NINGUNO);
            }
            else
            {
               int nFlag = 0;
               strparametriFlag= oDAGeneral.Obtener_Param("0143");

               LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.ENVIO_OPERACION_BCOSMOS, strHashcode,
                "BL_EnvioBCosmos.ObtenerOperacionesRecibidasAEnviarABCosmos",
                "El valor del flag de contabilidad Divestiture es:" + strparametriFlag,
                   NivelMensajeLog.NINGUNO);

               if (!string.IsNullOrEmpty(strparametriFlag))
               {
                   nFlag = Convert.ToInt32(strparametriFlag);

                   if (nFlag == 1)
                   {
                       LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.ENVIO_OPERACION_BCOSMOS, strHashcode,
                          "BL_EnvioBCosmos.ObtenerOperacionesRecibidasAEnviarABCosmos",
                          "Entro a la condiccion Falg==1:",
                             NivelMensajeLog.NINGUNO);

                       lstEnvioBCosmosCustomer = lstEnvioBCosmos.FindAll(x => x.Entidad == "2");
                       lstEnvioBCosmos.RemoveAll(x => x.Entidad == "2");

                       if (lstEnvioBCosmosCustomer != null)
                       {
                           if (lstEnvioBCosmosCustomer.Count > 0)
                           {
                               foreach(BE_EnvioBCosmos oBEEnvioBCosmos in lstEnvioBCosmosCustomer)
                               {
                                    oDAErroresOperaciones.Obtener_Cantidad_Log_Error(oBEEnvioBCosmos.BcrpRefer);

                                   if (oDAErroresOperaciones.Obtener_Cantidad_Log_Error(oBEEnvioBCosmos.BcrpRefer) < 1)
                                   {
                                       oDAGeneral.Insertar_Log_Error(oBEEnvioBCosmos.BcrpRefer, "Operacion de Tipo Consumo, No se contabilizan segun parametro (Flag)", TipoError.WARNING, true);
                                   }
                               }
                           }
                       }
                   }
               }
                //TODO Jr72296
                //filtrar las operaciones tipo Customer, segun parametro.

                LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.ENVIO_OPERACION_BCOSMOS, strHashcode,
                "BL_EnvioBCosmos.ObtenerOperacionesRecibidasAEnviarABCosmos",
                "Existen operaciones pendientes de contabilizar.",
                NivelMensajeLog.NINGUNO);
                return true;
            }

            return false;
        }

        /// <summary>
        /// Permite actualizar el flags GENEROADES=1 de la 
        /// operaciones que se enviara a BCosmos para que
        /// a la proxima iteracion esta ya no se vuelva a enviar
        /// </summary>
        /// <param name="prmBcrpRefer">Referencia de operacion</param>
        /// <param name="prmGeneroAdes">Flag</param>
        /// <param name="prmFechaHora">Fecha y hora actual en formato entero</param>
        /// <returns></returns>
        private bool ActualizarOperacionesAEnviarABCosmos(string prmBcrpRefer, string prmGeneroAdes, Int64 prmFechaHora)
        {
            DA_EnvioBCosmos oDAEnvioBCosmos = new DA_EnvioBCosmos(strHashcode);

            if (oDAEnvioBCosmos.Actualizar_Operaciones_Enviadas_BCosmos(prmBcrpRefer, prmGeneroAdes, prmFechaHora))
            {
                LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.ENVIO_OPERACION_BCOSMOS, strHashcode,
                "BL_EnvioBCosmos.ActualizarOperacionesAEnviarABCosmos",
                "Se actualizo correctamente la operacion con referencia [" + prmBcrpRefer + "] que se enviara a BCOSMOS.",
                NivelMensajeLog.NINGUNO);

                return true;
            }
            else
            {
                LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.ENVIO_OPERACION_BCOSMOS, strHashcode,
                "BL_EnvioBCosmos.ActualizarOperacionesAEnviarABCosmos",
                "No se puede enviar a BCOSMOS la operacion [" + prmBcrpRefer + 
                "] por problemas en base de batos. Se intentara enviar la la operacion a BCosmos al restablecer la base de datos.",
                NivelMensajeLog.NOTIFICACION);
            }

            return false;
        }

        /// <summary>
        /// Permite actualizar los flags ESTADOCREDITO=1 ESTADODEBITO=1 CONFIRABONO=1
        /// si el envio y respuesta de BCosmos se realizo correctamente
        /// para que este lista para el proceso de confirmacion de abono
        /// </summary>
        /// <param name="prmBcrpRefer">Referencia de la operacion</param>
        /// <param name="prmEstadoDebito">Flag debito</param>
        /// <param name="prmEstadoCredito">Flag credito</param>
        /// <param name="prmConfirmAbono">Flg Confirmacion de abono</param>
        private void ActualizarOperacionesDevueltasPorBCosmos(string prmBcrpRefer, string prmEstadoDebito, string prmEstadoCredito, string prmConfirmAbono)
        {
            DA_EnvioBCosmos oDAEnvioBCosmos = new DA_EnvioBCosmos(strHashcode);

            if (oDAEnvioBCosmos.Actualizar_Operaciones_Devueltas_BCosmos(prmBcrpRefer, prmEstadoDebito, prmEstadoCredito, prmConfirmAbono))
            {
                LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.ENVIO_OPERACION_BCOSMOS, strHashcode,
                "BL_EnvioBCosmos.ActualizarOperacionesDevueltasPorBCosmos",
                "Se actualizo correctamente la operacion recibida con referencia [" + prmBcrpRefer + "].",
                NivelMensajeLog.NINGUNO);
            }
            else
            {
                LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.ENVIO_OPERACION_BCOSMOS, strHashcode,
                "BL_EnvioBCosmos.ActualizarOperacionesDevueltasPorBCosmos",
                "No se puede actualizar la operacion recibida con referencia [" + prmBcrpRefer + "].",
                NivelMensajeLog.NINGUNO);
            }
        }

        /// <summary>
        /// Enviar operaciones CORE a usuarios del negocio.
        /// Verificar que flag este activo para enviar correo
        /// </summary>
        /// <param name="prmBcrpRefer">Referencia de operacion</param>
        private void EnviarEmailDeConfirmacionDeOperacion(string prmBcrpRefer)
        {
            DA_General oDAGeneral = new DA_General(strHashcode);
            DA_EnvioBCosmos oDAEnvioBCosmos = new DA_EnvioBCosmos(strHashcode);

            string strEnvioEmailOpe = oDAGeneral.Obtener_Param(Constantes.PARAM_CODIGO_BCOSMOS_EMAIL_OPE);

            if (strEnvioEmailOpe == "1")
            {
                BE_DatosOperacion oOperacion = oDAEnvioBCosmos.Obtener_Datos_Operaciones_Recibidas(prmBcrpRefer);

                if (oOperacion != null)
                {
                    if (oOperacion.BcrpRefer != null)
                    {
                        StringBuilder sbMensaje = new StringBuilder();
                        sbMensaje.AppendLine("El abono de la transferencia se realizo exitosamente.");
                        sbMensaje.AppendLine("");
                        sbMensaje.AppendLine("Refer.Bcr: " + oOperacion.BcrpRefer);
                        //sbMensaje.AppendLine(oOperacion.BcrpRefer);
                        sbMensaje.AppendLine("Fecha.Oper: " + oOperacion.Fecha);
                        //sbMensaje.AppendLine(oOperacion.Fecha);
                        sbMensaje.AppendLine("Hora.Oper: " + oOperacion.Hora);
                        //sbMensaje.AppendLine(oOperacion.Hora);
                        sbMensaje.AppendLine("Bco.Orig: " + oOperacion.BcoOrig);
                        //sbMensaje.AppendLine(oOperacion.BcoOrig);
                        sbMensaje.AppendLine("Moneda: " + oOperacion.Moneda);
                        //sbMensaje.AppendLine(oOperacion.Moneda);
                        sbMensaje.AppendLine("Monto: " + oOperacion.Monto);
                        //sbMensaje.AppendLine(oOperacion.Monto);
                        sbMensaje.AppendLine("Oper.Cta: " + oOperacion.OperCta);
                        //sbMensaje.AppendLine(oOperacion.OperCta);
                        sbMensaje.AppendLine("Clasificacion: " + oOperacion.Clasificacion);
                        //sbMensaje.AppendLine(oOperacion.Clasificacion);
                        sbMensaje.AppendLine("Concepto: " + oOperacion.Concepto);
                        //sbMensaje.AppendLine(oOperacion.Concepto);
                        //sbMensaje.AppendLine("Ordenante: " + oOperacion.Ordenante);
                        sbMensaje.AppendLine("Ordenante: " + oOperacion.Ordenante + Environment.NewLine);//mod por WZ
                        //sbMensaje.AppendLine(oOperacion.Ordenante);                        
                        //sbMensaje.AppendLine("Tipo Doc.Beneficiario: " + oOperacion.TipoDocBeneficiario.ToString().Trim());//agregado por WZ
                        sbMensaje.AppendLine("Tipo Doc.Beneficiario: " + oOperacion.TipoDocBeneficiario.ToString().Trim() + Environment.NewLine);//mod por WZ
                        //sbMensaje.AppendLine(oOperacion.TipoDocBeneficiario);          
                        sbMensaje.AppendLine("Numero Doc.Beneficiario: " + oOperacion.NumDocBeneficiario);//agregado por WZ
                        //sbMensaje.AppendLine(oOperacion.NumDocBeneficiario);
                        sbMensaje.AppendLine("Beneficiario: " + oOperacion.Beneficiario);
                        //sbMensaje.AppendLine(oOperacion.Beneficiario); 
                        sbMensaje.AppendLine("CCI: " + oOperacion.CciBeneficiario);
                        //sbMensaje.AppendLine(oOperacion.CciBeneficiario);
                        sbMensaje.AppendLine("Bco.Orig.Ref: " + oOperacion.BcoOrigRef);
                        //sbMensaje.AppendLine(oOperacion.BcoOrigRef);
                        sbMensaje.AppendLine("Bco.Orig.Ref.Sec: " + oOperacion.BcoOrigRefSec);                     
                        //sbMensaje.AppendLine(oOperacion.CciBeneficiario);
                        sbMensaje.AppendLine("Referencia TBE: " + oOperacion.RefTBE);//agregado por WZ
                        //sbMensaje.AppendLine(oOperacion.RefTBE);
                        sbMensaje.AppendLine("Observaciones: " + oOperacion.Observacion);//agregado por WZ
                        //sbMensaje.AppendLine(oOperacion.Observacion);
                        sbMensaje.AppendLine("Indicador ITF: " + (oOperacion.IndicadorItf.Trim().ToUpper() == "N" ? "SI" : "NO").ToString());
                        //sbMensaje.AppendLine(oOperacion.IndicadorItf.Trim().ToUpper() == "N" ? "SI" : "NO");

                        sbMensaje.AppendLine("");
                        sbMensaje.Append("*******************************************************************************************");                        
                        Globales.MAIL_NOTIFICACION_PARA_BD = oDAGeneral.Obtener_Correo("0002");

                        LogWriter.Notificar(strHashcode, sbMensaje.ToString(), NivelMensajeLog.NOTIFICACION);

                        Globales.MAIL_NOTIFICACION_PARA_BD = oDAGeneral.Obtener_Correo("0001");

                        LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.ENVIO_OPERACION_BCOSMOS, strHashcode,
                        "BL_EnvioBCosmos.EnviarEmailDeConfirmacionDeOperacion",
                        "Se envio email correctamente con las operaciones a los usuarios del negocio.",
                        NivelMensajeLog.NINGUNO);
                    }
                }
                else
                {
                    LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.ENVIO_OPERACION_BCOSMOS, strHashcode,
                    "BL_EnvioBCosmos.EnviarEmailDeConfirmacionDeOperacion",
                    "No se obtuvo operacion que notificar por email a los usuarios del negocio.",
                    NivelMensajeLog.NINGUNO);
                }
            }
            else
            {
                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.ENVIO_OPERACION_BCOSMOS, strHashcode,
                "BL_EnvioBCosmos.EnviarEmailDeConfirmacionDeOperacion",
                "El envio de email a los usuarios del negocio con las transferencias no esta habilitado. Verificar mantenimiento de parametros.",
                NivelMensajeLog.NINGUNO);
            }
        }
    }
}
