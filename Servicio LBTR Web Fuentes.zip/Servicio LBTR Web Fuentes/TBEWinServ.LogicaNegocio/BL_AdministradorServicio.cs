using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using TBEWinServ.EntidadesNegocio.Generales;

namespace TBEWinServ.LogicaNegocio
{
    public class BL_AdministradorServicio
    {
        private string strRutaArchivoServicios;

        public BL_AdministradorServicio(string prmRutaArchivoServicios) {
            strRutaArchivoServicios = prmRutaArchivoServicios;
        }

        public List<BE_Servicio> LeerServiciosXML()
        {
            XmlTextReader reader = null;
            List<BE_Servicio> lstServicios = new List<BE_Servicio>();
            BE_Servicio oServicio = null;

            try
            {
                reader = new XmlTextReader(strRutaArchivoServicios);

                while (reader.Read())
                {

                    if (reader.NodeType == XmlNodeType.Element)
                    {
                        if (reader.Name == "Servicio")
                        {
                            oServicio = new BE_Servicio();
                            oServicio.Codigo = reader.GetAttribute("Codigo");
                            oServicio.Nombre = reader.GetAttribute("Nombre");

                            if (reader.GetAttribute("Habilitado").ToLower() == "true")
                                oServicio.Habilitado = true;
                            else
                                oServicio.Habilitado = false;

                            lstServicios.Add(oServicio);
                        }
                    }

                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally {
                if (reader != null) reader.Close();           
            }

            return lstServicios;
        }

        public void ActualizarServicioXML(BE_Servicio prmServicio)
        {
            XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.PreserveWhitespace = true;
            xmlDoc.Load(strRutaArchivoServicios);

            XmlNode node = xmlDoc.SelectSingleNode("/Servicios/Servicio[@Codigo='" + prmServicio.Codigo + "']");

            if (prmServicio.Habilitado)
                node.Attributes.GetNamedItem("Habilitado").InnerText = "True";
            else
                node.Attributes.GetNamedItem("Habilitado").InnerText = "False";
                                                
            xmlDoc.Save(strRutaArchivoServicios);
        }

        /*public void ActualizarHoraFinalizacion(string prmHora)
        {
            XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.PreserveWhitespace = true;
            xmlDoc.Load(strRutaArchivoServicios);

            XmlNode node = xmlDoc.SelectSingleNode("/Servicios");

            node.Attributes.GetNamedItem("HoraFinalizacion").InnerText = prmHora;

            xmlDoc.Save(strRutaArchivoServicios);
        }

        public string ObtenerHoraFinalizacion() {
            XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.PreserveWhitespace = true;
            xmlDoc.Load(strRutaArchivoServicios);

            XmlNode node = xmlDoc.SelectSingleNode("/Servicios");

            return node.Attributes.GetNamedItem("HoraFinalizacion").InnerText;
        } */              

    }

}
