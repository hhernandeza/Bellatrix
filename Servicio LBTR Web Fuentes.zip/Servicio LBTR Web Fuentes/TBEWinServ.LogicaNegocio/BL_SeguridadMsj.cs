using System;
using System.Collections.Generic;
using System.Configuration;
using System.Text;
using System.Xml;
using System.IO;
using TBEWinServ.AccesoDatos;
using TBEWinServ.EntidadesNegocio.Transferencia;
using TBEWinServ.EntidadesNegocio.OperacionesRecibidas;
using TBEWinServ.EntidadesNegocio.ConsultasBCRP;
using TBEWinServ.EntidadesNegocio.Generales;
using TBEWinServ.EntidadesNegocio.Auditoria;
using TBEWinServ.EntidadesNegocio.CompraVenta;
using TBEWinServ.Utilitarios;
using TBEWinServ.Componentes.LBTRTransferenciaService;
using TBEWinServ.Componentes.LBTRCompraVentaService;
using TBEWinServ.ObjetosGlobales;
using secapiwnd;

namespace TBEWinServ.LogicaNegocio
{
    public class BL_SeguridadMsj
    {
        private string strHashcode = null;

        public BL_SeguridadMsj(string prmHashcode)
        {
            strHashcode = prmHashcode;
        }

        public String ManejarErrorApiSeguridad(String prmNombreFuncionApi, int prmCodigoError)
        {
            BE_ErrorApiSeguridad oErrorApi = null;

            return ManejarErrorApiSeguridad(prmNombreFuncionApi, prmCodigoError, ref oErrorApi);
        }

        private String ManejarErrorApiSeguridad(String prmNombreFuncionApi, 
                                                int prmCodigoError, 
                                                ref BE_ErrorApiSeguridad prmErrorApi)
        {
            string strMensajeError = "";
            BL_General oBLGen = new BL_General(strHashcode);
            //Si hubiese algun error al tratar de obtener el error desde el xml
            //el strMensajeError tendria el detalle y ademas el error retornado seria null
            prmErrorApi = oBLGen.ObtenerErrorApiSeguridad(prmNombreFuncionApi,
                                                            prmCodigoError.ToString(),
                                                            out strMensajeError);

            if (prmErrorApi != null)
            {
                strMensajeError = prmErrorApi.ToString();
            }

            return strMensajeError;
        }

        public securityAPI Conectar_a_BaseDatos()
        {
            int nCodigoRetorno = -1;
            securityAPI oApiSeg = null;
            string strMensajeError = "";

            try
            {
                string strTipoRepositorioClaves = ConfigurationManager.AppSettings["TIPO_REPOSITORIO_CLAVE"];
                string strServidor = ConfigurationManager.AppSettings["SERVIDOR_SIXSEC"];
                string strBaseDatos = ConfigurationManager.AppSettings["BASE_DATOS_SIXSEC"];
                string strUsuarioBD = strTipoRepositorioClaves == TipoRepositorioClaves.PSAFE ? ConfigurationManager.AppSettings["USUARIOBD_SIXSEC"] : ConfigurationManager.AppSettings["USUARIOBD_SIXSEC_PAR"];
                string strClaveBD = Globales.PASSWORD_BD_MSSQL;

                //Verificando si se esta usando en la cadena de conexion los datos de contingencia.
                //Si se estuvieran usando, entonces, el api deberia conectar usando el usuario y password de contingencia
                if (!String.IsNullOrEmpty(Globales.CONTING_BD_USER_SYBASE) && !String.IsNullOrEmpty(Globales.CONTING_BD_PWD_SYBASE)
                    && !String.IsNullOrEmpty(Globales.CONTING_BD_USER_MSSQL) && !String.IsNullOrEmpty(Globales.CONTING_BD_PWD_MSSQL)
                    )
                {
                    if (!String.IsNullOrEmpty(Globales.CADENA_CONEXION))
                    {
                        if (Globales.CADENA_CONEXION.Contains(Globales.CONTING_BD_USER_MSSQL) &&
                            Globales.CADENA_CONEXION.Contains(Globales.CONTING_BD_PWD_MSSQL))
                        {
                            LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.SEGURIDAD, strHashcode,
                                "BL_SeguridadMsj.Conectar_a_BaseDatos",
                                "Se procede a usar los datos de contingencia para conectar el API de seguridad.", false);
                            strUsuarioBD = Globales.CONTING_BD_USER_MSSQL;
                            strClaveBD = Globales.CONTING_BD_PWD_MSSQL;
                            Globales.APISEC_CONECTADA_CONTINGENCIA = true;
                        }
                    }
                }

                LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.SEGURIDAD, strHashcode,
                    "BL_SeguridadMsj.Conectar_a_BaseDatos",
                    "Se invoca fConectar_BaseDatos con los parametros: " + strServidor + "; " + strBaseDatos +
                    "; " + strUsuarioBD /*+ "; " + strClaveBD*/, false);

                //Antes de inicializar y conectar, verificamos si los datos de conexion estan completos
                if (String.IsNullOrEmpty(strUsuarioBD))
                {
                    LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.SEGURIDAD, strHashcode,
                        "BL_SeguridadMsj.Conectar_a_BaseDatos",
                        "El usuario de bd para conectarse a la bd del api de seguridad esta vacio. No se inicializa el API.", false);
                    return null;
                }

                if (String.IsNullOrEmpty(strClaveBD))
                {
                    LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.SEGURIDAD, strHashcode,
                        "BL_SeguridadMsj.Conectar_a_BaseDatos",
                        "El password de bd para conectarse a la bd del api de seguridad esta vacio. No se inicializa el API.", false);
                    return null;
                }
                
                oApiSeg = new securityAPI();

                nCodigoRetorno = oApiSeg.fConectar_BaseDatos(strServidor, strBaseDatos, strUsuarioBD, strClaveBD);

                if (nCodigoRetorno != 0)
                {
                    strMensajeError = this.ManejarErrorApiSeguridad("fConectar_BaseDatos", nCodigoRetorno);
                }
            }
            catch (Exception ex)
            {
                strMensajeError = "Error, " + ex.Message + ". " + ex.StackTrace;
            }

            if (!String.IsNullOrEmpty(strMensajeError))
            {
                oApiSeg = null;

                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SEGURIDAD, strHashcode,
                    "BL_SeguridadMsj.Conectar_a_BaseDatos",
                    strMensajeError, true);
            }
            else
            {
                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SEGURIDAD, strHashcode,
                    "BL_SeguridadMsj.Conectar_a_BaseDatos",
                    "Se establecio conexion a la base de datos del api de seguridad.", false);            
            }

            return oApiSeg;
        }

        /// <summary>
        /// Usado para confirmacion de abono y 
        /// anulacion de operacion pendiente (transferencia realizada en estado pendiente)
        /// </summary>
        /// <param name="prmNumRefLBTR"></param>
        /// <returns></returns>
        public string GenerarFirma(bool prmUsarFlagVerificacion, string prmNumRefLBTR, out string prmMensajeError)
        {
            prmMensajeError = "";
            string strFirma = string.Empty;
            string strDatosEnClaro = string.Empty;
            string strMensajeError = "";

            try
            {
                if (String.IsNullOrEmpty(prmNumRefLBTR))
                {
                    throw new Exception("El parametro recibido NumRefLBTR es vacio.");
                }
                else
                {
                    strDatosEnClaro = prmNumRefLBTR.Trim() + Globales.SID;
                }

                //se genera la firma
                if (Globales.APISEGURIDAD_USAR)
                {
                    if (prmUsarFlagVerificacion) 
                    {
                        Globales.THRCONFABONO_BLNAPIINVOCADO = true;
                        Globales.THRCONFABONO_DTULTINVOCAPI = DateTime.Now;
                    }
                    this.VerificarConexionActual();
                    if (prmUsarFlagVerificacion)
                    {
                        Globales.THRCONFABONO_BLNAPIINVOCADO = false;
                    }

                    if (ObjetosGlobalesApp.objAPISEG != null)
                    {
                        //llave pri del citi
                        BL_General oBLGen = new BL_General(strHashcode);
                        string strCodigoCiti = null;
                        BE_Banco oBanco = null;
                        List<BE_Banco> lstBancos = null;

                        strCodigoCiti = oBLGen.ObtenerValorConfiguracion(Constantes.PARAM_CODIGO_CITIBANK);

                        lstBancos = oBLGen.ObtenerBancos(new BE_Banco(strCodigoCiti));

                        if (lstBancos != null && lstBancos.Count > 0)
                        {
                            //Banco Citi
                            oBanco = lstBancos[0];

                            //Si tiene indice de clave primaria
                            if (oBanco.IndiceKPri.HasValue)
                            {
                                if (prmUsarFlagVerificacion)
                                {
                                    Globales.THRCONFABONO_BLNAPIINVOCADO = true;
                                    Globales.THRCONFABONO_DTULTINVOCAPI = DateTime.Now;
                                }
                                int nCodigoRetorno = ObjetosGlobalesApp.objAPISEG.fGeneraFirma_RSA(Constantes.APISEGURIDAD_METODOHASH,
                                                                                strDatosEnClaro,
                                                                                strCodigoCiti,
                                                                                oBanco.IndiceKPri.Value,
                                                                                ref strFirma);
                                if (prmUsarFlagVerificacion)
                                {
                                    Globales.THRCONFABONO_BLNAPIINVOCADO = false;
                                }

                                LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.SEGURIDAD, strHashcode,
                                    "BL_SeguridadMsj.GenerarFirma",
                                    "Se ejecuto el paso de generacion de firma de mensaje. fGeneraFirma_RSA\r\n" +
                                    "Metodo Hash: [" + Constantes.APISEGURIDAD_METODOHASH.ToString() + "]\r\n" +
                                    "Data Entrada: [" + (Globales.MOSTRAR_SID_LOG_TRAZA ? strDatosEnClaro : strDatosEnClaro.Replace(Globales.SID, "**********")) + "]\r\n" +
                                    "Codigo Inst: [" + strCodigoCiti + "]\r\n" +
                                    "ind. clave: [" + oBanco.IndiceKPri.Value.ToString() + "]\r\n" +
                                    "firma generada: [" + strFirma + "]", false);

                                if (nCodigoRetorno != 0)
                                {
                                    strMensajeError = this.ManejarErrorApiSeguridad("fGeneraFirma_RSA", nCodigoRetorno);
                                }
                            }
                            else
                            {
                                strMensajeError = "El banco " + oBanco.NomBancoBCR + " no tiene un indice de clave privada asignada.";
                            }
                        }
                        else
                        {
                            strMensajeError = "No se encontro el banco con codigo: " + strCodigoCiti;
                        }
                    }
                    else
                    {
                        strMensajeError = "La instancia del objeto global del API de seguridad no ha podido ser establecida.";
                    }

                }
                else
                {
                    strFirma = "firmaprueba";
                }
            }
            catch (Exception ex)
            {
                strFirma = null;
                strMensajeError = "Error, " + ex.Message + ". " + ex.StackTrace;
            }

            if (!String.IsNullOrEmpty(strMensajeError))
            {
                prmMensajeError = strMensajeError;

                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SEGURIDAD, strHashcode,
                    "BL_SeguridadMsj.GenerarFirma",
                    strMensajeError, true);
            }

            return strFirma;
        }

        /// <summary>
        /// Usado para el servicio de autenticacion al BCRP
        /// </summary>
        /// <param name="prmCodigo"></param>
        /// <param name="prmPassword"></param>
        /// <param name="prmPwdCifrado"></param>
        /// <param name="prmKsimCifrado"></param>
        /// <returns></returns>
        public string GenerarFirma(string prmCodigo, string prmPassword, 
                                    out string prmPwdCifrado, out string prmKsimCifrado)
        {
            string strMensajeError = null;
            string strFirma = string.Empty;
            prmPwdCifrado = string.Empty;
            prmKsimCifrado = string.Empty;

            try
            {
                if (Globales.APISEGURIDAD_USAR)
                {
                    Globales.THRINICIODIA_BLNAPIINVOCADO = true;
                    Globales.THRINICIODIA_DTULTINVOCAPI = DateTime.Now;
                    this.VerificarConexionActual();
                    Globales.THRINICIODIA_BLNAPIINVOCADO = false;

                    if (ObjetosGlobalesApp.objAPISEG != null)
                    {
                        List<BE_Banco> lstBancos = null;
                        BE_Banco oBancoBCRP = null;
                        BE_Banco oBancoCiti = null;
                        BL_General oBLGen = new BL_General(strHashcode);
                        string strCodigoBCRP = oBLGen.ObtenerValorConfiguracion(Constantes.PARAM_CODIGO_BCRP);

                        lstBancos = oBLGen.ObtenerBancos(new BE_Banco());

                        if (lstBancos != null && lstBancos.Count > 0)
                        {
                            oBancoBCRP = lstBancos.Find(delegate(BE_Banco oBancoParamBCRP) { return oBancoParamBCRP.CodBanco == strCodigoBCRP; });
                            oBancoCiti = lstBancos.Find(delegate(BE_Banco oBancoParamCiti) { return oBancoParamCiti.CodBanco == prmCodigo; });

                            if (oBancoBCRP == null)
                            {
                                strMensajeError = "El banco BCRP con codigo " + strCodigoBCRP + " no esta registrado en la base datos.";
                            }
                            else if (oBancoCiti == null)
                            {
                                strMensajeError = "El banco Citibank con codigo " + prmCodigo + " no esta registrado en la base datos.";
                            }
                            else
                            {
                                if (!oBancoBCRP.IndiceKPub.HasValue)
                                {
                                    strMensajeError = "El banco BCRP no tiene un indice de clave publica asignada.";
                                }
                                else if (!oBancoCiti.IndiceKPri.HasValue)
                                {
                                    strMensajeError = "El banco Citibank no tiene un indice de clave privada asignada.";
                                }
                                else
                                {
                                    Globales.THRINICIODIA_BLNAPIINVOCADO = true;
                                    Globales.THRINICIODIA_DTULTINVOCAPI = DateTime.Now;
                                    string strFuncionApiEmpleada = "fCifrarMensaje_3DES_RSA";
                                    int nCodigoRetorno = ObjetosGlobalesApp.objAPISEG.fCifrarMensaje_3DES_RSA(prmPassword,
                                                                                                strCodigoBCRP,
                                                                                                oBancoBCRP.IndiceKPub.Value,
                                                                                                ref prmPwdCifrado,
                                                                                                ref prmKsimCifrado);
                                    Globales.THRINICIODIA_BLNAPIINVOCADO = false;

                                    LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.SEGURIDAD,
                                        strHashcode,
                                        "BL_SeguridadMsj.GenerarFirma",
                                        "Se invoca el metodo fCifrarMensaje_3DES_RSA del api, con los siguientes parametros:" +
                                        "Codigo Inst. Destino: " + strCodigoBCRP + "\r\n" +
                                        "Ind. Clave Publica Destino: " + oBancoBCRP.IndiceKPub.Value.ToString() + "\r\n" +
                                        "Pwd Cifrado retornado: " + prmPwdCifrado + "\r\n" +
                                        "KSim Cifrado retornado: " + prmKsimCifrado + "\r\n" +
                                        "Tamanho KSim: " + prmKsimCifrado.Length.ToString(), false);

                                    if (nCodigoRetorno == 0)
                                    {
                                        //se firma si se pudo cifrar el password
                                        strFuncionApiEmpleada = "fGeneraFirma_RSA";
                                        string strDatosEnClaro = prmCodigo + prmKsimCifrado + prmPwdCifrado;
                                        Globales.THRINICIODIA_BLNAPIINVOCADO = true;
                                        Globales.THRINICIODIA_DTULTINVOCAPI = DateTime.Now;
                                        nCodigoRetorno = ObjetosGlobalesApp.objAPISEG.fGeneraFirma_RSA(Constantes.APISEGURIDAD_METODOHASH,
                                                                                    strDatosEnClaro,
                                                                                    prmCodigo,
                                                                                    oBancoCiti.IndiceKPri.Value,
                                                                                    ref strFirma);
                                        Globales.THRINICIODIA_BLNAPIINVOCADO = false;

                                        LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.SEGURIDAD,
                                            strHashcode,
                                            "BL_SeguridadMsj.GenerarFirma",
                                            "Se invoca el metodo fGeneraFirma_RSA del api, con los siguientes parametros:" +
                                            "Metodo hash: [" + Constantes.APISEGURIDAD_METODOHASH.ToString() + "]\r\n" +
                                            "Data Entrada: [" + strDatosEnClaro + "]\r\n" +
                                            "Codigo Inst: [" + prmCodigo + "]\r\n" +
                                            "Indice clave: [" + oBancoCiti.IndiceKPri.Value.ToString() + "]\r\n" +
                                            "Firma retornada: [" + strFirma + "]", false);
                                    }

                                    if (nCodigoRetorno != 0)
                                    {
                                        prmKsimCifrado = null;
                                        prmPwdCifrado = null;
                                        strFirma = null;

                                        strMensajeError = this.ManejarErrorApiSeguridad(strFuncionApiEmpleada, nCodigoRetorno);
                                    }
                                }
                            }
                        }
                        else
                        {
                            strMensajeError = "No existe banco alguno registrado en la base de datos.";
                        }
                    }
                    else
                    {
                        strMensajeError = "La instancia del objeto global del API de seguridad no ha podido ser establecida.";
                    }
                }
                else
                {                    
                    strFirma = "mifirma";
                    prmKsimCifrado = "ksimcifrado";
                    prmPwdCifrado = "pwdcifrado";                    
                }
            }
            catch (Exception ex)
            {
                strFirma = null;
                prmKsimCifrado = null;
                prmPwdCifrado = null;
                strMensajeError = "Error, " + ex.Message + ". " + ex.StackTrace;
            }

            if (!String.IsNullOrEmpty(strMensajeError))
            {
                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SEGURIDAD, strHashcode,
                    "BL_SeguridadMsj.GenerarFirma",
                    strMensajeError, true);
            }

            return strFirma;
        }

        /// <summary>
        /// Generacion de firma para transferencia
        /// </summary>
        /// <param name="prmTransferencia"></param>
        /// <param name="prmDatosTransferencia"></param>
        /// <returns></returns>
        public string GenerarFirma(BE_Transferencia prmTransferencia, 
                                    datosTransferencia prmDatosTransferencia,
                                    bool pblnControlarAPI,
                                    out string prmMensajeError) 
        {
            prmMensajeError = "";
            string strFirmaMsj = string.Empty;
            string strMensajeError = string.Empty;

            try
            {
                if (Globales.APISEGURIDAD_USAR)
                {
                    if (pblnControlarAPI)
                    {
                        Globales.THRENVIOOPEBCRP_BLNAPIINVOCADO = true;
                        Globales.THRENVIOOPEBCRP_DTULTINVOCAPI = DateTime.Now;
                    }
                    this.VerificarConexionActual();
                    if (pblnControlarAPI) Globales.THRENVIOOPEBCRP_BLNAPIINVOCADO = false;

                    if (ObjetosGlobalesApp.objAPISEG != null)
                    {
                        string strDatosEnClaro = string.Empty;
                        string strDatosCliente = string.Empty;
                        string strDataClienteCifrada = string.Empty;
                        string strKsimCifrada = string.Empty;
                        string strFirmaDataCliente = string.Empty;

                        //Data Cliente a Cifrar
                        string strDataClienteEnClaro = string.Empty;

                        if (prmTransferencia.DatosCliente != null)
                        {
                            strDataClienteEnClaro = prmTransferencia.DatosCliente.ToString();

                            //SE VERIFICA SI EL TAMA�O DE LA CADENA ES MULTIPLO DE 8, DE LO CONTRARIO, SE COMPLETA CON ESPACIOS EN BLANCO
                            int nTamanho = strDataClienteEnClaro.Length;
                            int nFactor = nTamanho % 8;

                            if (nFactor > 0)
                            {
                                int nQtyCaracteresCompletar = 8 - nFactor;
                                strDataClienteEnClaro = strDataClienteEnClaro.PadRight(nTamanho + nQtyCaracteresCompletar, ' ');
                            }
                        }

                        //Se establecen los Datos en Claro
                        if (!String.IsNullOrEmpty(prmTransferencia.CodConcepto)) strDatosEnClaro += prmTransferencia.CodConcepto.Trim();
                        if (!String.IsNullOrEmpty(prmTransferencia.CuentaDestino)) strDatosEnClaro += prmTransferencia.CuentaDestino.Trim();
                        if (!String.IsNullOrEmpty(prmTransferencia.CuentaOrigen)) strDatosEnClaro += prmTransferencia.CuentaOrigen.Trim();
                        strDatosEnClaro += "{[REEMPLAZO1]}";//datos cliente, se insertara cuando datos cliente contenga la data cliente cifrada, ksim cifrada, firma data cliente
                        if (prmTransferencia.FechaLiquidacion != null) strDatosEnClaro += prmTransferencia.FechaLiquidacion.Value.ToString("yyyyMMddHHmmss");
                        if (prmTransferencia.FecRefLBTREnlace != null) strDatosEnClaro += prmTransferencia.FecRefLBTREnlace.Value.ToString("yyyyMMddHHmmss");
                        if (!String.IsNullOrEmpty(prmTransferencia.InstruccionesPago)) strDatosEnClaro += prmTransferencia.InstruccionesPago.Trim();
                        if (!String.IsNullOrEmpty(prmTransferencia.Modalidad)) strDatosEnClaro += prmTransferencia.Modalidad.Trim();

                        if (prmTransferencia.Monto != null)
                            strDatosEnClaro += Utilitario.EliminarCerosNoSignificativos(prmTransferencia.Monto.Value);
                        else
                            strDatosEnClaro += "0";

                        if (!String.IsNullOrEmpty(prmTransferencia.NumRefLBTREnlace)) strDatosEnClaro += prmTransferencia.NumRefLBTREnlace.Trim();
                        if (!String.IsNullOrEmpty(prmTransferencia.NumRefOrigen)) strDatosEnClaro += prmTransferencia.NumRefOrigen.Trim();
                        if (prmTransferencia.Prioridad != null) strDatosEnClaro += prmTransferencia.Prioridad.Value.ToString();
                        strDatosEnClaro += "{[REEMPLAZO2]}";//SID

                        //-------------------------------------------------------------------------------------------------
                        BL_General oBLGen = new BL_General(strHashcode);
                        List<BE_Banco> lstBancos = null;
                        BE_Banco oBancoDestino = null;
                        BE_Banco oBancoCiti = null;
                        string strCodBancoDestino = prmTransferencia.CodBancoDestino;
                        string strCodigoCiti = oBLGen.ObtenerValorConfiguracion(Constantes.PARAM_CODIGO_CITIBANK);

                        lstBancos = oBLGen.ObtenerBancos(new BE_Banco());

                        if (lstBancos != null && lstBancos.Count > 0)
                        {
                            oBancoDestino = lstBancos.Find(delegate(BE_Banco oBancoParamDest) { return oBancoParamDest.CodBanco == strCodBancoDestino; });
                            oBancoCiti = lstBancos.Find(delegate(BE_Banco oBancoParamCiti) { return oBancoParamCiti.CodBanco == strCodigoCiti; });

                            if (oBancoDestino == null)
                            {
                                strMensajeError = "El banco destino con codigo " + strCodBancoDestino + " no esta registrado en la base datos.";
                            }
                            else if (oBancoCiti == null)
                            {
                                strMensajeError = "El banco Citibank con codigo " + strCodigoCiti + " no esta registrado en la base datos.";
                            }
                            else
                            {
                                if (!oBancoDestino.IndiceKPub.HasValue)
                                {
                                    strMensajeError = "El banco " + oBancoDestino.NomBancoBCR + " no tiene un indice de clave publica asignada.";
                                }
                                else if (!oBancoCiti.IndiceKPri.HasValue)
                                {
                                    strMensajeError = "El banco Citibank no tiene un indice de clave privada asignada.";
                                }
                                else
                                {
                                    string strFuncionApiEmpleada = "";
                                    int nCodigoRetorno = 0;

                                    //si hay data cliente a cifrar
                                    if (!String.IsNullOrEmpty(strDataClienteEnClaro))
                                    {
                                        //Se cifra la data cliente en claro y se obtiene la data cliente cifrada y la ksim empleada
                                        //se emplea el indice de la llave publica del banco destino
                                        LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.SEGURIDAD, strHashcode,
                                                "BL_SeguridadMsj.GenerarFirma",
                                                "Se procedera a cifrar la data cliente", false);

                                        strFuncionApiEmpleada = "fCifrarMensaje_3DES_RSA";

                                        if (pblnControlarAPI)
                                        {
                                            Globales.THRENVIOOPEBCRP_BLNAPIINVOCADO = true;
                                            Globales.THRENVIOOPEBCRP_DTULTINVOCAPI = DateTime.Now;
                                        }
                                        nCodigoRetorno = ObjetosGlobalesApp.objAPISEG.fCifrarMensaje_3DES_RSA(strDataClienteEnClaro,
                                                                                                strCodBancoDestino,
                                                                                                oBancoDestino.IndiceKPub.Value,
                                                                                                ref strDataClienteCifrada,
                                                                                                ref strKsimCifrada);
                                        if (pblnControlarAPI) Globales.THRENVIOOPEBCRP_BLNAPIINVOCADO = false;

                                        if (Globales.MOSTRAR_DATA_CLIENTE_LOG)
                                        {
                                            LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.SEGURIDAD, strHashcode,
                                                "BL_SeguridadMsj.GenerarFirma",
                                                "Data cliente antes de cifrar: [" + strDataClienteEnClaro + "]", false);
                                        }

                                        LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.SEGURIDAD, strHashcode,
                                            "BL_SeguridadMsj.GenerarFirma",
                                            "Se ha cifrado la data cliente. fCifrarMensaje_3DES_RSA\r\n" +
                                            "CodInstDest: [" + strCodBancoDestino + "]\r\n" +
                                            "IndClavePub: [" + oBancoDestino.IndiceKPub.Value.ToString() + "]\r\n" +
                                            "Data cliente cifrada: [" + strDataClienteCifrada + "]\r\n" +
                                            "KsimCifrada: [" + strKsimCifrada + "]\r\n" +
                                            "Tamanho Ksim: " + strKsimCifrada.Length.ToString(), false);
                                    }
                                    else
                                    {
                                        LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.SEGURIDAD, strHashcode,
                                            "BL_SeguridadMsj.GenerarFirma",
                                            "La transferencia no contiene datos de cliente", false);
                                    }

                                    if (nCodigoRetorno == 0)
                                    {
                                        //si desde el inicio hubo data cliente, se procede a firmar la data cliente cifrada + ksimcifrada
                                        if (!String.IsNullOrEmpty(strDataClienteEnClaro))
                                        {
                                            //se firma datos cliente
                                            strFuncionApiEmpleada = "fGeneraFirma_RSA";
                                            string strDataClienteAFirmar = strDataClienteCifrada + strKsimCifrada;

                                            LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.SEGURIDAD, strHashcode,
                                                "BL_SeguridadMsj.GenerarFirma",
                                                "Se procedera a generar la firma", false);

                                            if (pblnControlarAPI)
                                            {
                                                Globales.THRENVIOOPEBCRP_BLNAPIINVOCADO = true;
                                                Globales.THRENVIOOPEBCRP_DTULTINVOCAPI = DateTime.Now;
                                            }
                                            nCodigoRetorno = ObjetosGlobalesApp.objAPISEG.fGeneraFirma_RSA(Constantes.APISEGURIDAD_METODOHASH,
                                                                                        strDataClienteAFirmar,
                                                                                        strCodigoCiti,
                                                                                        oBancoCiti.IndiceKPri.Value,
                                                                                        ref strFirmaDataCliente);
                                            if (pblnControlarAPI) Globales.THRENVIOOPEBCRP_BLNAPIINVOCADO = false;

                                            LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.SEGURIDAD, strHashcode,
                                                "BL_SeguridadMsj.GenerarFirma",
                                                "Se firma data cliente cifrada + ksimcifrada. fGeneraFirma_RSA\r\n" +
                                                "MetodoHash: [" + Constantes.APISEGURIDAD_METODOHASH.ToString() + "]\r\n" +
                                                "Data Entrada: [" + strDataClienteAFirmar + "]\r\n" +
                                                "CodInst: [" + strCodigoCiti + "]\r\n" +
                                                "Num Clave: [" + oBancoCiti.IndiceKPri.Value.ToString() + "]\r\n" +
                                                "firma: [" + strFirmaDataCliente + "]", false);
                                        }

                                        //si se firmo correctamente datos cliente, se procede a firmar el mensaje
                                        if (nCodigoRetorno == 0)
                                        {
                                            //si hubo data cliente desde el inicio....
                                            if (!String.IsNullOrEmpty(strDataClienteEnClaro))
                                            {
                                                strDatosCliente = BE_DatosCliente.ArmarDatosCliente(strDataClienteCifrada,
                                                                    strKsimCifrada,
                                                                    strFirmaDataCliente);
                                            }

                                            prmDatosTransferencia.datosCliente = strDatosCliente;

                                            strFuncionApiEmpleada = "fGeneraFirma_RSA";
                                            strDatosEnClaro = strDatosEnClaro.Replace("{[REEMPLAZO1]}", strDatosCliente);
                                            strDatosEnClaro = strDatosEnClaro.Replace("{[REEMPLAZO2]}", Globales.SID);
                                            if (pblnControlarAPI)
                                            {
                                                Globales.THRENVIOOPEBCRP_BLNAPIINVOCADO = true;
                                                Globales.THRENVIOOPEBCRP_DTULTINVOCAPI = DateTime.Now;
                                            }
                                            nCodigoRetorno = ObjetosGlobalesApp.objAPISEG.fGeneraFirma_RSA(Constantes.APISEGURIDAD_METODOHASH,
                                                                                    strDatosEnClaro,
                                                                                    strCodigoCiti,
                                                                                    oBancoCiti.IndiceKPri.Value,
                                                                                    ref strFirmaMsj);
                                            if (pblnControlarAPI) Globales.THRENVIOOPEBCRP_BLNAPIINVOCADO = false;

                                            LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.SEGURIDAD, strHashcode,
                                                "BL_SeguridadMsj.GenerarFirma",
                                                "Se firma el mensaje. fGeneraFirma_RSA\r\n" +
                                                "SID: [" + (Globales.MOSTRAR_SID_LOG_TRAZA ? Globales.SID : "**********") + "]\r\n" +
                                                "datos cliente: [" + strDatosCliente + "]\r\n" +
                                                "MetodoHash: [" + Constantes.APISEGURIDAD_METODOHASH.ToString() + "]\r\n" +
                                                "Data Mensaje a Firmar: [" + strDatosEnClaro + "]\r\n" +
                                                "CodInst: [" + strCodigoCiti + "]\r\n" +
                                                "Num Clave: [" + oBancoCiti.IndiceKPri.Value.ToString() + "]\r\n" +
                                                "firma mensaje: [" + strFirmaMsj + "]", false);
                                        }
                                    }

                                    if (nCodigoRetorno != 0)
                                    {
                                        strFirmaMsj = null;

                                        strMensajeError = this.ManejarErrorApiSeguridad(strFuncionApiEmpleada, nCodigoRetorno);
                                    }

                                }
                            }
                        }
                        else
                        {
                            strMensajeError = "No existe banco alguno registrado en la base de datos.";
                        }

                    }
                    else
                    {
                        strMensajeError = "La instancia del objeto global del API de seguridad no ha podido ser establecida.";
                    }

                }
                else 
                {
                    if (prmTransferencia.DatosCliente != null)
                    {
                        prmDatosTransferencia.datosCliente = BE_DatosCliente.ArmarDatosCliente(prmTransferencia.DatosCliente.ToString(),
                                                                "ksimcifrada",
                                                                "firmadatoscliente");
                    }
                    strFirmaMsj = "mifirma";
                }                                
                
            }
            catch (Exception ex)
            {
                strFirmaMsj = null;
                strMensajeError = "Error: " + ex.Message + ". " + ex.StackTrace;
            }

            if (!String.IsNullOrEmpty(strMensajeError))
            {
                prmMensajeError = strMensajeError;

                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SEGURIDAD, strHashcode,
                    "BL_SeguridadMsj.GenerarFirma",
                    strMensajeError, true);
            }

            return strFirmaMsj;
        }
        
        /// <summary>
        /// Generacion de firma para CompraVenta
        /// </summary>
        /// <param name="prmTransferencia"></param>
        /// <param name="prmDatosTransferencia"></param>
        /// <returns></returns>
        public string GenerarFirma(BE_CompraVentaSalidas prmCompraVentaSalidas,
                                    datosCompraVentaME prmDatosCompraVentaME,
                                    out string prmMensajeError)
        {
            prmMensajeError = "";
            string strFirmaMsj = string.Empty;
            string strMensajeError = string.Empty;
            
            try
            {
                if (Globales.APISEGURIDAD_USAR)
                {
                    Globales.THRENVIOOPEBCRP_BLNAPIINVOCADO = true;
                    Globales.THRENVIOOPEBCRP_DTULTINVOCAPI = DateTime.Now;
                    this.VerificarConexionActual();
                    Globales.THRENVIOOPEBCRP_BLNAPIINVOCADO = false;

                    if (ObjetosGlobalesApp.objAPISEG != null)
                    {
                        string strDatosEnClaro = string.Empty;
                        string strDatosCliente = string.Empty;
                        string strDataClienteCifrada = string.Empty;
                        string strKsimCifrada = string.Empty;
                        string strFirmaDataCliente = string.Empty;

            //            //Data Cliente a Cifrar
            //            string strDataClienteEnClaro = string.Empty;

            //            if (prmTransferencia.DatosCliente != null)
            //            {
            //                strDataClienteEnClaro = prmTransferencia.DatosCliente.ToString();

            //                //SE VERIFICA SI EL TAMA�O DE LA CADENA ES MULTIPLO DE 8, DE LO CONTRARIO, SE COMPLETA CON ESPACIOS EN BLANCO
            //                int nTamanho = strDataClienteEnClaro.Length;
            //                int nFactor = nTamanho % 8;

            //                if (nFactor > 0)
            //                {
            //                    int nQtyCaracteresCompletar = 8 - nFactor;
            //                    strDataClienteEnClaro = strDataClienteEnClaro.PadRight(nTamanho + nQtyCaracteresCompletar, ' ');
            //                }
            //            }

            //            //Se establecen los Datos en Claro
                        if (!String.IsNullOrEmpty(prmCompraVentaSalidas.COD_CONCEPTO)) strDatosEnClaro += prmCompraVentaSalidas.COD_CONCEPTO.Trim();
                        if (!String.IsNullOrEmpty(prmCompraVentaSalidas.CTA_DESTINO)) strDatosEnClaro += prmCompraVentaSalidas.CTA_DESTINO.Trim();
                        if (!String.IsNullOrEmpty(prmCompraVentaSalidas.CTA_ORIGEN)) strDatosEnClaro += prmCompraVentaSalidas.CTA_ORIGEN.Trim();
                        //strDatosEnClaro += "{[REEMPLAZO1]}";//datos cliente, se insertara cuando datos cliente contenga la data cliente cifrada, ksim cifrada, firma data cliente
                        if (prmCompraVentaSalidas.FECHA_LIQUIDACION != null) strDatosEnClaro += prmCompraVentaSalidas.FECHA_LIQUIDACION.Value.ToString("yyyyMMddHHmmss");
                        //if (prmTransferencia.FecRefLBTREnlace != null) strDatosEnClaro += prmTransferencia.FecRefLBTREnlace.Value.ToString("yyyyMMddHHmmss");
                        if (!String.IsNullOrEmpty(prmCompraVentaSalidas.INSTRUCCIONES_PAGO)) strDatosEnClaro += prmCompraVentaSalidas.INSTRUCCIONES_PAGO.Trim();
                        //if (!String.IsNullOrEmpty(prmTransferencia.Modalidad)) strDatosEnClaro += prmTransferencia.Modalidad.Trim();

                        if (prmCompraVentaSalidas.MONTO_ME != null)
                            strDatosEnClaro += Utilitario.EliminarCerosNoSignificativos(prmCompraVentaSalidas.MONTO_ME.Value);
                        else
                            strDatosEnClaro += "0";

                        if (prmCompraVentaSalidas.MONTO_MN != null)
                            strDatosEnClaro += Utilitario.EliminarCerosNoSignificativos(prmCompraVentaSalidas.MONTO_MN.Value);
                        else
                            strDatosEnClaro += "0";

                        //if (!String.IsNullOrEmpty(prmTransferencia.NumRefLBTREnlace)) strDatosEnClaro += prmTransferencia.NumRefLBTREnlace.Trim();
                        if (!String.IsNullOrEmpty(prmCompraVentaSalidas.NUM_REF_LBTR_CV)) strDatosEnClaro += prmCompraVentaSalidas.NUM_REF_LBTR_CV.Trim();
                        if (!String.IsNullOrEmpty(prmCompraVentaSalidas.NUM_REF_ORIGEN)) strDatosEnClaro += prmCompraVentaSalidas.NUM_REF_ORIGEN.Trim();

                        if (prmCompraVentaSalidas.TIPO_CAMBIO != null)
                            strDatosEnClaro += Utilitario.EliminarCerosNoSignificativos(prmCompraVentaSalidas.TIPO_CAMBIO.Value);
                        else
                            strDatosEnClaro += "0";

                        //if (prmTransferencia.Prioridad != null) strDatosEnClaro += prmTransferencia.Prioridad.Value.ToString();
                        strDatosEnClaro += "{[REEMPLAZO1]}";//SID )Preguntar por que en este orden.

                        //-------------------------------------------------------------------------------------------------
                        BL_General oBLGen = new BL_General(strHashcode);
                        List<BE_Banco> lstBancos = null;
                        BE_Banco oBancoDestino = null;
                        BE_Banco oBancoCiti = null;
                        string strCodBancoDestino = prmCompraVentaSalidas.BCO_DESTINO;
                        string strCodigoCiti = oBLGen.ObtenerValorConfiguracion(Constantes.PARAM_CODIGO_CITIBANK);

                        lstBancos = oBLGen.ObtenerBancos(new BE_Banco());

                        if (lstBancos != null && lstBancos.Count > 0)
                        {
                            oBancoDestino = lstBancos.Find(delegate(BE_Banco oBancoParamDest) { return oBancoParamDest.CodBanco == strCodBancoDestino; });
                            oBancoCiti = lstBancos.Find(delegate(BE_Banco oBancoParamCiti) { return oBancoParamCiti.CodBanco == strCodigoCiti; });

                            if (oBancoDestino == null)
                            {
                                strMensajeError = "El banco destino con codigo " + strCodBancoDestino + " no esta registrado en la base datos.";
                            }
                            else if (oBancoCiti == null)
                            {
                                strMensajeError = "El banco Citibank con codigo " + strCodigoCiti + " no esta registrado en la base datos.";
                            }
                            else
                            {
                                if (!oBancoDestino.IndiceKPub.HasValue)
                                {
                                    strMensajeError = "El banco " + oBancoDestino.NomBancoBCR + " no tiene un indice de clave publica asignada.";
                                }
                                else if (!oBancoCiti.IndiceKPri.HasValue)
                                {
                                    strMensajeError = "El banco Citibank no tiene un indice de clave privada asignada.";
                                }
                                else
                                {
                                    string strFuncionApiEmpleada = "";
                                    int nCodigoRetorno = 0;

                                    ////si hay data cliente a cifrar
                                    //if (!String.IsNullOrEmpty(strDataClienteEnClaro))
                                    //{
                                    //    //Se cifra la data cliente en claro y se obtiene la data cliente cifrada y la ksim empleada
                                    //    //se emplea el indice de la llave publica del banco destino
                                    //    LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.SEGURIDAD, strHashcode,
                                    //            "BL_SeguridadMsj.GenerarFirma",
                                    //            "Se procedera a cifrar la data cliente", false);

                                    //    strFuncionApiEmpleada = "fCifrarMensaje_3DES_RSA";

                                    //    Globales.THRENVIOOPEBCRP_BLNAPIINVOCADO = true;
                                    //    Globales.THRENVIOOPEBCRP_DTULTINVOCAPI = DateTime.Now;
                                    //    nCodigoRetorno = ObjetosGlobalesApp.objAPISEG.fCifrarMensaje_3DES_RSA(strDataClienteEnClaro,
                                    //                                                            strCodBancoDestino,
                                    //                                                            oBancoDestino.IndiceKPub.Value,
                                    //                                                            ref strDataClienteCifrada,
                                    //                                                            ref strKsimCifrada);
                                    //    Globales.THRENVIOOPEBCRP_BLNAPIINVOCADO = false;

                                    //    if (Globales.MOSTRAR_DATA_CLIENTE_LOG)
                                    //    {
                                    //        LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.SEGURIDAD, strHashcode,
                                    //            "BL_SeguridadMsj.GenerarFirma",
                                    //            "Data cliente antes de cifrar: [" + strDataClienteEnClaro + "]", false);
                                    //    }

                                    //    LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.SEGURIDAD, strHashcode,
                                    //        "BL_SeguridadMsj.GenerarFirma",
                                    //        "Se ha cifrado la data cliente. fCifrarMensaje_3DES_RSA\r\n" +
                                    //        "CodInstDest: [" + strCodBancoDestino + "]\r\n" +
                                    //        "IndClavePub: [" + oBancoDestino.IndiceKPub.Value.ToString() + "]\r\n" +
                                    //        "Data cliente cifrada: [" + strDataClienteCifrada + "]\r\n" +
                                    //        "KsimCifrada: [" + strKsimCifrada + "]\r\n" +
                                    //        "Tamanho Ksim: " + strKsimCifrada.Length.ToString(), false);
                                    //}
                                    //else
                                    //{
                                    //    LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.SEGURIDAD, strHashcode,
                                    //        "BL_SeguridadMsj.GenerarFirma",
                                    //        "La transferencia no contiene datos de cliente", false);
                                    //}

                                    if (nCodigoRetorno == 0)
                                    {
                                        ////si desde el inicio hubo data cliente, se procede a firmar la data cliente cifrada + ksimcifrada
                                        //if (!String.IsNullOrEmpty(strDataClienteEnClaro))
                                        //{
                                        //    //se firma datos cliente
                                        //    strFuncionApiEmpleada = "fGeneraFirma_RSA";
                                        //    string strDataClienteAFirmar = strDataClienteCifrada + strKsimCifrada;

                                        //    LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.SEGURIDAD, strHashcode,
                                        //        "BL_SeguridadMsj.GenerarFirma",
                                        //        "Se procedera a generar la firma", false);

                                        //    Globales.THRENVIOOPEBCRP_BLNAPIINVOCADO = true;
                                        //    Globales.THRENVIOOPEBCRP_DTULTINVOCAPI = DateTime.Now;
                                        //    nCodigoRetorno = ObjetosGlobalesApp.objAPISEG.fGeneraFirma_RSA(Constantes.APISEGURIDAD_METODOHASH,
                                        //                                                strDataClienteAFirmar,
                                        //                                                strCodigoCiti,
                                        //                                                oBancoCiti.IndiceKPri.Value,
                                        //                                                ref strFirmaDataCliente);
                                        //    Globales.THRENVIOOPEBCRP_BLNAPIINVOCADO = false;

                                        //    LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.SEGURIDAD, strHashcode,
                                        //        "BL_SeguridadMsj.GenerarFirma",
                                        //        "Se firma data cliente cifrada + ksimcifrada. fGeneraFirma_RSA\r\n" +
                                        //        "MetodoHash: [" + Constantes.APISEGURIDAD_METODOHASH.ToString() + "]\r\n" +
                                        //        "Data Entrada: [" + strDataClienteAFirmar + "]\r\n" +
                                        //        "CodInst: [" + strCodigoCiti + "]\r\n" +
                                        //        "Num Clave: [" + oBancoCiti.IndiceKPri.Value.ToString() + "]\r\n" +
                                        //        "firma: [" + strFirmaDataCliente + "]", false);
                                        //}

                                        //si se firmo correctamente datos cliente, se procede a firmar el mensaje
                                        //if (nCodigoRetorno == 0)
                                        //{
                                            //si hubo data cliente desde el inicio....
                                            //if (!String.IsNullOrEmpty(strDataClienteEnClaro))
                                            //{
                                            //    strDatosCliente = BE_DatosCliente.ArmarDatosCliente(strDataClienteCifrada,
                                            //                        strKsimCifrada,
                                            //                        strFirmaDataCliente);
                                            //}

                                            //prmDatosTransferencia.datosCliente = strDatosCliente;

                                            strFuncionApiEmpleada = "fGeneraFirma_RSA";
                                            //strDatosEnClaro = strDatosEnClaro.Replace("{[REEMPLAZO1]}", strDatosCliente);
                                            strDatosEnClaro = strDatosEnClaro.Replace("{[REEMPLAZO1]}", Globales.SID);
                                            Globales.THRENVIOOPEBCRP_BLNAPIINVOCADO = true;
                                            Globales.THRENVIOOPEBCRP_DTULTINVOCAPI = DateTime.Now;
                                            nCodigoRetorno = ObjetosGlobalesApp.objAPISEG.fGeneraFirma_RSA(Constantes.APISEGURIDAD_METODOHASH,
                                                                                    strDatosEnClaro,
                                                                                    strCodigoCiti,
                                                                                    oBancoCiti.IndiceKPri.Value,
                                                                                    ref strFirmaMsj);
                                            Globales.THRENVIOOPEBCRP_BLNAPIINVOCADO = false;

                                            LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.SEGURIDAD, strHashcode,
                                                "BL_SeguridadMsj.GenerarFirma",
                                                "Se firma el mensaje. fGeneraFirma_RSA\r\n" +
                                                "SID: [" + (Globales.MOSTRAR_SID_LOG_TRAZA ? Globales.SID : "**********") + "]\r\n" +
                                                //"datos cliente: [" + strDatosCliente + "]\r\n" +
                                                "MetodoHash: [" + Constantes.APISEGURIDAD_METODOHASH.ToString() + "]\r\n" +
                                                "Data Mensaje a Firmar: [" + strDatosEnClaro + "]\r\n" +
                                                "CodInst: [" + strCodigoCiti + "]\r\n" +
                                                "Num Clave: [" + oBancoCiti.IndiceKPri.Value.ToString() + "]\r\n" +
                                                "firma mensaje: [" + strFirmaMsj + "]", false);
                                       // }
                                    }

                                    if (nCodigoRetorno != 0)
                                    {
                                        strFirmaMsj = null;

                                        strMensajeError = this.ManejarErrorApiSeguridad(strFuncionApiEmpleada, nCodigoRetorno);
                                    }

                                }
                            }
                        }
                        else
                        {
                            strMensajeError = "No existe banco alguno registrado en la base de datos.";
                        }

                    }
                    else
                    {
                        strMensajeError = "La instancia del objeto global del API de seguridad no ha podido ser establecida.";
                    }

                }
                else
                {
                    //if (prmTransferencia.DatosCliente != null)
                    //{
                    //    prmDatosTransferencia.datosCliente = BE_DatosCliente.ArmarDatosCliente(prmTransferencia.DatosCliente.ToString(),
                    //                                            "ksimcifrada",
                    //                                            "firmadatoscliente");
                    //}
                    //strFirmaMsj = "mifirma";
                }

            }
            catch (Exception ex)
            {
                strFirmaMsj = null;
                strMensajeError = "Error: " + ex.Message + ". " + ex.StackTrace;
            }

            if (!String.IsNullOrEmpty(strMensajeError))
            {
                prmMensajeError = strMensajeError;

                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SEGURIDAD, strHashcode,
                    "BL_SeguridadMsj.GenerarFirma",
                    strMensajeError, true);
            }

            return strFirmaMsj;
        }

        /// <summary>
        /// Retorna true si la validacion de la firma de datos cliente
        /// fue realizada con �xito.
        /// Adem�s, retorna la data de cliente descifrada si es que se pudiese realizar.
        /// </summary>
        /// <param name="blnUsarLlavesActuales">Si es true, se usaran las llaves actuales. De lo 
        /// contrario, se usar�n las llaves hist�ricas.</param>
        /// <param name="prmTipoOperacion"></param>
        /// <param name="prmDatosCliente"></param>
        /// <param name="prmCodigoBancoOrigen"></param>
        /// <param name="prmDataCliente"></param>
        /// <param name="prmFechaOperacion"></param>
        /// <param name="prmIndKpubBcoOri"></param>
        /// <param name="prmIndKpriCiti"></param>
        /// <param name="prmMensajeError"></param>
        /// <returns></returns>
        public bool ValidarFirmaDataCliente(String prmOrigenFlujo, bool blnUsarLlavesActuales, string prmTipoOperacion, 
                                            string prmDatosCliente, string prmCodigoBancoOrigen, 
                                            out string prmDataCliente, DateTime? prmFechaOperacion, 
                                            int? prmIndKpubBcoOri, int? prmIndKpriCiti,
                                            out string prmMensajeError, out bool prmErrorEnBD) 
        {
            prmDataCliente = null;
            prmMensajeError = "";
            prmErrorEnBD = false;
            string strMensajeError = "";
            bool blnFirmaClienteValida = false;
            bool blnUsarDataHistorica = false;
            BL_General oBLGen = new BL_General(strHashcode);
            string strValidarFirma = "";
            string strCodigoCiti = "";
            BE_Banco oBanco = null;
            List<BE_Banco> lstBancos = null;
            string strFuncionApiEmpleada = "";
            
            try
            {
                strValidarFirma = oBLGen.ObtenerValorConfiguracion(Constantes.PARAM_VALIDAR_FIRMA);

                prmErrorEnBD = oBLGen.errorEnDAO;

                if (prmErrorEnBD)
                {
                    prmMensajeError = "Error al obtener el indicador de validacion de firma de la tabla t_config.";
                    return false;
                }

                strCodigoCiti = oBLGen.ObtenerValorConfiguracion(Constantes.PARAM_CODIGO_CITIBANK);

                prmErrorEnBD = oBLGen.errorEnDAO;

                if (prmErrorEnBD)
                {
                    prmMensajeError = "Error al obtener el codigo de banco del banco Citibank de la tabla t_config.";
                    return false;
                }

                if (Globales.MOSTRAR_DATA_CLIENTE_LOG)
                {
                    LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.SEGURIDAD, strHashcode,
                        "BL_SeguridadMsj.ValidarFirmaDataCliente",
                        "El valor del campo Datos Cliente recibido es [" + prmDatosCliente + "]", false);
                }

                #region Validaciones 

                //si no se requiere validar la firma, se establece a true el flag de firma valida
                if (String.IsNullOrEmpty(strValidarFirma) || strValidarFirma != "1") blnFirmaClienteValida = true;

                //Se verifica si DatosCliente es vacio
                if (String.IsNullOrEmpty(prmDatosCliente))
                {
                    if (Globales.APISEGURIDAD_USAR)
                    {
                        //se estaria devolviendo el parametro prmDataCliente en null
                        prmMensajeError = "Sin datos cliente.";
                        return blnFirmaClienteValida;
                    }

                }

                //Se verifica si se ha inicializado el api de seguridad
                if (Globales.APISEGURIDAD_USAR)
                {
                    if (prmOrigenFlujo == FlujoOperacionRecibida.FlujoNormal)
                    {
                        Globales.THROPEREC_BLNAPIINVOCADO = true;
                        Globales.THROPEREC_DTULTINVOCAPI = DateTime.Now;
                    }
                    else if (prmOrigenFlujo == FlujoOperacionRecibida.FlujoContingencia)
                    {
                        Globales.THROPERECCONTING_BLNAPIINVOCADO = true;
                        Globales.THROPERECCONTING_DTULTINVOCAPI = DateTime.Now;
                    }
                    bool blnResultVerifCnxActual = this.VerificarConexionActual();
                    if (prmOrigenFlujo == FlujoOperacionRecibida.FlujoNormal)
                    {
                        Globales.THROPEREC_BLNAPIINVOCADO = false;
                    }
                    else if (prmOrigenFlujo == FlujoOperacionRecibida.FlujoContingencia)
                    {
                        Globales.THROPERECCONTING_BLNAPIINVOCADO = false;
                    }

                    if (!blnResultVerifCnxActual)
                    {
                        prmErrorEnBD = true;
                        strMensajeError = "La instancia del objeto global del API de seguridad no ha podido ser establecida.";
                        return false;
                    }


                #endregion

                    if (prmTipoOperacion == TipoOperacion.AvisoAfectacionOpeRec)
                    {
                        if (!blnUsarLlavesActuales)//Si no se usan llaves actuales, se usan las historicas
                        {
                            blnUsarDataHistorica = true;
                        }
                    }

                    //Se intenta obtener el objeto datos cliente que divide por secciones (datacliente,ksim,firma data cliente)
                    BE_ContenidoDatosCliente oDatosCliente = BE_DatosCliente.ObtenerContenidoDatosCliente(prmDatosCliente);

                    #region Validacion de info del campo DatosCliente

                    if (oDatosCliente == null ||
                        String.IsNullOrEmpty(oDatosCliente.DataClienteCifrada) ||
                        String.IsNullOrEmpty(oDatosCliente.KsimCifrada) ||
                        String.IsNullOrEmpty(oDatosCliente.FirmaDataCliente))
                    {
                        prmDataCliente = null;

                        prmMensajeError = "El valor de datos cliente no tiene una estructura XML valida.";

                        LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.SEGURIDAD, strHashcode,
                            "BL_SeguridadMsj.ValidarFirmaDataCliente",
                            "La info del objeto oDatosCliente esta vacio.", false);

                        return blnFirmaClienteValida;
                    }

                    #endregion

                    //En este punto, hay datos de cliente, se continua con el flujo
                    #region Validacion de la Firma de Cliente

                    int nCodigoRetornoFirma = -1;

                    if (Globales.APISEGURIDAD_USAR && strValidarFirma == "1")
                    {
                        if (ObjetosGlobalesApp.objAPISEG != null)
                        {
                            lstBancos = oBLGen.ObtenerBancos(new BE_Banco(prmCodigoBancoOrigen));
                            prmErrorEnBD = oBLGen.errorEnDAO;

                            if (prmErrorEnBD)
                            {
                                prmMensajeError = "Error al obtener el registro para el banco origen " + prmCodigoBancoOrigen;
                                return false;
                            }

                            if (lstBancos != null && lstBancos.Count > 0)
                            {
                                oBanco = lstBancos[0];

                                if (oBanco.IndiceKPub.HasValue)
                                {
                                    string strDataAValidar = oDatosCliente.DataClienteCifrada + oDatosCliente.KsimCifrada;

                                    if (!blnUsarDataHistorica)
                                    {
                                        if (prmOrigenFlujo == FlujoOperacionRecibida.FlujoNormal)
                                        {
                                            Globales.THROPEREC_BLNAPIINVOCADO = true;
                                            Globales.THROPEREC_DTULTINVOCAPI = DateTime.Now;
                                        }
                                        else if (prmOrigenFlujo == FlujoOperacionRecibida.FlujoContingencia)
                                        {
                                            Globales.THROPERECCONTING_BLNAPIINVOCADO = true;
                                            Globales.THROPERECCONTING_DTULTINVOCAPI = DateTime.Now;
                                        }
                                        strFuncionApiEmpleada = "fValidaFirma_RSA";
                                        nCodigoRetornoFirma = ObjetosGlobalesApp.objAPISEG.fValidaFirma_RSA(Constantes.APISEGURIDAD_METODOHASH,
                                                                                strDataAValidar, oDatosCliente.FirmaDataCliente,
                                                                                oBanco.CodBanco, oBanco.IndiceKPub.Value);
                                        if (prmOrigenFlujo == FlujoOperacionRecibida.FlujoNormal)
                                        {
                                            Globales.THROPEREC_BLNAPIINVOCADO = false;
                                        }
                                        else if (prmOrigenFlujo == FlujoOperacionRecibida.FlujoContingencia)
                                        {
                                            Globales.THROPERECCONTING_BLNAPIINVOCADO = false;
                                        }

                                        LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.SEGURIDAD, strHashcode,
                                            "BL_SeguridadMsj.ValidarFirmaDataCliente",
                                            "Se valida la firma de datos cliente. fValidaFirma_RSA\r\n" +
                                            "Metodo Hash: [" + Constantes.APISEGURIDAD_METODOHASH.ToString() + "]\r\n" +
                                            "Data Entrada: [" + strDataAValidar + "]\r\n" +
                                            "firma: [" + oDatosCliente.FirmaDataCliente + "]\r\n" +
                                            "Codigo Inst: [" + oBanco.CodBanco + "]\r\n" +
                                            "ind. clave: [" + oBanco.IndiceKPub.Value.ToString() + "]",
                                            false);
                                    }
                                    else
                                    {
                                        if (prmFechaOperacion.HasValue)
                                        {
                                            strFuncionApiEmpleada = "fValidaFirma_RSA_TH";

                                            if (!prmIndKpubBcoOri.HasValue)
                                            {
                                                nCodigoRetornoFirma = ObjetosGlobalesApp.objAPISEG.fValidaFirma_RSA_TH(Constantes.APISEGURIDAD_METODOHASH, strDataAValidar,
                                                                                oDatosCliente.FirmaDataCliente, oBanco.CodBanco, oBanco.IndiceKPub.Value,
                                                                                prmFechaOperacion.Value.ToString("yyyyMMddHHmmss"));

                                                LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.SEGURIDAD, strHashcode,
                                                    "BL_SeguridadMsj.ValidarFirmaDataCliente",
                                                    "Se valida la firma de datos cliente (prmIndKpubBcoOri es null). fValidaFirma_RSA_TH\r\n" +
                                                    "Metodo Hash: [" + Constantes.APISEGURIDAD_METODOHASH.ToString() + "]\r\n" +
                                                    "Data Entrada: [" + strDataAValidar + "]\r\n" +
                                                    "firma: [" + oDatosCliente.FirmaDataCliente + "]\r\n" +
                                                    "Codigo Inst:[ " + oBanco.CodBanco + "]\r\n" +
                                                    "ind. clave: [" + oBanco.IndiceKPub.Value.ToString() + "]\r\n" +
                                                    "Fecha: [" + prmFechaOperacion.Value.ToString("yyyyMMddHHmmss") + "]",
                                                    false);
                                            }
                                            else
                                            {
                                                nCodigoRetornoFirma = ObjetosGlobalesApp.objAPISEG.fValidaFirma_RSA_TH(Constantes.APISEGURIDAD_METODOHASH, strDataAValidar,
                                                                                oDatosCliente.FirmaDataCliente, oBanco.CodBanco, prmIndKpubBcoOri.Value,
                                                                                prmFechaOperacion.Value.ToString("yyyyMMddHHmmss"));

                                                LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.SEGURIDAD, strHashcode,
                                                    "BL_SeguridadMsj.ValidarFirmaDataCliente",
                                                    "Se valida la firma de datos cliente (prmIndKpubBcoOri no es null). fValidaFirma_RSA_TH\r\n" +
                                                    "Metodo Hash: [" + Constantes.APISEGURIDAD_METODOHASH.ToString() + "]\r\n" +
                                                    "Data Entrada: [" + strDataAValidar + "]\r\n" +
                                                    "firma: [" + oDatosCliente.FirmaDataCliente + "]\r\n" +
                                                    "Codigo Inst: [" + oBanco.CodBanco + "]\r\n" +
                                                    "ind. clave: [" + prmIndKpubBcoOri.Value.ToString() + "]\r\n" +
                                                    "Fecha: [" + prmFechaOperacion.Value.ToString("yyyyMMddHHmmss") + "]",
                                                    false);
                                            }
                                        }
                                        else
                                        {
                                            strMensajeError = "El parametro Fecha Operacion no fue establecido. Validacion de firma datos cliente.";
                                        }

                                    }

                                    if (nCodigoRetornoFirma != 0)
                                    {
                                        if (nCodigoRetornoFirma != -1)
                                        {
                                            BE_ErrorApiSeguridad oErrorApi = null;
                                            strMensajeError = this.ManejarErrorApiSeguridad(strFuncionApiEmpleada, nCodigoRetornoFirma, ref oErrorApi);

                                            if (oErrorApi != null)
                                            {
                                                if (oErrorApi.RequiereReconexion)
                                                {
                                                    prmErrorEnBD = true;
                                                }
                                            }
                                        }
                                    }
                                    else
                                    {
                                        blnFirmaClienteValida = true;

                                        LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.SEGURIDAD, strHashcode,
                                            "BL_SeguridadMsj.ValidarFirmaDataCliente",
                                            "La firma de datos cliente es correcta.", false);
                                    }

                                }
                                else
                                {
                                    prmErrorEnBD = true;
                                    strMensajeError = "El banco " + oBanco.NomBancoBCR + " no tiene un indice de clave publica asignada.";
                                }
                            }
                            else
                            {
                                prmErrorEnBD = true;
                                strMensajeError = "No se encontro el banco con codigo: " + prmCodigoBancoOrigen;
                            }
                        }
                        else
                        {
                            prmErrorEnBD = true;
                            strMensajeError = "La instancia del objeto global del API de seguridad no ha podido ser establecida.";
                        }
                    }

                    #endregion

                    #region Descifrado de Datos Cliente

                    //Si hubo error en la validacion de la firma, anteriormente, se guarda en una temporal para luego concatenar
                    string strTmpMensajeError = "";
                    if (!String.IsNullOrEmpty(strMensajeError))
                    {
                        strTmpMensajeError = "ValidacionFirmaDataCliente: [" + strMensajeError + "]";//se copia el msj error a una temporal
                        strMensajeError = "";//se limpia para que sea usado para el descifrado
                    }

                    if (Globales.APISEGURIDAD_USAR)
                    {
                        if (ObjetosGlobalesApp.objAPISEG != null)
                        {
                            lstBancos = oBLGen.ObtenerBancos(new BE_Banco(strCodigoCiti));
                            prmErrorEnBD = oBLGen.errorEnDAO;

                            if (prmErrorEnBD)
                            {
                                prmMensajeError = "Error al obtener el registro banco para el banco " + strCodigoCiti;
                                return false;
                            }

                            if (lstBancos != null && lstBancos.Count > 0)
                            {
                                oBanco = lstBancos[0];

                                if (oBanco.IndiceKPri.HasValue)
                                {
                                    int nCodigoRetorno = -1;

                                    if (!blnUsarDataHistorica)
                                    {
                                        if (prmOrigenFlujo == FlujoOperacionRecibida.FlujoNormal)
                                        {
                                            Globales.THROPEREC_BLNAPIINVOCADO = true;
                                            Globales.THROPEREC_DTULTINVOCAPI = DateTime.Now;
                                        }
                                        else if (prmOrigenFlujo == FlujoOperacionRecibida.FlujoContingencia)
                                        {
                                            Globales.THROPERECCONTING_BLNAPIINVOCADO = true;
                                            Globales.THROPERECCONTING_DTULTINVOCAPI = DateTime.Now;
                                        }
                                        strFuncionApiEmpleada = "fDescifrarMensaje_3DES_RSA";
                                        nCodigoRetorno = ObjetosGlobalesApp.objAPISEG.fDescifrarMensaje_3DES_RSA(oDatosCliente.DataClienteCifrada,
                                                            oDatosCliente.KsimCifrada,
                                                            oBanco.CodBanco, oBanco.IndiceKPri.Value,
                                                            ref prmDataCliente);
                                        if (prmOrigenFlujo == FlujoOperacionRecibida.FlujoNormal)
                                        {
                                            Globales.THROPEREC_BLNAPIINVOCADO = false;
                                        }
                                        else if (prmOrigenFlujo == FlujoOperacionRecibida.FlujoContingencia)
                                        {
                                            Globales.THROPERECCONTING_BLNAPIINVOCADO = false;
                                        }

                                        LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.SEGURIDAD, strHashcode,
                                            "BL_SeguridadMsj.ValidarFirmaDataCliente",
                                            "Se descifra la data cliente. fDescifrarMensaje_3DES_RSA\r\n" +
                                            "data cliente Cifrada: [" + oDatosCliente.DataClienteCifrada + "]\r\n" +
                                            "KSim Cifrada: [" + oDatosCliente.KsimCifrada + "]\r\n" +
                                            "Cod Inst.: [" + oBanco.CodBanco + "]\r\n" +
                                            "ind. clave: [" + oBanco.IndiceKPri.Value.ToString() + "]\r\n",
                                            false);
                                    }
                                    else
                                    {
                                        if (prmFechaOperacion.HasValue)
                                        {
                                            strFuncionApiEmpleada = "fDescifrarMensaje_3DES_RSA_TH";

                                            if (!prmIndKpriCiti.HasValue)
                                            {
                                                nCodigoRetorno = ObjetosGlobalesApp.objAPISEG.fDescifrarMensaje_3DES_RSA_TH(oDatosCliente.DataClienteCifrada,
                                                                    oDatosCliente.KsimCifrada,
                                                                    oBanco.CodBanco, oBanco.IndiceKPri.Value,
                                                                    prmFechaOperacion.Value.ToString("yyyyMMddHHmmss"),
                                                                    ref prmDataCliente);

                                                LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.SEGURIDAD, strHashcode,
                                                    "BL_SeguridadMsj.ValidarFirmaDataCliente",
                                                    "Se descifra la data cliente (prmIndKpriCiti es null). fDescifrarMensaje_3DES_RSA_TH\r\n" +
                                                    "data cliente Cifrada: [" + oDatosCliente.DataClienteCifrada + "]\r\n" +
                                                    "KSim Cifrada: [" + oDatosCliente.KsimCifrada + "]\r\n" +
                                                    "Cod Inst.: [" + oBanco.CodBanco + "]\r\n" +
                                                    "ind. clave: [" + oBanco.IndiceKPri.Value.ToString() + "]\r\n" +
                                                    "fecha: [" + prmFechaOperacion.Value.ToString("yyyyMMddHHmmss"),
                                                    false);
                                            }
                                            else
                                            {
                                                nCodigoRetorno = ObjetosGlobalesApp.objAPISEG.fDescifrarMensaje_3DES_RSA_TH(oDatosCliente.DataClienteCifrada,
                                                                    oDatosCliente.KsimCifrada,
                                                                    oBanco.CodBanco, prmIndKpriCiti.Value,
                                                                    prmFechaOperacion.Value.ToString("yyyyMMddHHmmss"),
                                                                    ref prmDataCliente);

                                                LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.SEGURIDAD, strHashcode,
                                                    "BL_SeguridadMsj.ValidarFirmaDataCliente",
                                                    "Se descifra la data cliente (prmIndKpriCiti no es null). fDescifrarMensaje_3DES_RSA_TH\r\n" +
                                                    "data cliente Cifrada: [" + oDatosCliente.DataClienteCifrada + "]\r\n" +
                                                    "KSim Cifrada: [" + oDatosCliente.KsimCifrada + "]\r\n" +
                                                    "Cod Inst.: [" + oBanco.CodBanco + "]\r\n" +
                                                    "ind. clave: [" + prmIndKpriCiti.Value.ToString() + "]\r\n" +
                                                    "fecha: [" + prmFechaOperacion.Value.ToString("yyyyMMddHHmmss"),
                                                    false);
                                            }
                                        }
                                        else
                                        {
                                            strMensajeError = "El parametro Fecha Operacion no fue establecido. Desciframiento de datos cliente.";
                                        }
                                    }

                                    if (nCodigoRetorno != 0)
                                    {
                                        if (nCodigoRetorno != -1)
                                        {
                                            BE_ErrorApiSeguridad oErrorApi = null;
                                            strMensajeError = this.ManejarErrorApiSeguridad(strFuncionApiEmpleada, nCodigoRetorno, ref oErrorApi);

                                            if (oErrorApi != null)
                                            {
                                                if (oErrorApi.RequiereReconexion)
                                                {
                                                    prmErrorEnBD = true;
                                                }
                                            }
                                        }
                                    }
                                    else
                                    {
                                        if (!String.IsNullOrEmpty(prmDataCliente))
                                        {
                                            prmDataCliente = prmDataCliente.Trim();
                                        }

                                        LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.SEGURIDAD, strHashcode,
                                            "BL_SeguridadMsj.ValidarFirmaDataCliente",
                                            "Se descifro la data cliente correctamente.", false);
                                    }

                                }
                                else
                                {
                                    prmErrorEnBD = true;
                                    strMensajeError = "El banco Citibank no tiene un indice de clave privada asignada.";
                                }
                            }
                            else
                            {
                                prmErrorEnBD = true;
                                strMensajeError = "No se encontro el banco Citi con codigo: " + strCodigoCiti;
                            }
                        }
                        else
                        {
                            //No es necesario establecerla, porque se hizo en la validacion de la firma
                            //strMensajeError = "La instancia del objeto global del API de seguridad no ha podido ser establecida.";
                        }
                    }
                    else
                    {
                        prmDataCliente = oDatosCliente.DataClienteCifrada;
                    }

                    if (Globales.MOSTRAR_DATA_CLIENTE_LOG)
                    {
                        LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.SEGURIDAD, strHashcode,
                            "BL_SeguridadMsj.ValidarFirmaDataCliente",
                            "El valor de Data Cliente descifrada es [" + prmDataCliente + "]", false);
                    }

                    if (!String.IsNullOrEmpty(strTmpMensajeError))
                    {
                        if (!String.IsNullOrEmpty(strMensajeError))
                        {
                            strMensajeError = strTmpMensajeError + "\r\n\r\nDescifradoDataCliente: [" + strMensajeError + "]";
                        }
                        else
                        {
                            strMensajeError = strTmpMensajeError;
                        }
                    }

                    #endregion
                }


            }
            catch (Exception ex)
            {
                strMensajeError = "Error, " + ex.Message + ". " + ex.StackTrace;
            }

            if (!String.IsNullOrEmpty(strMensajeError))
            {
                prmMensajeError = strMensajeError;

                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SEGURIDAD, strHashcode,
                    "BL_SeguridadMsj.ValidarFirmaDataCliente",
                    strMensajeError, true);
            }

            return blnFirmaClienteValida;
        }

        /// <summary>
        /// Validacion de firma del mensaje
        /// </summary>
        /// <param name="prmOperacionRecibida"></param>
        /// <returns></returns>
        public bool ValidarFirmaMensaje(String prmOrigenFlujo, BE_OperacionRecibida prmOperacionRecibida, out string prmMensajeError, out bool prmErrorEnBD) 
        {
            prmMensajeError = "";
            prmErrorEnBD = false;

            if (!Globales.APISEGURIDAD_USAR) return true;

            BL_General oBLGen = new BL_General(strHashcode);
            string strValidarFirma = oBLGen.ObtenerValorConfiguracion(Constantes.PARAM_VALIDAR_FIRMA);
            string strMensajeError = "";

            if (oBLGen.errorEnDAO)
            {
                prmMensajeError = "Error al obtener el indicador de validacion de firma desde la bd.";
                prmErrorEnBD = true;
                return false;
            }

            if (!String.IsNullOrEmpty(strValidarFirma) && strValidarFirma.Equals("1"))
            {
                //Validamos que el mensaje este firmado
                if (String.IsNullOrEmpty(prmOperacionRecibida.Firma))
                {
                    prmMensajeError = "La operacion no tiene firma.";

                    LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SEGURIDAD, strHashcode,
                        "BL_SeguridadMsj.ValidarFirmaMensaje",
                        "La firma del mensaje es NULL para la operacion con NumRefLBTR [" + prmOperacionRecibida.NumRefLBTR + "] del Banco Origen Origen [" + prmOperacionRecibida.CodBancoOrigen + "]. La validacion de la firma del mensaje retorna False.",
                        true);

                    return false;
                }

                if (prmOrigenFlujo == FlujoOperacionRecibida.FlujoNormal)
                {
                    Globales.THROPEREC_BLNAPIINVOCADO = true;
                    Globales.THROPEREC_DTULTINVOCAPI = DateTime.Now;
                }
                else if (prmOrigenFlujo == FlujoOperacionRecibida.FlujoContingencia)
                {
                    Globales.THROPERECCONTING_BLNAPIINVOCADO = true;
                    Globales.THROPERECCONTING_DTULTINVOCAPI = DateTime.Now;
                }
                bool blnResultVerifCnxActual = this.VerificarConexionActual();
                if (prmOrigenFlujo == FlujoOperacionRecibida.FlujoNormal)
                {
                    Globales.THROPEREC_BLNAPIINVOCADO = false;
                }
                else if (prmOrigenFlujo == FlujoOperacionRecibida.FlujoContingencia)
                {
                    Globales.THROPERECCONTING_BLNAPIINVOCADO = false;
                }
                
                if (blnResultVerifCnxActual)
                {
                    try
                    {
                        BE_Banco oBancoBCRP = null;
                        List<BE_Banco> lstBancos = null;
                        string strCodigoBCRP = "";
                        string strDatosEnClaro = "";
                        string strDatosCliente = prmOperacionRecibida.StrDatosCliente;

                        strCodigoBCRP = oBLGen.ObtenerValorConfiguracion(Constantes.PARAM_CODIGO_BCRP);
                        prmErrorEnBD = oBLGen.errorEnDAO;

                        if (prmErrorEnBD)
                        {
                            prmMensajeError = "Error al obtener el codigo BCRP de la tabla t_config.";
                            return false;
                        }

                        //Se obtiene los datos del banco BCRP
                        lstBancos = oBLGen.ObtenerBancos(new BE_Banco(strCodigoBCRP));
                        prmErrorEnBD = oBLGen.errorEnDAO;

                        if (prmErrorEnBD)
                        {
                            prmMensajeError = "Error al obtener el registro banco BCRP de la tabla bancos.";
                            return false;
                        }

                        if (lstBancos != null && lstBancos.Count > 0)
                        {
                            oBancoBCRP = lstBancos[0];

                            //Se verifica que el BCRP tenga asignado un indice de clave publica
                            if (oBancoBCRP.IndiceKPub.HasValue)
                            {
                                #region Data a Validar

                                //Transferencia
                                if (!String.IsNullOrEmpty(prmOperacionRecibida.CodBancoDestino)) strDatosEnClaro += prmOperacionRecibida.CodBancoDestino.Trim();
                                if (!String.IsNullOrEmpty(prmOperacionRecibida.CodBancoOrigen)) strDatosEnClaro += prmOperacionRecibida.CodBancoOrigen.Trim();
                                if (!String.IsNullOrEmpty(prmOperacionRecibida.CodConcepto)) strDatosEnClaro += prmOperacionRecibida.CodConcepto.Trim();                                
                                if (!String.IsNullOrEmpty(prmOperacionRecibida.CodMoneda)) strDatosEnClaro += prmOperacionRecibida.CodMoneda.Trim();
                                if (!String.IsNullOrEmpty(prmOperacionRecibida.CodServicio)) strDatosEnClaro += prmOperacionRecibida.CodServicio.Trim();
                                if (!String.IsNullOrEmpty(prmOperacionRecibida.CodigoSAB)) strDatosEnClaro += prmOperacionRecibida.CodigoSAB.Trim();
                                if (!String.IsNullOrEmpty(prmOperacionRecibida.CuentaDestino)) strDatosEnClaro += prmOperacionRecibida.CuentaDestino.Trim();
                                if (!String.IsNullOrEmpty(prmOperacionRecibida.CuentaInterbancariaSAB)) strDatosEnClaro += prmOperacionRecibida.CuentaInterbancariaSAB.Trim();
                                if (!String.IsNullOrEmpty(prmOperacionRecibida.CuentaOrigen)) strDatosEnClaro += prmOperacionRecibida.CuentaOrigen.Trim();
                                strDatosEnClaro += "{[REEMPLAZO1]}";//datoscliente
                                if (!String.IsNullOrEmpty(prmOperacionRecibida.EstadoLiquidacion)) strDatosEnClaro += prmOperacionRecibida.EstadoLiquidacion.Trim();
                                if (!String.IsNullOrEmpty(prmOperacionRecibida.FechaLiquidacion)) strDatosEnClaro += prmOperacionRecibida.FechaLiquidacion;
                                if (!String.IsNullOrEmpty(prmOperacionRecibida.FechaNegociacionCavali)) strDatosEnClaro += prmOperacionRecibida.FechaNegociacionCavali;
                                if (!String.IsNullOrEmpty(prmOperacionRecibida.HoraLiquidacion)) strDatosEnClaro += prmOperacionRecibida.HoraLiquidacion;
                                if (!String.IsNullOrEmpty(prmOperacionRecibida.InstruccionesPago)) strDatosEnClaro += prmOperacionRecibida.InstruccionesPago.Trim();
                                if (!String.IsNullOrEmpty(prmOperacionRecibida.Modalidad)) strDatosEnClaro += prmOperacionRecibida.Modalidad.Trim();

                                if (!String.IsNullOrEmpty(prmOperacionRecibida.MontoOperacionDestino))
                                    strDatosEnClaro += prmOperacionRecibida.MontoOperacionDestino;
                                else
                                    strDatosEnClaro += "0";

                                if (!String.IsNullOrEmpty(prmOperacionRecibida.MontoOperacionOrigen))
                                    strDatosEnClaro += prmOperacionRecibida.MontoOperacionOrigen;
                                else
                                    strDatosEnClaro += "0";

                                if (!String.IsNullOrEmpty(prmOperacionRecibida.NumRefCavali)) strDatosEnClaro += prmOperacionRecibida.NumRefCavali.Trim();
                                if (!String.IsNullOrEmpty(prmOperacionRecibida.NumRefLBTR)) strDatosEnClaro += prmOperacionRecibida.NumRefLBTR.Trim();
                                if (!String.IsNullOrEmpty(prmOperacionRecibida.NumRefLBTREnlace)) strDatosEnClaro += prmOperacionRecibida.NumRefLBTREnlace.Trim();
                                if (!String.IsNullOrEmpty(prmOperacionRecibida.NumRefOrigen)) strDatosEnClaro += prmOperacionRecibida.NumRefOrigen.Trim();

                                if (!String.IsNullOrEmpty(prmOperacionRecibida.TipoCambio))
                                    strDatosEnClaro += prmOperacionRecibida.TipoCambio;
                                else
                                    strDatosEnClaro += "0";

                                if (!String.IsNullOrEmpty(prmOperacionRecibida.TipoParticipanteCavali)) strDatosEnClaro += prmOperacionRecibida.TipoParticipanteCavali.Trim();
                                if (!String.IsNullOrEmpty(prmOperacionRecibida.TipoRegistro)) strDatosEnClaro += prmOperacionRecibida.TipoRegistro.Trim();

                                string strDataEntrada = strDatosEnClaro.Replace("{[REEMPLAZO1]}", strDatosCliente);

                                #endregion

                                if (prmOrigenFlujo == FlujoOperacionRecibida.FlujoNormal)
                                {
                                    Globales.THROPEREC_BLNAPIINVOCADO = true;
                                    Globales.THROPEREC_DTULTINVOCAPI = DateTime.Now;
                                }
                                else if (prmOrigenFlujo == FlujoOperacionRecibida.FlujoContingencia)
                                {
                                    Globales.THROPERECCONTING_BLNAPIINVOCADO = true;
                                    Globales.THROPERECCONTING_DTULTINVOCAPI = DateTime.Now;
                                }
                                int nCodigoRetorno = ObjetosGlobalesApp.objAPISEG.fValidaFirma_RSA(Constantes.APISEGURIDAD_METODOHASH, strDataEntrada,
                                                                                    prmOperacionRecibida.Firma, oBancoBCRP.CodBanco,
                                                                                    oBancoBCRP.IndiceKPub.Value);
                                if (prmOrigenFlujo == FlujoOperacionRecibida.FlujoNormal)
                                {
                                    Globales.THROPEREC_BLNAPIINVOCADO = false;
                                }
                                else if (prmOrigenFlujo == FlujoOperacionRecibida.FlujoContingencia)
                                {
                                    Globales.THROPERECCONTING_BLNAPIINVOCADO = false;
                                }

                                LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.SEGURIDAD, strHashcode,
                                    "BL_SeguridadMsj.ValidarFirmaMensaje",
                                    "Se valida la firma del mensaje. fValidaFirma_RSA\r\n" +
                                    "Metodo Hash: [" + Constantes.APISEGURIDAD_METODOHASH.ToString() + "]\r\n" +
                                    "Data Entrada: [" + strDataEntrada + "]\r\n" +
                                    "firma: [" + prmOperacionRecibida.Firma + "]\r\n" +
                                    "Codigo Inst: [" + oBancoBCRP.CodBanco + "]\r\n" +
                                    "ind. clave: [" + oBancoBCRP.IndiceKPub.Value.ToString() + "]",
                                    false);

                                if (nCodigoRetorno != 0)
                                {
                                    BE_ErrorApiSeguridad oErrorApi = null;
                                    strMensajeError = this.ManejarErrorApiSeguridad("fValidaFirma_RSA", nCodigoRetorno, ref oErrorApi);

                                    if (oErrorApi!=null)
                                    {
                                        if (oErrorApi.RequiereReconexion)
                                        {
                                            prmErrorEnBD = true;
                                        }
                                    }
                                }
                                else
                                {
                                    LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.SEGURIDAD, strHashcode,
                                        "BL_SeguridadMsj.ValidarFirmaMensaje",
                                        "La firma del mensaje es correcta.", false);
                                }
                            }
                            else
                            {
                                prmErrorEnBD = true;
                                strMensajeError = "El banco BCRP no tiene un indice de clave publica asignada.";
                            }
                        }
                        else
                        {
                            prmErrorEnBD = true;
                            strMensajeError = "No se encontro el banco BCRP con codigo: " + strCodigoBCRP;
                        }

                    }
                    catch (Exception ex)
                    {
                        strMensajeError = "Error, " + ex.Message + ". " + ex.StackTrace;
                    }
                }
                else
                {
                    prmErrorEnBD = true;
                    strMensajeError = "La instancia del objeto global del API de seguridad no ha podido ser establecida.";
                }

                if (!String.IsNullOrEmpty(strMensajeError))
                {
                    prmMensajeError = strMensajeError;

                    LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SEGURIDAD, strHashcode,
                        "BL_SeguridadMsj.ValidarFirmaMensaje",
                        strMensajeError, true);

                    return false;
                }

            }

            return true;
        }

        /// <summary>
        /// Verifica la conexion actual del api de seguridad
        /// Si no esta inicializado, lo inicializa. Si esta inicializado, verifica si no esta corrupto.
        /// </summary>
        /// <returns>Retorna true si la verificacion se hizo correctamente. False si hubo problemas de conectividad con la bd.</returns>
        public bool VerificarConexionActual()
        {
            //Si no se usa el API
            if (!Globales.APISEGURIDAD_USAR) return true;

            //Para verificar la conexi�n se usara una funcion cualquiera del api ya que esta intentara usar
            //la actual conexion. Si es que no hubiese, se generar�a un codigo de retorno diferente de cero, 
            //el cual sera evaluado en la reconexion
            String strMensajeError = "";
            bool blnExito = false;

            try
            {
                LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.SEGURIDAD, strHashcode,
                    "BL_SeguridadMsj.VerificarConexionActual",
                    "Se procede a verificar la conexion actual del API de Seguridad.", false);

                if (ObjetosGlobalesApp.objAPISEG == null)
                {
                    LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.SEGURIDAD, strHashcode,
                        "BL_SeguridadMsj.VerificarConexionActual",
                        "Se procede a invocar a la funcionar Conectar_a_BaseDatos debido a que el objeto ObjetosGlobalesApp.objAPISEG era NULL.", 
                        false);

                    ObjetosGlobalesApp.objAPISEG = this.Conectar_a_BaseDatos();

                    if (ObjetosGlobalesApp.objAPISEG != null)//Si se pudo inicializar
                    {
                        blnExito = true;
                    }
                }
                else
                {
                    string strFirma = string.Empty;
                    BL_General oBLGen = new BL_General(strHashcode);
                    string strCodigoCiti = null;
                    BE_Banco oBanco = null;
                    List<BE_Banco> lstBancos = null;

                    strCodigoCiti = oBLGen.ObtenerValorConfiguracion(Constantes.PARAM_CODIGO_CITIBANK);

                    lstBancos = oBLGen.ObtenerBancos(new BE_Banco(strCodigoCiti));

                    if (lstBancos != null && lstBancos.Count > 0)
                    {
                        //Banco Citi
                        oBanco = lstBancos[0];

                        //Si tiene indice de clave primaria
                        if (oBanco.IndiceKPri.HasValue)
                        {
                            int nCodigoRetorno = ObjetosGlobalesApp.objAPISEG.fGeneraFirma_RSA(Constantes.APISEGURIDAD_METODOHASH,
                                                                                        "DATAFIRMA",
                                                                                        strCodigoCiti,
                                                                                        oBanco.IndiceKPri.Value,
                                                                                        ref strFirma);

                            //Se evalua si hace reconexion o no, dependiendo del error obtenido
                            if (nCodigoRetorno != 0)
                            {
                                BE_ErrorApiSeguridad oErrorApi = null;

                                strMensajeError = this.ManejarErrorApiSeguridad("fGeneraFirma_RSA", nCodigoRetorno, ref oErrorApi);

                                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SEGURIDAD, strHashcode,
                                    "BL_SeguridadMsj.VerificarConexionActual",
                                    strMensajeError,
                                    true);

                                strMensajeError = "";//Se limpia ya que se mostro en este punto para asi no mostrarlo mas adelante

                                if (oErrorApi != null)
                                {
                                    if (oErrorApi.RequiereReconexion)
                                    {
                                        LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SEGURIDAD, strHashcode,
                                            "BL_SeguridadMsj.VerificarConexionActual",
                                            "El error indica Reconexion, se procede a invocar a la funcionar Conectar_a_BaseDatos debido a que el objeto ObjetosGlobalesApp.objAPISEG habia perdido la conexion.",
                                            false);

                                        ObjetosGlobalesApp.objAPISEG = this.Conectar_a_BaseDatos();

                                        if (ObjetosGlobalesApp.objAPISEG != null)
                                        {
                                            blnExito = true;
                                        }
                                    }
                                }
                            }
                            else
                            {
                                blnExito = true;
                            }
                        }
                        else
                        {
                            strMensajeError = "El banco " + oBanco.NomBancoBCR +
                                                " no tiene un indice de clave privada asignada.";
                        }
                    }
                    else
                    {
                        strMensajeError = "No se encontro el banco con codigo: " + strCodigoCiti;
                    }
                                        
                }
            }
            catch (Exception ex)
            {
                strMensajeError = "SEC1. Error durante la verificacion de la conexion del api: " + ex.Message + ". " + ex.StackTrace;

                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SEGURIDAD, strHashcode,
                    "BL_SeguridadMsj.VerificarConexionActual",
                    strMensajeError + "\r\nSEC2. Se procede a reinicializar el API de seguridad a pesar del error en la verificacion usando la generacion de firma.", false);

                try
                {
                    ObjetosGlobalesApp.objAPISEG = this.Conectar_a_BaseDatos();

                    if (ObjetosGlobalesApp.objAPISEG != null)
                    {
                        blnExito = true;
                    }
                }
                catch(Exception subex)
                {
                    strMensajeError += "\r\nError en la reinicializacion del api: " + subex.Message + ". " + subex.StackTrace;
                }

                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SEGURIDAD, strHashcode,
                    "BL_SeguridadMsj.VerificarConexionActual",
                    "SEC3. Finaliza la reinicializacion del API de seguridad.", false);
            }

            if (!String.IsNullOrEmpty(strMensajeError))
            {
                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SEGURIDAD, strHashcode,
                    "BL_SeguridadMsj.VerificarConexionActual",
                    strMensajeError, true);
            }

            LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.SEGURIDAD, strHashcode,
                "BL_SeguridadMsj.VerificarConexionActual",
                "Finaliza la verificacion de la conexion actual del API de Seguridad.", false);

            return blnExito;
        }
        
    }
}
