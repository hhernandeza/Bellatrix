using System;
using System.Web.Services;
using System.Web.Services.Protocols;
using System.IO;
using System.Net;
using System.Configuration;
using System.Xml;
using System.Text;
using System.Threading;
using TBEWinServ.Utilitarios;

namespace TBEWinServ.LogicaNegocio
{
    // Define a SOAP Extension that traces the SOAP request and SOAP
    // response for the XML Web service method the SOAP extension is
    // applied to.
    public class TraceExtension : SoapExtension
    {
        Stream oldStream;
        Stream newStream;
        string filename;

        // Save the Stream representing the SOAP request or SOAP response into
        // a local memory buffer.
        public override Stream ChainStream(Stream stream)
        {
            oldStream = stream;
            newStream = new MemoryStream();
            return newStream;
        }

        // When the SOAP extension is accessed for the first time, the XML Web
        // service method it is applied to is accessed to store the file
        // name passed in, using the corresponding SoapExtensionAttribute.    
        public override object GetInitializer(LogicalMethodInfo methodInfo, SoapExtensionAttribute attribute)
        {
            return ((TraceExtensionAttribute)attribute).Filename;
        }

        // The SOAP extension was configured to run using a configuration file
        // instead of an attribute applied to a specific XML Web service
        // method.
        public override object GetInitializer(Type WebServiceType)
        {
            // Return a file name to log the trace information to, based on the
            // type.
            string strRuta = "C:\\" + WebServiceType.FullName + ".log";

            if (!String.IsNullOrEmpty(ConfigurationManager.AppSettings["TRAZA_SOAPMSJ_RUTA"]))
            {
                strRuta = ConfigurationManager.AppSettings["TRAZA_SOAPMSJ_RUTA"];
                if (!strRuta.EndsWith(@"\"))
                {
                    strRuta += @"\";
                }
                strRuta += "TRAZA_yyyyMMdd_" + WebServiceType.FullName + ".txt";
            }
            return strRuta;
        }

        // Receive the file name stored by GetInitializer and store it in a
        // member variable for this specific instance.
        public override void Initialize(object initializer)
        {
            filename = (string)initializer;
        }

        //  If the SoapMessageStage is such that the SoapRequest or
        //  SoapResponse is still in the SOAP format to be sent or received,
        //  save it out to a file.
        public override void ProcessMessage(SoapMessage message)
        {
            switch (message.Stage)
            {
                case SoapMessageStage.BeforeSerialize:
                    break;
                case SoapMessageStage.AfterSerialize:
                    WriteOutput(message);
                    break;
                case SoapMessageStage.BeforeDeserialize:
                    WriteInput(message);
                    break;
                case SoapMessageStage.AfterDeserialize:
                    break;
                default:
                    throw new Exception("invalid stage");
            }
        }

        private void ModificarMensaje(Stream prmStream)
        {
            try
            {
                prmStream.Position = 0;

                String strCodTramaAuditoria = "";
                Stream streamModificado = new MemoryStream();
                String strDataXML = (new StreamReader(prmStream)).ReadToEnd();
                XmlDocument xmlDoc = new XmlDocument();

                xmlDoc.LoadXml(strDataXML);

                //Actualizando el encoding del mensaje
                if (xmlDoc.FirstChild.NodeType == XmlNodeType.XmlDeclaration)
                {
                    XmlDeclaration decl = (XmlDeclaration)xmlDoc.FirstChild;
                    decl.Encoding = "ISO-8859-1";
                }

                //Buscando por el nodo datosCliente
                XmlNodeList nodeList = xmlDoc.GetElementsByTagName("datosCliente");
                XmlNode nodoDatosCliente = null;
                XmlNode nodoDatosClienteHijo = null;
                String strDatosClienteOld = "";

                if (nodeList.Count > 0)
                {
                    nodoDatosCliente = nodeList.Item(0);
                    nodoDatosClienteHijo = nodoDatosCliente.ChildNodes.Count > 0 ? nodoDatosCliente.ChildNodes[0] : null;

                    if (nodoDatosClienteHijo != null)
                    {
                        strDatosClienteOld = nodoDatosClienteHijo.Value;

                        if (!String.IsNullOrEmpty(strDatosClienteOld))
                        {
                            XmlCDataSection cdata = xmlDoc.CreateCDataSection(strDatosClienteOld);
                            nodoDatosCliente.RemoveChild(nodoDatosClienteHijo);
                            nodoDatosCliente.AppendChild(cdata);
                        }
                    }
                }

                //Buscando el nodo numRefLBTREnlace para obtener los ultimos 20 caracteres
                nodeList = xmlDoc.GetElementsByTagName("numRefLBTREnlace");
                XmlNode nodoNumRefLBTREnlace = null;
                XmlNode nodoNumRefLBTREnlaceHijo = null;
                String strNumRefLBTREnlace = "";

                if (nodeList.Count > 0)
                {
                    nodoNumRefLBTREnlace = nodeList.Item(0);
                    nodoNumRefLBTREnlaceHijo = nodoNumRefLBTREnlace.ChildNodes.Count > 0 ? nodoNumRefLBTREnlace.ChildNodes[0] : null;

                    if (nodoNumRefLBTREnlaceHijo != null)
                    {
                        strNumRefLBTREnlace = nodoNumRefLBTREnlaceHijo.Value;

                        if (!String.IsNullOrEmpty(strNumRefLBTREnlace))
                        {
                            //Minimo sera tama�o 20 porque cuando se hace el despacho en BL_TRANSFERENCIA
                            //se le agrega 20 caracteres por el cod trama auditoria (aunque sea espacios en blanco).
                            if (strNumRefLBTREnlace.Length >= 20)
                            {
                                strCodTramaAuditoria = strNumRefLBTREnlace.Substring(strNumRefLBTREnlace.Length - 20, 20);
                                String strNumRefLBTREnlaceNuevo = strNumRefLBTREnlace.Remove(strNumRefLBTREnlace.Length - 20);
                                nodoNumRefLBTREnlaceHijo.Value = strNumRefLBTREnlaceNuevo;
                            }
                        }
                    }

                }

                //Actualizando mensaje                
                xmlDoc.Save(streamModificado);

                //Se actualiza la trama para el correspondiente codigo strCodTramaAuditoria
                streamModificado.Position = 0;
                ParametrosAuditoria oParametrosAuditoria = new ParametrosAuditoria();
                strCodTramaAuditoria = strCodTramaAuditoria.Trim();
                if (!String.IsNullOrEmpty(strCodTramaAuditoria))
                {
                    oParametrosAuditoria.CodTramaAuditoria = strCodTramaAuditoria;
                    oParametrosAuditoria.Trama = (new StreamReader(streamModificado)).ReadToEnd();
                    ParameterizedThreadStart tstart = new ParameterizedThreadStart(ActualizarTramaAuditoria);
                    Thread thr_Trama = new Thread(tstart);
                    thr_Trama.Start(oParametrosAuditoria);
                }

                //Se copia el stream modificado al stream que se utiliza en el proceso
                streamModificado.Position = 0;
                newStream = new MemoryStream();
                this.Copy(streamModificado, newStream);
            }
            catch (Exception ex)
            {
                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.TRAZA,
                    Utilitario.RetornaHashCode(Thread.CurrentThread.GetHashCode()),
                    "TraceExtension.ModificarMensaje", "Error: " + ex.Message + ". " + ex.StackTrace, true);
            }
        }

        private void ActualizarTramaAuditoria(object prmParametrosAuditoria)
        {
            ParametrosAuditoria oParametrosAuditoria = (ParametrosAuditoria)prmParametrosAuditoria;

            BL_Auditoria oBLAuditoria = new BL_Auditoria(Utilitario.RetornaHashCode(Thread.CurrentThread.GetHashCode()));
            oBLAuditoria.ActualizarAuditoria(oParametrosAuditoria.CodTramaAuditoria, oParametrosAuditoria.Trama);
        }

        public void WriteOutput(SoapMessage message)
        {
            try
            {
                if (filename.Contains("LBTRTransferenciaService"))
                {
                    ModificarMensaje(newStream);
                }

                bool blnMostrarTraza = true;

                if (filename.Contains("LBTRAutenticacionService"))
                {
                    blnMostrarTraza = Globales.MOSTRAR_SID_LOG_TRAZA;
                }
                else if (filename.Contains("PasswordSafeService.WSAPR"))
                {
                    blnMostrarTraza = Globales.MOSTRAR_TRAZA_PSAFE;
                }

                if (Globales.NO_MOSTRAR_TRAZA)//si es true, no se mostrara traza a pesar de lo anterior
                {
                    blnMostrarTraza = false;
                }

                if (blnMostrarTraza)
                {
                    string strRutaTraza = "";

                    try
                    {
                        newStream.Position = 0;
                        strRutaTraza = filename.Replace("yyyyMMdd", DateTime.Today.ToString("yyyyMMdd"));
                        FileStream fs = new FileStream(strRutaTraza, FileMode.Append, FileAccess.Write);
                        StreamWriter w = new StreamWriter(fs);

                        string soapString = (message is SoapServerMessage) ? "SoapResponse" : "SoapRequest";
                        w.WriteLine("-----" + soapString + " at " + DateTime.Now);
                        w.Flush();
                        Copy(newStream, fs);
                        w.Close();
                        fs.Close();
                    }
                    catch (Exception subex)
                    {
                        LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.TRAZA,
                            Utilitario.RetornaHashCode(Thread.CurrentThread.GetHashCode()),
                            "TraceExtension.WriteOutput", "Error al generar la traza en [" + strRutaTraza + "]: " + subex.Message + ". " + subex.StackTrace, true);
                    }
                }

                newStream.Position = 0;
                Copy(newStream, oldStream);
            }
            catch (Exception ex)
            {
                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.TRAZA,
                    Utilitario.RetornaHashCode(Thread.CurrentThread.GetHashCode()),
                    "TraceExtension.WriteOutput", "Error: " + ex.Message + ". " + ex.StackTrace, true);
            }
        }

        public void WriteInput(SoapMessage message)
        {
            try
            {
                Copy(oldStream, newStream);

                bool blnMostrarTraza = true;

                if (filename.Contains("LBTRAutenticacionService"))
                {
                    blnMostrarTraza = Globales.MOSTRAR_SID_LOG_TRAZA;
                }
                else if (filename.Contains("PasswordSafeService.WSAPR"))
                {
                    blnMostrarTraza = Globales.MOSTRAR_TRAZA_PSAFE;
                }

                if (Globales.NO_MOSTRAR_TRAZA)//si es true, no se mostrara traza a pesar de lo anterior
                {
                    blnMostrarTraza = false;
                }

                if (blnMostrarTraza)
                {
                    string strRutaTraza = "";

                    try
                    {
                        strRutaTraza = filename.Replace("yyyyMMdd", DateTime.Today.ToString("yyyyMMdd"));
                        FileStream fs = new FileStream(strRutaTraza, FileMode.Append, FileAccess.Write);
                        StreamWriter w = new StreamWriter(fs);

                        string soapString = (message is SoapServerMessage) ? "SoapRequest" : "SoapResponse";
                        w.WriteLine("-----" + soapString + " at " + DateTime.Now);
                        w.Flush();
                        newStream.Position = 0;
                        Copy(newStream, fs);
                        w.Close();
                        fs.Close();
                    }
                    catch (Exception subex)
                    {
                        LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.TRAZA,
                            Utilitario.RetornaHashCode(Thread.CurrentThread.GetHashCode()),
                            "TraceExtension.WriteInput", "Error al generar la traza en [" + strRutaTraza + "]: " + subex.Message + ". " + subex.StackTrace, true);
                    }
                }

                newStream.Position = 0;
            }
            catch (Exception ex)
            {
                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.TRAZA,
                    Utilitario.RetornaHashCode(Thread.CurrentThread.GetHashCode()),
                    "TraceExtension.WriteInput", "Error: " + ex.Message + ". " + ex.StackTrace, true);
            }
        }

        void Copy(Stream from, Stream to)
        {
            TextReader reader = new StreamReader(from);
            TextWriter writer = new StreamWriter(to);
            writer.WriteLine(reader.ReadToEnd());
            writer.Flush();
        }
    }

    // Create a SoapExtensionAttribute for the SOAP Extension that can be
    // applied to an XML Web service method.
    [AttributeUsage(AttributeTargets.All)]
    public class TraceExtensionAttribute : SoapExtensionAttribute
    {

        private string filename = "c:\\log.txt";
        private int priority;

        public override Type ExtensionType
        {
            get { return typeof(TraceExtension); }
        }

        public override int Priority
        {
            get { return priority; }
            set { priority = value; }
        }

        public string Filename
        {
            get
            {
                return filename;
            }
            set
            {
                filename = value;
            }
        }
    }

    [Serializable]
    public class ParametrosAuditoria
    {
        private String strCodTramaAuditoria;

        public String CodTramaAuditoria
        {
            get { return strCodTramaAuditoria; }
            set { strCodTramaAuditoria = value; }
        }

        private String strTrama;

        public String Trama
        {
            get { return strTrama; }
            set { strTrama = value; }
        }

    }

}