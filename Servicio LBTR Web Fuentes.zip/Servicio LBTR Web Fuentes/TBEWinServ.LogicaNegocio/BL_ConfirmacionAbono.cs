using System;
using System.Collections.Generic;
using System.Text;
using TBEWinServ.AccesoDatos;
using TBEWinServ.EntidadesNegocio.Generales;
using TBEWinServ.EntidadesNegocio.ConfirmacionAbono;
using TBEWinServ.Utilitarios;
using TBEWinServ.Componentes;

namespace TBEWinServ.LogicaNegocio
{
    public class BL_ConfirmacionAbono
    {
        private string strHashcode = "";

        public BL_ConfirmacionAbono(string prmHashcode) 
        {
            strHashcode = prmHashcode;
        }

        public void ConfirmarAbonoCliente() 
        {
            if (!String.IsNullOrEmpty(Globales.CADENA_CONEXION))
            {
                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.CONFIRMACION_ABONO, strHashcode,
                    "BL_ConfirmacionAbono.ConfirmarAbonoCliente",
                    "Inicia el proceso de envio automatico de Confirmaciones de Abono al BCRP.", false);

                DA_ConfirmacionAbono oDAConfAbono = new DA_ConfirmacionAbono(strHashcode);
                BE_ConfirmacionAbono oConfAbonoParam = new BE_ConfirmacionAbono();
                oConfAbonoParam.FechaLiquidacion = DateTime.Now.ToString("yyyyMMdd");
                oConfAbonoParam.Estado = Estados.PROCESADO;
                List<BE_ConfirmacionAbono> lstOperaciones = oDAConfAbono.Obtener_Operaciones_Confirmar(oConfAbonoParam);

                if (!String.IsNullOrEmpty(Globales.SID))
                {
                    if (lstOperaciones != null)
                    {
                        foreach (BE_ConfirmacionAbono oOperacion in lstOperaciones)
                        {
                            ConfirmarAbonoCliente(oOperacion.NumRefLBTR, true);
                        }
                    }
                }
                else
                {
                    LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.CONFIRMACION_ABONO, strHashcode,
                        "BL_ConfirmacionAbono.ConfirmarAbonoCliente",
                        "El SID no tiene valor. No se puede realizar la confirmacion de abono automatico.", false);
                }

                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.CONFIRMACION_ABONO, strHashcode,
                    "BL_ConfirmacionAbono.ConfirmarAbonoCliente",
                    "Finaliza el proceso de envio automatico de Confirmaciones de Abono al BCRP.", false);
            }
        }

        public int ConfirmarAbonoCliente(string prmNumRefLBTR, bool prmEsAutomatico) 
        {
            LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.CONFIRMACION_ABONO, strHashcode,
                "BL_ConfirmacionAbono.ConfirmarAbonoCliente",
                "Inicia el envio de la confirmacion de abono de la operacion: " + prmNumRefLBTR, false);
                        
            int nRetorno = 0;
            string strFirmaMsj = null;
            string strMsjError = "";
            WS_LBTRTransferenciaService oWSTransf = new WS_LBTRTransferenciaService(strHashcode);
                        
            oWSTransf.ConfirmarAbonoClienteRespuestaRecibida += new EventHandler<RespuestaBCRPEventArgs>(oWSTransf_ConfirmarAbonoClienteRespuestaRecibida);
            oWSTransf.OnConfirmacionAbonoError += new EventHandler<ConfirmacionAbonoEventArgs>(oWSTransf_OnConfirmacionAbonoError);

            if (!String.IsNullOrEmpty(Globales.CADENA_CONEXION))
            {
                if (!String.IsNullOrEmpty(Globales.SID))
                {
                    //Por ser automatico, se usaran los flag de verificacion dentro del generarfirma
                    strFirmaMsj = (new BL_SeguridadMsj(strHashcode)).GenerarFirma(prmEsAutomatico, prmNumRefLBTR, out strMsjError);

                    if (!String.IsNullOrEmpty(strFirmaMsj))
                    {
                        BE_ConfirmacionAbono oOperacion = new BE_ConfirmacionAbono();
                        oOperacion.NumRefLBTR = prmNumRefLBTR;
                        oOperacion.Estado = Estados.ENVIADO;

                        if (Actualizar_Operacion(oOperacion))
                        {
                            OperacionID oOperacionID = new OperacionID();
                            oOperacionID.NumRefLBTR = oOperacion.NumRefLBTR;
                            oOperacionID.EstadoOriginal = Estados.PROCESADO;

                            try
                            {
                                nRetorno = oWSTransf.ConfirmarAbonoCliente(Globales.SID, oOperacionID, strFirmaMsj);
                            }
                            catch (Exception ex)
                            {
                                nRetorno = 0;

                                strMsjError = "Error de Confirmacion Abono para " + prmNumRefLBTR + ": " + ex.Message + ". " + ex.StackTrace;
                            }
                        }
                    }
                    else
                    {
                        //Si hubo error:
                        strMsjError = "Error al generar la firma para la operacion [" + prmNumRefLBTR + "] a confirmar abono: [" + strMsjError + "]";
                    }
                }
                else
                {
                    strMsjError = "El valor del SID es nulo. El servicio LBTR no tiene una sesion activa.";
                }

            }
            else
            {
                strMsjError = "No se ha establecido la cadena de conexion.";
            }

            if (!String.IsNullOrEmpty(strMsjError))
            {
                (new BL_General(strHashcode)).InsertarLogError(prmNumRefLBTR, strMsjError, false);

                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.CONFIRMACION_ABONO, strHashcode,
                    "BL_ConfirmacionAbono.ConfirmarAbonoCliente",
                    strMsjError, true);
            }

            LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.CONFIRMACION_ABONO, strHashcode,
                "BL_ConfirmacionAbono.ConfirmarAbonoCliente",
                "Finaliza el envio de la confirmacion de abono de la operacion: " + prmNumRefLBTR, false);

            return nRetorno;
        }
                
        private void oWSTransf_ConfirmarAbonoClienteRespuestaRecibida(object sender, RespuestaBCRPEventArgs e)
        {
            BE_ConfirmacionAbono oOperacion = new BE_ConfirmacionAbono();
            oOperacion.NumRefLBTR = e.strNumRefLBTR;
            //Se recibe el estado 4 Procesado del BCRP
            oOperacion.Estado = (new BL_General(strHashcode)).Obtener_Estado_Equivalente(e.strEstado, TipoEstado.Liquidacion);
            oOperacion.ConfirmaAbono = "2";
            this.Actualizar_Operacion(oOperacion);

            LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.CONFIRMACION_ABONO, strHashcode,
                "BL_ConfirmacionAbono.oWSTransf_ConfirmarAbonoClienteRespuestaRecibida",
                "La funcion ConfirmacionAbonoCliente del web service retorno: " +
                "NumRefLBTR: " + e.strNumRefLBTR + "; Estado: " + oOperacion.Estado + "; Estado BCRP: " + e.strEstado, false);
        }
        
        private void oWSTransf_OnConfirmacionAbonoError(object sender, ConfirmacionAbonoEventArgs e)
        {
            if (!String.IsNullOrEmpty(e.CodigoError) && e.CodigoError.Equals(Constantes.SERVICIOLBTR_SESION_NO_ACTIVA)) 
            {
                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.CONFIRMACION_ABONO, strHashcode, 
                    "BL_ConfirmacionAbono.oWSTransf_OnConfirmacionAbonoError",
                    "Debido a que el codigo de error retornado es " + Constantes.SERVICIOLBTR_SESION_NO_ACTIVA +
                    " (Sesion no activa), \r\nse procedera a invocar al metodo Logon del servicio de autenticacion del LBTR.", true);
                Globales.SID = null;                
            }

            //Se revierte el estado al original
            BE_ConfirmacionAbono oOperacion = new BE_ConfirmacionAbono();
            oOperacion.NumRefLBTR = e.OperacionId.NumRefLBTR;
            oOperacion.Estado = Estados.ERROR_TRX;
            if (!String.IsNullOrEmpty(e.CodigoError))
            {
                if (e.CodigoError.Equals(Constantes.SERVICIOLBTR_OPER_YA_CONFIRMADA))
                {
                    oOperacion.ConfirmaAbono = "2";
                }
            }
            this.Actualizar_Operacion(oOperacion);

            string strMsjError = null;

            if (!String.IsNullOrEmpty(e.CodigoError))
            {
                strMsjError = "Error, el servicio web del BCRP respondio: " + e.CodigoError + " - " + e.MensajeError + ".";
            }
            else
            {
                strMsjError = "Error al utilizar el servicio web del BCRP. " + e.MensajeError;
            }

            (new BL_General(strHashcode)).InsertarLogError(e.OperacionId.NumRefLBTR, strMsjError, false);

            LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.CONFIRMACION_ABONO, strHashcode,
                "BL_ConfirmacionAbono.oWSTransf_OnConfirmacionAbonoError",
                strMsjError, true);
        }

        private bool Actualizar_Operacion(BE_ConfirmacionAbono prmOperacion)
        {
            if ((new DA_ConfirmacionAbono(strHashcode)).Actualizar_Operacion(prmOperacion) == false)
            {
                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.CONFIRMACION_ABONO, strHashcode, 
                    "BL_ConfirmacionAbono.Actualizar_Operacion",
                    "No se pudo actualizar la operacion: NumRefLBTR [" + prmOperacion.NumRefLBTR +
                    "] con la data: Estado Liquidacion = " + prmOperacion.Estado + "; ConfirmaAbono = " + prmOperacion.ConfirmaAbono, true);

                (new BL_General(strHashcode)).InsertarLogError(prmOperacion.NumRefLBTR,
                    "No se pudo actualizar la operacion: NumRefLBTR [" + prmOperacion.NumRefLBTR +
                    "] con la data: Estado Liquidacion = " + prmOperacion.Estado + "; ConfirmaAbono = " + prmOperacion.ConfirmaAbono, false);

                return false;
            }

            LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.CONFIRMACION_ABONO, strHashcode, 
                "BL_ConfirmacionAbono.Actualizar_Operacion",
                "Se actualizo la operacion: NumRefLBTR: " + prmOperacion.NumRefLBTR +
                " con la data: Estado Liquidacion = " + prmOperacion.Estado + "; ConfirmaAbono = " + prmOperacion.ConfirmaAbono, false);

            return true;
        }
                
    }
}
