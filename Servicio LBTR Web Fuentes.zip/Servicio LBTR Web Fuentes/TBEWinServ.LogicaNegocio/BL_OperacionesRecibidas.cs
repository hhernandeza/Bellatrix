using System;
using System.Collections.Generic;
using System.Configuration;
using System.Text;
using System.Threading;
using System.IO;
using TBEWinServ.AccesoDatos;
using TBEWinServ.EntidadesNegocio.Generales;
using TBEWinServ.EntidadesNegocio.OperacionesRecibidas;
using TBEWinServ.EntidadesNegocio.Transferencia;
using TBEWinServ.EntidadesNegocio.CompraVenta;
using TBEWinServ.Utilitarios;
using System.Xml.Serialization;

namespace TBEWinServ.LogicaNegocio
{
    public class BL_OperacionesRecibidas
    {
        List<BE_Concepto> lstConceptos = null;
        private string strEstadoOriginalRecibido = "";
        private string strMensajeErrorFirmaMsj = "";
        private string strMensajeErrorValidDataCliente = "";
        private bool esFirmaBCRPValida = false;
        private bool esFirmaClienteValida = false;
        private string strHashcode = "";

        public BL_OperacionesRecibidas(string prmHashcode)
        {
            strHashcode = prmHashcode;
        }

        public void ProcesarOperacionesRecibidas()
        {
            if (!String.IsNullOrEmpty(Globales.CADENA_CONEXION))
            {
                //Input
                String strRutaOpeRec = ConfigurationManager.AppSettings["RUTA_RECEPCION_OPERACIONES"];//Ruta de recepcion de avisos de afectacion
                String[] arrArchivosOpeRec = null;

                //Output
                String strRutaOpeRecNoProc = ConfigurationManager.AppSettings["RUTA_CONTINGENCIA_OPERACIONES_NOPROCESADAS"];//Ruta de deposito de las operaciones que no fueron grabadas

                try
                {
                    if (String.IsNullOrEmpty(strRutaOpeRec) || !Directory.Exists(strRutaOpeRec))
                    {
                        LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.AVISO_AFECTACION, strHashcode,
                            "BL_OperacionesRecibidas.ProcesarOperacionesRecibidas",
                            "El parametro RUTA_RECEPCION_OPERACIONES para operaciones recibidas - flujo normal no esta establecido o la ruta no es valida. Revisar el archivo .config", true);
                        return;
                    }
                     
                    if (String.IsNullOrEmpty(strRutaOpeRecNoProc) || !Directory.Exists(strRutaOpeRecNoProc))
                    {
                        LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.AVISO_AFECTACION, strHashcode,
                            "BL_OperacionesRecibidas.ProcesarOperacionesRecibidas",
                            "El parametro RUTA_CONTINGENCIA_OPERACIONES_NOPROCESADAS para operaciones recibidas - flujo normal no esta establecido o la ruta no es valida. Revisar el archivo .config", true);
                        return;
                    }

                    strRutaOpeRecNoProc = Path.Combine(strRutaOpeRecNoProc, DateTime.Today.ToString("yyyyMMdd"));
                    arrArchivosOpeRec = Directory.GetFileSystemEntries(strRutaOpeRec, "OPE_*.xml");

                    if (arrArchivosOpeRec.Length > 0)
                    {
                        lstConceptos = (new DA_General(strHashcode)).Obtener_Conceptos(new BE_Concepto(""));//Trae todos los conceptos

                        if (lstConceptos != null)
                        {
                            for (int i = 0; i < arrArchivosOpeRec.Length; i++)
                            {
                                DateTime dtmFechaHoraRecepcion = File.GetCreationTime(arrArchivosOpeRec[i]);
                                BE_OperacionRecibida oOperacionRecibida = ObtenerOpeRecDeserializado(arrArchivosOpeRec[i]);

                                if (oOperacionRecibida != null)
                                {
                                    if (this.RegistrarOperacionRecibida(oOperacionRecibida, dtmFechaHoraRecepcion, FlujoOperacionRecibida.FlujoNormal))
                                    {
                                        //Si se registr�, se elimina el archivo de operaci�n recibida
                                        File.Delete(arrArchivosOpeRec[i]);
                                    }
                                    else
                                    {
                                        if (!Directory.Exists(strRutaOpeRecNoProc))
                                        {
                                            Directory.CreateDirectory(strRutaOpeRecNoProc);
                                        }

                                        //Si no se logra registrar la operacion recibida, se mueve al directorio no procesados
                                        String strNombreFileDestino = Path.GetFileName(arrArchivosOpeRec[i]);
                                        String strFileDestino = Path.Combine(strRutaOpeRecNoProc, strNombreFileDestino);
                                        File.Move(arrArchivosOpeRec[i], strFileDestino);
                                        LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.AVISO_AFECTACION, strHashcode,
                                        "BL_OperacionesRecibidas.ProcesarOperacionesRecibidas",
                                        "La operacion recibida cuyo archivo es [" + arrArchivosOpeRec[i] + "] no pudo ser registrado. El archivo se movio a [" + strRutaOpeRecNoProc + "]", true);
                                    }
                                }
                            }
                        }
                        else
                        {
                            LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.AVISO_AFECTACION, strHashcode,
                                "BL_OperacionesRecibidas.ProcesarOperacionesRecibidas",
                                "Error al obtener el listado de conceptos, revisar el registro previo.", true);
                        }
                    }
                }
                catch (Exception ex)
                {
                    LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.AVISO_AFECTACION, strHashcode,
                        "BL_OperacionesRecibidas.ProcesarOperacionesRecibidas",
                        "Error al procesar las operaciones recibidas (flujo normal). " + ex.Message + "\r\n" + ex.StackTrace, true);
                }
            }

        }

        public void ProcesarOperacionesRecibidasContingencia()
        {
            if (!String.IsNullOrEmpty(Globales.CADENA_CONEXION))
            {
                //Indicador de Notificacion realizada apenas se logre insertar una operacion en este flujo
                bool blnNotificacionEnviada = false;

                //Input
                String strRutaOpeRecNoProc = ConfigurationManager.AppSettings["RUTA_CONTINGENCIA_OPERACIONES_NOPROCESADAS"];//Ruta de deposito de las operaciones que no fueron grabadas
                String[] arrArchivosOpeRec = null;
                //Output
                String strRutaOpeRecProc = ConfigurationManager.AppSettings["RUTA_CONTINGENCIA_OPERACIONES_PROCESADAS"];//Ruta de de deposito de las operaciones que fueron grabadas pero que inicialmente no se pudieron

                try
                {
                    if (String.IsNullOrEmpty(strRutaOpeRecNoProc) || !Directory.Exists(strRutaOpeRecNoProc))
                    {
                        LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.AVISO_AFECTACION, strHashcode,
                            "BL_OperacionesRecibidas.ProcesarOperacionesRecibidasContingencia",
                            "El parametro RUTA_CONTINGENCIA_OPERACIONES_NOPROCESADAS para operaciones recibidas - flujo contingencia no esta establecido o la ruta no es valida. Revisar el archivo .config", true);
                        return;
                    }

                    if (String.IsNullOrEmpty(strRutaOpeRecProc) || !Directory.Exists(strRutaOpeRecProc))
                    {
                        LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.AVISO_AFECTACION, strHashcode,
                            "BL_OperacionesRecibidas.ProcesarOperacionesRecibidasContingencia",
                            "El parametro RUTA_CONTINGENCIA_OPERACIONES_PROCESADAS para operaciones recibidas - flujo contingencia no esta establecido o la ruta no es valida. Revisar el archivo .config", true);
                        return;
                    }

                    string strCarpetaDiaAnteriorNoProc = Path.Combine(strRutaOpeRecNoProc, DateTime.Today.AddDays(-1).ToString("yyyyMMdd"));
                    strRutaOpeRecNoProc = Path.Combine(strRutaOpeRecNoProc, DateTime.Today.ToString("yyyyMMdd"));
                    strRutaOpeRecProc = Path.Combine(strRutaOpeRecProc, DateTime.Today.ToString("yyyyMMdd"));

                    try
                    {
                        if (Directory.Exists(strCarpetaDiaAnteriorNoProc))
                        {
                            String[] arrTmpFilesOld = Directory.GetFileSystemEntries(strCarpetaDiaAnteriorNoProc, "OPE_*.xml");

                            if (arrTmpFilesOld.Length == 0)
                            {
                                Directory.Delete(strCarpetaDiaAnteriorNoProc, true);
                            }
                        }
                    }
                    catch { }

                    if (!Directory.Exists(strRutaOpeRecNoProc))
                    {
                        return;//No hay nada que procesar
                    }

                    arrArchivosOpeRec = Directory.GetFileSystemEntries(strRutaOpeRecNoProc, "OPE_*.xml");

                    if (arrArchivosOpeRec.Length > 0)
                    {
                        lstConceptos = (new DA_General(strHashcode)).Obtener_Conceptos(new BE_Concepto(""));//Trae todos los conceptos

                        if (lstConceptos != null)
                        {
                            for (int i = 0; i < arrArchivosOpeRec.Length; i++)
                            {
                                DateTime dtmFechaHoraRecepcion = File.GetCreationTime(arrArchivosOpeRec[i]);
                                BE_OperacionRecibida oOperacionRecibida = ObtenerOpeRecDeserializado(arrArchivosOpeRec[i]);

                                if (oOperacionRecibida != null)
                                {
                                    if (this.RegistrarOperacionRecibida(oOperacionRecibida, dtmFechaHoraRecepcion, FlujoOperacionRecibida.FlujoContingencia))
                                    {
                                        if (!Directory.Exists(strRutaOpeRecProc))
                                        {
                                            Directory.CreateDirectory(strRutaOpeRecProc);
                                        }

                                        //Si se logra registrar la operacion recibida, se mueve al directorio procesados
                                        String strNombreFileDestino = Path.GetFileName(arrArchivosOpeRec[i]);
                                        String strFileDestino = Path.Combine(strRutaOpeRecProc, strNombreFileDestino);
                                        File.Move(arrArchivosOpeRec[i], strFileDestino);

                                        if (!blnNotificacionEnviada)
                                        {
                                            blnNotificacionEnviada = true;
                                            LogWriter.Notificar(strHashcode, "Se supero el inconveniente con la base de datos. Se pudo registrar la operacion recibida [" + oOperacionRecibida.NumRefLBTR + "]");
                                        }
                                    }
                                    else
                                    {
                                        if (blnNotificacionEnviada)//Si ya se habia enviado un correo de superacion del problema de bd pero vuelve a ocurrir, se notifica
                                        {
                                            blnNotificacionEnviada = false;
                                            LogWriter.Notificar(strHashcode, "A pesar de que se habia superado el inconveniente previamente, volvio a ocurrir un problema con la bd. No se pudo grabar la operacion recibida [" + oOperacionRecibida.NumRefLBTR + "]");
                                        }
                                    }
                                }

                            }
                        }
                        else
                        {
                            LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.AVISO_AFECTACION, strHashcode,
                                "BL_OperacionesRecibidas.ProcesarOperacionesRecibidasContingencia",
                                "Error al obtener el listado de conceptos, revisar el registro previo.", true);
                        }
                    }
                }
                catch (Exception ex)
                {
                    LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.AVISO_AFECTACION, strHashcode,
                        "BL_OperacionesRecibidas.ProcesarOperacionesRecibidasContingencia",
                        "Error al procesar las operaciones recibidas (flujo contingencia). " + ex.Message + "\r\n" + ex.StackTrace, true);
                }
            }

        }

        private BE_OperacionRecibida ObtenerOpeRecDeserializado(String prmRutaOpeRec)
        {
            BE_OperacionRecibida oOperacionRecibida = null;

            try
            {
                XmlSerializer serializer = new XmlSerializer(typeof(BE_OperacionRecibida));
                StreamReader r = new StreamReader(prmRutaOpeRec);
                oOperacionRecibida = (BE_OperacionRecibida)serializer.Deserialize(r);
                r.Close();

                if (oOperacionRecibida == null)
                {
                    LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.AVISO_AFECTACION, strHashcode,
                        "BL_OperacionesRecibidas.ObtenerOpeRecDeserializado",
                        "No se pudo deserializar el archivo de operacion recibida en: " + prmRutaOpeRec, true);
                }
            }
            catch (Exception ex)
            {
                oOperacionRecibida = null;
                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.AVISO_AFECTACION, strHashcode,
                    "BL_OperacionesRecibidas.ObtenerOpeRecDeserializado",
                    "Error al deserializar el archivo de operacion recibida en: [" + prmRutaOpeRec + "]\r\n" + ex.Message, true);
            }

            return oOperacionRecibida;
        }

        #region Registro y Validacion de la Operacion Recibida

        private bool RegistrarOperacionRecibida(BE_OperacionRecibida prmOperacionRecibida, 
                                                    DateTime prmFechaHoraRecepcion, String prmFlujo)
        {
            LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.AVISO_AFECTACION, strHashcode,
                "BL_OperacionesRecibidas.RegistrarOperacionRecibida",
                "Inicia el procesamiento del aviso de afectacion - " + prmOperacionRecibida.NumRefLBTR, false);

            bool blnErrorEnBD = false;//Usado para el modulo de seguridad
            bool esOrigenDefinido = false;
            bool esOriginadoPorCiti = false;
            string strDataCliente = null;
            string strCodTramaAuditoria = "";
            BL_SeguridadMsj oBLSeg = new BL_SeguridadMsj(strHashcode);
            DA_Transferencia oDATransf = new DA_Transferencia(strHashcode);
            BE_Transferencia oTransferencia = null;//si es diferente de null, significa que el aviso de afectacion fue causado por una transferencia realizada por el Citi            
            BE_Concepto oConcepto = null;
            BL_General oBLGen = new BL_General(strHashcode);
            bool blnExito = false;//True indica que se grab� correctamente en la bd

            if (!String.IsNullOrEmpty(Globales.CADENA_CONEXION))
            {
                try
                {   
                    strEstadoOriginalRecibido = prmOperacionRecibida.EstadoLiquidacion;

                    this.MostrarDatosOperacionEnLog(prmOperacionRecibida);

                    //SE BUSCA EL NUMREFLBTR DEL AVISO DE AFECTACION EN T_DESA PARA SABER SI ES UNA OPERACION QUE PARTIO DEL CITI
                    oTransferencia = oDATransf.Obtener_Datos_Transferencia(new BE_Transferencia(prmOperacionRecibida.NumRefLBTR));
                    if (oDATransf.Excepcion == null)//Si no hay error
                    {
                        esOrigenDefinido = true;

                        if (oTransferencia != null)//Si se encontro el numrefLBTR en T_DESA, es una operacion originada por Citi
                        {
                            esOriginadoPorCiti = true;
                        }
                    }
                    else//Si hay error
                    {
                        throw new Exception("Error al buscar el NumRefLBTR en T_DESA: " + oDATransf.Excepcion.Message);
                    }

                    //SE VALIDA LA FIRMA DEL MENSAJE
                    esFirmaBCRPValida = oBLSeg.ValidarFirmaMensaje(prmFlujo, prmOperacionRecibida, out strMensajeErrorFirmaMsj, out blnErrorEnBD);

                    if (blnErrorEnBD)//Verificamos si hubo error de bd en la validacion de firma para no procesar la operacion y dejarlo pendiente
                    {
                        throw new Exception("Se produjo un problema al realizar la validacion de la firma del mensaje: " + strMensajeErrorFirmaMsj);
                    }

                    //Inicio Cambio jr72296
                    #region Registrar los avisos de afectacion de CompraVenta en la tabla T_LBTR_ENTRADAS

                    BE_OperacionRecibida prmOperacionRecibidaCV = new BE_OperacionRecibida();
                    prmOperacionRecibidaCV = prmOperacionRecibida;

                    if (prmOperacionRecibida.CodServicio == ServicioBCRP.CompraVenta)
                    {
                        RegistrarOperacionRecibidaCompraVenta(prmOperacionRecibidaCV, prmFechaHoraRecepcion, prmFlujo);
                    }

                    #endregion
                    //Fin Cambio jr72296

                    //APLICARIA PARA LOS AVISOS DE AFECTACION ENVIADAS POR LAS OTRAS ESF - OPERACIONES RECIBIDAS
                    //Y NO PARA LAS QUE FUERON ORIGINADAS POR EL CITI
                    if (!esOriginadoPorCiti)
                    {
                        //SE OBTIENE EL CONCEPTO
                        if (!String.IsNullOrEmpty(prmOperacionRecibida.CodConcepto))
                        {
                            oConcepto = lstConceptos.Find(delegate(BE_Concepto prmConcepto) { return prmConcepto.CodConcepto == prmOperacionRecibida.CodConcepto; });
                        }

                        //SOLO SE REGISTRA AUDITORIA PARA LAS OPERACIONES RECIBIDAS, LAS QUE FUERON ENVIADAS POR OTROS BANCOS.
                        //SE REGISTRA EN ESTE PUNTO PARA GRABARLO TAL CUAL ES RECIBIDO PORQUE LUEGO SE PROCESA EL MENSAJE RECIBIDO CAMBIANDO VALORES POR EQUIVALENTES. 
                        strCodTramaAuditoria = this.RegistrarTrama(prmOperacionRecibida);

                        #region Obtencion Data Cliente y validacion de firma datos cliente

                        if (oConcepto != null && oConcepto.UsaDatosCliente)
                        {
                            try
                            {
                                //OBTENGO LA VALIDACION DE LA FIRMA Y LA DATA DE CLIENTE
                                esFirmaClienteValida = oBLSeg.ValidarFirmaDataCliente(prmFlujo, true, TipoOperacion.AvisoAfectacion,
                                                                                        prmOperacionRecibida.StrDatosCliente,
                                                                                        prmOperacionRecibida.CodBancoOrigen,
                                                                                        out strDataCliente,
                                                                                        null, null, null,
                                                                                        out strMensajeErrorValidDataCliente,
                                                                                        out blnErrorEnBD);

                                if (blnErrorEnBD)//Verificamos si hubo error de bd en la validacion de firma para no procesar la operacion y dejarlo pendiente
                                {
                                    throw new Exception("Se produjo un problema al realizar la validacion/descifrado de datos cliente de la operacion: " + strMensajeErrorValidDataCliente);
                                }

                                if (!String.IsNullOrEmpty(strDataCliente))
                                {
                                    prmOperacionRecibida.DatosCliente = BE_DatosCliente.ObtenerDataClienteDesdeXML(strDataCliente);
                                }
                            }
                            catch (Exception ex)
                            {
                                if (!String.IsNullOrEmpty(strMensajeErrorValidDataCliente))
                                {
                                    strMensajeErrorValidDataCliente += "\r\n\r\nError al obtener la data de cliente desde su formato XML (" + ex.Message + "; " + ex.StackTrace + ")";
                                }
                                else
                                    strMensajeErrorValidDataCliente = "Error al obtener la data de cliente desde su formato XML (" + ex.Message + "; " + ex.StackTrace + ")";
                            }
                        }
                        else
                        {
                            strMensajeErrorValidDataCliente = "";
                            esFirmaClienteValida = true;
                        }

                        #endregion
                    }

                    #region SE REACOMODAN LAS PROPIEDADES AL FORMATO QUE SE GUARDARAN

                    if (!String.IsNullOrEmpty(prmOperacionRecibida.FechaLiquidacion))
                    {
                        prmOperacionRecibida.FechaLiquidacion = prmOperacionRecibida.FechaLiquidacion.Substring(0, 8);
                    }
                    if (!String.IsNullOrEmpty(prmOperacionRecibida.FechaNegociacionCavali))
                    {
                        prmOperacionRecibida.FechaNegociacionCavali = prmOperacionRecibida.FechaNegociacionCavali.Substring(0, 8);
                    }
                    if (!String.IsNullOrEmpty(prmOperacionRecibida.HoraLiquidacion) && prmOperacionRecibida.HoraLiquidacion.Length == 14)
                    {
                        prmOperacionRecibida.HoraLiquidacion = prmOperacionRecibida.HoraLiquidacion.Substring(8, 6);
                    }
                    prmOperacionRecibida.EstadoLiquidacion = oBLGen.Obtener_Estado_Equivalente(prmOperacionRecibida.EstadoLiquidacion, TipoEstado.Liquidacion);
                    prmOperacionRecibida.CodTramaAuditoria = strCodTramaAuditoria;
                    prmOperacionRecibida.strFechaHoraRecepcion = prmFechaHoraRecepcion.ToString("yyyyMMddHHmmss");
                    prmOperacionRecibida.strFechaHoraRegistro = DateTime.Now.ToString("yyyyMMddHHmmss");
                    prmOperacionRecibida.strFlujoRegistro = prmFlujo;

                    #endregion

                    if (!esOriginadoPorCiti)//Si no existe en T_DESA, se registra en T_LBTR_OPER_RECIBIDAS
                    {
                        //Verificamos si es una operacion de Cavali para establecer el CCI Beneficiario con la cuenta Interbancaria SAB
                        if (oConcepto != null && oConcepto.EsCavali)
                        {
                            //Operacion de Cavali no traen datos de cliente, por ello, se inicializa la propiedad DatosCliente
                            prmOperacionRecibida.DatosCliente = new BE_DatosCliente();
                            prmOperacionRecibida.DatosCliente.CCIBeneficiario = prmOperacionRecibida.CuentaInterbancariaSAB;

                            //Se establece el color del registro con el que se mostrara en la app cliente
                            prmOperacionRecibida.ColorRegistro = TipoColorRegistro.Cavali;
                            prmOperacionRecibida.IndCorporativo = "N";
                            prmOperacionRecibida.IndCORE = "N";
                        }
                         //Inicio Cambio JR72296 Divestiture 02/2015
                        #region Identificar Tipo beneficiario - comsumer o corporate

                          string strMensajeValidacionCCI=string.Empty;
                          string strEntidad = string.Empty;

                          prmOperacionRecibida.DatosCliente.ChrEntidad = Utilitario.ValidarCCI(prmOperacionRecibida.DatosCliente.CCIBeneficiario, out strMensajeValidacionCCI);

                          if(!string.IsNullOrEmpty(strMensajeValidacionCCI)) 
                          {
                           strMensajeErrorValidDataCliente += "\n\r" + strMensajeValidacionCCI;
                          }
                          
                        #endregion 
                        //Fin Cambio JR72296 Divestiture 02/2015

                        prmOperacionRecibida.ADES = ValidarCampoADES(prmOperacionRecibida, oConcepto);

                        LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.AVISO_AFECTACION, strHashcode,
                            "BL_OperacionesRecibidas.RegistrarOperacionRecibida",
                            "La validacion del campo ADES retorno " + prmOperacionRecibida.ADES, false);

                        DA_OperacionesRecibidas oDAOpeRecib = new DA_OperacionesRecibidas(strHashcode);
                        bool blnMostrarDataOperacion = false;
                        string strMensajeErrorRegistro = "";

                        if (oDAOpeRecib.RegistrarOperacionRecibida(prmOperacionRecibida, out blnMostrarDataOperacion))
                        {
                            blnExito = true;
                            strMensajeErrorRegistro = "Se registro la operacion [" + prmOperacionRecibida.NumRefLBTR + "] en T_LBTR_OPER_RECIBIDAS.";

                            if (blnMostrarDataOperacion)
                            {
                                strMensajeErrorRegistro += " Pero con datos incompletos. Revisar el log para mayor detalle";
                            }

                            LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.AVISO_AFECTACION, strHashcode,
                                "BL_OperacionesRecibidas.RegistrarOperacionRecibida",
                                strMensajeErrorRegistro, blnMostrarDataOperacion);

                            if (blnMostrarDataOperacion)
                            {
                                oBLGen.InsertarLogError(prmOperacionRecibida.NumRefLBTR,
                                "La operaci�n se grab� con datos incompletos.", true);

                                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.AVISO_AFECTACION, strHashcode,
                                "BL_OperacionesRecibidas.RegistrarOperacionRecibida",
                                "Datos de la operacion [" + prmOperacionRecibida.NumRefLBTR + "]:\r\n" + prmOperacionRecibida.ToString(), false);
                            }

                            if (prmFlujo == FlujoOperacionRecibida.FlujoContingencia)
                            {
                                    oBLGen.InsertarLogError(prmOperacionRecibida.NumRefLBTR,
                                    "La operaci�n se recibio el [" + prmFechaHoraRecepcion.ToString("dd/MM/yyyy HH:mm:ss") +
                                    "] pero se registro el [" + DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss") + "].", TipoError.WARNING, true);
                            }
                        }
                        else
                        {
                            strMensajeErrorRegistro = "No se pudo registrar la operacion [" + prmOperacionRecibida.NumRefLBTR +
                                                                "] en el flujo [";
                            if (prmFlujo == FlujoOperacionRecibida.FlujoContingencia)
                            {
                                strMensajeErrorRegistro += "CONTINGENCIA]";
                            }
                            else
                            {
                                strMensajeErrorRegistro += "NORMAL]";
                            }
                            strMensajeErrorRegistro += " debido a [" + oDAOpeRecib.Excepcion.Message + "]. Revisar el log para mayor detalle.";

                            LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.AVISO_AFECTACION, strHashcode,
                                "BL_OperacionesRecibidas.RegistrarOperacionRecibida",
                                strMensajeErrorRegistro, true);

                            if (blnMostrarDataOperacion)
                            {
                                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.AVISO_AFECTACION, strHashcode,
                                    "BL_OperacionesRecibidas.RegistrarOperacionRecibida",
                                    "Datos de la operacion [" + prmOperacionRecibida.NumRefLBTR + "]:\r\n" + prmOperacionRecibida.ToString(), false);
                            }
                        }
                    }
                    else
                    {
                        if (esFirmaBCRPValida)
                        {
                            oTransferencia.Estado = prmOperacionRecibida.EstadoLiquidacion;

                            if (!String.IsNullOrEmpty(prmOperacionRecibida.TipoRegistro))
                            {
                                if (prmOperacionRecibida.TipoRegistro.Equals(Constantes.INDICADOR_CONFIRMAABONO))
                                {
                                    oTransferencia.ConfirmaAbono = "1";
                                }
                                else if (prmOperacionRecibida.TipoRegistro.Equals(Constantes.INDICADOR_ANULACION))
                                {
                                    oTransferencia.Estado = Estados.ANULADO;
                                }
                            }

                            if (oBLGen.Actualizar_Transferencia(oTransferencia))//El log se escribe dentro
                            {
                                blnExito = true;
                            }
                        }
                        else
                        {
                            oBLGen.InsertarLogError(oTransferencia.TRANSACT + oTransferencia.SEC, "No se pudo actualizar la transferencia " + prmOperacionRecibida.NumRefLBTR + " mediante avisos de afectacion. Firma no valida: \r\n[" + strMensajeErrorFirmaMsj + "]", false);

                            LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.AVISO_AFECTACION, strHashcode,
                                "BL_OperacionesRecibidas.RegistrarOperacionRecibida",
                                "No se pudo actualizar la transferencia con NumRefLBTR " + prmOperacionRecibida.NumRefLBTR + " mediante avisos de afectacion. Firma no valida:\r\n[" + strMensajeErrorFirmaMsj + "]", true);
                        }
                    }
                }
                catch (Exception ex)
                {
                    if (esOrigenDefinido)//si se sabe donde se tuvo que registrar la operacion
                    {
                        if (oTransferencia != null)
                        {
                            oBLGen.InsertarLogError(oTransferencia.TRANSACT + oTransferencia.SEC, "Error al procesar el aviso de afectacion: " + ex.Message, false);
                        }
                        else
                        {
                            oBLGen.InsertarLogError(prmOperacionRecibida.NumRefLBTR, "Error al procesar el aviso de afectacion: " + ex.Message, true);
                        }
                    }

                    LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.AVISO_AFECTACION, strHashcode,
                        "BL_OperacionesRecibidas.RegistrarOperacionRecibida",
                        "Error: " + ex.Message + ". " + ex.StackTrace, true);
                }
            }
            else
            {
                LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.AVISO_AFECTACION, strHashcode,
                    "BL_OperacionesRecibidas.RegistrarOperacionRecibida",
                    "No se registra [" + prmOperacionRecibida.NumRefLBTR + "] debido a que la cadena de conexion esta establecida a vacio.", false);
            }

            LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.AVISO_AFECTACION, strHashcode,
                "BL_OperacionesRecibidas.RegistrarOperacionRecibida",
                "Finaliza el procesamiento del aviso de afectacion - " + prmOperacionRecibida.NumRefLBTR, false);

            return blnExito;
        }

        private string ValidarCampoADES(BE_OperacionRecibida prmOperacionRecibida, BE_Concepto oConcepto)
        {
            BL_General oBLGen = new BL_General(strHashcode);
            List<BE_Banco> lstBancos = null;
            BE_Banco oBancoCiti = null;
            string strValorRetorno = "1";

            #region Validacion de Concepto

            if (!String.IsNullOrEmpty(prmOperacionRecibida.CodConcepto))
            {
                if (oConcepto == null)
                {
                    strValorRetorno = "0";
                    LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.AVISO_AFECTACION, strHashcode,
                        "BL_OperacionesRecibidas.ValidarCampoADES",
                        "El codigo de concepto no se encuentra registrado en la base de datos.", false);

                    oBLGen.InsertarLogError(prmOperacionRecibida.NumRefLBTR, "El codigo de concepto no se encuentra registrado.", true);
                }
            }
            else
            {
                strValorRetorno = "0";

                LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.AVISO_AFECTACION, strHashcode,
                    "BL_OperacionesRecibidas.ValidarCampoADES",
                    "El codigo de concepto es requerido.", false);

                oBLGen.InsertarLogError(prmOperacionRecibida.NumRefLBTR, "El codigo de concepto es requerido.", true);
            }

            #endregion

            #region Validacion de firmas

            //Si la firma del BCRP no es valida (firma del mensaje)
            if (!esFirmaBCRPValida)
            {
                strValorRetorno = "0";
                LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.AVISO_AFECTACION, strHashcode,
                    "BL_OperacionesRecibidas.ValidarCampoADES",
                    "Error en la validacion de la firma de la operacion: \r\n[" + strMensajeErrorFirmaMsj + "]", false);
                oBLGen.InsertarLogError(prmOperacionRecibida.NumRefLBTR, "Error en la validacion de la firma de la operacion: \r\n[" + strMensajeErrorFirmaMsj + "]", true);
            }

            //Si la firma de Datos Cliente no es valida
            //Primero, se verifica si este concepto usa datos de cliente
            if (oConcepto != null && oConcepto.UsaDatosCliente)
            {
                if (!String.IsNullOrEmpty(strMensajeErrorValidDataCliente))
                {
                    strValorRetorno = "0";
                    oBLGen.InsertarLogError(prmOperacionRecibida.NumRefLBTR, "Error en la validacion de Datos Cliente de la operacion:\r\n[" + strMensajeErrorValidDataCliente + "]", true);

                    LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.AVISO_AFECTACION, strHashcode,
                        "BL_OperacionesRecibidas.RegistrarOperacionRecibida",
                        "Error en la validacion de Datos Cliente:\r\n[" + strMensajeErrorValidDataCliente + "]", false);
                }
            }

            #endregion

            #region Validacion de Fecha Liquidacion

            //Fecha Liquidacion Diferente a la fecha actual
            if (!prmOperacionRecibida.FechaLiquidacion.Substring(0, 8).Equals(DateTime.Today.ToString("yyyyMMdd")))
            {
                strValorRetorno = "0";
                LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.AVISO_AFECTACION, strHashcode,
                    "BL_OperacionesRecibidas.ValidarCampoADES",
                    "La fecha liquidacion no es igual a la fecha actual.", false);

                oBLGen.InsertarLogError(prmOperacionRecibida.NumRefLBTR, "La fecha de liquidacion no corresponde a la fecha actual.", true);
            }

            #endregion

            #region Validacion del codigo de banco

            //Verificacion de Codigos de Banco Origen
            if (!String.IsNullOrEmpty(prmOperacionRecibida.CodBancoOrigen))
            {
                lstBancos = (new DA_General(strHashcode)).Obtener_Bancos(new BE_Banco(prmOperacionRecibida.CodBancoOrigen));

                if (lstBancos == null || lstBancos.Count == 0)
                {
                    strValorRetorno = "0";
                    LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.AVISO_AFECTACION, strHashcode,
                        "BL_OperacionesRecibidas.ValidarCampoADES",
                        "El codigo de banco origen no se encuentra registrado en la base de datos.", false);

                    oBLGen.InsertarLogError(prmOperacionRecibida.NumRefLBTR, "El codigo de banco origen no se encuentra registrado.", true);
                }
            }
            else
            {
                strValorRetorno = "0";
                LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.AVISO_AFECTACION, strHashcode,
                    "BL_OperacionesRecibidas.ValidarCampoADES",
                    "El codigo de banco origen es requerido.", false);

                oBLGen.InsertarLogError(prmOperacionRecibida.NumRefLBTR, "El codigo de banco origen es requerido.", true);
            }

            //Verificacion de Codigos de Banco Destino
            if (!String.IsNullOrEmpty(prmOperacionRecibida.CodBancoDestino))
            {
                lstBancos = (new DA_General(strHashcode)).Obtener_Bancos(new BE_Banco(prmOperacionRecibida.CodBancoDestino));

                if (lstBancos == null || lstBancos.Count == 0)
                {
                    strValorRetorno = "0";
                    LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.AVISO_AFECTACION, strHashcode,
                        "BL_OperacionesRecibidas.ValidarCampoADES",
                        "El codigo de banco destino no se encuentra registrado en la base de datos.", false);

                    oBLGen.InsertarLogError(prmOperacionRecibida.NumRefLBTR, "El codigo de banco destino no se encuentra registrado.", true);
                }
                else
                {
                    oBancoCiti = lstBancos[0];
                }
            }
            else
            {
                strValorRetorno = "0";
                LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.AVISO_AFECTACION, strHashcode,
                    "BL_OperacionesRecibidas.ValidarCampoADES",
                    "El codigo de banco destino es requerido.", false);

                oBLGen.InsertarLogError(prmOperacionRecibida.NumRefLBTR, "El codigo de banco destino es requerido.", true);
            }

            #endregion

            #region Validacion Conversion Estado Liquidacion

            if (String.IsNullOrEmpty(prmOperacionRecibida.EstadoLiquidacion))
            {
                strValorRetorno = "0";
                LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.AVISO_AFECTACION, strHashcode,
                    "BL_OperacionesRecibidas.ValidarCampoADES",
                    "El estado de liquidacion proveniente del BCRP con valor [" + strEstadoOriginalRecibido + "] no pudo ser convertido al equivalente de Citi.", false);

                oBLGen.InsertarLogError(prmOperacionRecibida.NumRefLBTR, "El estado de liquidacion proveniente del BCRP con valor [" + strEstadoOriginalRecibido + "] no pudo ser convertido al equivalente de Citi.", true);
            }

            #endregion

            #region Validacion de Numero de Documento

            //si el concepto indica que esta operacion usa datos de cliente, se valida
            if (oConcepto != null && oConcepto.UsaDatosCliente && prmOperacionRecibida.DatosCliente != null)
            {
                strValorRetorno = this.ValidacionNumeroDocumento(prmOperacionRecibida, oConcepto, strValorRetorno);
            }

            #endregion

            #region Validacion de Nro de Cuenta CCI Beneficiario

            //SI EL CONCEPTO INDICA QUE ESTA OPERACION USA DATOS DE CLIENTE O QUE SE ENVIA A BCOSMOS O ES CAVALI, SE VALIDA EL CCI DEL BENEFICIARIO
            if (oConcepto != null && (oConcepto.UsaDatosCliente || oConcepto.UsaBCosmos || oConcepto.EsCavali))
            {
                String strCCIBeneficiario = prmOperacionRecibida.DatosCliente.CCIBeneficiario;

                if (String.IsNullOrEmpty(strCCIBeneficiario)) strCCIBeneficiario = "";

                if (!String.IsNullOrEmpty(strCCIBeneficiario) && strCCIBeneficiario.Length == 20)
                {
                    bool blnEsCuentaMatriz = false;

                    if (oBancoCiti != null)
                    {
                        if (!String.IsNullOrEmpty(oBancoCiti.CuentaMatriz))
                        {
                            //SE VERIFICA SI EL CCI DEL BENEFICIARIO ES LA CUENTA MATRIZ
                            if (oBancoCiti.CuentaMatriz.Equals(strCCIBeneficiario))
                            {
                                blnEsCuentaMatriz = true;

                                if (prmOperacionRecibida.UsarCuentaTramite)//Consumer
                                {
                                    oBLGen.InsertarLogError(prmOperacionRecibida.NumRefLBTR,
                                        "El CCI del Beneficiario es la cuenta matriz.", TipoError.WARNING, true);
                                }
                                else
                                {
                                    oBLGen.InsertarLogError(prmOperacionRecibida.NumRefLBTR,
                                        "El CCI del Beneficiario es la cuenta matriz. La operacion no se enviara a BCOSMOS.", TipoError.ERROROPERCTA, true);
                                    strValorRetorno = "0";
                                }

                                LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.AVISO_AFECTACION, strHashcode,
                                    "BL_OperacionesRecibidas.ValidarCampoADES",
                                    "El CCI del Beneficiario es la cuenta matriz.", false);
                            }
                        }
                    }

                    //Solo se valida si no es cuenta matriz
                    if (!blnEsCuentaMatriz)
                    {
                        if (BL_General.f_modulo11(strCCIBeneficiario.Substring(8, 10)) < 0)
                        {
                            LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.AVISO_AFECTACION, strHashcode,
                                    "BL_OperacionesRecibidas.ValidarCampoADES",
                                    "El numero de cuenta CCI del beneficiario no es valido.", false);

                            if (prmOperacionRecibida.UsarCuentaTramite)//Consumer
                            {
                                oBLGen.InsertarLogError(prmOperacionRecibida.NumRefLBTR, 
                                    "Validacion modulo 11, CCI del beneficiario no es valido.", TipoError.WARNING, true);
                            }
                            else
                            {
                                strValorRetorno = "0";
                                oBLGen.InsertarLogError(prmOperacionRecibida.NumRefLBTR, 
                                    "Validacion modulo 11, CCI del beneficiario no es valido.", TipoError.ERROROPERCTA, true);
                            }
                        }
                    }
                }
                else
                {

                    string strMensajeErrorCtaBen = "El numero de cuenta CCI del beneficiario es requerido y debe ser de 20 caracteres.";

                    if (oConcepto.EsCavali)
                    {
                        strMensajeErrorCtaBen = "La cuenta interbancaria SAB de Cavali es requerido y debe ser de 20 caracteres.";
                    }

                    LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.AVISO_AFECTACION, strHashcode,
                        "BL_OperacionesRecibidas.ValidarCampoADES",
                        strMensajeErrorCtaBen, false);

                    if (prmOperacionRecibida.UsarCuentaTramite)//Consumer
                    {
                        oBLGen.InsertarLogError(prmOperacionRecibida.NumRefLBTR, strMensajeErrorCtaBen, TipoError.WARNING, true);
                    }
                    else
                    {
                        strValorRetorno = "0";
                        oBLGen.InsertarLogError(prmOperacionRecibida.NumRefLBTR, strMensajeErrorCtaBen, TipoError.ERROROPERCTA, true);
                    }
                }
            }

            #endregion

            //SI NO SE ENVIA A BCOSMOS
            if (oConcepto != null && !oConcepto.UsaBCosmos)
            {
                //Si no tiene errores anteriores, debido a que esta validacion es warning, se establece el campo color
                if (strValorRetorno == "1")
                {
                    prmOperacionRecibida.ColorRegistro = TipoColorRegistro.BCosmos;
                }
                strValorRetorno = "0";
                oBLGen.InsertarLogError(prmOperacionRecibida.NumRefLBTR, "Esta operacion con el tipo de concepto establecido no se envia a BCOSMOS.", TipoError.WARNINGBCOSMOS, true);
                LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.AVISO_AFECTACION, strHashcode,
                    "BL_OperacionesRecibidas.ValidarCampoADES",
                    "Esta operacion con el tipo de concepto establecido no se envia a BCOSMOS.", false);
            }

            return strValorRetorno;
        }

        private string ValidacionNumeroDocumento(BE_OperacionRecibida prmOperacionRecibida, BE_Concepto oConcepto, string prmValorRetorno)
        {
            string strTipoConcepto = oConcepto.CodConcepto.Substring(0, 1);
            bool blnExonerado = prmOperacionRecibida.DatosCliente.IndicadorITF == "E" ? true : false;
            string strBaseNumber = "";
            DA_General oDAGen = new DA_General(strHashcode);
            BE_FILE01 oFile01 = null;

            if (strTipoConcepto.Equals("A") || strTipoConcepto.Equals("B"))
            {
                #region Validacion Datos Beneficiario

                if (String.IsNullOrEmpty(prmOperacionRecibida.DatosCliente.TipoDocBeneficiario))
                {
                    prmValorRetorno = this.ManejaErrorValidacionNumDoc(TipoErrorValNumDoc.TipoDocumentoRequeridoBen, prmOperacionRecibida, true);
                }

                if (String.IsNullOrEmpty(prmOperacionRecibida.DatosCliente.NumDocBeneficiario))
                {
                    prmValorRetorno = this.ManejaErrorValidacionNumDoc(TipoErrorValNumDoc.NumeroDocumentoRequeridoBen, prmOperacionRecibida, true);
                }

                if (!String.IsNullOrEmpty(prmOperacionRecibida.DatosCliente.NumDocBeneficiario))
                {
                    if (prmOperacionRecibida.DatosCliente.TipoDocBeneficiario == TipoDocumento.DNI)
                    {
                        if (prmOperacionRecibida.DatosCliente.NumDocBeneficiario.Length != 8)
                        {
                            this.ManejaErrorValidacionNumDoc(TipoErrorValNumDoc.TamanhoNroDocBenefDNI, prmOperacionRecibida, false);
                        }
                    }
                    else if (prmOperacionRecibida.DatosCliente.TipoDocBeneficiario == TipoDocumento.RUC)
                    {
                        if (prmOperacionRecibida.DatosCliente.NumDocBeneficiario.Length != 11)
                        {
                            this.ManejaErrorValidacionNumDoc(TipoErrorValNumDoc.TamanhoNroDocBenefRUC, prmOperacionRecibida, false);
                        }
                    }
                }

                #endregion

                if (strTipoConcepto.Equals("B"))
                {
                    #region Validacion Datos Ordenante

                    if (String.IsNullOrEmpty(prmOperacionRecibida.DatosCliente.TipoDocOrdenante))
                    {
                        prmValorRetorno = this.ManejaErrorValidacionNumDoc(TipoErrorValNumDoc.TipoDocumentoRequeridoOrd, prmOperacionRecibida, true);
                    }

                    if (String.IsNullOrEmpty(prmOperacionRecibida.DatosCliente.NumDocOrdenante))
                    {
                        prmValorRetorno = this.ManejaErrorValidacionNumDoc(TipoErrorValNumDoc.NumeroDocumentoRequeridoOrd, prmOperacionRecibida, true);
                    }

                    if (String.IsNullOrEmpty(prmOperacionRecibida.DatosCliente.CCIOrdenante))
                    {
                        this.ManejaErrorValidacionNumDoc(TipoErrorValNumDoc.CCIOrdenanteRequerido, prmOperacionRecibida, false);
                    }

                    if (String.IsNullOrEmpty(prmOperacionRecibida.DatosCliente.NombreOrdenante))
                    {
                        this.ManejaErrorValidacionNumDoc(TipoErrorValNumDoc.NombreOrdenanteRequerido, prmOperacionRecibida, false);
                    }

                    if (!String.IsNullOrEmpty(prmOperacionRecibida.DatosCliente.NumDocOrdenante))
                    {
                        if (prmOperacionRecibida.DatosCliente.TipoDocOrdenante == TipoDocumento.DNI)
                        {
                            if (prmOperacionRecibida.DatosCliente.NumDocOrdenante.Length != 8)
                            {
                                this.ManejaErrorValidacionNumDoc(TipoErrorValNumDoc.TamanhoNroDocOrdDNI, prmOperacionRecibida, false);
                            }
                        }
                        else if (prmOperacionRecibida.DatosCliente.TipoDocOrdenante == TipoDocumento.RUC)
                        {
                            if (prmOperacionRecibida.DatosCliente.NumDocOrdenante.Length != 11)
                            {
                                this.ManejaErrorValidacionNumDoc(TipoErrorValNumDoc.TamanhoNroDocOrdRUC, prmOperacionRecibida, false);
                            }
                        }
                    }

                    #endregion

                    if (blnExonerado)
                    {
                        if (prmOperacionRecibida.DatosCliente.TipoDocBeneficiario != prmOperacionRecibida.DatosCliente.TipoDocOrdenante)
                        {
                            prmValorRetorno = this.ManejaErrorValidacionNumDoc(TipoErrorValNumDoc.TiposDocumentoDistintos, prmOperacionRecibida, true);
                        }

                        if (prmOperacionRecibida.DatosCliente.NumDocBeneficiario != prmOperacionRecibida.DatosCliente.NumDocOrdenante)
                        {
                            prmValorRetorno = this.ManejaErrorValidacionNumDoc(TipoErrorValNumDoc.NumerosDocDistintos, prmOperacionRecibida, true);
                        }
                    }
                }

                if (!String.IsNullOrEmpty(prmOperacionRecibida.DatosCliente.CCIBeneficiario) &&
                        prmOperacionRecibida.DatosCliente.CCIBeneficiario.Length == 20)
                {
                    //Se obtiene el base number a partir del CCI del Beneficiario
                    strBaseNumber = prmOperacionRecibida.DatosCliente.CCIBeneficiario.Substring(8, 10);//se obtiene la cuenta a partir del CCI Benef
                    strBaseNumber = strBaseNumber.Substring(1, 6);//se obtiene el base a partir de esa cuenta
                }

                if (!String.IsNullOrEmpty(strBaseNumber))
                {
                    if (Utilitario.EsConsumer(strBaseNumber))
                    {
                        #region Obtencion Cuenta Tramite

                        string strCuentaTramite = "";
                        prmOperacionRecibida.ColorRegistro = TipoColorRegistro.Consumer;
                        prmOperacionRecibida.IndCorporativo = "N";
                        prmOperacionRecibida.UsarCuentaTramite = true;

                        //Se obtiene la cuenta tramite segun el codigo de moneda del concepto
                        if (oConcepto.MonCod == TipoMoneda.Soles)
                            strCuentaTramite = oDAGen.Obtener_Param(Constantes.PARAM_CODIGO_CTATRAMITE_MN);
                        else if (oConcepto.MonCod == TipoMoneda.Dolares)
                            strCuentaTramite = oDAGen.Obtener_Param(Constantes.PARAM_CODIGO_CTATRAMITE_ME);

                        if (oDAGen.Excepcion != null)
                        {
                            throw new Exception("Error al intentar obtener el parametro cuenta tramite de la base de datos.");
                        }

                        //Verificamos si la cuenta tramite asociado al concepto es vacio                               
                        if (String.IsNullOrEmpty(strCuentaTramite))
                            prmValorRetorno = this.ManejaErrorValidacionNumDoc(TipoErrorValNumDoc.CuentaTramiteNulo, prmOperacionRecibida, true);
                        else
                            prmOperacionRecibida.CuentaTramite = strCuentaTramite;

                        #endregion

                        prmOperacionRecibida.IndCORE = "S"; //indicador Consumer 
                        prmOperacionRecibida.IndCorporativo = "N";
                        //Verificar si el cliente es realmente Consumer
                        if (
                              prmOperacionRecibida.DatosCliente.TipoDocBeneficiario != TipoDocumento.DNI &&
                              prmOperacionRecibida.DatosCliente.TipoDocBeneficiario != TipoDocumento.LIBELECT &&
                              prmOperacionRecibida.DatosCliente.TipoDocBeneficiario != TipoDocumento.LIBMIL &&
                              prmOperacionRecibida.DatosCliente.TipoDocBeneficiario != TipoDocumento.PASAPORTE &&
                              prmOperacionRecibida.DatosCliente.TipoDocBeneficiario != TipoDocumento.CARNEEXTRANJ)
                            {
                             //prmOperacionRecibida.IndCORE = "N"; 
                             this.ManejaErrorValidacionNumDoc(TipoErrorValNumDoc.BeneficiarioNoEsConsumer, prmOperacionRecibida, false);
                            }
                    }
                    else if (
                                prmOperacionRecibida.DatosCliente.TipoDocBeneficiario == TipoDocumento.DNI ||
                                prmOperacionRecibida.DatosCliente.TipoDocBeneficiario == TipoDocumento.LIBELECT ||
                                prmOperacionRecibida.DatosCliente.TipoDocBeneficiario == TipoDocumento.LIBMIL ||
                                prmOperacionRecibida.DatosCliente.TipoDocBeneficiario == TipoDocumento.PASAPORTE ||
                                prmOperacionRecibida.DatosCliente.TipoDocBeneficiario == TipoDocumento.CARNEEXTRANJ ||
                                prmOperacionRecibida.DatosCliente.TipoDocBeneficiario == TipoDocumento.RUC)
                    {
                        prmOperacionRecibida.IndCorporativo = "S";
                        prmOperacionRecibida.IndCORE = "N";

                        if (prmOperacionRecibida.DatosCliente.TipoDocBeneficiario != TipoDocumento.RUC)
                        {
                            prmValorRetorno = this.ManejaErrorValidacionNumDoc(TipoErrorValNumDoc.CuentaCorporateSinRUC, prmOperacionRecibida, true);
                        }
                        else 
                        {
                            if (!String.IsNullOrEmpty(strBaseNumber) && blnExonerado)
                            {
                                //Busca el base number en la tabla File01 de GENDB                                
                                oFile01 = oDAGen.BuscarBaseNumber(strBaseNumber);

                                if (oDAGen.Excepcion != null)
                                {
                                    throw new Exception("Error al intentar buscar el base number en la base de datos GENDB.");
                                }

                                if (oFile01 == null)
                                {
                                    //***BASE NUMBER NO REGISTRADO EN FILE01***
                                    prmValorRetorno = this.ManejaErrorValidacionNumDoc(TipoErrorValNumDoc.BaseNumberNoRegistradoEnFile01, prmOperacionRecibida, true);
                                }
                                else
                                {
                                    if (String.IsNullOrEmpty(oFile01.RUC))
                                    {
                                        //***RUC DEL FILE01 VACIO***
                                        prmValorRetorno = this.ManejaErrorValidacionNumDoc(TipoErrorValNumDoc.RUCdelFile01Vacio, prmOperacionRecibida, true);
                                    }
                                    else
                                    {
                                        if (oFile01.RUC.Trim() != prmOperacionRecibida.DatosCliente.NumDocBeneficiario)
                                        {
                                            //***RUC DEL BENEFICIARIO RECIBIDO NO COINCIDE CON EL RUC DEL FILE01***
                                            prmValorRetorno = this.ManejaErrorValidacionNumDoc(TipoErrorValNumDoc.RUCBenefDifRUCFile01, prmOperacionRecibida, true);
                                        }
                                    }
                                }
                            }
                        }
                    }
                    else
                    {
                        if (!String.IsNullOrEmpty(prmOperacionRecibida.DatosCliente.TipoDocBeneficiario))
                        {
                            //UNDONE JR72296 20150305
                            prmOperacionRecibida.IndCorporativo = "N";
                            prmOperacionRecibida.IndCORE = "N";
                            prmValorRetorno = this.ManejaErrorValidacionNumDoc(TipoErrorValNumDoc.TipoDocumentoNoExiste, prmOperacionRecibida, true);
                        }
                        else 
                        {
                            prmOperacionRecibida.IndCorporativo = "N";
                            //TODO Tipo Doc se encuentra vacio.
                            prmOperacionRecibida.IndCORE = "N";
                            prmValorRetorno = this.ManejaErrorValidacionNumDoc(TipoErrorValNumDoc.TipoDocumentoNULLoVacio, prmOperacionRecibida, true);
                        }
                    }
                }
                else 
                {
                    prmValorRetorno = this.ManejaErrorValidacionNumDoc(TipoErrorValNumDoc.BasenumberVacio, prmOperacionRecibida, true);
                }
            }

            return prmValorRetorno;
        }

        private string ManejaErrorValidacionNumDoc(TipoErrorValNumDoc tipoError, BE_OperacionRecibida prmOperacionRecibida, bool blnEsError)
        {
            String strMensaje = "";
            BL_General oBLGen = new BL_General(strHashcode);
            bool esSubsanadoConITF = false;

            switch (tipoError)
            {
                case TipoErrorValNumDoc.TipoDocumentoRequeridoBen:
                    strMensaje = "El tipo de documento del beneficiario es requerido.";
                    break;
                case TipoErrorValNumDoc.TipoDocumentoRequeridoOrd:
                    strMensaje = "El tipo de documento del ordenante es requerido.";
                    break;
                case TipoErrorValNumDoc.NumeroDocumentoRequeridoBen:
                    strMensaje = "El numero de documento del beneficiario es requerido.";
                    break;
                case TipoErrorValNumDoc.NumeroDocumentoRequeridoOrd:
                    strMensaje = "El numero de documento del ordenante es requerido.";
                    break;
                case TipoErrorValNumDoc.TamanhoNroDocBenefRUC:
                    strMensaje = "El numero de documento del beneficiario debe tener 11 caracteres.";
                    break;
                case TipoErrorValNumDoc.TamanhoNroDocBenefDNI:
                    strMensaje = "El numero de documento del beneficiario debe tener 8 caracteres.";
                    break;
                case TipoErrorValNumDoc.TamanhoNroDocOrdRUC:
                    strMensaje = "El numero de documento del ordenante debe tener 11 caracteres.";
                    break;
                case TipoErrorValNumDoc.TamanhoNroDocOrdDNI:
                    strMensaje = "El numero de documento del ordenante debe tener 8 caracteres.";
                    break;
                case TipoErrorValNumDoc.CCIOrdenanteRequerido:
                    strMensaje = "El CCI del ordenante esta vacio.";
                    break;
                case TipoErrorValNumDoc.NombreOrdenanteRequerido:
                    strMensaje = "El nombre del ordenante esta vacio.";
                    break;
                case TipoErrorValNumDoc.TiposDocumentoDistintos:
                    esSubsanadoConITF = true;
                    strMensaje = "Operaci�n deber� ser afecta a ITF, el tipo de documento del ordenante no coincide con la del beneficiario.";
                    break;
                case TipoErrorValNumDoc.NumerosDocDistintos:
                    esSubsanadoConITF = true;
                    strMensaje = "Operaci�n deber� ser afecta a ITF, el n�mero de documento del ordenante no coincide con la del beneficiario.";
                    break;
                case TipoErrorValNumDoc.CuentaTramiteNulo:
                    strMensaje = "Cuenta tr�mite no establecida en par�metros.";
                    break;
                case TipoErrorValNumDoc.BeneficiarioNoEsConsumer:
                    strMensaje = "El beneficiario tiene tipo documento " + Utilitario.ObtenerTipoDocumentoDescripcion(prmOperacionRecibida.DatosCliente.TipoDocBeneficiario) + 
                        " pero no es un cliente Consumer v�lido.";
                    break;
                case TipoErrorValNumDoc.TipoDocumentoNoExiste:
                    strMensaje = "El tipo de documento del beneficiario no existe en la base de datos.";
                    break;
                case TipoErrorValNumDoc.BaseNumberNoRegistradoEnFile01:
                    esSubsanadoConITF = true;
                    strMensaje = "El base number del beneficiario no esta registrado en la base de datos (FILE01)";
                    break;
                case TipoErrorValNumDoc.RUCdelFile01Vacio:
                    esSubsanadoConITF = true;
                    strMensaje = "El RUC no esta establecido para este base number (FILE01).";
                    break;
                case TipoErrorValNumDoc.RUCBenefDifRUCFile01:
                    esSubsanadoConITF = true;
                    strMensaje = "El RUC del beneficiario recibido no coincide con el RUC registrado en el FILE01 para el base number.";
                    break;

                case TipoErrorValNumDoc.TipoDocumentoNULLoVacio:
                    strMensaje = "El Tipo de cocumento de beneficiario se encuentra vac�o";
                    break;

                case TipoErrorValNumDoc.CuentaCorporateSinRUC:
                    strMensaje = "El Cliente reconocido como corporate tiene un tipo de documento diferente a RUC";
                    break;
                case TipoErrorValNumDoc.BasenumberVacio:
                    strMensaje = "El Basenumber se encuentra vac�o o nulo";
                    break;
            }

            if (blnEsError)
            {
                if (esSubsanadoConITF)
                {
                    oBLGen.InsertarLogError(prmOperacionRecibida.NumRefLBTR, strMensaje, TipoError.ERRORNUMDOCITF, true);
                }
                else
                {
                    oBLGen.InsertarLogError(prmOperacionRecibida.NumRefLBTR, strMensaje, TipoError.ERRORNUMDOC, true);
                }
            }
            else
                oBLGen.InsertarLogError(prmOperacionRecibida.NumRefLBTR, strMensaje, TipoError.WARNING, true);

            LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.AVISO_AFECTACION, strHashcode, "BL_OperacionesRecibidas.ManejaErrorValidacionNumDoc",
                prmOperacionRecibida.NumRefLBTR + " - " + strMensaje, false);

            return "0";
        }

        private void MostrarDatosOperacionEnLog(BE_OperacionRecibida prmOperacionRecibida)
        {
            StringBuilder sbContenido = new StringBuilder();
            sbContenido.Append("codBancoDestino: "); sbContenido.AppendLine(prmOperacionRecibida.CodBancoDestino);
            sbContenido.Append("codBancoOrigen: "); sbContenido.AppendLine(prmOperacionRecibida.CodBancoOrigen);
            sbContenido.Append("codConcepto: "); sbContenido.AppendLine(prmOperacionRecibida.CodConcepto);
            sbContenido.Append("codigoSAB: "); sbContenido.AppendLine(prmOperacionRecibida.CodigoSAB);
            sbContenido.Append("codServicio: "); sbContenido.AppendLine(prmOperacionRecibida.CodServicio);
            sbContenido.Append("codMoneda: "); sbContenido.AppendLine(prmOperacionRecibida.CodMoneda);
            sbContenido.Append("cuentaDestino: "); sbContenido.AppendLine(prmOperacionRecibida.CuentaDestino);
            sbContenido.Append("cuentaInterbancariaSAB: "); sbContenido.AppendLine(prmOperacionRecibida.CuentaInterbancariaSAB);
            sbContenido.Append("cuentaOrigen: "); sbContenido.AppendLine(prmOperacionRecibida.CuentaOrigen);
            sbContenido.Append("datosCliente: "); sbContenido.AppendLine(prmOperacionRecibida.StrDatosCliente);
            sbContenido.Append("estado: "); sbContenido.AppendLine(prmOperacionRecibida.EstadoLiquidacion);
            sbContenido.Append("fechaLiquidacion: "); sbContenido.AppendLine(prmOperacionRecibida.FechaLiquidacion);
            sbContenido.Append("fechaNegociacionCavali: "); sbContenido.AppendLine(prmOperacionRecibida.FechaNegociacionCavali);
            sbContenido.Append("horaLiquidacion: "); sbContenido.AppendLine(prmOperacionRecibida.HoraLiquidacion);
            sbContenido.Append("instruccionesPago: "); sbContenido.AppendLine(prmOperacionRecibida.InstruccionesPago);
            sbContenido.Append("modalidad: "); sbContenido.AppendLine(prmOperacionRecibida.Modalidad);
            sbContenido.Append("montoDestino: "); sbContenido.AppendLine(prmOperacionRecibida.MontoOperacionDestino);
            sbContenido.Append("montoOrigen: "); sbContenido.AppendLine(prmOperacionRecibida.MontoOperacionOrigen);
            sbContenido.Append("numRefCavali: "); sbContenido.AppendLine(prmOperacionRecibida.NumRefCavali);
            sbContenido.Append("numRefLBTR: "); sbContenido.AppendLine(prmOperacionRecibida.NumRefLBTR);
            sbContenido.Append("numRefLBTREnlace: "); sbContenido.AppendLine(prmOperacionRecibida.NumRefLBTREnlace);
            sbContenido.Append("numRefOrigen: "); sbContenido.AppendLine(prmOperacionRecibida.NumRefOrigen);
            sbContenido.Append("tipoCambio: "); sbContenido.AppendLine(prmOperacionRecibida.TipoCambio);
            sbContenido.Append("tipoParticipanteCavali: "); sbContenido.AppendLine(prmOperacionRecibida.TipoParticipanteCavali);
            sbContenido.Append("tipoRegistro: "); sbContenido.AppendLine(prmOperacionRecibida.TipoRegistro);
            sbContenido.Append("hashcode: "); sbContenido.AppendLine(prmOperacionRecibida.Hashcode);
            sbContenido.Append("firma: "); sbContenido.AppendLine(prmOperacionRecibida.Firma);

            LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.AVISO_AFECTACION, strHashcode,
                "BL_OperacionesRecibidas.MostrarDatosOperacionEnLog",
                "Contenido del aviso de afectacion recibido antes de procesarlo: \r\n" + sbContenido.ToString(), false);
        }

        private string RegistrarTrama(BE_OperacionRecibida prmOperacionRecibida)
        {

            try
            {
                BL_General oBLGen = new BL_General(strHashcode);
                BL_Auditoria oBLSeg = new BL_Auditoria(strHashcode);
                string strCodigoBCRP = oBLGen.ObtenerValorConfiguracion(Constantes.PARAM_CODIGO_BCRP);
                string strCodigoCiti = oBLGen.ObtenerValorConfiguracion(Constantes.PARAM_CODIGO_CITIBANK);
                List<BE_Banco> lstBancos = null;
                BE_Banco oBancoOrigen = null;
                BE_Banco oBancoCiti = null;
                BE_Banco oBancoBCRP = null;

                lstBancos = oBLGen.ObtenerBancos(new BE_Banco());

                if (lstBancos != null && lstBancos.Count > 0)
                {
                    oBancoOrigen = lstBancos.Find(delegate(BE_Banco oBancoParamOrigen) { return oBancoParamOrigen.CodBanco == prmOperacionRecibida.CodBancoOrigen; });
                    oBancoCiti = lstBancos.Find(delegate(BE_Banco oBancoParamCiti) { return oBancoParamCiti.CodBanco == strCodigoCiti; });
                    oBancoBCRP = lstBancos.Find(delegate(BE_Banco oBancoParamBCRP) { return oBancoParamBCRP.CodBanco == strCodigoBCRP; });

                    if (oBancoOrigen != null)
                    {
                        return oBLSeg.RegistrarAuditoria(TipoOperacion.AvisoAfectacionOpeRec,
                                                    prmOperacionRecibida.Trama, "",
                                                    prmOperacionRecibida.CodBancoOrigen, strCodigoCiti,
                                                    oBancoCiti.IndiceKPri, oBancoOrigen.IndiceKPub,
                                                    oBancoBCRP.IndiceKPub, prmOperacionRecibida.Firma);
                    }
                    else
                    {
                        return "";
                    }
                }
                else
                {
                    LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.AVISO_AFECTACION, strHashcode,
                        "BL_OperacionesRecibidas.RegistrarTrama",
                        "No existen bancos registrados en la base de datos.", false);
                }
            }
            catch (Exception ex)
            {
                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.AVISO_AFECTACION, strHashcode,
                    "BL_OperacionesRecibidas.RegistrarTrama",
                    "Error, " + ex.Message + ". " + ex.StackTrace, true);
            }

            return null;
        }

        private bool RegistrarOperacionRecibidaCompraVenta(BE_OperacionRecibida prmOperacionRecibida,
                                            DateTime prmFechaHoraRecepcion, String prmFlujo){

            BE_Concepto oConcepto = null;
            BL_General oBLGen = new BL_General(strHashcode);
            bool blnExitoCV = false;

            try
            {
                //SE OBTIENE EL CONCEPTO(C082 y C083)
                if (!String.IsNullOrEmpty(prmOperacionRecibida.CodConcepto))
                {
                    oConcepto = lstConceptos.Find(delegate(BE_Concepto prmConcepto) { return prmConcepto.CodConcepto == prmOperacionRecibida.CodConcepto && prmOperacionRecibida.CodServicio == ServicioBCRP.CompraVenta; });
                }
                BE_CompraVentaEntradas prmOperacionCVEntrada = new BE_CompraVentaEntradas();

                #region SE REACOMODAN LAS PROPIEDADES AL FORMATO QUE SE GUARDARAN

                if (!String.IsNullOrEmpty(prmOperacionRecibida.FechaLiquidacion))
                {
                    prmOperacionRecibida.FechaLiquidacion = prmOperacionRecibida.FechaLiquidacion.Substring(0, 8);
                }

                if (!String.IsNullOrEmpty(prmOperacionRecibida.FechaNegociacionCavali))
                {
                    prmOperacionRecibida.FechaNegociacionCavali = prmOperacionRecibida.FechaNegociacionCavali.Substring(0, 8);
                }

                if (!String.IsNullOrEmpty(prmOperacionRecibida.HoraLiquidacion) && prmOperacionRecibida.HoraLiquidacion.Length == 14)
                {
                    prmOperacionRecibida.HoraLiquidacion = prmOperacionRecibida.HoraLiquidacion.Substring(8, 6);
                }

                prmOperacionRecibida.EstadoLiquidacion = prmOperacionRecibida.EstadoLiquidacion;
                //prmOperacionRecibida.HoraLiquidacion = prmFechaHoraRecepcion.ToString("yyyyMMddHHmmss");
                prmOperacionRecibida.strFlujoRegistro = prmFlujo;

        #endregion

                DA_CompraVenta_Entradas oDAOpeRecib = new DA_CompraVenta_Entradas(strHashcode);
                bool blnMostrarDataOperacion = false;
                string strMensajeErrorRegistro = "";

                if (esFirmaBCRPValida) //Si la firma es Valida se insertara en la tabla T_LBTR_ENTRADAS
                {
                    if (oDAOpeRecib.Insertar_Operacion_Recibida(prmOperacionRecibida, out blnMostrarDataOperacion))
                    {
                        blnExitoCV = true;
                        strMensajeErrorRegistro = "Se registro la operacion [" + prmOperacionRecibida.NumRefLBTR + "] en T_LBTR_ENTRADAS.";

                        if (blnMostrarDataOperacion)
                        {
                            strMensajeErrorRegistro += " Pero con datos incompletos. Revisar el log para mayor detalle";
                        }

                        LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.AVISO_AFECTACION, strHashcode,
                            "BL_OperacionesRecibidas.RegistrarOperacionRecibidaCompraVenta",
                            strMensajeErrorRegistro, blnMostrarDataOperacion);

                        if (blnMostrarDataOperacion)
                        {
                            oBLGen.InsertarLogError(prmOperacionRecibida.NumRefLBTR,
                                "La operaci�n se grab� con datos incompletos.", true);

                            LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.AVISO_AFECTACION, strHashcode,
                                "BL_OperacionesRecibidas.RegistrarOperacionRecibidaCompraVenta",
                                "Datos de la operacion [" + prmOperacionRecibida.NumRefLBTR + "]:\r\n" + prmOperacionRecibida.ToString(), false);
                        }

                        if (prmFlujo == FlujoOperacionRecibida.FlujoContingencia)
                        {
                            oBLGen.InsertarLogError(prmOperacionRecibida.NumRefLBTR,
                                "La operaci�n CompraVenta se recibio el [" + prmFechaHoraRecepcion.ToString("dd/MM/yyyy HH:mm:ss") +
                                "] pero se registro el [" + DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss") + "].", TipoError.WARNING, true);
                        }
                    }
                    else
                    {
                        strMensajeErrorRegistro = "No se pudo registrar la operacion [" + prmOperacionRecibida.NumRefLBTR +
                                                            "] en el flujo [";
                        if (prmFlujo == FlujoOperacionRecibida.FlujoContingencia)
                        {
                            strMensajeErrorRegistro += "CONTINGENCIA]";
                        }
                        else
                        {
                            strMensajeErrorRegistro += "NORMAL]";
                        }
                        strMensajeErrorRegistro += " debido a [" + oDAOpeRecib.Excepcion.Message + "]. Revisar el log para mayor detalle.";

                        LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.AVISO_AFECTACION, strHashcode,
                            "BL_OperacionesRecibidas.RegistrarOperacionRecibidaCompraVenta",
                            strMensajeErrorRegistro, true);

                        if (blnMostrarDataOperacion)
                        {
                            LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.AVISO_AFECTACION, strHashcode,
                                "BL_EntradasCompraVentaBCRP.RegistrarOperacionRecibidaCompraVenta",
                                "Datos de la operacion [" + prmOperacionRecibida.NumRefLBTR + "]:\r\n" + prmOperacionRecibida.ToString(), false);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
            LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.AVISO_AFECTACION, strHashcode,
                        "BL_OperacionesRecibidas.RegistrarOperacionRecibidaCompraVenta",
                        "Error: " + ex.Message + ". " + ex.StackTrace, true);
            }
            return blnExitoCV;
        }
        #endregion
    }

    public enum TipoErrorValNumDoc
    {
        TipoDocumentoRequeridoBen = 1,
        TipoDocumentoRequeridoOrd = 2,
        NumeroDocumentoRequeridoBen = 3,
        NumeroDocumentoRequeridoOrd = 4,
        BaseNumberNoRegistradoEnFile01 = 5,
        RUCdelFile01Vacio = 6,
        RUCBenefDifRUCFile01 = 7,
        NumerosDocDistintos = 8,
        CuentaTramiteNulo = 9,
        BeneficiarioNoEsConsumer = 10,
        TiposDocumentoDistintos = 11,
        TamanhoNroDocBenefRUC = 12,
        TamanhoNroDocBenefDNI = 13,
        TipoDocumentoNoExiste = 14,
        TamanhoNroDocOrdRUC = 15,
        TamanhoNroDocOrdDNI = 16,
        CCIOrdenanteRequerido = 17,
        NombreOrdenanteRequerido = 18,
        TipoDocumentoNULLoVacio = 19,
        CuentaCorporateSinRUC = 20,
        BasenumberVacio = 21
    }

    public struct FlujoOperacionRecibida
    {
        public const string FlujoNormal = "N";
        public const string FlujoContingencia = "C";
    }

}
