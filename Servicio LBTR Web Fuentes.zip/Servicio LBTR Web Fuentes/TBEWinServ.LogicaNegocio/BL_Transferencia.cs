using System;
using System.Collections.Generic;
using System.Text;
using TBEWinServ.AccesoDatos;
using TBEWinServ.EntidadesNegocio.Generales;
using TBEWinServ.EntidadesNegocio.Transferencia;
using TBEWinServ.Utilitarios;
using TBEWinServ.Componentes;
using TBEWinServ.Componentes.LBTRTransferenciaService;

namespace TBEWinServ.LogicaNegocio
{
    public class BL_Transferencia
    {
        private string strHashcode = "";
        private string strCodTramaAuditoria = "";
        string strTransferidoPor = "";
        DA_Transferencia oDATransf = null;
        DA_General oDAGen = null;

        public BL_Transferencia(string prmHashcode) 
        {
            strHashcode = prmHashcode;
            oDATransf = new DA_Transferencia(strHashcode);
            oDAGen = new DA_General(strHashcode);
        }

        #region Envio Transferencia

        public void TransferirOperacionesPaylink()
        {
            try
            {
                if (!String.IsNullOrEmpty(Globales.CADENA_CONEXION))
                {
                    if (!String.IsNullOrEmpty(Globales.SID))
                    {
                        string strHoraCorte = oDAGen.Obtener_Param("0403");
                        DateTime? dtFechaHoraCorte = null;

                        if (!Utilitario.ValidarHora(strHoraCorte, out dtFechaHoraCorte))
                        {
                            LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.ENVIO_TRANSFERENCIAS, strHashcode,
                                "BL_Transferencia.TransferirOperacionesPaylink",
                                "El parametro 0403 Hora de Corte Envio Paylink a BCRP no tiene un valor valido para hora (HH:mm). Se enviaran las operaciones Paylink sin aplicar restriccion.", true);
                        }

                        List<BE_Transferencia> lstTransferencias = oDATransf.Obtener_Operaciones_Enviar_BCRP(dtFechaHoraCorte);

                        foreach (BE_Transferencia oTransferencia in lstTransferencias)
                        {
                            EnviarTransferencia(oTransferencia, true);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.ENVIO_TRANSFERENCIAS, strHashcode,
                    "BL_Transferencia.TransferirOperacionesPaylink", "Error en el proceso de envio de operaciones al BCRP: " + ex.Message, true);
            }
        }

        public int EnviarTransferencia(BE_Transferencia prmTransferencia)
        {
            return EnviarTransferencia(prmTransferencia, false);        
        }

        private int EnviarTransferencia(BE_Transferencia prmTransferencia, bool pblnEnvioAutomatico) 
        {
            int nRetorno = 0;
            bool blnActualizarEnError = false;
            bool blnProcesar = false;
            string strMsjError = null;

            if (!Globales.LstTransferenciasEnCurso.ContainsKey(prmTransferencia.TRANSACT + prmTransferencia.SEC))
            {
                try
                {
                    Globales.LstTransferenciasEnCurso.Add(prmTransferencia.TRANSACT + prmTransferencia.SEC,
                                                        prmTransferencia.TRANSACT + prmTransferencia.SEC);
                    blnProcesar = true;                    
                }
                catch{}

                if (blnProcesar)
                {
                    blnActualizarEnError = true;

                    LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.ENVIO_TRANSFERENCIAS, strHashcode,
                        "BL_Transferencia.EnviarTransferencia",
                        "Inicia el proceso de transferencia para TRANSACT: [" + prmTransferencia.TRANSACT +
                        "], SEC: [" + prmTransferencia.SEC + "]", false);

                    #region Procesamiento de Transferencia

                    string strFirmaMsj = null;
                    WS_LBTRTransferenciaService oWSTransf = new WS_LBTRTransferenciaService(strHashcode);

                    try
                    {
                        if (!String.IsNullOrEmpty(Globales.CADENA_CONEXION))
                        {
                            if (!String.IsNullOrEmpty(Globales.SID))
                            {
                                strTransferidoPor = prmTransferencia.TransferidoPor;
                                prmTransferencia = oDATransf.Obtener_Datos_Transferencia(prmTransferencia);
                                oWSTransf.InstruirTransferenciaRespuestaRecibida += new EventHandler<RespuestaBCRPEventArgs>(oWSTransf_InstruirTransferenciaRespuestaRecibida);
                                oWSTransf.OnInstruirTransferenciaError += new EventHandler<TransferenciaEventArgs>(oWSTransf_OnInstruirTransferenciaError);

                                if (oDATransf.Excepcion == null)
                                {
                                    if (prmTransferencia != null)
                                    {
                                        if (prmTransferencia.Estado == Estados.POR_ENVIAR)
                                        {
                                            if (!String.IsNullOrEmpty(prmTransferencia.CodConcepto))
                                            {
                                                List<BE_Concepto> lstConceptos = null;
                                                BE_Concepto oParamConcepto = new BE_Concepto();
                                                oParamConcepto.CodConcepto = prmTransferencia.CodConcepto;
                                                lstConceptos = oDAGen.Obtener_Conceptos(oParamConcepto);

                                                if (lstConceptos != null && lstConceptos.Count > 0)
                                                {
                                                    //Se verifica si el concepto usa datos cliente
                                                    if (!lstConceptos[0].UsaDatosCliente)
                                                    {
                                                        prmTransferencia.DatosCliente = null;
                                                    }

                                                    datosTransferencia oDatosTransf = new datosTransferencia();
                                                    EstablecerDatosTransferencia(prmTransferencia, oDatosTransf);

                                                    if (oDatosTransf != null)
                                                    {
                                                        strFirmaMsj = (new BL_SeguridadMsj(strHashcode)).GenerarFirma(prmTransferencia,
                                                                                                        oDatosTransf, pblnEnvioAutomatico, out strMsjError);

                                                        if (!String.IsNullOrEmpty(strFirmaMsj))
                                                        {
                                                            //si fecha enviado es vacio, entonces llenar estado enviado, de lo contrario reenviado
                                                            if (prmTransferencia.FechaEnviado == null)
                                                                prmTransferencia.Estado = Estados.ENVIADO;
                                                            else
                                                                prmTransferencia.Estado = Estados.REENVIADO;

                                                            prmTransferencia.Firma = strFirmaMsj;

                                                            if ((new BL_General(strHashcode)).Actualizar_Transferencia(prmTransferencia))
                                                            {
                                                                TransferenciaID oTransferenciaId = new TransferenciaID();
                                                                oTransferenciaId.Transact = prmTransferencia.TRANSACT;
                                                                oTransferenciaId.SEC = prmTransferencia.SEC;
                                                                oTransferenciaId.EstadoOriginal = prmTransferencia.EstadoOriginal;

                                                                strCodTramaAuditoria = this.RegistrarTrama(prmTransferencia, oDatosTransf.datosCliente);

                                                                //SE AGREGA EL CODIGO DE LA TRAMA (20 caracteres) A UN CAMPO 
                                                                //DEL OBJETO A ENVIAR COMO TRANSFERENCIA
                                                                //PARA OBTENERLO EN EL MOMENTO DE LA SALIDA (TRACEEXTENSION)
                                                                //Y CAPTURAR EL MENSAJE SOAP Y ACTUALIZAR EL CONTENIDO DE LA TRAMA
                                                                //Finalmente se removera lo agregado para no afectar
                                                                if (String.IsNullOrEmpty(strCodTramaAuditoria)) strCodTramaAuditoria = "";
                                                                oDatosTransf.numRefLBTREnlace += strCodTramaAuditoria.PadRight(20, ' ');
                                                                                                                                
                                                                nRetorno = oWSTransf.InstruirTransferencia(Globales.SID, oDatosTransf, strFirmaMsj, oTransferenciaId);
                                                            }
                                                            else
                                                            {
                                                                strMsjError = "No se pudo actualizar estado [" + prmTransferencia.Estado + "] de la transferencia. No se realizara la transferencia.";
                                                            }
                                                        }
                                                        else
                                                        {
                                                            //Si hubo error:
                                                            strMsjError = "Error al generar la firma de la transferencia:\r\n[" + strMsjError + "]";
                                                        }
                                                    }
                                                    else
                                                    {
                                                        strMsjError = "Error, no se pudo establecer los datos de la operacion a enviar. oDatosTransf es NULL.";
                                                    }
                                                }
                                                else
                                                {
                                                    strMsjError = "El concepto " + prmTransferencia.CodConcepto + " no esta registrado en la base de datos.";
                                                }
                                            }
                                            else
                                            {
                                                strMsjError = "No tiene establecido el dato codigo concepto. No se realizara la transferencia.";
                                            }
                                        }
                                        else
                                        {
                                            strMsjError = "La operacion no se encuentra en el estado Por Enviar";
                                        }
                                    }
                                    else
                                    {
                                        strMsjError = "No se encontro el registro en la base de datos (T_DESA).";
                                    }
                                }
                                else
                                {
                                    strMsjError = "Error al buscar el registro codigo [" + prmTransferencia.TRANSACT + "] en la base de datos (T_DESA). Realizar seguimiento al log del servicio.";
                                }
                            }
                            else
                            {
                                strMsjError = "El valor del SID es nulo. No tiene una sesion activa.";
                            }
                        }
                        else
                        {
                            strMsjError = "La cadena de conexion no esta establecida";
                        }

                    }
                    catch (Exception ex)
                    {
                        strMsjError = "Error durante el procesamiento: " + ex.Message + ". " + ex.StackTrace;
                    }

                    #endregion

                    LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.ENVIO_TRANSFERENCIAS, strHashcode,
                        "BL_Transferencia.EnviarTransferencia",
                        "Finaliza el proceso de transferencia para TRANSACT: [" + prmTransferencia.TRANSACT +
                        "], SEC: [" + prmTransferencia.SEC + "]",
                        false);
                }
                else
                {
                    nRetorno = 2;
                    strMsjError = "[2] La operacion [" + prmTransferencia.TRANSACT + "-"+ prmTransferencia.SEC + "] esta siendo transferida o bloqueada por otro usuario";
                    blnActualizarEnError = false;
                }
            }
            else
            {
                nRetorno = 2;
                strMsjError = "[1] La operacion [" + prmTransferencia.TRANSACT + "-" + prmTransferencia.SEC + "] esta siendo transferida o bloqueada por otro usuario";
                blnActualizarEnError = false;
            }

            if (!String.IsNullOrEmpty(strMsjError))
            {                
                if (blnActualizarEnError)
                {
                    prmTransferencia.Estado = Estados.ERROR_TRX;
                    (new BL_General(strHashcode)).Actualizar_Transferencia(prmTransferencia);
                    try
                    {
                        Globales.LstTransferenciasEnCurso.Remove(prmTransferencia.TRANSACT + prmTransferencia.SEC);
                    }
                    catch { }
                    (new BL_General(strHashcode)).InsertarLogError(prmTransferencia.TRANSACT + prmTransferencia.SEC, strMsjError, false);
                }

                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.ENVIO_TRANSFERENCIAS, strHashcode,
                    "BL_Transferencia.EnviarTransferencia", strMsjError, blnActualizarEnError);
            }

            return nRetorno;
        }
                
        private void oWSTransf_InstruirTransferenciaRespuestaRecibida(object sender, RespuestaBCRPEventArgs e)
        {
            //Actualizar Estado de la transferencia
            BE_Transferencia oTransf = new BE_Transferencia();
            oTransf.TRANSACT = e.TransferenciaId.Transact;
            oTransf.SEC = e.TransferenciaId.SEC;
            oTransf.NumRefLBTR = e.strNumRefLBTR;
            oTransf.Estado = (new BL_General(strHashcode)).Obtener_Estado_Equivalente(e.strEstado, TipoEstado.Liquidacion);
            oTransf.CodTramaAuditoria = strCodTramaAuditoria;
            oTransf.TransferidoPor = DateTime.Now.ToString("yyyyMMddHHmmss") + strTransferidoPor;
            (new BL_General(strHashcode)).Actualizar_Transferencia(oTransf);

            LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.ENVIO_TRANSFERENCIAS, strHashcode,
                "BL_Transferencia.oWSTransf_InstruirTransferenciaRespuestaRecibida",
                "La funcion InstruirTransferencia del web service retorno: " +
                "Transact: " + oTransf.TRANSACT + "; SEC: " + oTransf.SEC + "; NumRefLBTR: " + oTransf.NumRefLBTR + "; Estado: " + oTransf.Estado + "; Estado BCRP: " + e.strEstado, false);            
        }

        private void oWSTransf_OnInstruirTransferenciaError(object sender, TransferenciaEventArgs e)
        {
            if (!String.IsNullOrEmpty(e.CodigoError) && e.CodigoError.Equals(Constantes.SERVICIOLBTR_SESION_NO_ACTIVA))
            {
                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.ENVIO_TRANSFERENCIAS, strHashcode, 
                    "BL_Transferencia.oWSTransf_OnInstruirTransferenciaError",
                    "Debido a que el codigo de error retornado es " + Constantes.SERVICIOLBTR_SESION_NO_ACTIVA +
                    " (Sesion no activa), \r\nse procedera a invocar al metodo Logon del servicio de autenticacion del LBTR."
                    , true);
                Globales.SID = null;               
            }
                        
            BE_Transferencia oTransf = new BE_Transferencia();
            oTransf.TRANSACT = e.TransferenciaId.Transact;
            oTransf.SEC = e.TransferenciaId.SEC;
            oTransf.Estado = Estados.ERROR_TRX;
            oTransf.TipoIngreso = "M";//La operacion, si fuera Paylink, se convierte en tipo manual para que lo envien manualmente
            (new BL_General(strHashcode)).Actualizar_Transferencia(oTransf);
            try
            {
                Globales.LstTransferenciasEnCurso.Remove(oTransf.TRANSACT + oTransf.SEC);
            }
            catch { }

            string strMsjError = null;

            if (!String.IsNullOrEmpty(e.CodigoError))
            {
                strMsjError = "Error, el servicio web del BCRP respondio: " + e.CodigoError + " - " + e.MensajeError + ".";
            }
            else
            {
                strMsjError = "Error al utilizar el servicio web del BCRP. " + e.MensajeError;
            }

            (new BL_General(strHashcode)).InsertarLogError(e.TransferenciaId.Transact + e.TransferenciaId.SEC, strMsjError, false);

            LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.ENVIO_TRANSFERENCIAS, strHashcode,
                "BL_Transferencia.oWSTransf_OnInstruirTransferenciaError",
                strMsjError, false);
        }

        private void EstablecerDatosTransferencia(BE_Transferencia prmBE_Transf, datosTransferencia prmDatosTransf)
        {
            BL_General oBLGen = new BL_General(strHashcode);
                        
            try
            {
                String strCaracteresPermitidos = oBLGen.ObtenerValorParametro(Constantes.PARAM_CODIGO_CARACT_VALID);

                //SE VERIFICA EL CONTENIDO DE CIERTOS CAMPOS PARA VER SI NO EXISTEN CARACTERES NO PERMITIDOS
                if (prmBE_Transf.DatosCliente != null)
                {
                    prmBE_Transf.DatosCliente.DireccionBeneficiario = oBLGen.ValidarContenidoString(prmBE_Transf.DatosCliente.DireccionBeneficiario, strCaracteresPermitidos);
                    prmBE_Transf.DatosCliente.DireccionOrdenante = oBLGen.ValidarContenidoString(prmBE_Transf.DatosCliente.DireccionOrdenante, strCaracteresPermitidos);
                    prmBE_Transf.DatosCliente.NombreBeneficiario = oBLGen.ValidarContenidoString(prmBE_Transf.DatosCliente.NombreBeneficiario, strCaracteresPermitidos);
                    prmBE_Transf.DatosCliente.NombreOrdenante = oBLGen.ValidarContenidoString(prmBE_Transf.DatosCliente.NombreOrdenante, strCaracteresPermitidos);
                    prmBE_Transf.DatosCliente.Observaciones = oBLGen.ValidarContenidoString(prmBE_Transf.DatosCliente.Observaciones, strCaracteresPermitidos);
                }
                
                prmBE_Transf.InstruccionesPago = oBLGen.ValidarContenidoString(prmBE_Transf.InstruccionesPago, strCaracteresPermitidos);
                prmBE_Transf.NumRefLBTREnlace = oBLGen.ValidarContenidoString(prmBE_Transf.NumRefLBTREnlace, strCaracteresPermitidos);
                prmBE_Transf.NumRefOrigen = oBLGen.ValidarContenidoString(prmBE_Transf.NumRefOrigen, strCaracteresPermitidos);

                //SE VERIFICA SI EL CONTENIDO DE DATA CLIENTE CONTIENE ALGUN CARACTER ESPECIAL XML
                if (prmBE_Transf.DatosCliente != null)
                {
                    prmBE_Transf.DatosCliente.DireccionBeneficiario = oBLGen.InterpretarCaracteresEspecialesXML(prmBE_Transf.DatosCliente.DireccionBeneficiario);
                    prmBE_Transf.DatosCliente.DireccionOrdenante = oBLGen.InterpretarCaracteresEspecialesXML(prmBE_Transf.DatosCliente.DireccionOrdenante);
                    prmBE_Transf.DatosCliente.NombreBeneficiario = oBLGen.InterpretarCaracteresEspecialesXML(prmBE_Transf.DatosCliente.NombreBeneficiario);
                    prmBE_Transf.DatosCliente.NombreOrdenante = oBLGen.InterpretarCaracteresEspecialesXML(prmBE_Transf.DatosCliente.NombreOrdenante);
                    prmBE_Transf.DatosCliente.Observaciones = oBLGen.InterpretarCaracteresEspecialesXML(prmBE_Transf.DatosCliente.Observaciones);
                }

                //SE ESTABLECE EL BEAN DATOSTRANSFERENCIA
                prmDatosTransf.codConcepto = String.IsNullOrEmpty(prmBE_Transf.CodConcepto) ? "" : prmBE_Transf.CodConcepto;
                prmDatosTransf.cuentaDestino = String.IsNullOrEmpty(prmBE_Transf.CuentaDestino) ? "" : prmBE_Transf.CuentaDestino;
                prmDatosTransf.cuentaOrigen = String.IsNullOrEmpty(prmBE_Transf.CuentaOrigen) ? "" : prmBE_Transf.CuentaOrigen;

                if (prmBE_Transf.FechaLiquidacion != null)
                {
                    prmDatosTransf.fechaLiquidacionSpecified = true;
                    prmBE_Transf.FechaLiquidacion = Utilitario.FechaSinHora(prmBE_Transf.FechaLiquidacion.Value);
                    prmDatosTransf.fechaLiquidacion = prmBE_Transf.FechaLiquidacion.Value;
                }

                if (prmBE_Transf.FecRefLBTREnlace != null)
                {
                    prmDatosTransf.fechaRefLBTREnlaceSpecified = true;
                    prmBE_Transf.FecRefLBTREnlace = Utilitario.FechaSinHora(prmBE_Transf.FecRefLBTREnlace.Value);
                    prmDatosTransf.fechaRefLBTREnlace = prmBE_Transf.FecRefLBTREnlace.Value;
                }

                prmDatosTransf.instruccionesPago = String.IsNullOrEmpty(prmBE_Transf.InstruccionesPago) ? "" : prmBE_Transf.InstruccionesPago;
                prmDatosTransf.modalidad = String.IsNullOrEmpty(prmBE_Transf.Modalidad) ? "" : prmBE_Transf.Modalidad;

                if (prmBE_Transf.Monto != null)
                {
                    prmDatosTransf.montoOperacionSpecified = true;
                    prmDatosTransf.montoOperacion = prmBE_Transf.Monto.Value;
                }

                prmDatosTransf.numRefOrigen = String.IsNullOrEmpty(prmBE_Transf.NumRefOrigen) ? "" : prmBE_Transf.NumRefOrigen;
                prmDatosTransf.numRefLBTREnlace = String.IsNullOrEmpty(prmBE_Transf.NumRefLBTREnlace) ? "" : prmBE_Transf.NumRefLBTREnlace;

                if (prmBE_Transf.Prioridad != null)
                {
                    prmDatosTransf.prioridadSpecified = true;
                    prmDatosTransf.prioridad = prmBE_Transf.Prioridad.Value;
                }

            }
            catch (Exception ex)
            {
                prmDatosTransf = null;
                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.ENVIO_TRANSFERENCIAS, strHashcode,
                    "BL_Transferencia.EstablecerDatosTransferencia",
                    "Error al establecer los datos de la transferencia: " + ex.Message + ". " + ex.StackTrace, true);
            }
        }

        private string RegistrarTrama(BE_Transferencia prmTransferencia, string prmDatosClienteCifrado) 
        {
            StringBuilder sbTrama = new StringBuilder();
            string strTrama = "";
            string strTramaEnClaro = "";

            try
            {
                sbTrama.Append("<?xml version=\"1.0\" encoding=\"ISO-8859-1\" ?>");
                sbTrama.Append("<datosTransferencia>");
                sbTrama.Append("<codConcepto>"); sbTrama.Append(prmTransferencia.CodConcepto); sbTrama.Append("</codConcepto>");
                sbTrama.Append("<cuentaDestino>"); sbTrama.Append(prmTransferencia.CuentaDestino); sbTrama.Append("</cuentaDestino>");
                sbTrama.Append("<cuentaOrigen>"); sbTrama.Append(prmTransferencia.CuentaOrigen); sbTrama.Append("</cuentaOrigen>");
                
                sbTrama.Append("<datosCliente>{[REEMPLAZO1]}</datosCliente>");
                
                sbTrama.Append("<fechaLiquidacion>");
                if (prmTransferencia.FechaLiquidacion.HasValue) sbTrama.Append(prmTransferencia.FechaLiquidacion.Value.ToString("yyyyMMddHHmmss"));
                sbTrama.Append("</fechaLiquidacion>");

                sbTrama.Append("<fechaRefLBTREnlace>");
                if (prmTransferencia.FecRefLBTREnlace.HasValue) sbTrama.Append(prmTransferencia.FecRefLBTREnlace.Value.ToString("yyyyMMddHHmmss"));
                sbTrama.Append("</fechaRefLBTREnlace>");

                sbTrama.Append("<instruccionesPago>"); sbTrama.Append(prmTransferencia.InstruccionesPago); sbTrama.Append("</instruccionesPago>");
                sbTrama.Append("<modalidad>"); sbTrama.Append(prmTransferencia.Modalidad); sbTrama.Append("</modalidad>");

                sbTrama.Append("<montoOperacion>");
                if (prmTransferencia.Monto.HasValue) sbTrama.Append(prmTransferencia.Monto.Value.ToString("#########.###"));
                sbTrama.Append("</montoOperacion>");

                sbTrama.Append("<numRefLBTREnlace>"); sbTrama.Append(prmTransferencia.NumRefLBTREnlace); sbTrama.Append("</numRefLBTREnlace>");
                sbTrama.Append("<numRefOrigen>"); sbTrama.Append(prmTransferencia.NumRefOrigen); sbTrama.Append("</numRefOrigen>");
                
                sbTrama.Append("<prioridad>");
                if (prmTransferencia.Prioridad.HasValue) sbTrama.Append(prmTransferencia.Prioridad.Value.ToString()); 
                sbTrama.Append("</prioridad>");

                sbTrama.Append("</datosTransferencia>");

                strTramaEnClaro = sbTrama.ToString();
                strTrama = sbTrama.ToString();
                strTrama = strTrama.Replace("{[REEMPLAZO1]}", prmDatosClienteCifrado);

                if (prmTransferencia.DatosCliente != null)
                {
                    strTramaEnClaro = strTramaEnClaro.Replace("{[REEMPLAZO1]}", BE_DatosCliente.ArmarDatosCliente(prmTransferencia.DatosCliente.ToString(), "", ""));
                }
                else 
                {
                    strTramaEnClaro = strTramaEnClaro.Replace("{[REEMPLAZO1]}", "");
                }

                BL_General oBLGen = new BL_General(strHashcode);
                BL_Auditoria oBLSeg = new BL_Auditoria(strHashcode);
                string strCodigoCiti = oBLGen.ObtenerValorConfiguracion(Constantes.PARAM_CODIGO_CITIBANK);
                List<BE_Banco> lstBancos = null;
                BE_Banco oBancoDestino = null;
                BE_Banco oBancoCiti = null;

                lstBancos = oBLGen.ObtenerBancos(new BE_Banco());

                if (lstBancos != null && lstBancos.Count > 0)
                {
                    oBancoDestino = lstBancos.Find(delegate(BE_Banco oBancoParamDest) { return oBancoParamDest.CodBanco == prmTransferencia.CodBancoDestino; });
                    oBancoCiti = lstBancos.Find(delegate(BE_Banco oBancoParamCiti) { return oBancoParamCiti.CodBanco == strCodigoCiti; });

                    return oBLSeg.RegistrarAuditoria(TipoOperacion.Transferencias, strTrama, strTramaEnClaro,
                                                strCodigoCiti, prmTransferencia.CodBancoDestino,
                                                oBancoCiti.IndiceKPri, oBancoDestino.IndiceKPub, null, prmTransferencia.Firma);
                }
                else
                {
                    LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.ENVIO_TRANSFERENCIAS, strHashcode,
                        "BL_Transferencia.RegistrarTrama",
                        "No existen bancos registrados en la base de datos.", true);
                }
            }
            catch (Exception ex)
            {
                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.ENVIO_TRANSFERENCIAS, strHashcode,
                    "BL_Transferencia.RegistrarTrama",
                    "Error, " + ex.Message + ". " + ex.StackTrace, true);
            }

            return null;
        }

        #endregion
        
        #region Anular Operacion Pendiente

        public int AnularOperacionPendiente(string prmNumRefLBTR) 
        {
            LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.ANULACION_OPERACION, strHashcode,
                "BL_Transferencia.AnularOperacionPendiente",
                "Inicia el proceso de anulacion de la operacion: " + prmNumRefLBTR, false);

            int nRetorno = 0;
            string strFirmaMsj = null;
            string strMsjError = null;
            WS_LBTRAnulacionesService oWSAnul = new WS_LBTRAnulacionesService(strHashcode);

            oWSAnul.AnularOperacionPendienteRespuestaRecibida += new EventHandler<RespuestaBCRPEventArgs>(oWSAnul_AnularOperacionPendienteRespuestaRecibida);
            oWSAnul.OnAnularOperacionPendienteError += new EventHandler<AnularOperacionPendienteEventArgs>(oWSAnul_OnAnularOperacionPendienteError);
            
            try
            {
                if (!String.IsNullOrEmpty(Globales.CADENA_CONEXION))
                {
                    if (!String.IsNullOrEmpty(Globales.SID))
                    {
                        strFirmaMsj = (new BL_SeguridadMsj(strHashcode)).GenerarFirma(false, prmNumRefLBTR, out strMsjError);

                        if (!String.IsNullOrEmpty(strFirmaMsj))
                        {
                            BE_Transferencia oTransf = oDATransf.Obtener_Datos_Transferencia(new BE_Transferencia(prmNumRefLBTR));

                            if (oDATransf.Excepcion == null)
                            {
                                if (oTransf != null)
                                {
                                    OperacionID oOperacionID = new OperacionID();
                                    oOperacionID.NumRefLBTR = prmNumRefLBTR;
                                    oOperacionID.EstadoOriginal = oTransf.EstadoOriginal;
                                    nRetorno = oWSAnul.AnularOperacionPendiente(Globales.SID, oOperacionID, strFirmaMsj);
                                }
                                else
                                {
                                    strMsjError = "No se encontro la operacion " + prmNumRefLBTR + " en T_DESA.";
                                }
                            }
                            else
                            {
                                strMsjError = "Error al buscar la operacion [" + prmNumRefLBTR + "] en la base de datos (T_DESA).";
                            }
                        }
                        else
                        {
                            //Si hubo error:
                            strMsjError = "Error al generar la firma de la operacion a anular:\r\n[" + strMsjError + "]";
                        }
                    }
                    else
                    {
                        strMsjError = "El valor del SID es nulo. No tiene una sesion activa.";
                    }
                                        
                }
                else
                {
                    strMsjError = "La cadena de conexion no esta establecida";
                }
            }
            catch (Exception ex)
            {
                nRetorno = 0;
                strMsjError = "Error: " + ex.Message + ". " + ex.StackTrace;
            }

            if (!String.IsNullOrEmpty(strMsjError))
            {
                (new BL_General(strHashcode)).InsertarLogError(prmNumRefLBTR, strMsjError, false);

                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.ANULACION_OPERACION, strHashcode,
                    "BL_Transferencia.AnularOperacionPendiente",
                    strMsjError, true);
            }

            LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.ANULACION_OPERACION, strHashcode,
                "BL_Transferencia.AnularOperacionPendiente",
                "Finaliza el proceso de anulacion de la operacion: " + prmNumRefLBTR, false);

            return nRetorno;
        }

        private void oWSAnul_OnAnularOperacionPendienteError(object sender, AnularOperacionPendienteEventArgs e)
        {
            if (!String.IsNullOrEmpty(e.CodigoError) && e.CodigoError.Equals(Constantes.SERVICIOLBTR_SESION_NO_ACTIVA))
            {
                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.ANULACION_OPERACION, strHashcode,
                    "BL_Transferencia.oWSAnul_OnAnularOperacionPendienteError",
                    "Debido a que el codigo de error retornado es " + Constantes.SERVICIOLBTR_SESION_NO_ACTIVA +
                    " (Sesion no activa), \r\nse procedera a invocar al metodo Logon del servicio de autenticacion del LBTR."
                    , true);
                Globales.SID = null;
            }

            BE_Transferencia oTransf = oDATransf.Obtener_Datos_Transferencia(new BE_Transferencia(e.OperacionId.NumRefLBTR));

            if (oTransf != null)
            {
                oTransf.Estado = e.OperacionId.EstadoOriginal;
                (new BL_General(strHashcode)).Actualizar_Transferencia(oTransf);
            }

            string strMsjError = null;

            if (!String.IsNullOrEmpty(e.CodigoError))
            {
                strMsjError = "Error, el servicio web del BCRP respondio: " + e.CodigoError + " - " + e.MensajeError + ".";
            }
            else
            {
                strMsjError = "Error al utilizar el servicio web del BCRP. " + e.MensajeError;
            }

            (new BL_General(strHashcode)).InsertarLogError(e.OperacionId.NumRefLBTR, strMsjError, false);

            LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.ENVIO_TRANSFERENCIAS, strHashcode,
                "BL_Transferencia.oWSAnul_OnAnularOperacionPendienteError",
                strMsjError, true);
        }

        private void oWSAnul_AnularOperacionPendienteRespuestaRecibida(object sender, RespuestaBCRPEventArgs e)
        {
            BE_Transferencia oTransf = oDATransf.Obtener_Datos_Transferencia(new BE_Transferencia(e.OperacionId.NumRefLBTR));

            LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.ANULACION_OPERACION, strHashcode,
                "BL_Transferencia.oWSAnul_AnularOperacionPendienteRespuestaRecibida",
                "La funcion AnularOperacionPendiente del web service retorno: " +
                "NumRefLBTR: " + e.strNumRefLBTR + "; Estado BCRP: " + e.strEstado, false);

            if (oTransf != null)
            {
                oTransf.Estado = oTransf.Estado = (new BL_General(strHashcode)).Obtener_Estado_Equivalente(e.strEstado, TipoEstado.Liquidacion);
                (new BL_General(strHashcode)).Actualizar_Transferencia(oTransf);
            }
        }

        #endregion

    }
}
