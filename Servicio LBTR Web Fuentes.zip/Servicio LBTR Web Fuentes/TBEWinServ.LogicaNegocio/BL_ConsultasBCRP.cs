using System;
using System.Collections.Generic;
using System.Text;
using TBEWinServ.AccesoDatos;
using TBEWinServ.EntidadesNegocio.ConsultasBCRP;
using TBEWinServ.EntidadesNegocio.Generales;
using TBEWinServ.EntidadesNegocio.Auditoria;
using TBEWinServ.EntidadesNegocio.OperacionesRecibidas;
using TBEWinServ.Utilitarios;
using TBEWinServ.Componentes;
using TBEWinServ.Componentes.LBTRConsultasService;

namespace TBEWinServ.LogicaNegocio
{
    public class BL_ConsultasBCRP
    {
        private string strHashcode = "";

        public BL_ConsultasBCRP(string prmHashcode) {
            strHashcode = prmHashcode;
        }

        #region Consulta Operaciones/Otorgadas
        
        public int ConsultarOperacionesRecibidas(BE_ConsultaBCRP prmConsultaBCRP, bool blnUsarLlavesActuales)
        {            
            LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.CONSULTAS_BCRP, strHashcode,
                "BL_ConsultasBCR.ConsultarOperacionesRecibidas",
                "Inicia el proceso de ConsultarOperacionesRecibidas.", false);

            //Informacion de la consulta, aparte el parametro viene con la fecha liquidacion y el id de consulta
            prmConsultaBCRP.FechaConsulta = DateTime.Today.ToString("yyyyMMdd");
            prmConsultaBCRP.TipoConsulta = TipoOperacion.AvisoAfectacionOpeRec;

            int nRetorno = ConsultarOperaciones(prmConsultaBCRP, blnUsarLlavesActuales);

            LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.CONSULTAS_BCRP, strHashcode,
                "BL_ConsultasBCR.ConsultarOperacionesRecibidas",
                "Finaliza el proceso de ConsultarOperacionesRecibidas.", false);

            return nRetorno;
        }

        public int ConsultarOperacionesOtorgadas(BE_ConsultaBCRP prmConsultaBCRP)
        {
            LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.CONSULTAS_BCRP, strHashcode,
                "BL_ConsultasBCR.ConsultarOperacionesOtorgadas",
                "Inicia el proceso de ConsultarOperacionesOtorgadas.", false);
                        
            //Informacion de la consulta, aparte el parametro viene con la fecha liquidacion y el id de consulta
            prmConsultaBCRP.FechaConsulta = DateTime.Today.ToString("yyyyMMdd");
            prmConsultaBCRP.TipoConsulta = TipoOperacion.AvisoAfectacionOpeOtor;

            int nRetorno = ConsultarOperaciones(prmConsultaBCRP, true);

            LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.CONSULTAS_BCRP, strHashcode,
                "BL_ConsultasBCR.ConsultarOperacionesOtorgadas",
                "Finaliza el proceso de ConsultarOperacionesOtorgadas.", false);

            return nRetorno;
        }

        private int ConsultarOperaciones(BE_ConsultaBCRP prmConsultaBCRP, bool blnUsarLlavesActuales)
        {
            int nRetorno = 0;
            string strMsjError = null;
            WS_LBTRConsultasService oWSCons = new WS_LBTRConsultasService(strHashcode);

            oWSCons.OnConsultarOperacionError += new EventHandler<ConsultarOperacionesEventArgs>(oWSCons_OnConsultarOperacionError);

            if (BL_ConectividadBD.ProbarConexionSybase(Globales.CADENA_CONEXION))
            {
                if (!String.IsNullOrEmpty(Globales.SID))
                {

                    if (!String.IsNullOrEmpty(prmConsultaBCRP.FechaLiquidacion))
                    {
                        try
                        {
                            DateTime dtFecLiq = new DateTime(int.Parse(prmConsultaBCRP.FechaLiquidacion.Substring(0, 4)),
                                                                int.Parse(prmConsultaBCRP.FechaLiquidacion.Substring(4, 2)),
                                                                int.Parse(prmConsultaBCRP.FechaLiquidacion.Substring(6, 2)));

                            dtFecLiq = Utilitario.FechaSinHora(dtFecLiq);
                            beanOperacion[] arrOperaciones = oWSCons.ConsultarOperaciones(prmConsultaBCRP.TipoConsulta, Globales.SID, dtFecLiq, prmConsultaBCRP.IdConsulta);

                            if (arrOperaciones != null)
                            {
                                ProcesarConsultaOperaciones(prmConsultaBCRP, arrOperaciones, out strMsjError, blnUsarLlavesActuales);
                                nRetorno = 1;
                            }
                            else
                            {
                                nRetorno = 1;
                            }
                        }
                        catch (Exception ex)
                        {
                            nRetorno = 0;
                            strMsjError = "Error en el proceso de consulta. " + ex.Message + "; " + ex.StackTrace;
                        }
                    }
                    else
                    {
                        strMsjError = "El parametro Fecha es requerido.";
                    }

                }
                else
                {
                    strMsjError = "El valor del SID es nulo. El servicio LBTR no tiene una sesion activa.";
                }
            }
            else
            {
                strMsjError = "No hay conexion con la base de datos.";
            }

            if (!String.IsNullOrEmpty(strMsjError))
            {
                (new BL_General(strHashcode)).InsertarLogError(prmConsultaBCRP.IdConsulta, strMsjError, true);

                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.CONSULTAS_BCRP, strHashcode,
                    "BL_ConsultasBCR.ConsultarOperacionesRecibidas",
                    "Error para la consulta con ID [" + prmConsultaBCRP.IdConsulta + "]: " + strMsjError, true);
            }
            
            return nRetorno;
        }

        private void ProcesarConsultaOperaciones(BE_ConsultaBCRP prmConsultaBCRP, 
                                                    beanOperacion[] arrOperaciones,
                                                    out String prmMensajeError,
                                                    bool blnUsarLlavesActuales)
        {
            prmMensajeError = "";
            BE_OperacionRecibidaConsulta oOperacion = null;

            if (arrOperaciones != null) 
            {
                StringBuilder sbSeguimiento = new StringBuilder();
                
                sbSeguimiento.AppendLine("Inicia Seguimiento consulta [");

                for (int i = 0; i < arrOperaciones.Length; i++)
                {
                    sbSeguimiento.Append("\r\nProceso [");
                    sbSeguimiento.Append(arrOperaciones[i].numRefLBTR);
                    sbSeguimiento.Append("]: Inicia [");
                    sbSeguimiento.Append(DateTime.Now.ToString("HHmmss"));
                    sbSeguimiento.Append("]");

                    #region Procesamiento Operacion

                    oOperacion = new BE_OperacionRecibidaConsulta();
                    
                    oOperacion.IdConsulta = prmConsultaBCRP.IdConsulta;
                    oOperacion.FecConsulta = prmConsultaBCRP.FechaConsulta;
                    oOperacion.TipoConsulta = prmConsultaBCRP.TipoConsulta;
                    
                    oOperacion.CodBancoDestino = arrOperaciones[i].codBancoDestino;
                    oOperacion.CodBancoOrigen = arrOperaciones[i].codBancoOrigen;
                    oOperacion.CodConcepto = arrOperaciones[i].codConcepto;
                    oOperacion.CodMoneda = arrOperaciones[i].codMoneda;
                    oOperacion.ConfirmaAbono = arrOperaciones[i].confirmaAbono;
                    oOperacion.CuentaDestino = arrOperaciones[i].cuentaDestino;
                    oOperacion.CuentaOrigen = arrOperaciones[i].cuentaOrigen;
                    oOperacion.Estado = (new BL_General(strHashcode)).Obtener_Estado_Equivalente(arrOperaciones[i].estadoLiquidacion, TipoEstado.Liquidacion);
                    if (arrOperaciones[i].fechaLiquidacionSpecified)
                        oOperacion.FechaLiquidacion = arrOperaciones[i].fechaLiquidacion.ToString("yyyyMMdd");
                    if (!String.IsNullOrEmpty(arrOperaciones[i].horaLiquidacion))
                        oOperacion.HoraLiquidacion = arrOperaciones[i].horaLiquidacion.Replace(":", "");
                    oOperacion.InstruccionesPago = arrOperaciones[i].instruccionesPago;
                    if (arrOperaciones[i].montoOperacionSpecified)
                        oOperacion.MontoOperacion = arrOperaciones[i].montoOperacion.ToString();
                    oOperacion.NumRefEnlace = arrOperaciones[i].numRefEnlaceOperacion;
                    oOperacion.NumRefLBTR = arrOperaciones[i].numRefLBTR;
                    oOperacion.NumRefOrigen = arrOperaciones[i].numRefOrigen;
                    if (arrOperaciones[i].prioridadSpecified)
                        oOperacion.Prioridad = arrOperaciones[i].prioridad.ToString();
                    if (arrOperaciones[i].tipoCambioSpecified)
                        oOperacion.TipoCambio = arrOperaciones[i].tipoCambio.ToString();

                    if (prmConsultaBCRP.TipoConsulta == TipoOperacion.AvisoAfectacionOpeRec)
                    {
                        sbSeguimiento.Append(" Se obtendra operec [");
                        sbSeguimiento.Append(DateTime.Now.ToString("HHmmss"));
                        sbSeguimiento.Append("]");

                        //se busca la operacion recibida en la tabla t_lbtr_oper_recibidas para obtener el cod. trama
                        DA_OperacionesRecibidas oDAOpeRec = new DA_OperacionesRecibidas(strHashcode);
                        List<BE_OperacionRecibida> lstOpeRec = oDAOpeRec.Obtener_Operaciones_Recibidas(new BE_OperacionRecibida(arrOperaciones[i].numRefLBTR));
                                                
                        if (lstOpeRec != null && lstOpeRec.Count > 0)
                        {
                            sbSeguimiento.Append(" Se obtuvo operec [");
                            sbSeguimiento.Append(DateTime.Now.ToString("HHmmss"));
                            sbSeguimiento.Append("]");

                            string strCodTramaAuditoria = lstOpeRec[0].CodTramaAuditoria;

                            //Se busca el codigo de trama de auditoria asociada a esta operacion recibida
                            List<BE_Auditoria> lstAuditoria = (new DA_Auditoria(strHashcode)).Consultar_Auditoria(new BE_Auditoria(strCodTramaAuditoria));

                            if (lstAuditoria != null && lstAuditoria.Count > 0)
                            {
                                sbSeguimiento.Append(" Se obtuvo trama [");
                                sbSeguimiento.Append(DateTime.Now.ToString("HHmmss"));
                                sbSeguimiento.Append("] y procesara data cliente,");

                                string strDataCliente = null;
                                string strMensajeErrorValidDataCliente = "";
                                if (!String.IsNullOrEmpty(arrOperaciones[i].datosCliente))
                                {
                                    bool blnErrorBD = false;
                                    bool esFirmaClienteValida = (new BL_SeguridadMsj(strHashcode)).ValidarFirmaDataCliente("", blnUsarLlavesActuales, 
                                                                                                                            prmConsultaBCRP.TipoConsulta, 
                                                                                                                            arrOperaciones[i].datosCliente, 
                                                                                                                            arrOperaciones[i].codBancoOrigen, 
                                                                                                                            out strDataCliente, 
                                                                                                                            lstAuditoria[0].FecOperacion, 
                                                                                                                            lstAuditoria[0].IndiceKPubBanco, 
                                                                                                                            lstAuditoria[0].IndiceKPriCiti, 
                                                                                                                            out strMensajeErrorValidDataCliente,
                                                                                                                            out blnErrorBD);

                                    sbSeguimiento.Append(" Se proceso Data Cliente [");
                                    sbSeguimiento.Append(DateTime.Now.ToString("HHmmss"));
                                    sbSeguimiento.Append("]");

                                    if (!blnErrorBD)
                                    {
                                        if (!String.IsNullOrEmpty(strMensajeErrorValidDataCliente))
                                        {
                                            prmMensajeError += "\r\nOperacion numRefLBTR [" + arrOperaciones[i].numRefLBTR + "], error en la validacion de Datos Cliente: [" + strMensajeErrorValidDataCliente + "]";
                                        }

                                        try
                                        {
                                            oOperacion.DatosCliente = BE_DatosCliente.ObtenerDataClienteDesdeXML(strDataCliente);
                                            
                                            sbSeguimiento.Append(" Data Cliente LeidoXML [");
                                            sbSeguimiento.Append(DateTime.Now.ToString("HHmmss"));
                                            sbSeguimiento.Append("]");
                                        }
                                        catch (Exception ex)
                                        {
                                            prmMensajeError += "\r\nOperacion numRefLBTR [" + arrOperaciones[i].numRefLBTR + "], error al obtener data cliente desde su formato xml: [" + ex.Message + "]";
                                        }
                                    }
                                    else
                                    {
                                        prmMensajeError += "\r\nSe produjo un problema de base de datos al realizar la validacion/descifrado de datos cliente de la operacion.";
                                    }
                                    
                                }
                            }
                            else
                            {
                                prmMensajeError += "\r\nOperacion numRefLBTR [" + arrOperaciones[i].numRefLBTR + "], no se encontro el registro de trama de auditoria [" + strCodTramaAuditoria + "] en T_LBTR_TRAMA_AUDITORIA";
                            }
                        }
                        else
                        {
                            prmMensajeError += "\r\nOperacion numRefLBTR [" + arrOperaciones[i].numRefLBTR + "], no se encontro en la tabla de operaciones recibidas T_LBTR_OPER_RECIBIDAS.";
                        }
                    }
                    
                    #endregion

                    sbSeguimiento.Append(" Se Insertara en BD [");
                    sbSeguimiento.Append(DateTime.Now.ToString("HHmmss"));
                    sbSeguimiento.Append("]");

                    if (!(new DA_ConsultasBCRP(strHashcode)).Insertar_ConsultaOperacion(oOperacion))
                    {
                        sbSeguimiento.Append(" No se inserto en BD [");
                        sbSeguimiento.Append(DateTime.Now.ToString("HHmmss"));
                        sbSeguimiento.AppendLine("]");
                        prmMensajeError += "\r\nOperacion numRefLBTR [" + oOperacion.NumRefLBTR + "], no se pudo insertar en la tabla de consulta T_LBTR_CONSOPEREC.";
                    }
                    else
                    {
                        sbSeguimiento.Append(" Se Inserto en BD [");
                        sbSeguimiento.Append(DateTime.Now.ToString("HHmmss"));
                        sbSeguimiento.AppendLine("]");
                    }
                }

                sbSeguimiento.Append("Finaliza Seguimiento consulta]]");

                LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.CONSULTAS_BCRP, strHashcode,
                    "BL_ConsultasBCR.ConsultarOperacionesRecibidas",
                    sbSeguimiento.ToString(), false);
            }

        }

        private void oWSCons_OnConsultarOperacionError(object sender, ConsultarOperacionesEventArgs e)
        {
            if (!String.IsNullOrEmpty(e.CodigoError) && e.CodigoError.Equals(Constantes.SERVICIOLBTR_SESION_NO_ACTIVA))
            {
                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.CONSULTAS_BCRP, strHashcode, 
                    "BL_ConsultasBCR.oWSCons_OnConsultarOpeRecibidasError",
                    "Debido a que el codigo de error retornado es " + Constantes.SERVICIOLBTR_SESION_NO_ACTIVA +
                    " (Sesion no activa), \r\nse procedera a invocar al metodo Logon del servicio de autenticacion del LBTR."
                    , true);
                Globales.SID = null;
            }

            string strMsjError = null;

            if (!String.IsNullOrEmpty(e.CodigoError))
            {
                strMsjError = "Error, el servicio web del BCRP respondio: " + e.CodigoError + " - " + e.MensajeError + ".";
            }
            else
            {
                strMsjError = "Error al utilizar el servicio web del BCRP: " + e.MensajeError;
            }

            (new BL_General(strHashcode)).InsertarLogError(e.IdConsulta, strMsjError, true);

            LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.CONSULTAS_BCRP, strHashcode,
                "BL_ConsultasBCR.oWSCons_OnConsultarOpeRecibidasError",
                strMsjError, true);
        }
        
        #endregion 

        #region Consulta Saldo Cta Cte

        public int ConsultarSaldosCtaCte(BE_ConsultaBCRP prmConsultaBCRP)
        {
            LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.CONSULTAS_BCRP, strHashcode,
                "BL_ConsultasBCR.ConsultarSaldosCtaCte",
                "Inicia el proceso de ConsultarSaldosCtaCte.", false);
                        
            int nRetorno = 0;
            string strMsjError = null;

            if (BL_ConectividadBD.ProbarConexionSybase(Globales.CADENA_CONEXION))
            {

                //Informacion de la consulta, aparte el parametro viene con la fecha liquidacion y el id de consulta
                prmConsultaBCRP.FechaConsulta = DateTime.Today.ToString("yyyyMMdd");
                prmConsultaBCRP.TipoConsulta = TipoOperacion.ConsultaSaldosCtaCte;//no es relevante en este proceso
                prmConsultaBCRP.FechaConsulta = DateTime.Today.ToString("yyyyMMdd");

                WS_LBTRConsultasService oWSCons = new WS_LBTRConsultasService(strHashcode);

                oWSCons.OnConsultarSaldosCtaCteError += new EventHandler<ConsultarSaldosCtaCteEventArgs>(oWSCons_OnConsultarSaldosCtaCteError);

                if (!String.IsNullOrEmpty(Globales.SID))
                {
                    if (!String.IsNullOrEmpty(prmConsultaBCRP.NumeroCuenta) && !String.IsNullOrEmpty(prmConsultaBCRP.FechaLiquidacion))
                    {
                        try
                        {

                            DateTime dtFecLiq = new DateTime(int.Parse(prmConsultaBCRP.FechaLiquidacion.Substring(0, 4)),
                                                                int.Parse(prmConsultaBCRP.FechaLiquidacion.Substring(4, 2)),
                                                                int.Parse(prmConsultaBCRP.FechaLiquidacion.Substring(6, 2)));

                            dtFecLiq = Utilitario.FechaSinHora(dtFecLiq);
                            beanSaldoCtaCte[] arrSaldoCtaCte = oWSCons.ConsultarSaldosCtaCte(Globales.SID, prmConsultaBCRP.NumeroCuenta, dtFecLiq, prmConsultaBCRP.IdConsulta);

                            if (arrSaldoCtaCte != null)
                            {
                                ProcesarConsultaSaldoCtaCte(prmConsultaBCRP, arrSaldoCtaCte, out strMsjError);
                                nRetorno = 1;
                            }
                            else
                            {
                                nRetorno = 1;
                            }
                            
                        }
                        catch (Exception ex)
                        {
                            strMsjError = "Error: " + ex.Message + "; " + ex.StackTrace;                            
                        }
                    }
                    else
                    {
                        strMsjError = "El parametro Fecha y Numero de Cuenta son requeridos.";
                    }

                }
                else
                {
                    strMsjError = "El valor del SID es nulo. El servicio LBTR no tiene una sesion activa.";
                }

            }
            else
            {
                strMsjError = "No hay conexion con la base de datos";
            }

            if (!String.IsNullOrEmpty(strMsjError))
            {
                (new BL_General(strHashcode)).InsertarLogError(prmConsultaBCRP.IdConsulta, strMsjError, true);

                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.CONSULTAS_BCRP, strHashcode,
                    "BL_ConsultasBCR.ConsultarSaldosCtaCte",
                    strMsjError, true);
            }

            LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.CONSULTAS_BCRP, strHashcode,
                "BL_ConsultasBCR.ConsultarSaldosCtaCte",
                "Finaliza el proceso de ConsultarSaldosCtaCte.", false);

            return nRetorno;
        }

        private void ProcesarConsultaSaldoCtaCte(BE_ConsultaBCRP prmConsultaBCRP, 
                                                    beanSaldoCtaCte[] arrSaldoCtaCte,
                                                    out String prmMensajeError)
        {
            BE_SaldoCtaCte oSaldoCtaCte;
            prmMensajeError = "";

            if (arrSaldoCtaCte != null)
            {

                for (int i = 0; i < arrSaldoCtaCte.Length; i++)
                {
                    oSaldoCtaCte = new BE_SaldoCtaCte();

                    oSaldoCtaCte.IdConsulta = prmConsultaBCRP.IdConsulta;
                    oSaldoCtaCte.FecConsulta = prmConsultaBCRP.FechaConsulta;

                    oSaldoCtaCte.CodEntidad = arrSaldoCtaCte[i].codEntidad;
                    oSaldoCtaCte.NumCuenta = arrSaldoCtaCte[i].numCuenta;
                    if (arrSaldoCtaCte[i].fechaSaldoSpecified)
                        oSaldoCtaCte.FechaSaldo = arrSaldoCtaCte[i].fechaSaldo.ToString("yyyyMMdd");
                    if (arrSaldoCtaCte[i].saldoActualSpecified)
                        oSaldoCtaCte.SaldoActual = arrSaldoCtaCte[i].saldoActual.ToString();
                    if (arrSaldoCtaCte[i].saldoInicialSpecified)
                        oSaldoCtaCte.SaldoInicial = arrSaldoCtaCte[i].saldoInicial.ToString();
                    if (arrSaldoCtaCte[i].totalAbonosSpecified)
                        oSaldoCtaCte.TotalAbonos = arrSaldoCtaCte[i].totalAbonos.ToString();
                    if (arrSaldoCtaCte[i].totalCargosSpecified)
                        oSaldoCtaCte.TotalCargos = arrSaldoCtaCte[i].totalCargos.ToString();

                    if (!(new DA_ConsultasBCRP(strHashcode)).Insertar_SaldoCtaCte(oSaldoCtaCte))
                    {
                        prmMensajeError += "\r\nError al insertar el registro de saldo cta cte con numero de cuenta [" + oSaldoCtaCte.NumCuenta + "] a la tabla de consulta.";
                    }
                }
            }

        }

        private void oWSCons_OnConsultarSaldosCtaCteError(object sender, ConsultarSaldosCtaCteEventArgs e)
        {
            if (!String.IsNullOrEmpty(e.CodigoError) && e.CodigoError.Equals(Constantes.SERVICIOLBTR_SESION_NO_ACTIVA))
            {
                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.CONSULTAS_BCRP, strHashcode, 
                    "BL_ConsultasBCR.oWSCons_OnConsultarSaldosCtaCteError",
                    "Debido a que el codigo de error retornado es " + Constantes.SERVICIOLBTR_SESION_NO_ACTIVA +
                    " (Sesion no activa), \r\nse procedera a invocar al metodo Logon del servicio de autenticacion del LBTR."
                    , true);
                Globales.SID = null;
            }

            string strMsjError = null;

            if (!String.IsNullOrEmpty(e.CodigoError))
            {
                strMsjError = "Error, el servicio web del BCRP respondio: " + e.CodigoError + " - " + e.MensajeError + ".";
            }
            else
            {
                strMsjError = "Error al utilizar el servicio web del BCRP. " + e.MensajeError;
            }

            (new BL_General(strHashcode)).InsertarLogError(e.IdConsulta, strMsjError, true);

            LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.CONSULTAS_BCRP, strHashcode,
                "BL_ConsultasBCR.oWSCons_OnConsultarSaldosCtaCteError",
                strMsjError, true);
        }
        
        #endregion

    }
}
