﻿using System;
using System.Collections.Generic;
using System.Text;
using TBEWinServ.AccesoDatos;
using TBEWinServ.EntidadesNegocio.Generales;
using TBEWinServ.EntidadesNegocio.CompraVenta;
using TBEWinServ.Utilitarios;
using TBEWinServ.Componentes;
using TBEWinServ.Componentes.LBTRCompraVentaService;

namespace TBEWinServ.LogicaNegocio
{
    public class BL_SalidasCompraVentaBCRP
    {
        private string strHashcode = "";
        private string strCodTramaAuditoria = "";
        //string strTransferidoPor = "";
        DA_CompraVenta_Salidas oDACompraVenta = null;
        DA_General oDAGen = null;
        List<BE_CompraVentaSalidas> lstOperacionesConError = null;

        public BL_SalidasCompraVentaBCRP(string prmHashcode) 
        {
            strHashcode = prmHashcode;
            oDACompraVenta = new DA_CompraVenta_Salidas(strHashcode);
            oDAGen = new DA_General(strHashcode);
        }

        public void EnviarOperacionesCompraVentaAlBCRP()
        {
            LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SALIDAS_COMPRAVENTA, strHashcode,
                   "BL_SalidasCompraVentaBCRP.EnviarOperacionesCompraVentaAlBCRP",
                   "Inicia el proceso para el envio de operaciones de CompraVenta al BCRP", false);
            try
            {
                if (!String.IsNullOrEmpty(Globales.CADENA_CONEXION))
                {
                    if (!String.IsNullOrEmpty(Globales.SID))
                    {
                        string strHoraCorte = oDAGen.Obtener_Param("0206");
                        DateTime? dtFechaHoraCorte = null;
                        lstOperacionesConError = new List<BE_CompraVentaSalidas>();
                        StringBuilder strContenidoCoreo = new StringBuilder();

                        #region Validar Hora de Corte

                        if (!Utilitario.ValidarHora(strHoraCorte, out dtFechaHoraCorte))
                        {
                            LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SALIDAS_COMPRAVENTA, strHashcode,
                                "BL_SalidasCompraVentaBCRP.EnviarOperacionesCompraVentaAlBCRP",
                                "El parametro 0206 Hora de Corte Envio CompraVenta a BCRP no tiene un valor valido para hora (HH:mm)", true);
                            return;
                        }

                        #endregion

                        if (DateTime.Now <= dtFechaHoraCorte)
                        {
                            if (Globales.ListProcesosCorreoEnviado.Contains(Validacion_CompraVenta.HoraCorte))
                            {
                                Globales.ListProcesosCorreoEnviado.Remove(Validacion_CompraVenta.HoraCorte);
                            }

                            #region Validar Lista de Codigo de Errores para Reenvio

                            string strListaCodigoErrores = oDAGen.Obtener_Param("0208");
                    

                            if (Utilitario.ValidarListaCodigoErrores(strListaCodigoErrores, out Globales.ERRORES_PARA_REENVIO))
                            {
                                if (Globales.ListProcesosCorreoEnviado.Contains(Validacion_CompraVenta.CodigoErrores))
                                {
                                    Globales.ListProcesosCorreoEnviado.Remove(Validacion_CompraVenta.CodigoErrores);
                                }
                            }
                            else 
                            {
                                if (!Globales.ListProcesosCorreoEnviado.Contains(Validacion_CompraVenta.CodigoErrores))
                                {
                                    Globales.MAIL_NOTIFICACION_PARA_BD = oDAGen.Obtener_Correo("0003");

                                    LogWriter.Notificar(strHashcode, "El parametro 0208 Lista de Codigo de Errores para Reenvio no tiene un valor valido, no se reenviaran las operaciones", NivelMensajeLog.NOTIFICACION);

                                    Globales.MAIL_NOTIFICACION_PARA_BD = "";

                                    LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SALIDAS_COMPRAVENTA, strHashcode,
                                        "BL_SalidasCompraVentaBCRP.EnviarOperacionesCompraVentaAlBCRP",
                                        "El parametro 0208 Lista de Codigo de Errores para Reenvio no tiene un valor valido", true);

                                    Globales.ListProcesosCorreoEnviado.Add(Validacion_CompraVenta.CodigoErrores);

                                    return;
                                }
                            }

                            #endregion 

                            List<BE_CompraVentaSalidas> lstOperacionesCompraVenta = oDACompraVenta.Obtener_Operaciones_Enviar_BCRP(dtFechaHoraCorte, Estados.REGISTRADO, Globales.ERRORES_PARA_REENVIO);

                            if (lstOperacionesCompraVenta != null)
                            {
                                foreach (BE_CompraVentaSalidas oCompraVentaSalidas in lstOperacionesCompraVenta)
                                {
                                    EnviarSalidasCompraVenta(oCompraVentaSalidas);
                                }

                                if (lstOperacionesConError != null) 
                                {
                                    if (lstOperacionesConError.Count > 0) 
                                    {
                                        Int32 contador =1;
                                        //Si existen Operaciones con errores para reenvio automatico se enviara 1 correo con la lista de todas las operaciones:
                                        strContenidoCoreo.AppendLine("Operaciones de CompraVenta con Errores");
                                        strContenidoCoreo.AppendLine("Se realizara el reenvió para las operaciones que recibieron error del sistema LBTR del BCRP debido a que los errores retornados se encuentran contenidos en la lista de codigo de errores para reenvio automático [parámetro 208]");
                                        foreach (BE_CompraVentaSalidas oOperacionConError in lstOperacionesConError)
                                        {
                                            strContenidoCoreo.AppendLine("Nro: " + contador.ToString().PadRight(4,' ')  + " NUM_REF_ORIGEN: " + oOperacionConError.NUM_REF_ORIGEN + " ERROR RETORNADO: " + oOperacionConError.CODIGO_ERROR_LBTR + " MENSAJE ERROR RETORNADO: " + oOperacionConError.MENSAJE_LBTR);
                                            contador++;
                                        }

                                        Globales.MAIL_NOTIFICACION_PARA_BD = oDAGen.Obtener_Correo("0003");

                                        LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SALIDAS_COMPRAVENTA, strHashcode,
                                        "BL_SalidasCompraVentaBCRP.EnviarOperacionesCompraVentaAlBCRP",
                                        "Se encontraron operaciones con error que se reenviaran automaticamente debido a que los errores se encuentran contenidos en la lista de código de errores para reenvió automatico [parametro 208]", false);

                                        LogWriter.Notificar(strHashcode, strContenidoCoreo.ToString(), NivelMensajeLog.NOTIFICACION);

                                        Globales.MAIL_NOTIFICACION_PARA_BD = "";
                                    }
                                }
                            }
                        }
                        else
                        {
                            if (!Globales.ListProcesosCorreoEnviado.Contains(Validacion_CompraVenta.HoraCorte))
                            {
                                Globales.MAIL_NOTIFICACION_PARA_BD = oDAGen.Obtener_Correo("0003");

                                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SALIDAS_COMPRAVENTA, strHashcode,
                                "BL_SalidasCompraVentaBCRP.EnviarOperacionesCompraVentaAlBCRP",
                                "Se llego a la hora de corte, no se enviaran mas operaciones al bcrp durante el día", false);

                                LogWriter.Notificar(strHashcode, "Se llego a la hora de corte, no se enviaran mas operaciones al bcrp durante el día", NivelMensajeLog.NOTIFICACION);

                                Globales.MAIL_NOTIFICACION_PARA_BD = "";

                                Globales.ListProcesosCorreoEnviado.Add(Validacion_CompraVenta.HoraCorte);
                            }
                        }

                    }
                }
            }
            catch (Exception ex)
            {
                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SALIDAS_COMPRAVENTA, strHashcode,
                    "BL_SalidasCompraVentaBCRP.EnviarOperacionesCompraVentaAlBCRP", "Error en el proceso de envio de operaciones Compra Venta al BCRP: " + ex.Message, true);
            }

            LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SALIDAS_COMPRAVENTA, strHashcode,
                   "BL_SalidasCompraVentaBCRP.EnviarOperacionesCompraVentaAlBCRP",
                   "Finaliza el proceso para el envio de operaciones de CompraVenta al BCRP", false);
        }

        private int EnviarSalidasCompraVenta(BE_CompraVentaSalidas prmOperacionCompraVenta)
        {
            int nRetorno = 0;
            string strMsjError = null;

            LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SALIDAS_COMPRAVENTA, strHashcode,
                "BL_SalidasCompraVentaBCRP.EnviarSalidasCompraVenta",
                "Inicia el proceso de envio para la operacion para ID: [" + prmOperacionCompraVenta.ID_LBTR_SALIDAS +
                "], Numero Referencia Origen : [" + prmOperacionCompraVenta.NUM_REF_ORIGEN + "]", false);

            #region Procesamiento de salidas

            string strFirmaMsj = null;
            WS_LBTRCompraVentaService oWSCompraVenta = new WS_LBTRCompraVentaService(strHashcode);

            try
            {
                if (!String.IsNullOrEmpty(Globales.CADENA_CONEXION))
                {
                    if (!String.IsNullOrEmpty(Globales.SID))
                    {
                        //strTransferidoPor = prmOperacionCompraVenta.TransferidoPor;
                        prmOperacionCompraVenta = oDACompraVenta.Obtener_Datos_Compra_Venta(prmOperacionCompraVenta);
                        oWSCompraVenta.SalidasCompraVentaRespuestaRecibida += new EventHandler<RespuestaCompraVentaBCRPEventArgs>(oWSTransf_SalidasCompraVentaRespuestaRecibida);
                        oWSCompraVenta.OnSalidasCompraVentaError += new EventHandler<CompraVentaEventArgs>(oWSTransf_OnSalidasCompraVentaError);

                        if (oDACompraVenta.Excepcion == null)
                        {
                            if (prmOperacionCompraVenta != null)
                            {
                                if (prmOperacionCompraVenta.ESTADO_ENVIO == Estados.REGISTRADO || prmOperacionCompraVenta.ESTADO_ENVIO == Estados.ERROR_TRX)
                                {
                                    if (!String.IsNullOrEmpty(prmOperacionCompraVenta.COD_CONCEPTO))
                                    {
                                        List<BE_Concepto> lstConceptos = null;
                                        BE_Concepto oParamConcepto = new BE_Concepto();
                                        oParamConcepto.CodConcepto = prmOperacionCompraVenta.COD_CONCEPTO;
                                        lstConceptos = oDAGen.Obtener_Conceptos(oParamConcepto);

                                        if (lstConceptos != null && lstConceptos.Count > 0)
                                        {
                                            //Se verifica si el concepto usa datos cliente
                                            if (!lstConceptos[0].UsaDatosCliente)
                                            {
                                                //prmOperacionCompraVenta.DatosCliente = null;
                                            }

                                            datosCompraVentaME oDatosCompraVentaME = new datosCompraVentaME();
                                            EstablecerDatosSalidasCompraVenta(prmOperacionCompraVenta, oDatosCompraVentaME);

                                            if (oDatosCompraVentaME != null)
                                            {
                                                strFirmaMsj = (new BL_SeguridadMsj(strHashcode)).GenerarFirma(prmOperacionCompraVenta, oDatosCompraVentaME, out strMsjError);

                                                if (!String.IsNullOrEmpty(strFirmaMsj)) /*Solo por Pruebas cambiar a "if (!String.IsNullOrEmpty(strFirmaMsj))" */
                                                {
                                                    prmOperacionCompraVenta.ESTADO_ENVIO = Estados.CARGADO_NO_ENVIADO;
                                                    prmOperacionCompraVenta.FIRMA = strFirmaMsj;

                                                    if ((new BL_General(strHashcode)).Actualizar_CompraVenta(prmOperacionCompraVenta))
                                                    {
                                                        strCodTramaAuditoria = this.RegistrarTrama(prmOperacionCompraVenta);

                                                        //if (String.IsNullOrEmpty(strCodTramaAuditoria)) strCodTramaAuditoria = "";
                                                        //oDatosCompraVentaME.numRefLBTRCV += strCodTramaAuditoria.PadRight(20, ' ');

                                                        CompraVentaID oCompraVentaId = new CompraVentaID();
                                                        oCompraVentaId.ID_LBTR_SALIDAS = prmOperacionCompraVenta.ID_LBTR_SALIDAS;
                                                        oCompraVentaId.NUM_REF_ORIGEN = prmOperacionCompraVenta.NUM_REF_ORIGEN;
                                                        oCompraVentaId.ESTADO_ENVIO = prmOperacionCompraVenta.ESTADO_ENVIO;

                                                        if (prmOperacionCompraVenta.COD_CONCEPTO == Conceptos_CV.Compras)
                                                        {
                                                            nRetorno = oWSCompraVenta.InstruirCompraVenta(Globales.SID, oDatosCompraVentaME, strFirmaMsj, oCompraVentaId);
                                                        }

                                                        if (prmOperacionCompraVenta.COD_CONCEPTO == Conceptos_CV.Ventas)
                                                        {
                                                            nRetorno = oWSCompraVenta.ConfirmarConpraVenta(Globales.SID, oDatosCompraVentaME, strFirmaMsj, oCompraVentaId);
                                                        }
                                                    }
                                                    else
                                                    {
                                                        strMsjError = "No se pudo actualizar estado [" + prmOperacionCompraVenta.ESTADO_ENVIO + "] de la Operacion. No se realizara la instriuccion de la compra.";
                                                    }
                                                }
                                                else
                                                {
                                                    //Si hubo error:
                                                    strMsjError = "Error al generar la firma de la transferencia:\r\n[" + strMsjError + "]";
                                                }
                                            }
                                            else
                                            {
                                                strMsjError = "Error, no se pudo establecer los datos de la operacion a enviar. oDatosTransf es NULL.";
                                            }
                                        }
                                        else
                                        {
                                            strMsjError = "El concepto " + prmOperacionCompraVenta.COD_CONCEPTO + " no esta registrado en la base de datos.";
                                        }
                                    }
                                    else
                                    {
                                        strMsjError = "No tiene establecido el dato codigo concepto. No se realizara la transferencia.";
                                    }
                                }
                                else
                                {
                                    strMsjError = "La operacion no se encuentra en el estado Por Enviar";
                                }
                            }
                            else
                            {
                                strMsjError = "No se encontro el registro en la base de datos (T_DESA).";
                            }
                        }
                        else
                        {
                            strMsjError = "Error al buscar el registro codigo [" + prmOperacionCompraVenta.ID_LBTR_SALIDAS + "] en la base de datos (T_LBTR_SALIDAS). Realizar seguimiento al log del servicio.";
                        }
                    }
                    else
                    {
                        strMsjError = "El valor del SID es nulo. No tiene una sesion activa.";
                    }
                }
                else
                {
                    strMsjError = "La cadena de conexion no esta establecida";
                }
            }
            catch (Exception ex)
            {
                strMsjError = "Error durante el procesamiento: " + ex.Message + ". " + ex.StackTrace;
            }

            #endregion
            
            if (!String.IsNullOrEmpty(strMsjError))
            {
                prmOperacionCompraVenta.ESTADO_ENVIO = Estados.ERROR_TRX;
                (new BL_General(strHashcode)).Actualizar_CompraVenta(prmOperacionCompraVenta);
                (new BL_General(strHashcode)).InsertarLogError(prmOperacionCompraVenta.ID_LBTR_SALIDAS + prmOperacionCompraVenta.NUM_REF_ORIGEN, strMsjError, false); //cambiar NumRefOrigen por SEC
                 LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SALIDAS_COMPRAVENTA, strHashcode,
                 "BL_SalidasCompraVentaBCRP.EnviarSalidasCompraVenta", strMsjError, true);
            }

            LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SALIDAS_COMPRAVENTA, strHashcode,
                "BL_SalidasCompraVentaBCRP.EnviarSalidasCompraVenta",
                "Finaliza la instruccion de la compra para OPERACION: [" + prmOperacionCompraVenta.ID_LBTR_SALIDAS +
                "], NUM_REF_ORIGEN: [" + prmOperacionCompraVenta.NUM_REF_ORIGEN + "]", //cambiar NumRefOrigen por SEC
                false);

            return nRetorno;
        }

        private void oWSTransf_SalidasCompraVentaRespuestaRecibida(object sender, RespuestaCompraVentaBCRPEventArgs e)
        {
            //Actualizar Estado de la Operacion
            BE_CompraVentaSalidas oBE_CompraVentaSalidas = new BE_CompraVentaSalidas();
            oBE_CompraVentaSalidas.ID_LBTR_SALIDAS = e.CompraVentaId.ID_LBTR_SALIDAS;            
            oBE_CompraVentaSalidas.NUM_REF_ORIGEN = e.CompraVentaId.NUM_REF_ORIGEN; //revizar.!
            oBE_CompraVentaSalidas.NUM_REF_LBTR = e.strNumRefLBTR; //revizar.!
            oBE_CompraVentaSalidas.ESTADO_LBTR = e.strEstado;
            oBE_CompraVentaSalidas.ESTADO_ENVIO= "2";
            (new BL_General(strHashcode)).Actualizar_CompraVenta(oBE_CompraVentaSalidas);

            LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.SALIDAS_COMPRAVENTA, strHashcode,
                "BL_SalidasCompraVentaBCRP.oWSTransf_SalidasCompraVentaRespuestaRecibida",
                "La funcion InstruirTransferencia/confirmarCompraVenta del web service retorno: " +
                "ID_LBTR_SALIDAS: " + oBE_CompraVentaSalidas.ID_LBTR_SALIDAS + "; NumRefOrigen: " + oBE_CompraVentaSalidas.NUM_REF_ORIGEN + "; NUM_REF_LBTR: " + e.strNumRefLBTR + "; Estado LBTR: " + e.strEstado, false);
        }

        private void oWSTransf_OnSalidasCompraVentaError(object sender, CompraVentaEventArgs e)
        {
            if (!String.IsNullOrEmpty(e.CodigoError) && e.CodigoError.Equals(Constantes.SERVICIOLBTR_SESION_NO_ACTIVA))
            {
                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SALIDAS_COMPRAVENTA, strHashcode,
                    "BL_SalidasCompraVentaBCRP.oWSTransf_OnSalidasCompraVentaError",
                    "Debido a que el codigo de error retornado es " + Constantes.SERVICIOLBTR_SESION_NO_ACTIVA +
                    " (Sesion no activa), \r\nse procedera a invocar al metodo Logon del servicio de autenticacion del LBTR."
                    , true);
                Globales.SID = null;
            }

            BE_CompraVentaSalidas oBE_CompraVentaSalidas = new BE_CompraVentaSalidas();
            oBE_CompraVentaSalidas.ID_LBTR_SALIDAS = e.CompraVentaId.ID_LBTR_SALIDAS;
            oBE_CompraVentaSalidas.NUM_REF_ORIGEN = e.CompraVentaId.NUM_REF_ORIGEN;
            oBE_CompraVentaSalidas.ESTADO_ENVIO = Estados.ERROR_TRX;
            oBE_CompraVentaSalidas.ESTADO_LBTR = Estados.ERROR_TRX;
            oBE_CompraVentaSalidas.MENSAJE_LBTR = e.MensajeError;
            oBE_CompraVentaSalidas.CODIGO_ERROR_LBTR = e.CodigoError;
            (new BL_General(strHashcode)).Actualizar_CompraVenta(oBE_CompraVentaSalidas);

            string strMsjError = null;

            if (!String.IsNullOrEmpty(e.CodigoError))
            {
                strMsjError = "Error, el servicio web del BCRP respondio: " + e.CodigoError + " - " + e.MensajeError + ".";

                //Si el codigo se encuentra en el parametro de lista de errores para reenvio. Agregamos a la lista para enviar por correo.
                if (Globales.ERRORES_PARA_REENVIO.Contains(e.CodigoError))
                {
                    lstOperacionesConError.Add(oBE_CompraVentaSalidas); 
                }
            }
            else
            {
                strMsjError = "Error al utilizar el servicio web del BCRP. " + e.MensajeError;
            }

            (new BL_General(strHashcode)).InsertarLogError(e.CompraVentaId.NUM_REF_ORIGEN, strMsjError, false);

            LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SALIDAS_COMPRAVENTA, strHashcode,
                "BL_SalidasCompraVentaBCRP.oWSTransf_OnSalidasCompraVentaError",
                strMsjError, false);
        }

        private void EstablecerDatosSalidasCompraVenta(BE_CompraVentaSalidas prmBE_CompraVentaSalidas, datosCompraVentaME prmDatosCompraVentaME)
        {
            BL_General oBLGen = new BL_General(strHashcode);

            try
            {
                String strCaracteresPermitidos = oBLGen.ObtenerValorParametro(Constantes.PARAM_CODIGO_CARACT_VALID);

                prmBE_CompraVentaSalidas.INSTRUCCIONES_PAGO = oBLGen.ValidarContenidoString(prmBE_CompraVentaSalidas.INSTRUCCIONES_PAGO, strCaracteresPermitidos);
                prmBE_CompraVentaSalidas.NUM_REF_ORIGEN = oBLGen.ValidarContenidoString(prmBE_CompraVentaSalidas.NUM_REF_ORIGEN, strCaracteresPermitidos);

                //SE ESTABLECE EL BEAN DATOSTRANSFERENCIA
                prmDatosCompraVentaME.codConcepto = String.IsNullOrEmpty(prmBE_CompraVentaSalidas.COD_CONCEPTO) ? "" : prmBE_CompraVentaSalidas.COD_CONCEPTO;
                prmDatosCompraVentaME.cuentaDestino = String.IsNullOrEmpty(prmBE_CompraVentaSalidas.CTA_DESTINO) ? "" : prmBE_CompraVentaSalidas.CTA_DESTINO;
                prmDatosCompraVentaME.cuentaOrigen = String.IsNullOrEmpty(prmBE_CompraVentaSalidas.CTA_ORIGEN) ? "" : prmBE_CompraVentaSalidas.CTA_ORIGEN;

                if (prmBE_CompraVentaSalidas.FECHA_LIQUIDACION != null)
                {
                      prmDatosCompraVentaME.fechaLiquidacionSpecified = true;
                      prmBE_CompraVentaSalidas.FECHA_LIQUIDACION = Utilitario.FechaSinHora(prmBE_CompraVentaSalidas.FECHA_LIQUIDACION.Value);
                      prmDatosCompraVentaME.fechaLiquidacion = prmBE_CompraVentaSalidas.FECHA_LIQUIDACION.Value;
                }

                prmDatosCompraVentaME.instruccionesPago = String.IsNullOrEmpty(prmBE_CompraVentaSalidas.INSTRUCCIONES_PAGO) ? "" : prmBE_CompraVentaSalidas.INSTRUCCIONES_PAGO;

                if (prmBE_CompraVentaSalidas.MONTO_ME != null)
                {
                    prmDatosCompraVentaME.montoMESpecified = true;
                    prmDatosCompraVentaME.montoME = prmBE_CompraVentaSalidas.MONTO_ME.Value;
                }

                if (prmBE_CompraVentaSalidas.MONTO_MN != null)
                {
                    prmDatosCompraVentaME.montoMNSpecified = true;
                    prmDatosCompraVentaME.montoMN = prmBE_CompraVentaSalidas.MONTO_MN.Value;
                }

                prmDatosCompraVentaME.numRefLBTRCV = String.IsNullOrEmpty(prmBE_CompraVentaSalidas.NUM_REF_LBTR_CV) ? "" : prmBE_CompraVentaSalidas.NUM_REF_LBTR_CV;
                prmDatosCompraVentaME.numRefOrigen = String.IsNullOrEmpty(prmBE_CompraVentaSalidas.NUM_REF_ORIGEN) ? "" : prmBE_CompraVentaSalidas.NUM_REF_ORIGEN;

                if (prmBE_CompraVentaSalidas.TIPO_CAMBIO != null)
                {
                    prmDatosCompraVentaME.tipoCambioSpecified = true;
                    prmDatosCompraVentaME.tipoCambio = prmBE_CompraVentaSalidas.TIPO_CAMBIO.Value;
                }
            }
            catch (Exception ex)
            {
                prmDatosCompraVentaME = null;
                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SALIDAS_COMPRAVENTA, strHashcode,
                    "BL_SalidasCompraVentaBCRP.EstablecerDatosSalidasCompraVenta",
                    "Error al establecer los datos de la transferencia: " + ex.Message + ". " + ex.StackTrace, true);
            }
        }

        private string RegistrarTrama(BE_CompraVentaSalidas prmCompraVentaSalidas)
        {
            StringBuilder sbTrama = new StringBuilder();
            string strTrama = "";
            string strTramaEnClaro = "";

            try
            {
                sbTrama.Append("<?xml version=\"1.0\" encoding=\"ISO-8859-1\" ?>");
                sbTrama.Append("<datosCompraVentaME>");
                sbTrama.Append("<codConcepto>"); sbTrama.Append(prmCompraVentaSalidas.COD_CONCEPTO); sbTrama.Append("</codConcepto>");
                sbTrama.Append("<cuentaDestino>"); sbTrama.Append(prmCompraVentaSalidas.CTA_DESTINO); sbTrama.Append("</cuentaDestino>");
                sbTrama.Append("<cuentaOrigen>"); sbTrama.Append(prmCompraVentaSalidas.CTA_ORIGEN); sbTrama.Append("</cuentaOrigen>");

                //sbTrama.Append("<datosCliente>{[REEMPLAZO1]}</datosCliente>");

                sbTrama.Append("<fechaLiquidacion>");
                if (prmCompraVentaSalidas.FECHA_LIQUIDACION.HasValue) sbTrama.Append(prmCompraVentaSalidas.FECHA_LIQUIDACION.Value.ToString("yyyyMMddHHmmss"));
                sbTrama.Append("</fechaLiquidacion>");

                //sbTrama.Append("<fechaRefLBTREnlace>");
                //if (prmTransferencia.FecRefLBTREnlace.HasValue) sbTrama.Append(prmTransferencia.FecRefLBTREnlace.Value.ToString("yyyyMMddHHmmss"));
                //sbTrama.Append("</fechaRefLBTREnlace>");

                sbTrama.Append("<instruccionesPago>"); sbTrama.Append(prmCompraVentaSalidas.INSTRUCCIONES_PAGO); sbTrama.Append("</instruccionesPago>");
                //sbTrama.Append("<modalidad>"); sbTrama.Append(prmTransferencia.Modalidad); sbTrama.Append("</modalidad>");

                sbTrama.Append("<montoME>");
                if (prmCompraVentaSalidas.MONTO_ME.HasValue) sbTrama.Append(prmCompraVentaSalidas.MONTO_ME.Value.ToString("#########.###"));
                sbTrama.Append("</montoME>");

                sbTrama.Append("<montoMN>");
                if (prmCompraVentaSalidas.MONTO_MN.HasValue) sbTrama.Append(prmCompraVentaSalidas.MONTO_MN.Value.ToString("#########.###"));
                sbTrama.Append("</montoMN>");

                sbTrama.Append("<numRefLBTRCV>"); sbTrama.Append(prmCompraVentaSalidas.NUM_REF_LBTR_CV); sbTrama.Append("</numRefLBTRCV>");
                sbTrama.Append("<numRefOrigen>"); sbTrama.Append(prmCompraVentaSalidas.NUM_REF_ORIGEN); sbTrama.Append("</numRefOrigen>");

                //sbTrama.Append("<prioridad>");
                //if (prmTransferencia.Prioridad.HasValue) sbTrama.Append(prmTransferencia.Prioridad.Value.ToString());
                //sbTrama.Append("</prioridad>");

                sbTrama.Append("<tipoCambio>");
                if (prmCompraVentaSalidas.TIPO_CAMBIO.HasValue) sbTrama.Append(prmCompraVentaSalidas.TIPO_CAMBIO.Value.ToString("#########.###"));
                sbTrama.Append("</tipoCambio>");

                sbTrama.Append("</datosCompraVentaME>");

                strTramaEnClaro = sbTrama.ToString();
                strTrama = sbTrama.ToString();
                ///strTrama = strTrama.Replace("{[REEMPLAZO1]}", prmDatosClienteCifrado);

                //if (prmTransferencia.DatosCliente != null)
                //{
                //    strTramaEnClaro = strTramaEnClaro.Replace("{[REEMPLAZO1]}", BE_DatosCliente.ArmarDatosCliente(prmTransferencia.DatosCliente.ToString(), "", ""));
                //}
                //else
                //{
                //    strTramaEnClaro = strTramaEnClaro.Replace("{[REEMPLAZO1]}", "");
                //}

                BL_General oBLGen = new BL_General(strHashcode);
                BL_Auditoria oBLSeg = new BL_Auditoria(strHashcode);
                string strCodigoCiti = oBLGen.ObtenerValorConfiguracion(Constantes.PARAM_CODIGO_CITIBANK);
                List<BE_Banco> lstBancos = null;
                BE_Banco oBancoDestino = null;
                BE_Banco oBancoCiti = null;

                lstBancos = oBLGen.ObtenerBancos(new BE_Banco());

                if (lstBancos != null && lstBancos.Count > 0)
                {
                    oBancoDestino = lstBancos.Find(delegate(BE_Banco oBancoParamDest) { return oBancoParamDest.CodBanco == prmCompraVentaSalidas.BCO_DESTINO; });
                    oBancoCiti = lstBancos.Find(delegate(BE_Banco oBancoParamCiti) { return oBancoParamCiti.CodBanco == strCodigoCiti; });

                    return oBLSeg.RegistrarAuditoria(TipoOperacion.CompraVenta, strTrama, strTramaEnClaro,
                                                strCodigoCiti, prmCompraVentaSalidas.BCO_DESTINO,
                                                oBancoCiti.IndiceKPri, oBancoDestino.IndiceKPub, null, prmCompraVentaSalidas.FIRMA);
                }
                else
                {
                    LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SALIDAS_COMPRAVENTA, strHashcode,
                        "BL_SalidasCompraVentaBCRP.RegistrarTrama",
                        "No existen bancos registrados en la base de datos.", true);
                }
            }
            catch (Exception ex)
            {
                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SALIDAS_COMPRAVENTA, strHashcode,
                    "BL_SalidasCompraVentaBCRP.RegistrarTrama",
                    "Error, " + ex.Message + ". " + ex.StackTrace, true);
            }

            return null;
        }




















    }
}
