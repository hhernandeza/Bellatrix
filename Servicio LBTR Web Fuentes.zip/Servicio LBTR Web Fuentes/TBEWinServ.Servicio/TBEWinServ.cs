﻿using System;
using System.Configuration;
using System.Collections.Generic;
using System.ComponentModel;
using System.ServiceProcess;
using System.Text;
using System.Threading;
using TBEWinServ.Utilitarios;
using TBEWinServ.LogicaNegocio;
using TBEWinServ.EntidadesNegocio.Generales;
using TBEWinServ.FachadaRemotingServidor;
using TBEWinServ.Componentes;//Usado para password safe
using TBEWinServ.ObjetosGlobales;
//hh72295:20161104:I: ADECUACION PARA RECUPERAR PASSWORD DESDE DB STBSEGDB Y DESENCRIPTAR CON HSM 
using TBEWinServ.AccesoDatos;
//hh72295:20161104:F: ADECUACION PARA RECUPERAR PASSWORD DESDE DB STBSEGDB Y DESENCRIPTAR CON HSM 

namespace TBEWinServ.Servicio
{
    public partial class TBEWinServ : ServiceBase
    {
        #region Variables generales
                
        ServicioRemoting oRemServer = new ServicioRemoting();

        private string strRutaAppContingencia = ConfigurationManager.AppSettings["RUTA_APP_CONTINGENCIA"];
        private string strRutaArchivoServicios = ConfigurationManager.AppSettings["RUTA_ARCHIVO_SERVICIOS"];
        private List<BE_Servicio> lstServiciosHabilitados = new List<BE_Servicio>();

        private Thread thr_EnvioOpeBCRP;
        private Thread thr_INICIOFINDIA;
        private Thread thr_CONF_ABONO;
        private Thread thr_CONF_BCOSMOS;
        private Thread thr_OPEREC;
        private Thread thr_OPERECConting;
        private Thread thr_VerifProc;
        private Thread thr_ENVIO_BCOSMOS;
        private Thread thr_APERTURACIERREBATCH_BCOSMOS;
        private Thread thr_EnvioCompraVenta; //Agregado jr72296
        //hh72295:20170117:I: ADECUACION CITISCREENING EN OPERACIONES DE ENTRADA
        private Thread thr_EnvioOperacionCitiscreening; 
        //hh72295:20170117:F: ADECUACION CITISCREENING EN OPERACIONES DE ENTRADA

        private bool blnFinalizarEnvioOpeBCRP = false;
        private int nIntervaloEnvioOpeBCRP = 60000;//cada 1 minuto

        private bool blnFinalizarConfBCosmos = false;
        private int nIntervaloConfBCosmos = 300000;//cada 5 minutos
                
        private bool blnFinalizarConfAbono = false;
        private int nIntervaloConfAbono = 20000;//cada 20 segundos

        private bool blnFinalizarInicioFinDia = false;
        private int nIntervaloInicioFinDia = 300000;//cada 5 minutos

        private bool blnFinalizarOPEREC = false;
        private int nIntervaloOPEREC = 60000;//cada 1 minuto

        private bool blnFinalizarOPERECConting = false;
        private int nIntervaloOPERECConting = 60000;//cada 1 minuto

        private bool blnFinalizarVerifProc = false;
        private int nIntervaloVerifProc = 1000;//cada segundo

        private bool blnFinalizarEnvioBCosmos = false;
        private int nIntervaloEnvioBCosmos = 60000;//cada 1 minuto
        
        private bool blnFinalizarAperturaCierreBatchBCosmos = false;
        private int nIntervaloAperturaCierreBatchBCosmos = 300000;//cada 1 minuto

        private bool blnFinalizarEnvioCompraVenta= false;
        private int nIntervaloEnvioCompraVenta= 60000;//cada 1 minuto

        //hh72295:20170117:I: ADECUACION CITISCREENING EN OPERACIONES DE ENTRADA
        private bool blnFinalizarEnvioOperacionCitiscreening = false;
        private int nIntervaloEnvioOperacionCitiscreening = 60000;//cada 1 minuto
        //hh72295:20170117:F: ADECUACION CITISCREENING EN OPERACIONES DE ENTRADA

        private string strHoraInicio = null;
        private string strHoraFinalizacion1 = null;
        private string strHoraFinalizacion2 = null;

        private string strHoraReposoIni = null;
        private string strHoraReposoFin = null;

        private string strServidorPLB = null;
        private string strBDPLB = null;

        private string strServidorSTB = null;
        private string strBDSTB = null;
        private string strPuertoSTB = null;

        private string strUsuarioBD_SYBASE = null;
        private string strUsuarioBD_SYBASE_PAR = null;
        private string strUsuarioBD_MSSQL = null;
        private string strUsuarioBD_MSSQL_PAR = null;

        private string strPSafe_DefinitionName = null;
        private string strPSafe_Host_BD = null;
        private string strPSafe_Host_LBTR = null;
        private string strPSafe_CompCertificate = null;
        private string strPSafe_CCSerialNumber = null;
        private string strPSafe_CCIssuer = null;
        private string strPSafe_CCSubject = null;
        private string strPSafe_Account_BD = null;
        private string strPSafe_Account_LBTR = null;
        private bool blnUsarCompCert = false;

        private string strPAR_Url_Sybase = null;
        private string strPAR_ThumbPrint_Sybase = null;
        private string strPAR_SystemName_Sybase = null;
        private string strPAR_AccountName_Sybase = null;

        private string strPAR_Url_MSSQL = null;
        private string strPAR_ThumbPrint_MSSQL = null;
        private string strPAR_SystemName_MSSQL = null;
        private string strPAR_AccountName_MSSQL = null;

        private string strPAR_Url_LBTR = null;
        private string strPAR_ThumbPrint_LBTR = null;
        private string strPAR_SystemName_LBTR = null;
        private string strPAR_AccountName_LBTR = null;  

        private bool blnActualizarPwdLogon = false;
        private string strDiaActual = "";
        private string strDiaAnterior = "";

        private string strHoraApertura = null;
        private string strHoraCierre1 = null;
        private string strHoraCierre2 = null;
        private string strTipoRepositorioClaves = null;
        TBEMQWinServ.FachadaRemotingCliente.Servicio oTramaMQ = null;
        #endregion

        #region Constructor

        public TBEWinServ()
        {            
            InitializeComponent();

            strHoraReposoIni = ConfigurationManager.AppSettings["HORA_REPOSO_INI"];
            strHoraReposoFin = ConfigurationManager.AppSettings["HORA_REPOSO_FIN"];

            strServidorPLB = ConfigurationManager.AppSettings["SERVIDOR_PLB"];
            strBDPLB = ConfigurationManager.AppSettings["BASE_DATOS_PLB"];

            strServidorSTB = ConfigurationManager.AppSettings["SERVIDOR"];
            strBDSTB = ConfigurationManager.AppSettings["BASE_DATOS"];
            strPuertoSTB = ConfigurationManager.AppSettings["PUERTO"];

            Globales.RUTA_XML_ERRORES_APISEG = ConfigurationManager.AppSettings["RUTA_XML_ERRORES_APISEG"];

            string strIntervaloEnvioOpeBCRP = ConfigurationManager.AppSettings.Get("INTERVALO_EVENTO_TIMER_ENVIO_OPE_BCRP");
            string strIntervaloConfBCosmos = ConfigurationManager.AppSettings.Get("INTERVALO_EVENTO_TIMER_CONFBCOSMOS");
            string strIntervaloConfAbono = ConfigurationManager.AppSettings.Get("INTERVALO_EVENTO_TIMER_CONFABONO");
            string strIntervaloInicioFinDia = ConfigurationManager.AppSettings.Get("INTERVALO_EVENTO_TIMER_INICIOFINDIA");
            string strIntervaloOPEREC = ConfigurationManager.AppSettings.Get("INTERVALO_EVENTO_TIMER_OPEREC");
            string strIntervaloOPERECConting = ConfigurationManager.AppSettings.Get("INTERVALO_EVENTO_TIMER_OPEREC_CONTINGENCIA");
            string strIntervaloVerifProc = ConfigurationManager.AppSettings.Get("INTERVALO_EVENTO_TIMER_VERIFICACION");
            string strIntervaloEnvioBCosmos = ConfigurationManager.AppSettings.Get("INTERVALO_EVENTO_TIMER_ENVIO_BCOSMOS");
            string strIntervaloAperturaCierreBatchBCosmos = ConfigurationManager.AppSettings.Get("INTERVALO_EVENTO_TIMER_APERTURACIERREBATCH_BCOSMOS");
            string strIntervaloEnvioCompraVenta = ConfigurationManager.AppSettings.Get("INTERVALO_EVENTO_TIMER_ENVIO_COMPRA_VENTA");//Agregado jr72296
            string strSYNCBCosmosTimeout = ConfigurationManager.AppSettings.Get("SYNCBCOSMOS_TIMEOUT");
            string strSYNCBCosmosReintentos = ConfigurationManager.AppSettings.Get("SYNCBCOSMOS_REINTENTOS_X_INTERVALO");
            string strSistemaOrigen = ConfigurationManager.AppSettings.Get("SISTEMA_ORIGEN");
            strTipoRepositorioClaves = ConfigurationManager.AppSettings["TIPO_REPOSITORIO_CLAVE"];

            if (strTipoRepositorioClaves == TipoRepositorioClaves.PSAFE)
            {   //P-SAFE
                strUsuarioBD_SYBASE = ConfigurationManager.AppSettings["USUARIOBD"];
                strUsuarioBD_MSSQL = ConfigurationManager.AppSettings["USUARIOBD_MSSQL"];
            }
            else
            {   //PAR
                strUsuarioBD_SYBASE_PAR = ConfigurationManager.AppSettings["USUARIOBD_PAR"]; //USUARIODB = USUARIODB_CLIENTES
                strUsuarioBD_MSSQL_PAR = ConfigurationManager.AppSettings["USUARIOBD_MSSQL_PAR"];
            }

            strPSafe_DefinitionName = ConfigurationManager.AppSettings["PSAFE_DEFINITION_NAME"];
            strPSafe_Host_BD = ConfigurationManager.AppSettings["PSAFE_HOST_BD"];
            strPSafe_Host_LBTR = ConfigurationManager.AppSettings["PSAFE_HOST_LBTR"];
            strPSafe_CompCertificate = ConfigurationManager.AppSettings["PSAFE_COMPUTER_CERTIFICATE"];
            strPSafe_CCSerialNumber = ConfigurationManager.AppSettings["PSAFE_COMPUTER_CERTIFICATE_SERIALNUMBER"];
            strPSafe_CCIssuer = ConfigurationManager.AppSettings["PSAFE_COMPUTER_CERTIFICATE_ISSUER"];
            strPSafe_CCSubject = ConfigurationManager.AppSettings["PSAFE_COMPUTER_CERTIFICATE_SUBJECT"];
            strPSafe_Account_BD = ConfigurationManager.AppSettings["PSAFE_ACCOUNT_BD"];
            strPSafe_Account_LBTR = ConfigurationManager.AppSettings["PSAFE_ACCOUNT_LBTR"];
            if (strPSafe_CompCertificate.ToLower().Equals("true")) blnUsarCompCert = true;

            strPAR_Url_Sybase = ConfigurationManager.AppSettings["PAR_Url_Sybase"];
            strPAR_ThumbPrint_Sybase = ConfigurationManager.AppSettings["PAR_ThumbPrint_Sybase"];
            strPAR_SystemName_Sybase = ConfigurationManager.AppSettings["PAR_SystemName_Sybase"];
            strPAR_AccountName_Sybase = ConfigurationManager.AppSettings["PAR_AccountName_Sybase"];

            strPAR_Url_MSSQL = ConfigurationManager.AppSettings["PAR_Url_MSSQL"];
            strPAR_ThumbPrint_MSSQL = ConfigurationManager.AppSettings["PAR_ThumbPrint_MSSQL"];
            strPAR_SystemName_MSSQL = ConfigurationManager.AppSettings["PAR_SystemName_MSSQL"];
            strPAR_AccountName_MSSQL = ConfigurationManager.AppSettings["PAR_AccountName_MSSQL"];

            strPAR_Url_LBTR = ConfigurationManager.AppSettings["PAR_Url_LBTR"];
            strPAR_ThumbPrint_LBTR = ConfigurationManager.AppSettings["PAR_ThumbPrint_LBTR"];
            strPAR_SystemName_LBTR = ConfigurationManager.AppSettings["PAR_SystemName_LBTR"];
            strPAR_AccountName_LBTR = ConfigurationManager.AppSettings["PAR_AccountName_LBTR"];

            int.TryParse(ConfigurationManager.AppSettings["PAR_MaxPasswordLength"], out Globales.PAR_MAX_PASSWORD_LENGTH);

            string strDatos = "";

            for (int i = 0; i < ConfigurationManager.AppSettings.Count; i++)
            {
                strDatos += ConfigurationManager.AppSettings.GetKey(i) + ": " + ConfigurationManager.AppSettings.Get(i) + "; ";
            }

            LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS, 
                Utilitario.RetornaHashCode(Thread.CurrentThread.GetHashCode()), 
                "TBEWinServ()",
                "Se inicializa el servicio windows con los siguientes datos del config: " + strDatos, false);
                                                
            try
            {
                double.TryParse(ConfigurationManager.AppSettings["TIEMPO_MAX_ESPERA_RESPUESTA_API"], out Globales.APISEC_TIEMPOMAXESPERA);
                int.TryParse(ConfigurationManager.AppSettings["PSAFE_TIMEOUT"], out Globales.PSAFE_TIMEOUT);
                int.TryParse(ConfigurationManager.AppSettings["LBTRSERVICES_TIMEOUT"], out Globales.LBTRSERVICES_TIMEOUT);

                nIntervaloEnvioOpeBCRP = int.Parse(strIntervaloEnvioOpeBCRP);
                nIntervaloConfBCosmos = int.Parse(strIntervaloConfBCosmos);
                nIntervaloConfAbono = int.Parse(strIntervaloConfAbono);
                nIntervaloInicioFinDia = int.Parse(strIntervaloInicioFinDia);
                nIntervaloOPEREC = int.Parse(strIntervaloOPEREC);
                nIntervaloOPERECConting = int.Parse(strIntervaloOPERECConting);
                int.TryParse(strIntervaloVerifProc, out nIntervaloVerifProc);
                nIntervaloEnvioBCosmos = int.Parse(strIntervaloEnvioBCosmos);
                nIntervaloAperturaCierreBatchBCosmos = int.Parse(strIntervaloAperturaCierreBatchBCosmos);
                nIntervaloEnvioCompraVenta = int.Parse(strIntervaloEnvioCompraVenta); //Agregado jr72296
                Globales.SYNCBCOSMOS_TIMEOUT = int.Parse(strSYNCBCosmosTimeout);
                Globales.SYNCBCOSMOS_REINTENTOS = int.Parse(strSYNCBCosmosReintentos);
                Globales.SISTEMA_ORIGEN = int.Parse(strSistemaOrigen);
            }
            catch{
                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS, 
                    Utilitario.RetornaHashCode(Thread.CurrentThread.GetHashCode()), 
                    "TBEWinServ()",
                    "Error: revisar en el config si el valor para INTERVALO_EVENTO_TIMER_CONFABONO, " +
                    "INTERVALO_EVENTO_TIMER_INICIOFINDIA, " +
                    "SYNCBCOSMOS_TIMEOUT, SYNCBCOSMOS_REINTENTOS_X_INTERVALO, INTERVALO_EVENTO_TIMER_OPEREC, " +
                    "INTERVALO_EVENTO_TIMER_OPEREC_CONTINGENCIA, INTERVALO_EVENTO_TIMER_ENVIO_BCOSMOS, SISTEMA_ORIGEN,INTERVALO_EVENTO_TIMER_ENVIO_COMPRA_VENTA " +  //Modificado jr72296
                    "es un valor entero.", true);
            }
        }
                                                                
        #endregion

        #region Eventos de Servicio Windows

        protected override void OnStart(string[] args)
        {
            LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS, 
                Utilitario.RetornaHashCode(Thread.CurrentThread.GetHashCode()), 
                "TBEWinServ.OnStart",
                "Se inicia el servicio windows.v20160802", false);

            if (args != null && args.Length == 3)//Se invocó a través del winform y recibirá usuario password y pwd logon
            {
                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS,
                Utilitario.RetornaHashCode(Thread.CurrentThread.GetHashCode()),
                "TBEWinServ.OnStart",
                "Se inicia el servicio windows desde CONTINGENCIA", false);

                strDiaActual = DateTime.Today.ToString("yyyyMMdd");
                strDiaAnterior = strDiaActual;

                Globales.CONTING_BD_USER_SYBASE = args[0];
                Globales.CONTING_BD_PWD_SYBASE = args[1];
                Globales.CONTING_BD_USER_MSSQL = args[0];
                Globales.CONTING_BD_PWD_MSSQL = args[1];
                Globales.PASSWORD_BD_SYBASE = args[1];
                Globales.PASSWORD_BD_MSSQL = args[1];

                Globales.CADENA_CONEXION = Utilitario.ObtenerCadenaConexion(true, strServidorSTB, strBDSTB, strPuertoSTB, args[0], args[1]);
                Globales.CADENA_CONEXION_PLB = Utilitario.ObtenerCadenaConexion(false, strServidorPLB, strBDPLB, null, args[0], args[1]);

                if (Globales.MOSTRAR_CADENA_CNX_LOG)
                {
                    LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS,
                        Globales.HASHCODE_thrInicioFinDia,
                        "TBEWinServ.OnStart",
                        "La cadena de conexion es: [" + Globales.CADENA_CONEXION + "]", false);

                    LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS,
                       Globales.HASHCODE_thrInicioFinDia,
                       "TBEWinServ.OnStart",
                       "La cadena de conexion es MSSQL: [" + Globales.CADENA_CONEXION_PLB + "]", false);
                }

                if (!String.IsNullOrEmpty(args[2]))
                {
                    Globales.LBTR_PASSWORD = args[2];
                    blnActualizarPwdLogon = true;
                }
            }
            else 
            {
                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS, Globales.HASHCODE_thrInicioFinDia,
                "TBEWinServ.OnStart",
                "Se inicia el servicio Windows.", NivelMensajeLog.NOTIFICACION); //se envía correo
            }

            EstablecerServiciosHabilitados();

            BL_General.InicializarListaCaracteresNoValidos();
            
            try
            {
                blnFinalizarVerifProc = false;
                thr_VerifProc = new Thread(Iniciar_VerifProc);
                thr_VerifProc.Start();
                
                //Thread.Sleep(5000);

                blnFinalizarInicioFinDia = false;
                thr_INICIOFINDIA = new Thread(Iniciar_TmrInicioFinDia);
                thr_INICIOFINDIA.Start();

                //Thread.Sleep(5000);
               
                blnFinalizarEnvioOpeBCRP = false;
                thr_EnvioOpeBCRP = new Thread(Iniciar_TmrEnvioOpeBCRP);
                thr_EnvioOpeBCRP.Start();

                //Thread.Sleep(2000);
               
                blnFinalizarConfAbono = false;
                thr_CONF_ABONO = new Thread(Iniciar_TmrConfAbono);
                thr_CONF_ABONO.Start();

                //Thread.Sleep(2000);

                blnFinalizarConfBCosmos = false;
                thr_CONF_BCOSMOS = new Thread(Iniciar_TmrConfBCosmos);
                thr_CONF_BCOSMOS.Start();

                //Thread.Sleep(2000);

                blnFinalizarOPEREC = false;
                thr_OPEREC = new Thread(Iniciar_TmrOpeRec);
                thr_OPEREC.Start();

                //Thread.Sleep(2000);

                blnFinalizarOPERECConting = false;
                thr_OPERECConting = new Thread(Iniciar_TmrOpeRecConting);
                thr_OPERECConting.Start();

                //Thread.Sleep(2000);

                oRemServer.HabilitarEscucha();

                //Thread.Sleep(2000);

                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS,
                Utilitario.RetornaHashCode(Thread.CurrentThread.GetHashCode()), 
                "TBEWinServ.OnStart",
                "Se inicializa TBEMQWinServ.FachadaRemotingCliente para acceso al servicio MQ.", false);

                oTramaMQ = new TBEMQWinServ.FachadaRemotingCliente.Servicio();

                blnFinalizarAperturaCierreBatchBCosmos = false;
                thr_APERTURACIERREBATCH_BCOSMOS = new Thread(Iniciar_TmrAperturaCierreBatchBCosmos);
                thr_APERTURACIERREBATCH_BCOSMOS.Start();

                //Thread.Sleep(2000);

                blnFinalizarEnvioBCosmos = false;
                thr_ENVIO_BCOSMOS = new Thread(Iniciar_TmrEnvioBCosmos);
                thr_ENVIO_BCOSMOS.Start();

                //Thread.Sleep(5000);

                blnFinalizarEnvioCompraVenta = false;
                thr_EnvioCompraVenta = new Thread(Iniciar_TmrEnvioCompraVenta);
                thr_EnvioCompraVenta.Start();

                //hh72295:20170117:I: ADECUACION CITISCREENING EN OPERACIONES DE ENTRADA
                blnFinalizarEnvioOperacionCitiscreening = false;
                thr_EnvioOperacionCitiscreening = new Thread(Iniciar_TmrEnvioOperacionCitiscreening);
                thr_EnvioOperacionCitiscreening.Start();
                //hh72295:20170117:F: ADECUACION CITISCREENING EN OPERACIONES DE ENTRADA
            }
            catch (Exception ex)
            {
                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS, 
                    Utilitario.RetornaHashCode(Thread.CurrentThread.GetHashCode()), 
                    "TBEWinServ.OnStart",
                    "Error al iniciar el servicio windows: " + ex.Message + "; StackTrace: " + ex.StackTrace, true);
            }
        }

        protected override void OnStop()
        {
            LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS,  Utilitario.RetornaHashCode(Thread.CurrentThread.GetHashCode()), 
                "TBEWinServ.OnStop",
                "Se procede a detener el servicio windows.", NivelMensajeLog.NOTIFICACION);

            try
            {
                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS, 
                    Utilitario.RetornaHashCode(Thread.CurrentThread.GetHashCode()), 
                    "TBEWinServ.OnStop",
                    "Se establece el flag de finalizacion a true para los threads en proceso y se procede a abortarlos.", 
                    false);

                blnFinalizarInicioFinDia = true;
                blnFinalizarEnvioOpeBCRP = true;
                blnFinalizarEnvioBCosmos = true;
                blnFinalizarAperturaCierreBatchBCosmos = true;
                blnFinalizarConfAbono = true;
                blnFinalizarConfBCosmos = true;
                blnFinalizarOPEREC = true;
                blnFinalizarOPERECConting = true;
                blnFinalizarEnvioCompraVenta = true;
                blnFinalizarVerifProc = true;

                oRemServer.DeshabilitarEscucha();
                                
                if (thr_EnvioOpeBCRP != null) thr_EnvioOpeBCRP.Join(new TimeSpan(0, 0, 30));
                if (thr_CONF_ABONO != null) thr_CONF_ABONO.Join(new TimeSpan(0, 0, 30));
                if (thr_CONF_BCOSMOS != null) thr_CONF_BCOSMOS.Join(new TimeSpan(0, 0, 30));                
                if (thr_OPEREC != null) thr_OPEREC.Join(new TimeSpan(0, 0, 45));
                if (thr_OPERECConting != null) thr_OPERECConting.Join(new TimeSpan(0, 0, 45));
                if (thr_ENVIO_BCOSMOS != null) thr_ENVIO_BCOSMOS.Join(new TimeSpan(0, 0, 30));
                if (thr_APERTURACIERREBATCH_BCOSMOS != null) thr_APERTURACIERREBATCH_BCOSMOS.Join(new TimeSpan(0, 0, 30));                
                if (thr_INICIOFINDIA != null) thr_INICIOFINDIA.Join(new TimeSpan(0, 1, 0));
                if (thr_EnvioCompraVenta != null) thr_EnvioCompraVenta.Join(new TimeSpan(0, 0, 30));
                if (thr_VerifProc != null) thr_VerifProc.Join(new TimeSpan(0, 1,0));              

                //Deshabilitado porque dentro del logoff se hace uso del api de seg
                //el cual puede ser un foco de excepcion no controlable al ser codigo no administrado
                //y al aplicarlo en este metodo OnStop hara que el servicio nunca se detenga 
                //hasta ser reiniciado el servidor
                //LBTR_Logoff(Utilitario.RetornaHashCode(Thread.CurrentThread.GetHashCode()));

                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS, 
                    Utilitario.RetornaHashCode(Thread.CurrentThread.GetHashCode()), 
                    "TBEWinServ.OnStop",
                    "Finalizaron los sub procesos satisfactoriamente.", false);
            }
            catch (Exception ex)
            {
                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS, 
                    Utilitario.RetornaHashCode(Thread.CurrentThread.GetHashCode()), 
                    "TBEWinServ.OnStop",
                    "Error al detener el servicio windows: " + ex.Message + "; StackTrace: " + ex.StackTrace, true);
            }
        }

        protected override void OnCustomCommand(int command)
        {
            base.OnCustomCommand(command);

            if (command == Constantes.ACTUALIZAR_SERVICIOSHABILITADOS)
            {
                EstablecerServiciosHabilitados();
            }
        }

        #endregion

        #region Metodos para los procesos
                
        private void Iniciar_TmrInicioFinDia()
        {
            LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS, 
                Utilitario.RetornaHashCode(Thread.CurrentThread.GetHashCode()), 
                "TBEWinServ.Iniciar_TmrInicioFinDia",
                "Se inicia el thread thr_INICIOFINDIA.", false);

            while (!blnFinalizarInicioFinDia)
            {
                Globales.HASHCODE_thrInicioFinDia = Utilitario.RetornaHashCode(thr_INICIOFINDIA.GetHashCode()) + DateTime.Now.ToString("HHmmss");
                this.RealizarInicioFinalizacionDelDia();
                Thread.Sleep(this.nIntervaloInicioFinDia);
            }
        }
                
        private void Iniciar_TmrEnvioOpeBCRP()
        {
            LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS,
                    Utilitario.RetornaHashCode(Thread.CurrentThread.GetHashCode()),
                    "TBEWinServ.Iniciar_TmrEnvioOpeBCRP",
                    "Se inicia el thread thr_EnvioOpeBCRP.", false);

            while (!blnFinalizarEnvioOpeBCRP)
            {
                String strHashcode = Utilitario.RetornaHashCode(thr_EnvioOpeBCRP.GetHashCode()) + DateTime.Now.ToString("HHmmss");
                this.Iniciar_Servicio(TipoServicio.ENVIO_TRANSFERENCIAS, strHashcode);
                Thread.Sleep(this.nIntervaloEnvioOpeBCRP);
            }
        }
                
        private void Iniciar_TmrConfAbono()
        {
            if (EsServicioHabilitado(TipoServicio.CONFIRMACION_ABONO))
            {
                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS, 
                    Utilitario.RetornaHashCode(Thread.CurrentThread.GetHashCode()), 
                    "TBEWinServ.Iniciar_TmrConfAbono",
                    "Se inicia el thread thr_CONF_ABONO.", false);

                while (!blnFinalizarConfAbono)
                {
                    String strHashcode = Utilitario.RetornaHashCode(thr_CONF_ABONO.GetHashCode()) + DateTime.Now.ToString("HHmmss");
                    this.Iniciar_Servicio(TipoServicio.CONFIRMACION_ABONO, strHashcode);
                    Thread.Sleep(this.nIntervaloConfAbono);
                }
            }
            else 
            {
                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS,
                    Utilitario.RetornaHashCode(Thread.CurrentThread.GetHashCode()), 
                    "TBEWinServ.Iniciar_TmrConfAbono",
                    "El proceso Confirmacion de Abono se encuentra deshabilitado.", false);
            }
        }

        private void Iniciar_TmrConfBCosmos()
        {
            if (EsServicioHabilitado(TipoServicio.CONFIRMACION_BCOSMOS))
            {
                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS, 
                    Utilitario.RetornaHashCode(Thread.CurrentThread.GetHashCode()),
                    "TBEWinServ.Iniciar_TmrConfBCosmos",
                    "Se inicia el thread thr_CONF_BCOSMOS.", false);

                while (!blnFinalizarConfBCosmos)
                {
                    String strHashcode = Utilitario.RetornaHashCode(thr_CONF_BCOSMOS.GetHashCode()) + DateTime.Now.ToString("HHmmss");
                    this.Iniciar_Servicio(TipoServicio.CONFIRMACION_BCOSMOS, strHashcode);
                    Thread.Sleep(this.nIntervaloConfBCosmos);
                }
            }
            else
            {
                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS, 
                    Utilitario.RetornaHashCode(Thread.CurrentThread.GetHashCode()),
                    "TBEWinServ.Iniciar_TmrConfBCosmos",
                    "El proceso Confirmacion BCosmos se encuentra deshabilitado.", false);
            }
        }

        private void Iniciar_TmrOpeRec()
        {
            if (EsServicioHabilitado(TipoServicio.AVISO_AFECTACION))
            {
                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS,
                    Utilitario.RetornaHashCode(Thread.CurrentThread.GetHashCode()),
                    "TBEWinServ.Iniciar_TmrOpeRec",
                    "Se inicia el thread thr_OPEREC.", false);

                while (!blnFinalizarOPEREC)
                {
                    String strHashcode = Utilitario.RetornaHashCode(thr_OPEREC.GetHashCode()) + DateTime.Now.ToString("HHmmss");
                    this.Iniciar_Servicio(TipoServicio.AVISO_AFECTACION, strHashcode);
                    Thread.Sleep(this.nIntervaloOPEREC);
                }
            }
            else
            {
                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS,
                    Utilitario.RetornaHashCode(Thread.CurrentThread.GetHashCode()),
                    "TBEWinServ.Iniciar_TmrOpeRec",
                    "El proceso Operaciones Recibidas se encuentra deshabilitado.", false);
            }
        }

        private void Iniciar_TmrOpeRecConting()
        {
            if (EsServicioHabilitado(TipoServicio.AVISO_AFECTACION_CONTING))
            {
                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS,
                    Utilitario.RetornaHashCode(Thread.CurrentThread.GetHashCode()),
                    "TBEWinServ.Iniciar_TmrOpeRecConting",
                    "Se inicia el thread thr_OPERECConting.", false);

                while (!blnFinalizarOPERECConting)
                {
                    String strHashcode = Utilitario.RetornaHashCode(thr_OPERECConting.GetHashCode()) + DateTime.Now.ToString("HHmmss");
                    this.Iniciar_Servicio(TipoServicio.AVISO_AFECTACION_CONTING, strHashcode);
                    Thread.Sleep(this.nIntervaloOPERECConting);
                }
            }
            else
            {
                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS,
                    Utilitario.RetornaHashCode(Thread.CurrentThread.GetHashCode()),
                    "TBEWinServ.Iniciar_TmrOpeRecConting",
                    "El proceso Operaciones Recibidas Contingencia se encuentra deshabilitado.", false);
            }
        }

        private void Iniciar_VerifProc()
        {
            String strHashCodeVerifProc = thr_VerifProc.GetHashCode().ToString();
            bool blnNotificoError = false;

            while (!blnFinalizarVerifProc)
            {
                try
                {
                    if (Globales.THRINICIODIA_BLNAPIINVOCADO)
                    {
                        TimeSpan tsDiferencia = DateTime.Now - Globales.THRINICIODIA_DTULTINVOCAPI;
                        double dbDiferencia = tsDiferencia.TotalSeconds;
                        if (dbDiferencia >= Globales.APISEC_TIEMPOMAXESPERA)
                        {
                            System.Diagnostics.Process.Start(strRutaAppContingencia, "REINICIAR");
                            
                            LogWriter.Notificar(strHashCodeVerifProc, "El thread de INICIO de DIA invoco al API de seguridad pero no respondio en " + Globales.APISEC_TIEMPOMAXESPERA.ToString() + ". Se realizara el llamado a la aplicacion de contingencia [" + strRutaAppContingencia + "]");
                            LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS, strHashCodeVerifProc,
                            "TBEWinServ.Iniciar_VerifProc",
                            "El thread de INICIO de DIA invoco al API de seguridad pero no respondio en " + Globales.APISEC_TIEMPOMAXESPERA.ToString() + ". Se realizara el llamado a la aplicacion de contingencia [" + strRutaAppContingencia + "]", false);                        
                            break;
                        }
                    }

                    if (Globales.THRENVIOOPEBCRP_BLNAPIINVOCADO)
                    {
                        TimeSpan tsDiferencia = DateTime.Now - Globales.THRENVIOOPEBCRP_DTULTINVOCAPI;
                        double dbDiferencia = tsDiferencia.TotalSeconds;
                        if (dbDiferencia >= Globales.APISEC_TIEMPOMAXESPERA)
                        {
                            System.Diagnostics.Process.Start(strRutaAppContingencia, "REINICIAR");

                            LogWriter.Notificar(strHashCodeVerifProc, "El thread de Envio Operaciones a BCRP invoco al API de seguridad pero no respondio en " + Globales.APISEC_TIEMPOMAXESPERA.ToString() + ". Se realizara el llamado a la aplicacion de contingencia [" + strRutaAppContingencia + "]");
                            LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS, strHashCodeVerifProc,
                            "TBEWinServ.Iniciar_VerifProc",
                            "El thread de Envio Operaciones a BCRP invoco al API de seguridad pero no respondio en " + Globales.APISEC_TIEMPOMAXESPERA.ToString() + ". Se realizara el llamado a la aplicacion de contingencia [" + strRutaAppContingencia + "]", false);
                            break;
                        }
                    }

                    if (Globales.THRCONFABONO_BLNAPIINVOCADO)
                    {
                        TimeSpan tsDiferencia = DateTime.Now - Globales.THRCONFABONO_DTULTINVOCAPI;
                        double dbDiferencia = tsDiferencia.TotalSeconds;
                        if (dbDiferencia >= Globales.APISEC_TIEMPOMAXESPERA)
                        {
                            System.Diagnostics.Process.Start(strRutaAppContingencia, "REINICIAR");

                            LogWriter.Notificar(strHashCodeVerifProc, "El thread de Conf. Abono invoco al API de seguridad pero no respondio en " + Globales.APISEC_TIEMPOMAXESPERA.ToString() + ". Se realizara el llamado a la aplicacion de contingencia [" + strRutaAppContingencia + "]");
                            LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS, strHashCodeVerifProc,
                            "TBEWinServ.Iniciar_VerifProc",
                            "El thread de Conf. Abono invoco al API de seguridad pero no respondio en " + Globales.APISEC_TIEMPOMAXESPERA.ToString() + ". Se realizara el llamado a la aplicacion de contingencia [" + strRutaAppContingencia + "]", false);
                            break;
                        }
                    }

                    if (Globales.THROPEREC_BLNAPIINVOCADO)
                    {
                        TimeSpan tsDiferencia = DateTime.Now - Globales.THROPEREC_DTULTINVOCAPI;
                        double dbDiferencia = tsDiferencia.TotalSeconds;
                        if (dbDiferencia >= Globales.APISEC_TIEMPOMAXESPERA)
                        {
                            System.Diagnostics.Process.Start(strRutaAppContingencia, "REINICIAR");

                            LogWriter.Notificar(strHashCodeVerifProc, "El thread de Procesamiento Ope. Recibidas invoco al API de seguridad pero no respondio en " + Globales.APISEC_TIEMPOMAXESPERA.ToString() + ". Se realizara el llamado a la aplicacion de contingencia [" + strRutaAppContingencia + "]");
                            LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS, strHashCodeVerifProc,
                            "TBEWinServ.Iniciar_VerifProc",
                            "El thread de Procesamiento Ope. Recibidas invoco al API de seguridad pero no respondio en " + Globales.APISEC_TIEMPOMAXESPERA.ToString() + ". Se realizara el llamado a la aplicacion de contingencia [" + strRutaAppContingencia + "]", false);
                            break;
                        }
                    }

                    if (Globales.THROPERECCONTING_BLNAPIINVOCADO)
                    {
                        TimeSpan tsDiferencia = DateTime.Now - Globales.THROPERECCONTING_DTULTINVOCAPI;
                        double dbDiferencia = tsDiferencia.TotalSeconds;
                        if (dbDiferencia >= Globales.APISEC_TIEMPOMAXESPERA)
                        {
                            System.Diagnostics.Process.Start(strRutaAppContingencia, "REINICIAR");

                            LogWriter.Notificar(strHashCodeVerifProc, "El thread de Procesamiento Ope. Recibidas Contingencia invoco al API de seguridad pero no respondio en " + Globales.APISEC_TIEMPOMAXESPERA.ToString() + ". Se realizara el llamado a la aplicacion de contingencia [" + strRutaAppContingencia + "]");
                            LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS, strHashCodeVerifProc,
                            "TBEWinServ.Iniciar_VerifProc",
                            "El thread de Procesamiento Ope. Recibidas Contingencia invoco al API de seguridad pero no respondio en " + Globales.APISEC_TIEMPOMAXESPERA.ToString() + ". Se realizara el llamado a la aplicacion de contingencia [" + strRutaAppContingencia + "]", false);
                            break;
                        }
                    }

                }
                catch (Exception ex)
                {
                    if (!blnNotificoError)
                    {
                        LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS, strHashCodeVerifProc,
                            "TBEWinServ.Iniciar_VerifProc",
                            "Error durante la verificacion de subprocesos invocando al api de seguridad, revisar el detalle y reiniciar el servicio: \r\n" + ex.Message + "\r\n" + ex.StackTrace, true);
                        blnNotificoError = true;
                    }
                }

                Thread.Sleep(nIntervaloVerifProc);
            }
        }

        private void Iniciar_TmrEnvioBCosmos()
        {
            if (EsServicioHabilitado(TipoServicio.ENVIO_OPERACION_BCOSMOS))
            {
                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS,
                    Utilitario.RetornaHashCode(Thread.CurrentThread.GetHashCode()),
                    "TBEWinServ.Iniciar_TmrEnvioBCosmos",
                    "Se inicia el thread thr_ENVIO_BCOSMOS.", NivelMensajeLog.NINGUNO);

                while (!blnFinalizarEnvioBCosmos)
                {
                    String strHashcode = Utilitario.RetornaHashCode(thr_ENVIO_BCOSMOS.GetHashCode()) + DateTime.Now.ToString("HHmmss");
                    this.Iniciar_Servicio(TipoServicio.ENVIO_OPERACION_BCOSMOS, strHashcode);
                    Thread.Sleep(this.nIntervaloEnvioBCosmos);
                }
            }
            else
            {
                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS,
                    Utilitario.RetornaHashCode(Thread.CurrentThread.GetHashCode()),
                    "TBEWinServ.Iniciar_TmrEnvioBCosmos",
                    "El proceso de envio de operaciones a BCosmos se encuentra deshabilitado.", NivelMensajeLog.NINGUNO);
            }
        }

        private void Iniciar_TmrAperturaCierreBatchBCosmos()
        {
            LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS,
                Utilitario.RetornaHashCode(Thread.CurrentThread.GetHashCode()),
                "TBEWinServ.Iniciar_TmrAperturaCierreBatchBCosmos",
                "Se inicia el thread thr_APERTURACIERREBATCH_BCOSMOS.", NivelMensajeLog.NINGUNO);

            while (!blnFinalizarAperturaCierreBatchBCosmos)
            {
                Globales.HASHCODE_thrInicioFinDiaBCosmos = Utilitario.RetornaHashCode(thr_APERTURACIERREBATCH_BCOSMOS.GetHashCode()) + DateTime.Now.ToString("HHmmss");
                this.RealizarAperturaCierreDeBatchBCosmos();
                Thread.Sleep(this.nIntervaloAperturaCierreBatchBCosmos);
            }
        }

        private void Iniciar_TmrEnvioCompraVenta()
        {
            LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS,
                    Utilitario.RetornaHashCode(Thread.CurrentThread.GetHashCode()),
                    "TBEWinServ.Iniciar_TmrEnvioCompraVenta",
                    "Se inicia el thread thr_EnvioCompraVenta.", false);

            while (!blnFinalizarEnvioCompraVenta)
            {
                String strHashcode = Utilitario.RetornaHashCode(thr_EnvioCompraVenta.GetHashCode()) + DateTime.Now.ToString("HHmmss");
                this.Iniciar_Servicio(TipoServicio.SALIDAS_COMPRAVENTA, strHashcode);
                Thread.Sleep(this.nIntervaloEnvioCompraVenta);
            }
        }

        //hh72295:20170117:I: ADECUACION CITISCREENING EN OPERACIONES DE ENTRADA
        private void Iniciar_TmrEnvioOperacionCitiscreening()
        {
            LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS,
                    Utilitario.RetornaHashCode(Thread.CurrentThread.GetHashCode()),
                    "TBEWinServ.Iniciar_TmrEnvioOperacionCitiscreening",
                    "Se inicia el thread thr_EnvioOperacionCitiscreening.", false);

            while (!blnFinalizarEnvioOperacionCitiscreening)
            {
                String strHashcode = Utilitario.RetornaHashCode(thr_EnvioOperacionCitiscreening.GetHashCode()) + DateTime.Now.ToString("HHmmss");
                this.Iniciar_Servicio(TipoServicio.ENVIO_OPERACION_CITISCREENING, strHashcode);
                Thread.Sleep(this.nIntervaloEnvioOperacionCitiscreening);
            }
        }
        //hh72295:20170117:F: ADECUACION CITISCREENING EN OPERACIONES DE ENTRADA
        
        #endregion

        #region Metodos Generales

        private bool EstaEnHorarioReposo()
        {
            DateTime dtHoraIni;
            DateTime dtHoraFin;

            if (Utilitario.ValidarHora(strHoraReposoIni))
            {
                dtHoraIni = new DateTime(DateTime.Today.Year, DateTime.Today.Month, DateTime.Today.Day,
                                                    int.Parse(strHoraReposoIni.Substring(0, 2)), int.Parse(strHoraReposoIni.Substring(3, 2)), 0);
            }
            else
            {
                dtHoraIni = new DateTime(DateTime.Today.Year, DateTime.Today.Month, DateTime.Today.Day, 0, 0, 0);
            }

            if (Utilitario.ValidarHora(strHoraReposoFin))
            {
                dtHoraFin = new DateTime(DateTime.Today.Year, DateTime.Today.Month, DateTime.Today.Day,
                                                    int.Parse(strHoraReposoFin.Substring(0, 2)), int.Parse(strHoraReposoFin.Substring(3, 2)), 0);
            }
            else
            {
                dtHoraFin = new DateTime(DateTime.Today.Year, DateTime.Today.Month, DateTime.Today.Day, 7, 0, 0);
            }

            if (dtHoraIni >= dtHoraFin)
            {
                dtHoraIni = new DateTime(DateTime.Today.Year, DateTime.Today.Month, DateTime.Today.Day, 0, 0, 0);
            }

            if (DateTime.Now >= dtHoraIni & DateTime.Now <= dtHoraFin)
            {
                return true;
            }

            return false;
        }

        private bool EsServicioHabilitado(TipoServicio prmTipoServicio)
        {
            bool blnValor = false;
            string strID = "";

            switch (prmTipoServicio)
            {
                case TipoServicio.CONFIRMACION_ABONO:
                    strID = TipoServicio_ID.CONFIRMACION_ABONO;
                    break;
                case TipoServicio.CONFIRMACION_BCOSMOS:
                    strID = TipoServicio_ID.CONFIRMACION_BCOSMOS;
                    break;
                case TipoServicio.AVISO_AFECTACION:
                    strID = TipoServicio_ID.OPE_RECIBIDAS;
                    break;
                case TipoServicio.AVISO_AFECTACION_CONTING:
                    strID = TipoServicio_ID.OPE_RECIBIDAS_CONTING;
                    break;
                case TipoServicio.ENVIO_OPERACION_BCOSMOS:
                    strID = TipoServicio_ID.ENVIO_OPERACION_BCOSMOS;
                    break;
                default:
                    break;
            }
                            
            if (!String.IsNullOrEmpty(strID) && lstServiciosHabilitados.Count > 0)
                blnValor = lstServiciosHabilitados.Exists(delegate(BE_Servicio oServicio) { return oServicio.Codigo == strID; });
            else
                blnValor = false;
            return blnValor;
        }
               
        private void EstablecerServiciosHabilitados()
        {
            try
            {
                List<BE_Servicio> lstServicios = (new BL_AdministradorServicio(strRutaArchivoServicios)).LeerServiciosXML();
                lstServiciosHabilitados = lstServicios.FindAll(delegate(BE_Servicio oServicio) 
                { return oServicio.Habilitado == true; });

                string strMensajeLog = "Los siguientes servicios estan habilitados para procesar: ";
                foreach (BE_Servicio oServicio in lstServicios)
                {
                    strMensajeLog += oServicio.Nombre + ", ";
                }
                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS, 
                    Utilitario.RetornaHashCode(Thread.CurrentThread.GetHashCode()), 
                    "TBEWinServ.EstablecerServiciosHabilitados",
                    strMensajeLog, false);
            }
            catch (Exception ex)
            {
                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS, 
                    Utilitario.RetornaHashCode(Thread.CurrentThread.GetHashCode()),
                    "TBEWinServ.EstablecerServiciosHabilitados",
                    "Error al establecer los servicios a procesar usando el archivo Servicios.xml: " +
                     ex.Message + "; StackTrace: " + ex.StackTrace, true);
            }
        }

        private void EstablecerCnxDesdeContingencia()
        {
            if (!String.IsNullOrEmpty(Globales.CONTING_BD_USER_SYBASE) && !String.IsNullOrEmpty(Globales.CONTING_BD_PWD_SYBASE) &&
                 !String.IsNullOrEmpty(Globales.CONTING_BD_USER_MSSQL) && !String.IsNullOrEmpty(Globales.CONTING_BD_PWD_MSSQL))
            {
                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS,
                    Globales.HASHCODE_thrInicioFinDia,
                    "TBEWinServ.EstablecerCnxDesdeContingencia",
                    "[CONTINGENCIA] Se procedera a probar el usuario/contrasena de base de datos establecido como contingencia.", false);

                Globales.CADENA_CONEXION = Utilitario.ObtenerCadenaConexion(true, strServidorSTB, strBDSTB, strPuertoSTB, Globales.CONTING_BD_USER_SYBASE, Globales.CONTING_BD_PWD_SYBASE);
                Globales.CADENA_CONEXION_PLB = Utilitario.ObtenerCadenaConexion(false, strServidorPLB, strBDPLB, null, Globales.CONTING_BD_USER_MSSQL, Globales.CONTING_BD_PWD_MSSQL);

                bool blnExitoSTB = BL_ConectividadBD.ProbarConexionSybase(Globales.CADENA_CONEXION);
                bool blnExitoPLB = BL_ConectividadBD.ProbarConexionMSSQL(Globales.CADENA_CONEXION_PLB);

                //Se prueba la conectividad
                if (!blnExitoSTB || !blnExitoPLB)
                {
                    Globales.CADENA_CONEXION = null;
                    Globales.CADENA_CONEXION_PLB = null;
                    Globales.PASSWORD_BD_SYBASE = null;
                    Globales.PASSWORD_BD_MSSQL = null;
                    Globales.CONTING_BD_USER_SYBASE = null;
                    Globales.CONTING_BD_PWD_SYBASE = null;
                    Globales.CONTING_BD_USER_MSSQL = null;
                    Globales.CONTING_BD_PWD_MSSQL = null;
                    LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS,
                        Globales.HASHCODE_thrInicioFinDia,
                        "TBEWinServ.EstablecerCnxDesdeContingencia",
                        "[CONTINGENCIA] Se probo la conectividad usando la cadena de conexion con datos de CONTINGENCIA y no hubo exito. " + 
                        "Se limpia la cadena de conexion. Hacer uso de la consola de Contingencia [TBEWinServ.Consola.exe] " +
                        "para reestablecer la conexión a BD. ¿CNX STB OK?= " + blnExitoSTB.ToString() + "; ¿CNX PLBDB OK?= " + blnExitoPLB.ToString(), true);
                }
                else
                {
                    Globales.PASSWORD_BD_SYBASE = Globales.CONTING_BD_PWD_SYBASE;
                    Globales.PASSWORD_BD_MSSQL = Globales.CONTING_BD_PWD_MSSQL;
                    LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS,
                        Globales.HASHCODE_thrInicioFinDia,
                        "TBEWinServ.EstablecerCnxDesdeContingencia",
                        "[CONTINGENCIA] La cadena de conexion de BD con datos de contingencia es CORRECTA y SE EMPLEARA en el sistema.", false);
                }
            }
            else
            {
                Globales.CADENA_CONEXION = null;
                Globales.CADENA_CONEXION_PLB = null;
                Globales.PASSWORD_BD_SYBASE = null;
                Globales.PASSWORD_BD_MSSQL = null;
                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS,
                    Globales.HASHCODE_thrInicioFinDia,
                    "TBEWinServ.EstablecerCnxDesdeContingencia",
                    "[CONTINGENCIA] No estan establecidos el usuario y password de conexion a bd como contingencia. La cadena CNX sigue vacio. Hacer uso de la consola de Contingencia [TBEWinServ.Consola.exe] para reestablecer la conexión a BD.", true);
            }
        }

        private void LlamadaPasswordSafeLogonBCR()
        {            
            if (String.IsNullOrEmpty(Globales.LBTR_PASSWORD))
            {
                LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.SERVICIO_WINDOWS, Globales.HASHCODE_thrInicioFinDia, "TBEWinServ.LlamadaPasswordSafe",
                    "Se invoca al metodo LlamadaPasswordSafe para establecer el password de inicio de dia en los servicios del BCRP.", false);

                WS_PasswordSafe wsPSafe = new WS_PasswordSafe(strPSafe_DefinitionName, strPSafe_Host_LBTR, blnUsarCompCert, 
                                                                    strPSafe_CCSerialNumber, strPSafe_CCIssuer, strPSafe_CCSubject);
                Globales.LBTR_PASSWORD = wsPSafe.GetPassword(strPSafe_Account_LBTR);
                if (wsPSafe.Reintentar)
                {
                    Globales.LBTR_PASSWORD = null;
                    LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS,
                        Globales.HASHCODE_thrInicioFinDia,
                        "TBEWinServ.LlamadaPasswordSafe",
                        "No se pudo obtener el password para la autenticacion en los servicios web LBTR del BCRP desde el PSafe.", false);

                    LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS,
                        Globales.HASHCODE_thrInicioFinDia,
                        "TBEWinServ.LlamadaPasswordSafe",
                        "Se procede a obtener el password de contingencia para realizar la autenticacion en los servicios web LBTR del BCRP.", false);

                    Globales.LBTR_PASSWORD = (new BL_ConexionAlterna(Globales.HASHCODE_thrInicioFinDia)).ObtenerPwdLogonBCRP();

                    if (!String.IsNullOrEmpty(Globales.LBTR_PASSWORD))
                    {
                        LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS,
                            Globales.HASHCODE_thrInicioFinDia,
                            "TBEWinServ.LlamadaPasswordSafe",
                            "[CONTINGENCIA] Se obtuvo el password de contingencia para realizar la autenticacion en los servicios web LBTR del BCRP.", false);
                    }
                    else
                    {
                        LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS,
                            Globales.HASHCODE_thrInicioFinDia,
                            "TBEWinServ.EstablecerCnxBD",
                            "[CONTINGENCIA] No se pudo obtener un valor para el password de inicio de dia en BCRP. No se podra realizar el proceso de Logon en los servicios del BCRP. Hacer uso de la consola de contingencia [TBEWinServ.Consola.exe] para establecer el password de Inicio de Dia en BCRP.", true);
                    }
                }
                else
                {
                    LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS,
                        Globales.HASHCODE_thrInicioFinDia,
                        "TBEWinServ.LlamadaPasswordSafe",
                        "El password para la autenticacion en los servicios web LBTR fueron establecidos correctamente.", false);

                    LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS,
                       Globales.HASHCODE_thrInicioFinDia,
                       "TBEWinServ.LlamadaPasswordSafe",
                       "El password es : la autenticacion en los servicios web LBTR fueron establecidos correctamente.", false);

                    (new BL_ConexionAlterna(Globales.HASHCODE_thrInicioFinDia)).GuardarPwdLogonBCRP(Globales.LBTR_PASSWORD);
                }
            }
            else
            {
                if (blnActualizarPwdLogon)
                {
                    if (((new BL_ConexionAlterna(Globales.HASHCODE_thrInicioFinDia)).GuardarPwdLogonBCRP(Globales.LBTR_PASSWORD)) == false)
                    {
                        LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS,
                            Globales.HASHCODE_thrInicioFinDia,
                            "TBEWinServ.LlamadaPasswordSafe",
                            "No se pudo actualizar la contingencia del password de inicio de dia en BCRP en la base de datos. Ver el detalle en el log.", true);
                    }
                    else
                    {
                        LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.SERVICIO_WINDOWS,
                            Globales.HASHCODE_thrInicioFinDia,
                            "TBEWinServ.LlamadaPasswordSafe",
                            "Se actualizo la contingencia del password de inicio de dia en BCRP en la base de datos.", false);
                    }
                    blnActualizarPwdLogon = false;
                }
            }
        }

        private void LlamadaPasswordSafeCnxBD()
        {            
            if (String.IsNullOrEmpty(Globales.CADENA_CONEXION) || String.IsNullOrEmpty(Globales.CADENA_CONEXION_PLB) || 
                String.IsNullOrEmpty(Globales.PASSWORD_BD_SYBASE) || String.IsNullOrEmpty(Globales.PASSWORD_BD_MSSQL))
            {
                LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.SERVICIO_WINDOWS,
                    Globales.HASHCODE_thrInicioFinDia,
                    "TBEWinServ.LlamadaPasswordSafe",
                    "Se invoca al metodo LlamadaPasswordSafe para establecer la cadena de conexion", false);

                Globales.CADENA_CONEXION = ""; Globales.CADENA_CONEXION_PLB = ""; Globales.PASSWORD_BD_SYBASE = ""; Globales.PASSWORD_BD_MSSQL = "";

                WS_PasswordSafe wsPSafe = new WS_PasswordSafe(strPSafe_DefinitionName, strPSafe_Host_BD, blnUsarCompCert, strPSafe_CCSerialNumber, strPSafe_CCIssuer, strPSafe_CCSubject);
                Globales.PASSWORD_BD_SYBASE = wsPSafe.GetPassword(strPSafe_Account_BD);
                Globales.PASSWORD_BD_MSSQL = Globales.PASSWORD_BD_SYBASE;

                if (wsPSafe.Reintentar)
                {
                    Globales.PASSWORD_BD_SYBASE= null; Globales.PASSWORD_BD_MSSQL = null;                    
                    LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.SERVICIO_WINDOWS,
                        Globales.HASHCODE_thrInicioFinDia,
                        "TBEWinServ.LlamadaPasswordSafe",
                        "No se pudo obtener el password para la conexion a base de datos desde el PSafe.", false);
                    EstablecerCnxDesdeContingencia();
                }
                else
                {
                    //Si no hubo error, se crea la cadena de conexion
                    Globales.CADENA_CONEXION = Utilitario.ObtenerCadenaConexion(true, strServidorSTB, strBDSTB, strPuertoSTB, strUsuarioBD_SYBASE, Globales.PASSWORD_BD_SYBASE);
                    Globales.CADENA_CONEXION_PLB = Utilitario.ObtenerCadenaConexion(false, strServidorPLB, strBDPLB, null, strUsuarioBD_MSSQL, Globales.PASSWORD_BD_MSSQL);

                    LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.SERVICIO_WINDOWS,
                        Globales.HASHCODE_thrInicioFinDia,
                        "TBEWinServ.LlamadaPasswordSafe",
                        "La cadena de conexion se establecio correctamente y ahora se probara la conectividad.", false);

                    if (Globales.MOSTRAR_CADENA_CNX_LOG)
                    {
                        LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS,
                            Globales.HASHCODE_thrInicioFinDia,
                            "TBEWinServ.LlamadaPasswordSafe",
                            "La cadena de conexion es: [" + Globales.CADENA_CONEXION + "]", false);
                    }

                    //Se prueba la conectividad
                    bool blnExitoSTB = BL_ConectividadBD.ProbarConexionSybase(Globales.CADENA_CONEXION);
                    bool blnExitoPLB = BL_ConectividadBD.ProbarConexionMSSQL(Globales.CADENA_CONEXION_PLB);

                    if (!blnExitoSTB || !blnExitoPLB)
                    {
                        Globales.CADENA_CONEXION = null;
                        Globales.CADENA_CONEXION_PLB = null;
                        Globales.PASSWORD_BD_SYBASE = null;
                        Globales.PASSWORD_BD_MSSQL = null;
                        LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS,
                            Globales.HASHCODE_thrInicioFinDia,
                            "TBEWinServ.LlamadaPasswordSafe",
                            "Se probo la conectividad usando la cadena de conexion y no hubo exito. Se limpia la cadena de conexion. " +
                            "¿CNX STBDB OK? = " + blnExitoSTB.ToString() + "; ¿CNX PLBDB OK?=" + blnExitoPLB.ToString(), true);

                        EstablecerCnxDesdeContingencia();
                    }
                    else
                    {
                        if (Globales.APISEC_CONECTADA_CONTINGENCIA)//Si el api esta conectado con datos de contingencia, lo reseteamos
                        {
                            LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.SERVICIO_WINDOWS,
                                Globales.HASHCODE_thrInicioFinDia, "TBEWinServ.LlamadaPasswordSafe",
                                "Instancia del Api de seg establecida a null para que no use datos de contingencia.", false);

                            Globales.APISEC_CONECTADA_CONTINGENCIA = false;
                            ObjetosGlobalesApp.objAPISEG = null;
                        }

                        LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS,
                            Globales.HASHCODE_thrInicioFinDia, "TBEWinServ.LlamadaPasswordSafe",
                            "La cadena de conexion de BD es correcta y se empleara en el sistema. Usuario ", false);
                    }
                }
            }
        }

        private void LlamadaPasswordRepositoryLogonBCR()
        {
            if (String.IsNullOrEmpty(Globales.LBTR_PASSWORD))
            {
                LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.SERVICIO_WINDOWS,
                    Globales.HASHCODE_thrInicioFinDia,
                    "TBEWinServ.LlamadaPasswordRepository",
                    "Se invoca al metodo LlamadaPasswordRepository para establecer el password de inicio de dia en los servicios del BCRP.", false);

                PARCertificate par = new PARCertificate(strPAR_Url_LBTR, strPAR_ThumbPrint_LBTR, strPAR_SystemName_LBTR);
                Globales.LBTR_PASSWORD = par.GetPassword(strPAR_AccountName_LBTR);

                if (par.Reintentar)
                {
                    Globales.LBTR_PASSWORD = null;
                    LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS,
                        Globales.HASHCODE_thrInicioFinDia,
                        "TBEWinServ.LlamadaPasswordRepository",
                        "No se pudo obtener el password para la autenticacion en los servicios web LBTR del BCRP desde el Password Repository.", false);

                    LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS,
                        Globales.HASHCODE_thrInicioFinDia,
                        "TBEWinServ.LlamadaPasswordRepository",
                        "Se procede a obtener el password de contingencia para realizar la autenticacion en los servicios web LBTR del BCRP.", false);

                    Globales.LBTR_PASSWORD = (new BL_ConexionAlterna(Globales.HASHCODE_thrInicioFinDia)).ObtenerPwdLogonBCRP();

                    if (!String.IsNullOrEmpty(Globales.LBTR_PASSWORD))
                    {
                        LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS,
                            Globales.HASHCODE_thrInicioFinDia,
                            "TBEWinServ.LlamadaPasswordRepository",
                            "[CONTINGENCIA] Se obtuvo el password de contingencia para realizar la autenticacion en los servicios web LBTR del BCRP.", false);
                    }
                    else
                    {
                        LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS,
                            Globales.HASHCODE_thrInicioFinDia,
                            "TBEWinServ.EstablecerCnxBD",
                            "[CONTINGENCIA] No se pudo obtener un valor para el password de inicio de dia en BCRP. No se podra realizar el proceso de Logon en los servicios del BCRP. Hacer uso de la consola de contingencia [TBEWinServ.Consola.exe] para establecer el password de Inicio de Dia en BCRP.", true);
                    }
                }
                else
                {
                    LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS,
                        Globales.HASHCODE_thrInicioFinDia,
                        "TBEWinServ.LlamadaPasswordRepository",
                        "El password para la autenticacion en los servicios web LBTR fueron establecidos correctamente.", false);

                    (new BL_ConexionAlterna(Globales.HASHCODE_thrInicioFinDia)).GuardarPwdLogonBCRP(Globales.LBTR_PASSWORD);
                }
            }
            else
            {
                if (blnActualizarPwdLogon)
                {
                    if (((new BL_ConexionAlterna(Globales.HASHCODE_thrInicioFinDia)).GuardarPwdLogonBCRP(Globales.LBTR_PASSWORD)) == false)
                    {
                        LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS,
                            Globales.HASHCODE_thrInicioFinDia,
                            "TBEWinServ.LlamadaPasswordRepository",
                            "No se pudo actualizar la contingencia del password de inicio de dia en BCRP en la base de datos. Ver el detalle en el log.", true);
                    }
                    else
                    {
                        LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.SERVICIO_WINDOWS,
                            Globales.HASHCODE_thrInicioFinDia,
                            "TBEWinServ.LlamadaPasswordRepository",
                            "Se actualizo la contingencia del password de inicio de dia en BCRP en la base de datos.", false);
                    }
                    blnActualizarPwdLogon = false;
                }
            }
        }

        private void LlamadaPasswordRepositoryCnxBD()
        {
            if (String.IsNullOrEmpty(Globales.CADENA_CONEXION) || String.IsNullOrEmpty(Globales.CADENA_CONEXION_PLB) ||
                String.IsNullOrEmpty(Globales.PASSWORD_BD_SYBASE) || String.IsNullOrEmpty(Globales.PASSWORD_BD_MSSQL))
            {
                LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.SERVICIO_WINDOWS,
                    Globales.HASHCODE_thrInicioFinDia,
                    "TBEWinServ.LlamadaPasswordRepository",
                    "Se invoca al metodo LlamadaPasswordRepository para establecer la cadena de conexion SYBASE", false);

                Globales.CADENA_CONEXION = ""; Globales.CADENA_CONEXION_PLB = ""; Globales.PASSWORD_BD_SYBASE = ""; Globales.PASSWORD_BD_MSSQL = "";

                PARCertificate par = new PARCertificate(strPAR_Url_Sybase, strPAR_ThumbPrint_Sybase, strPAR_SystemName_Sybase);
                Globales.PASSWORD_BD_SYBASE = par.GetPassword(strPAR_AccountName_Sybase);

                if (par.Reintentar)
                {
                    Globales.PASSWORD_BD_SYBASE = null;
                    Globales.PASSWORD_BD_MSSQL = null;
                    LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.SERVICIO_WINDOWS,
                        Globales.HASHCODE_thrInicioFinDia,
                        "TBEWinServ.LlamadaPasswordRepository",
                        "No se pudo obtener el password Sybase para la conexion a base de datos desde el Password Repository.", false);
                    EstablecerCnxDesdeContingencia();
                }
                else
                {
                    LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.SERVICIO_WINDOWS,
                    Globales.HASHCODE_thrInicioFinDia,
                    "TBEWinServ.LlamadaPasswordRepository",
                    "Se invoca al metodo LlamadaPasswordRepository para establecer la cadena de conexion MSSQL", false);

                    par = new PARCertificate(strPAR_Url_MSSQL, strPAR_ThumbPrint_MSSQL, strPAR_SystemName_MSSQL);
                    Globales.PASSWORD_BD_MSSQL = par.GetPassword(strPAR_AccountName_MSSQL);

                    //Si no hubo error, se crea la cadena de conexion
                    Globales.CADENA_CONEXION = Utilitario.ObtenerCadenaConexion(true, strServidorSTB, strBDSTB, strPuertoSTB, strUsuarioBD_SYBASE_PAR, Globales.PASSWORD_BD_SYBASE);
                    Globales.CADENA_CONEXION_PLB = Utilitario.ObtenerCadenaConexion(false, strServidorPLB, strBDPLB, null, strUsuarioBD_MSSQL_PAR, Globales.PASSWORD_BD_MSSQL);
                    //hh72295:20161104:I: ADECUACION PARA RECUPERAR PASSWORD DESDE DB STBSEGDB Y DESENCRIPTAR CON HSM 
                    Globales.CADENA_CONEXION_SIXSEC = Utilitario.ObtenerCadenaConexionSIXSEC();
                    //hh72295:20161104:F: ADECUACION PARA RECUPERAR PASSWORD DESDE DB STBSEGDB Y DESENCRIPTAR CON HSM 

                    LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.SERVICIO_WINDOWS,
                        Globales.HASHCODE_thrInicioFinDia,
                        "TBEWinServ.LlamadaPasswordRepository",
                        "La cadena de conexion se establecio correctamente y ahora se probara la conectividad.", false);

                    if (Globales.MOSTRAR_CADENA_CNX_LOG)
                    {
                        LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS,
                            Globales.HASHCODE_thrInicioFinDia,
                            "TBEWinServ.LlamadaPasswordRepository",
                            "La cadena de conexion es: [" + Globales.CADENA_CONEXION + "]", false);

                        LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS,
                           Globales.HASHCODE_thrInicioFinDia,
                           "TBEWinServ.LlamadaPasswordRepository",
                           "La cadena de conexion es MSSQL: [" + Globales.CADENA_CONEXION_PLB + "]", false);
                    }

                    //Se prueba la conectividad
                    bool blnExitoSTB = BL_ConectividadBD.ProbarConexionSybase(Globales.CADENA_CONEXION);
                    bool blnExitoPLB = BL_ConectividadBD.ProbarConexionMSSQL(Globales.CADENA_CONEXION_PLB);

                    if (!blnExitoSTB || !blnExitoPLB)
                    {
                        Globales.CADENA_CONEXION = null;
                        Globales.CADENA_CONEXION_PLB = null;
                        Globales.PASSWORD_BD_SYBASE = null;
                        Globales.PASSWORD_BD_MSSQL = null;
                        LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS,
                            Globales.HASHCODE_thrInicioFinDia,
                            "TBEWinServ.LlamadaPasswordRepository",
                            "Se probo la conectividad usando la cadena de conexion y no hubo exito. Se limpia la cadena de conexion. " +
                            "¿CNX STBDB OK? = " + blnExitoSTB.ToString() + "; ¿CNX PLBDB OK?=" + blnExitoPLB.ToString(), true);
                        EstablecerCnxDesdeContingencia();
                    }
                    else
                    {
                        if (Globales.APISEC_CONECTADA_CONTINGENCIA)//Si el api esta conectado con datos de contingencia, lo reseteamos
                        {
                            LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.SERVICIO_WINDOWS,
                                Globales.HASHCODE_thrInicioFinDia, "TBEWinServ.LlamadaPasswordRepository",
                                "Instancia del Api de seg establecida a null para que no use datos de contingencia.", false);

                            Globales.APISEC_CONECTADA_CONTINGENCIA = false;
                            ObjetosGlobalesApp.objAPISEG = null;
                        }

                        LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS,
                            Globales.HASHCODE_thrInicioFinDia, "TBEWinServ.LlamadaPasswordRepository",
                            "La cadena de conexion de BD es correcta y se empleara en el sistema.", false);
                    }
                }
            }                        
        }

        private void RealizarInicioFinalizacionDelDia()
        {
            if (!EstaEnHorarioReposo())
            {
                strDiaActual = DateTime.Today.ToString("yyyyMMdd");

                if (strDiaActual != strDiaAnterior)
                {
                    //Nuevo Dia
                    strDiaAnterior = strDiaActual;

                    //Limpiar variables para que sean cargadas nuevamente en el nuevo dia
                    Globales.CADENA_CONEXION = null;
                    Globales.CADENA_CONEXION_PLB = null;
                    Globales.PASSWORD_BD_SYBASE = null;
                    Globales.PASSWORD_BD_MSSQL = null;
                    Globales.LBTR_PASSWORD = null;
                    Globales.LstTransferenciasEnCurso.Clear();
                }

                switch (strTipoRepositorioClaves)
                {
                    case TipoRepositorioClaves.PSAFE:
                        LlamadaPasswordSafeCnxBD();
                        LlamadaPasswordSafeLogonBCR();
                        break;
                    case TipoRepositorioClaves.PAR:
                        LlamadaPasswordRepositoryCnxBD();
                        //LlamadaPasswordRepositoryLogonBCR();
                        //hh72295:20161104:I: ADECUACION PARA RECUPERAR PASSWORD DESDE DB STBSEGDB Y DESENCRIPTAR CON HSM 
                        LlamadaPasswordHSMLogonBCR();
                        //hh72295:20161104:F: ADECUACION PARA RECUPERAR PASSWORD DESDE DB STBSEGDB Y DESENCRIPTAR CON HSM 
                        break;
                    default: /*Dato Incorrecto*/
                        LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.SERVICIO_WINDOWS,
                           Globales.HASHCODE_thrInicioFinDia,
                           "TBEWinServ.RealizarInicioFinalizacionDelDia",
                           "El parámetro para identificar que repositorio de claves usar es incorrecto, solo debe ser PAR o PSAFE.", NivelMensajeLog.NINGUNO);
                        EstablecerCnxDesdeContingencia();
                        break;
                }

                if (!String.IsNullOrEmpty(Globales.CADENA_CONEXION) && !String.IsNullOrEmpty(Globales.CADENA_CONEXION_PLB) && !String.IsNullOrEmpty(Globales.LBTR_PASSWORD))
                {
                    LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS,
                        Globales.HASHCODE_thrInicioFinDia,
                        "TBEWinServ.RealizarInicioFinalizacionDelDia",
                        "Se invoca al metodo RealizarInicioFinalizacionDelDia.", false);

                    try
                    {
                        //Se verifica la conexion a la bd
                        //Si no hay conexion, se establece a null para que volver a obtener los valores desde el PSafe
                        bool blnExitoSTB = BL_ConectividadBD.ProbarConexionSybase(Globales.CADENA_CONEXION);
                        bool blnExitoPLB = BL_ConectividadBD.ProbarConexionMSSQL(Globales.CADENA_CONEXION_PLB);

                        if (!blnExitoSTB || !blnExitoPLB)
                        {
                            LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS,
                                Globales.HASHCODE_thrInicioFinDia,
                                "TBEWinServ.RealizarInicioFinalizacionDelDia",
                                "Se ha probado la conexion con la Cadena de Conexion actual y no hubo exito. " + 
                                "Se establecen las variables globales a NULL para obtener los parametros nuevamente. " +
                                "¿CNX STBDB OK?=" + blnExitoSTB.ToString() + "; ¿CNX PLBDB OK?=" + blnExitoPLB.ToString(), false);
                            Globales.CADENA_CONEXION = null;
                            Globales.CADENA_CONEXION_PLB = null;
                            Globales.PASSWORD_BD_SYBASE = null;
                            Globales.PASSWORD_BD_MSSQL = null;
                            return;
                        }
                        else
                            this.InicializarApiSeguridad(Globales.HASHCODE_thrInicioFinDia);//solo conecta si el api no esta inicializado

                        if (BL_General.EsFechaLaborable(DateTime.Today))
                        {
                            #region Establecer Horas de Inicio y Finalizacion

                            Dictionary<string, string> dicConfig = BL_General.ObtenerListaConfig();

                            if (dicConfig.ContainsKey(Constantes.PARAM_CODIGO_HORAINI))
                                strHoraInicio = dicConfig[Constantes.PARAM_CODIGO_HORAINI];
                            else
                                throw new Exception("No se ha encontrado la hora de inicio en la tabla T_Config (CodAgrupacion: " +
                                                    Constantes.PARAM_CODIGO_AGRUPACION + ", Codigo: " + Constantes.PARAM_CODIGO_HORAINI + ")");

                            if (dicConfig.ContainsKey(Constantes.PARAM_CODIGO_HORAFIN1))
                                strHoraFinalizacion1 = dicConfig[Constantes.PARAM_CODIGO_HORAFIN1];
                            else
                                throw new Exception("No se ha encontrado la hora de finalizacion 1 en la tabla T_Config (CodAgrupacion: " +
                                                    Constantes.PARAM_CODIGO_AGRUPACION + ", Codigo: " + Constantes.PARAM_CODIGO_HORAFIN1 + ")");

                            if (dicConfig.ContainsKey(Constantes.PARAM_CODIGO_HORAFIN2))
                                strHoraFinalizacion2 = dicConfig[Constantes.PARAM_CODIGO_HORAFIN2];
                            else
                                throw new Exception("No se ha encontrado la hora de finalizacion 2 en la tabla T_Config (CodAgrupacion: " +
                                                    Constantes.PARAM_CODIGO_AGRUPACION + ", Codigo: " + Constantes.PARAM_CODIGO_HORAFIN2 + ")");

                            LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.SERVICIO_WINDOWS,
                                Globales.HASHCODE_thrInicioFinDia,
                                "TBEWinServ.RealizarInicioFinalizacionDelDia",
                                "Parametros de Inicio Fin de Dia. Hora Inicio: " + strHoraInicio +
                                "; Hora Finalizacion 1: " + strHoraFinalizacion1 +
                                "; strHoraFinalizacion 2: " + strHoraFinalizacion2, false);

                            #endregion

                            #region Validar Horas

                            if (!Utilitario.ValidarHora(strHoraInicio)) throw new Exception("El valor de la hora de inicio es incorrecto.");
                            if (!Utilitario.ValidarHora(strHoraFinalizacion1)) throw new Exception("El valor de la hora de finalizacion 1 es incorrecto.");
                            if (!Utilitario.ValidarHora(strHoraFinalizacion2)) throw new Exception("El valor de la hora de finalizacion 2 es incorrecto.");

                            #endregion

                            #region Establecer variables

                            DateTime dtIntervaloInicio = DateTime.Now.AddSeconds(DateTime.Now.Second * -1);
                            DateTime dtIntervaloFin = DateTime.Now.AddSeconds(DateTime.Now.Second * -1).AddMilliseconds(nIntervaloInicioFinDia);
                            DateTime dtHoraInicio = new DateTime(dtIntervaloInicio.Year, dtIntervaloInicio.Month, dtIntervaloInicio.Day,
                                                    int.Parse(strHoraInicio.Substring(0, 2)), int.Parse(strHoraInicio.Substring(3, 2)), 0);
                            DateTime dtHoraFinalizacion = new DateTime(dtIntervaloInicio.Year, dtIntervaloInicio.Month, dtIntervaloInicio.Day,
                                                    int.Parse(strHoraFinalizacion2.Substring(0, 2)), int.Parse(strHoraFinalizacion2.Substring(3, 2)), 0);
                            #endregion

                            #region Manejo de Horas cuando el intervalo se da entre el dia actual y el siguiente

                            if (dtIntervaloInicio.Day != dtIntervaloFin.Day)
                            {
                                if (int.Parse(strHoraInicio.Substring(0, 2)) <= dtIntervaloFin.Hour)
                                    dtHoraInicio = new DateTime(dtIntervaloFin.Year, dtIntervaloFin.Month, dtIntervaloFin.Day,
                                                        int.Parse(strHoraInicio.Substring(0, 2)), int.Parse(strHoraInicio.Substring(3, 2)), 0);

                                if (int.Parse(strHoraFinalizacion2.Substring(0, 2)) <= dtIntervaloFin.Hour)
                                    dtHoraFinalizacion = new DateTime(dtIntervaloFin.Year, dtIntervaloFin.Month, dtIntervaloFin.Day,
                                                        int.Parse(strHoraFinalizacion2.Substring(0, 2)), int.Parse(strHoraFinalizacion2.Substring(3, 2)), 0);
                            }

                            #endregion

                            #region Realizando Logon

                            if (String.IsNullOrEmpty(Globales.SID) && dtIntervaloFin >= dtHoraInicio && dtIntervaloFin <= dtHoraFinalizacion)
                            {

                                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS,
                                    Globales.HASHCODE_thrInicioFinDia,
                                    "TBEWinServ.RealizarInicioFinalizacionDelDia",
                                    "Se invocara a metodo logon del servicio de autenticacion del BCRP.", false);

                                Globales.SID = (new BL_Autenticacion(Globales.HASHCODE_thrInicioFinDia)).Logon();

                                if (!String.IsNullOrEmpty(Globales.SID))
                                {
                                    LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS,
                                        Globales.HASHCODE_thrInicioFinDia,
                                        "TBEWinServ.RealizarInicioFinalizacionDelDia",
                                        "Se obtuvo el SID correctamente del servicio LBTR Web del BCRP.", false);
                                }
                                else
                                {
                                    LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS,
                                        Globales.HASHCODE_thrInicioFinDia,
                                        "TBEWinServ.RealizarInicioFinalizacionDelDia",
                                        "No se pudo obtener el SID del servicio LBTR Web del BCRP.", false);
                                }
                            }

                            #endregion

                            #region Realizando Logoff

                            if (!String.IsNullOrEmpty(Globales.SID))
                            {
                                DateTime dtMedianoche = new DateTime(dtIntervaloInicio.Year, dtIntervaloInicio.Month, dtIntervaloInicio.Day, 23, 50, 0);

                                if (dtIntervaloFin >= dtMedianoche)
                                {
                                    ActualizarHoraFinalizacion2(strHoraFinalizacion1);
                                    LBTR_Logoff(Globales.HASHCODE_thrInicioFinDia);
                                }
                                else
                                {
                                    if (dtIntervaloFin >= dtHoraFinalizacion)
                                    {
                                        ActualizarHoraFinalizacion2(strHoraFinalizacion1);
                                        LBTR_Logoff(Globales.HASHCODE_thrInicioFinDia);
                                    }
                                }
                            }

                            #endregion

                        }
                        else
                        {
                            LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS,
                                Globales.HASHCODE_thrInicioFinDia,
                                "TBEWinServ.RealizarInicioFinalizacionDelDia",
                                "No se inicia el dia (Logon) debido a que es un dia no laborable.", false);
                        }
                    }
                    catch (Exception ex)
                    {
                        LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS,
                            Globales.HASHCODE_thrInicioFinDia,
                            "TBEWinServ.RealizarInicioFinalizacionDelDia",
                            "Error, mensaje: " + ex.Message + "; stackTrace: " + ex.StackTrace, true);
                    }

                    LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS,
                        Globales.HASHCODE_thrInicioFinDia,
                        "TBEWinServ.RealizarInicioFinalizacionDelDia",
                        "Finaliza el metodo RealizarInicioFinalizacionDelDia.", false);
                }
            }
        }

        private void ActualizarHoraFinalizacion2(string prmHora) {
            (new BL_General(Globales.HASHCODE_thrInicioFinDia)).ActualizarConfig(Constantes.PARAM_CODIGO_AGRUPACION, Constantes.PARAM_CODIGO_HORAFIN2, prmHora);
        }

        private void LBTR_Logoff(string prmHashCodeOrigen) 
        {
            LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS, prmHashCodeOrigen, 
                "TBEWinServ.LBTR_Logoff",
                "Se invoca a LBTR_Logoff para llamar al metodo Logoff del servicio de autenticacion del LBTR Web del BCRP.", false);

            try
            {
                if ((new BL_Autenticacion(prmHashCodeOrigen)).Logoff())
                {
                    LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS, prmHashCodeOrigen,
                        "TBEWinServ.LBTR_Logoff",
                        "Se hizo logoff correctamente en el servicio LBTR Web del BCRP.", false);
                }
                else
                {
                    LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS, prmHashCodeOrigen,
                        "TBEWinServ.LBTR_Logoff",
                        "No se pudo hacer logoff en el servicio LBTR Web del BCRP.", false);
                    /*
                     * Si falla el logoff, de todas maneras se establecen las variables globales a null
                     * para que sean establecidas nuevamente en la siguiente iteracion.
                     * Si luego se realiza una transferencia, el BCRP retornaria el error 
                     * "La institucion ya tiene una sesion activa: -195"
                     */
                }
            }
            catch (Exception ex)
            {
                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS, prmHashCodeOrigen,
                    "TBEWinServ.LBTR_Logoff",
                    "Error: \r\n" + ex.Message + "\r\n" + ex.StackTrace, true);
            }

            Globales.SID = null;
        }               

        private void Iniciar_Servicio(TipoServicio prmTipoServicio, String prmHashcode)
        {
            if (!EstaEnHorarioReposo())
            {
                BL_Transaccion oTransaccion = new BL_Transaccion(prmTipoServicio, prmHashcode);
                oTransaccion.TramaMQ = oTramaMQ;
                oTransaccion.Procesar();
            }
        }

        /// <summary>
        /// Se inicializa solo una vez. Se finaliza cuando el servicio sea desinstalado (uninstall.bat).
        /// </summary>
        /// <param name="prmHashcode"></param>
        private void InicializarApiSeguridad(string prmHashcode) 
        {
            //Se inicializa la variable global y se intenta conectar a la bd del six security.
            //Si no hay conexion, no se lograra inicializar la variable global
            if (Globales.APISEGURIDAD_USAR && ObjetosGlobalesApp.objAPISEG == null)
            {
                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS, prmHashcode,
                    "TBEWinServ.InicializarApiSeguridad",
                    "Se procede a inicializar el api de seguridad", false);

                Globales.THRINICIODIA_BLNAPIINVOCADO = true;
                Globales.THRINICIODIA_DTULTINVOCAPI = DateTime.Now;
                ObjetosGlobalesApp.objAPISEG = (new BL_SeguridadMsj(prmHashcode)).Conectar_a_BaseDatos();
                Globales.THRINICIODIA_BLNAPIINVOCADO = false;
            }
        }

        private void RealizarAperturaCierreDeBatchBCosmos()
        {
            if (!EstaEnHorarioReposo())
            {
                //if (!String.IsNullOrEmpty(Globales.CADENA_CONEXION) && !String.IsNullOrEmpty(Globales.LBTR_PASSWORD))
                if (!String.IsNullOrEmpty(Globales.CADENA_CONEXION))
                {
                    LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS,
                        Globales.HASHCODE_thrInicioFinDiaBCosmos,
                        "TBEWinServ.RealizarAperturaCierreDeBatchBCosmos",
                        "Se invoca al metodo RealizarAperturaCierreDeBatchBCosmos.", NivelMensajeLog.NINGUNO);

                    try
                    {
                        if (BL_General.EsFechaLaborable(DateTime.Today))
                        {
                            BL_General oBLGeneral = new BL_General(Globales.HASHCODE_thrInicioFinDiaBCosmos);
                            string strEstadoBatch = oBLGeneral.ObtenerValorParametro(Constantes.PARAM_CODIGO_BCOSMOS_ESTADO_BATCH);

                            #region Establecer Horas de Apertura y Cierre de Batch

                            Dictionary<string, string> dicConfig = BL_General.ObtenerListaConfigBCosmos();

                            if (dicConfig.ContainsKey(Constantes.PARAM_CODIGO_BCOSMOS_HORAINI))
                                strHoraApertura = dicConfig[Constantes.PARAM_CODIGO_BCOSMOS_HORAINI];
                            else
                                throw new Exception("No se ha encontrado la hora de apertura del batch en la tabla T_Config (CodAgrupacion: " +
                                                    Constantes.PARAM_CODIGO_AGRUPACION + ", Codigo: " + Constantes.PARAM_CODIGO_BCOSMOS_HORAINI + ")");

                            if (dicConfig.ContainsKey(Constantes.PARAM_CODIGO_BCOSMOS_HORAFIN1))
                                strHoraCierre1 = dicConfig[Constantes.PARAM_CODIGO_BCOSMOS_HORAFIN1];
                            else
                                throw new Exception("No se ha encontrado la hora de cierre 1 del batch en la tabla T_Config (CodAgrupacion: " +
                                                    Constantes.PARAM_CODIGO_AGRUPACION + ", Codigo: " + Constantes.PARAM_CODIGO_BCOSMOS_HORAFIN1 + ")");

                            if (dicConfig.ContainsKey(Constantes.PARAM_CODIGO_BCOSMOS_HORAFIN2))
                                strHoraCierre2 = dicConfig[Constantes.PARAM_CODIGO_BCOSMOS_HORAFIN2];
                            else
                                throw new Exception("No se ha encontrado la hora de cierre 2 del batch en la tabla T_Config (CodAgrupacion: " +
                                                    Constantes.PARAM_CODIGO_AGRUPACION + ", Codigo: " + Constantes.PARAM_CODIGO_BCOSMOS_HORAFIN2 + ")");

                            LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.SERVICIO_WINDOWS,
                                Globales.HASHCODE_thrInicioFinDiaBCosmos,
                                "TBEWinServ.RealizarInicioFinalizacionDelDiaBCosmos",
                                "Parametros de Apertura y Cierre del Batch de BCosmos. Hora Apertura: " + strHoraApertura +
                                "; Hora Cierre 1: " + strHoraCierre1 +
                                "; Hora Cierre 2: " + strHoraCierre2, NivelMensajeLog.NINGUNO);

                            #endregion

                            #region Validar Horas

                            if (!Utilitario.ValidarHora(strHoraApertura)) throw new Exception("El valor de la hora de apertura del batch es incorrecto.");
                            if (!Utilitario.ValidarHora(strHoraCierre1)) throw new Exception("El valor de la hora de cierre 1 del batch es incorrecto.");
                            if (!Utilitario.ValidarHora(strHoraCierre2)) throw new Exception("El valor de la hora de cierre 2 del batch es incorrecto.");

                            #endregion

                            #region Establecer variables

                            DateTime dtIntervaloInicio = DateTime.Now.AddSeconds(DateTime.Now.Second * -1);
                            DateTime dtIntervaloFin = DateTime.Now.AddSeconds(DateTime.Now.Second * -1).AddMilliseconds(nIntervaloAperturaCierreBatchBCosmos);
                            DateTime dtHoraInicio = new DateTime(dtIntervaloInicio.Year, dtIntervaloInicio.Month, dtIntervaloInicio.Day,
                                                    int.Parse(strHoraApertura.Substring(0, 2)), int.Parse(strHoraApertura.Substring(3, 2)), 0);
                            DateTime dtHoraFinalizacion = new DateTime(dtIntervaloInicio.Year, dtIntervaloInicio.Month, dtIntervaloInicio.Day,
                                                    int.Parse(strHoraCierre2.Substring(0, 2)), int.Parse(strHoraCierre2.Substring(3, 2)), 0);

                            #endregion

                            #region Manejo de Horas cuando el intervalo se da entre el dia actual y el siguiente

                            if (dtIntervaloInicio.Day != dtIntervaloFin.Day)
                            {
                                if (int.Parse(strHoraApertura.Substring(0, 2)) <= dtIntervaloFin.Hour)
                                    dtHoraInicio = new DateTime(dtIntervaloFin.Year, dtIntervaloFin.Month, dtIntervaloFin.Day,
                                                        int.Parse(strHoraApertura.Substring(0, 2)), int.Parse(strHoraApertura.Substring(3, 2)), 0);

                                if (int.Parse(strHoraCierre2.Substring(0, 2)) <= dtIntervaloFin.Hour)
                                    dtHoraFinalizacion = new DateTime(dtIntervaloFin.Year, dtIntervaloFin.Month, dtIntervaloFin.Day,
                                                        int.Parse(strHoraCierre2.Substring(0, 2)), int.Parse(strHoraCierre2.Substring(3, 2)), 0);
                            }

                            #endregion

                            #region Realizando Apertura del Batch

                            if (strEstadoBatch.ToUpper() == Constantes.INDICADOR_CIERRE_BATCH &&
                                dtIntervaloFin >= dtHoraInicio &&
                                dtIntervaloFin <= dtHoraFinalizacion)
                            {
                                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS,
                                    Globales.HASHCODE_thrInicioFinDiaBCosmos,
                                    "TBEWinServ.RealizarAperturaCierreDeBatchBCosmos",
                                    "Se intentara realizar la apertura del batch de BCosmos.", NivelMensajeLog.NINGUNO);

                                new BL_EnvioBCosmos(Globales.HASHCODE_thrInicioFinDiaBCosmos, oTramaMQ).AperturarBatch();
                            }

                            #endregion

                            #region Realizando Cierre del Batch

                            if (strEstadoBatch.ToUpper() == Constantes.INDICADOR_APERTURA_BATCH)
                            {
                                DateTime dtMedianoche = new DateTime(dtIntervaloInicio.Year, dtIntervaloInicio.Month, dtIntervaloInicio.Day, 23, 50, 0);
                                bool blnCierre = false;

                                if (dtIntervaloFin >= dtMedianoche)
                                {
                                    oBLGeneral.ActualizarConfig(Constantes.PARAM_CODIGO_AGRUPACION, Constantes.PARAM_CODIGO_BCOSMOS_HORAFIN2, strHoraCierre1);
                                    blnCierre = true;
                                }
                                else
                                {
                                    if (dtIntervaloFin >= dtHoraFinalizacion)
                                    {
                                        oBLGeneral.ActualizarConfig(Constantes.PARAM_CODIGO_AGRUPACION, Constantes.PARAM_CODIGO_BCOSMOS_HORAFIN2, strHoraCierre1);
                                        blnCierre = true;
                                    }
                                }

                                if (blnCierre)
                                {
                                    LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS,
                                    Globales.HASHCODE_thrInicioFinDiaBCosmos,
                                    "TBEWinServ.RealizarAperturaCierreDeBatchBCosmos",
                                    "Se intentara realizar el cierre del batch de BCosmos.", NivelMensajeLog.NINGUNO);

                                    new BL_EnvioBCosmos(Globales.HASHCODE_thrInicioFinDiaBCosmos, oTramaMQ).CerrarBatch();
                                }
                            }

                            #endregion
                        }
                        else
                        {
                            LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS,
                                Globales.HASHCODE_thrInicioFinDiaBCosmos,
                                "TBEWinServ.RealizarAperturaCierreDeBatchBCosmos",
                                "No se verifica si se aperturo o cerro el batch debido a que es un dia no laborable.", 
                                NivelMensajeLog.NINGUNO);
                        }
                    }
                    catch (Exception ex)
                    {
                        LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS,
                            Globales.HASHCODE_thrInicioFinDiaBCosmos,
                            "TBEWinServ.RealizarAperturaCierreDeBatchBCosmos",
                            "Error, mensaje: " + ex.Message + "; stackTrace: " + ex.StackTrace, NivelMensajeLog.ERROR);
                    }

                    LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS,
                        Globales.HASHCODE_thrInicioFinDiaBCosmos,
                        "TBEWinServ.RealizarAperturaCierreDeBatchBCosmos",
                        "Finaliza el metodo RealizarAperturaCierreDeBatchBCosmos.", NivelMensajeLog.NINGUNO);
                }
            }
        }

        //hh72295:20161104:I: ADECUACION PARA RECUPERAR PASSWORD DESDE DB STBSEGDB Y DESENCRIPTAR CON HSM 
        private void LlamadaPasswordHSMLogonBCR()
        {
            try
            {
                string strMensajeError = "";
                string strHashcode = Utilitario.RetornaHashCode(Thread.CurrentThread.GetHashCode()) + DateTime.Now.ToString("HHmmss");
                //hh72295:20161104:I: SACAR ESTO, SE PUSO SOLO PARA PRUEBA
                //Globales.LBTR_PASSWORD = (new BL_ConexionAlterna(Globales.HASHCODE_thrInicioFinDia)).ObtenerPwdLogonBCRP();
                //hh72295:20161104:F: SACAR ESTO, SE PUSO SOLO PARA PRUEBA
                if (String.IsNullOrEmpty(Globales.LBTR_PASSWORD))
                {
                    LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.SERVICIO_WINDOWS, Globales.HASHCODE_thrInicioFinDia,
                    "TBEWinServ.LlamadaPasswordHSMLogonBCR",
                    "Se invoca al metodo LlamadaPasswordHSMLogonBCR para establecer el password de inicio de dia en los servicios del BCRP.", false);

                    if (Globales.APISEGURIDAD_USAR && ObjetosGlobalesApp.objAPISEG == null)
                    {
                        LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS, strHashcode,
                            "TBEWinServ.LlamadaPasswordHSMLogonBCR", "Se procede a inicializar el api de seguridad", false);

                        Globales.THRINICIODIA_BLNAPIINVOCADO = true;
                        Globales.THRINICIODIA_DTULTINVOCAPI = DateTime.Now;
                        ObjetosGlobalesApp.objAPISEG = (new BL_SeguridadMsj(strHashcode)).Conectar_a_BaseDatos();
                        Globales.THRINICIODIA_BLNAPIINVOCADO = false;
                    }

                    //RECUPERANDO PWD ENCRIPTADO Y CLAVE DES GUARDA EN TABLA [TP_PARAMETRO] DE LA DB [STBSEGDB]
                    string ostrPasswordCifradoLogonLBTR = "";
                    string ostrClaveDESCifradoLogonLBTR = "";
                    string strLBTR_PASSWORD = "";
                    DA_Transferencia daTransf = new DA_Transferencia(strHashcode);
                    daTransf.Obtener_SecurityData_LogonLBTR(out ostrPasswordCifradoLogonLBTR, out ostrClaveDESCifradoLogonLBTR);
                    BL_General oBLGen = new BL_General(strHashcode);
                    string strCodigoCITI = oBLGen.ObtenerValorConfiguracion(Constantes.PARAM_CODIGO_CITIBANK);
                    List<BE_Banco> lstBancos = oBLGen.ObtenerBancos(new BE_Banco());
                    BE_Banco oBancoCITI = lstBancos.Find(delegate(BE_Banco oBancoParamCITI) { return oBancoParamCITI.CodBanco == strCodigoCITI; });
                    string strFuncionApiEmpleada = "fDescifrarMensaje_3DES_RSA";
                    int nCodigoRetorno = ObjetosGlobalesApp.objAPISEG.fDescifrarMensaje_3DES_RSA(ostrPasswordCifradoLogonLBTR,
                                                                                                ostrClaveDESCifradoLogonLBTR,
                                                                                                strCodigoCITI,
                                                                                                oBancoCITI.IndiceKPri.Value,
                                                                                                ref strLBTR_PASSWORD);
                    LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.SEGURIDAD,
                        strHashcode,
                        "TBEWinServ.LlamadaPasswordHSMLogonBCR",
                        "Se invoca el metodo fDescifrarMensaje_3DES_RSA del api, con los siguientes parametros:" + "\r\n" +
                        "PwdCifrado logon LBTR: " + ostrPasswordCifradoLogonLBTR + "\r\n" +
                        "KsimCifrado: " + ostrClaveDESCifradoLogonLBTR + "\r\n" +
                        "Código institución: " + strCodigoCITI + "\r\n" +
                        "Ind. Clave Privada : " + oBancoCITI.IndiceKPri.Value, false);
                    //+ "\r\n" + ":" + strLBTR_PASSWORD
                    if (nCodigoRetorno == 0)
                    {
                        Globales.LBTR_PASSWORD = strLBTR_PASSWORD;
                        LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS,
                            Globales.HASHCODE_thrInicioFinDia,
                            "TBEWinServ.LlamadaPasswordHSMLogonBCR",
                            "El password para la autenticacion en los servicios web LBTR fueron establecidos correctamente.", false);
                        (new BL_ConexionAlterna(Globales.HASHCODE_thrInicioFinDia)).GuardarPwdLogonBCRP(Globales.LBTR_PASSWORD);
                    }
                    else
                    {
                        strMensajeError = "";
                        BE_ErrorApiSeguridad prmErrorApi = oBLGen.ObtenerErrorApiSeguridad(strFuncionApiEmpleada,
                                                                        nCodigoRetorno.ToString(),
                                                                        out strMensajeError);
                        LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SEGURIDAD, strHashcode, "TBEWinServ.LlamadaPasswordHSMLogonBCR", "Error:" + strMensajeError, false);

                        Globales.LBTR_PASSWORD = null;
                        LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS,
                            Globales.HASHCODE_thrInicioFinDia,
                            "TBEWinServ.LlamadaPasswordHSMLogonBCR",
                            "No se pudo obtener el password para la autenticacion en los servicios web LBTR del BCRP desde el Password Repository.", false);

                        LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS,
                            Globales.HASHCODE_thrInicioFinDia,
                            "TBEWinServ.LlamadaPasswordHSMLogonBCR",
                            "Se procede a obtener el password de contingencia para realizar la autenticacion en los servicios web LBTR del BCRP.", false);

                        Globales.LBTR_PASSWORD = (new BL_ConexionAlterna(Globales.HASHCODE_thrInicioFinDia)).ObtenerPwdLogonBCRP();

                        if (!String.IsNullOrEmpty(Globales.LBTR_PASSWORD))
                        {
                            LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS,
                                Globales.HASHCODE_thrInicioFinDia,
                                "TBEWinServ.LlamadaPasswordHSMLogonBCR",
                                "[CONTINGENCIA] Se obtuvo el password de contingencia para realizar la autenticacion en los servicios web LBTR del BCRP.", false);
                        }
                        else
                        {
                            LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS,
                                Globales.HASHCODE_thrInicioFinDia,
                                "TBEWinServ.LlamadaPasswordHSMLogonBCR",
                                "[CONTINGENCIA] No se pudo obtener un valor para el password de inicio de dia en BCRP. No se podra realizar el proceso de Logon en los servicios del BCRP. Hacer uso de la consola de contingencia [TBEWinServ.Consola.exe] para establecer el password de Inicio de Dia en BCRP.", true);
                        }
                    }
                }
                else
                {
                    if (blnActualizarPwdLogon)
                    {
                        if (((new BL_ConexionAlterna(Globales.HASHCODE_thrInicioFinDia)).GuardarPwdLogonBCRP(Globales.LBTR_PASSWORD)) == false)
                        {
                            LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS,
                                Globales.HASHCODE_thrInicioFinDia,
                                "TBEWinServ.LlamadaPasswordRepository",
                                "No se pudo actualizar la contingencia del password de inicio de dia en BCRP en la base de datos. Ver el detalle en el log.", true);
                        }
                        else
                        {
                            LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.SERVICIO_WINDOWS,
                                Globales.HASHCODE_thrInicioFinDia,
                                "TBEWinServ.LlamadaPasswordRepository",
                                "Se actualizo la contingencia del password de inicio de dia en BCRP en la base de datos.", false);
                        }
                        blnActualizarPwdLogon = false;
                    }
                }
            }
            catch (Exception ex)
            {
                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS,
                Globales.HASHCODE_thrInicioFinDia,
                "TBEWinServ.LlamadaPasswordRepository",
                "Error, mensaje: " + ex.Message + "; stackTrace: " + ex.StackTrace, true);
            }
        }
        //hh72295:20161104:F: ADECUACION PARA RECUPERAR PASSWORD DESDE DB STBSEGDB Y DESENCRIPTAR CON HSM 
        #endregion                
    }
        
}
