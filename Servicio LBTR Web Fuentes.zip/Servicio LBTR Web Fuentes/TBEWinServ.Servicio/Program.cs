﻿using System.Collections.Generic;
using System.ServiceProcess;
using System.Text;

namespace TBEWinServ.Servicio
{
    static class Program
    {
        /// <summary>
        /// Punto de entrada principal para la aplicacion.
        /// </summary>
        static void Main()
        {
            ServiceBase[] ServicesToRun;

            // Se puede ejecutar mas de un servicio de usuario dentro del mismo proceso. Para agregar
            // otro servicio a este proceso, cambie la siguiente linea para
            // crear un segundo objeto de servicio. Por ejemplo,
            //
            //   ServicesToRun = new ServiceBase[] {new Service1(), new MySecondUserService()};
            //
            ServicesToRun = new ServiceBase[] { new TBEWinServ() };

            ServiceBase.Run(ServicesToRun);
        }
    }
}