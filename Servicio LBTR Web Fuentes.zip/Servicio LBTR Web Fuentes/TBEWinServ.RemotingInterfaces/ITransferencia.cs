using System;
using System.Text;
using TBEWinServ.EntidadesNegocio.Transferencia;

namespace TBEWinServ.RemotingInterfaces
{
    public interface ITransferencia
    {
        int EnviarTransferencia(BE_Transferencia prmTransferencia);
        int ConfirmarAbonoCliente(string prmNumRefLBTR);
        int AnularOperacionPendiente(string prmNumRefLBTR);
    }
}
