using System;
using System.Text;
using TBEWinServ.EntidadesNegocio.ConsultasBCRP;

namespace TBEWinServ.RemotingInterfaces
{
    public interface IConsultasBCRP
    {
        int ConsultarOperacionesOtorgadas(BE_ConsultaBCRP prmConsultaBCRP);
        int ConsultarOperacionesRecibidas(BE_ConsultaBCRP prmConsultaBCRP, bool blnUsarLlavesActuales);
        int ConsultarSaldosCtaCte(BE_ConsultaBCRP prmConsultaBCRP);
    }
}
