using System;
using System.Collections.Generic;
using System.Text;

namespace TBEWinServ.RemotingInterfaces
{
    public interface IAuditoria
    {
        int ConsultarAuditoria(string prmIdConsulta, string prmTipoOperacion, string prmEstados, string prmFechaIni, string prmFechaFin, string prmCodBanco, string prmCodConcepto, bool blnUsarLlavesActuales);
    }
}
