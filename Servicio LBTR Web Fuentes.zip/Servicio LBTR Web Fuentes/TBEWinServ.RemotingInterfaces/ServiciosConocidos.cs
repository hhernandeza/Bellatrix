using System;
using System.Text;

namespace TBEWinServ.RemotingInterfaces
{
    public struct ServiciosConocidos
    {
        public const string Transferencia = "Transferencia.rem";
        public const string ConsultasBCRP = "ConsultasBCRP.rem";
        public const string Auditoria = "Auditoria.rem";
    }
}
