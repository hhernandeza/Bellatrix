using System;
using System.Collections.Generic;
using System.Text;
using secapiwnd;

namespace TBEWinServ.ObjetosGlobales
{
    public static class ObjetosGlobalesApp
    {
        public static securityAPI objAPISEG = null;
    }
}
