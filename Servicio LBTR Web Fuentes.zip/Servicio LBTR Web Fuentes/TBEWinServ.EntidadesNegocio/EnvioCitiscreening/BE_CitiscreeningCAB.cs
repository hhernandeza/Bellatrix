﻿//hh72295:20170117:I: ADECUACION CITISCREENING EN OPERACIONES DE ENTRADA
using System;
using System.Collections.Generic;
using System.Text;

namespace TBEWinServ.EntidadesNegocio.EnvioCitiscreening
{
    public class BE_CitiscreeningCAB
    {
        private string strSECUENCIA;

        public string SECUENCIA 
        {
            get { return strSECUENCIA; }
            set { strSECUENCIA = value; }
        }

        private string strFECHA;

        public string FECHA
        {
            get { return strFECHA; }
            set { strFECHA = value; }
        }

        private string strTRAMAINPUT;

        public string TRAMAINPUT
        {
            get { return strTRAMAINPUT; }
            set { strTRAMAINPUT = value; }
        }

        private string strNUMEROHITS;

        public string NUMEROHITS
        {
            get { return strNUMEROHITS; }
            set { strNUMEROHITS = value; }
        }

        private string strOBSMAKER;

        public string OBSMAKER  
        {
            get { return strOBSMAKER; }
            set { strOBSMAKER = value; }
        }

        private decimal strMAKER;

        public decimal MAKER
        {
            get { return strMAKER; }
            set { strMAKER = value; }
        }

        private string strFECMAKER;

        public string FECMAKER
        {
            get { return strFECMAKER; }
            set { strFECMAKER = value; }
        }

        private string strOBSCHECKER;

        public string OBSCHECKER
        {
            get { return strOBSCHECKER; }
            set { strOBSCHECKER = value; }
        }

        private string strCHECKER;

        public string CHECKER   
        {
            get { return strCHECKER; }
            set { strCHECKER = value; }
        }

        private string strFECCHECKER;

        public string FECCHECKER 
        {
            get { return strFECCHECKER; }
            set { strFECCHECKER = value; }
        }

        private string strESTADOMK;

        public string ESTADOMK  
        {
            get { return strESTADOMK; }
            set { strESTADOMK = value; }
        }

        private string strESTADOCH;

        public string ESTADOCH 
        {
            get { return strESTADOCH; }
            set { strESTADOCH = value; }
        }

        private string strESTADOCS;

        public string ESTADOCS
        {
            get { return strESTADOCS; }
            set { strESTADOCS = value; }
        }

        private string strFLAGWFCS;

        public string FLAGWFCS
        {
            get { return strFLAGWFCS; }
            set { strFLAGWFCS = value; }
        }

        private string strDISPOSITIONDETAILWFCS;

        public string DISPOSITIONDETAILWFCS
        {
            get { return strDISPOSITIONDETAILWFCS; }
            set { strDISPOSITIONDETAILWFCS = value; }
        }

        private string strNUMREINTENTOS;

        public string NUMREINTENTOS
        {
            get { return strNUMREINTENTOS; }
            set { strNUMREINTENTOS = value; }
        }
    }
}
//hh72295:20170117:F: ADECUACION CITISCREENING EN OPERACIONES DE ENTRADA
