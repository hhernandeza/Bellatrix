﻿//hh72295:20170117:I: ADECUACION CITISCREENING EN OPERACIONES DE ENTRADA
using System;
using System.Collections.Generic;
using System.Text;

namespace TBEWinServ.EntidadesNegocio.EnvioCitiscreening
{
    public class BE_EnvioCitiscreening
    {
        //BCRP_REFER
        string strBcrpRefer;

        public string BcrpRefer
        {
            get { return strBcrpRefer; }
            set { strBcrpRefer = value; }
        }

        //BCRP_FECHA
        string strFecha;

        public string Fecha
        {
            get { return strFecha; }
            set { strFecha = value; }
        }

        //BCOORIG
        string strBcoOrig;

        public string BcoOrig
        {
            get { return strBcoOrig; }
            set { strBcoOrig = value; }
        }

        //OPER_MONTO
        string strOperMonto;

        public string OperMonto
        {
            get { return strOperMonto; }
            set { strOperMonto = value; }
        }

        //INDICADORITF
        string strIndicadorItf;

        public string IndicadorItf
        {
            get { return strIndicadorItf; }
            set { strIndicadorItf = value; }
        }

        //NUMDOCORDENANTE
        string strNumDocOrdenante;

        public string NumDocOrdenante
        {
            get { return strNumDocOrdenante; }
            set { strNumDocOrdenante = value; }
        }

        //TIPODOCORDENANTE
        string strTipoDocOrdenante;

        public string TipoDocOrdenante
        {
            get { return strTipoDocOrdenante; }
            set { strTipoDocOrdenante = value; }
        }

        //CODMONEDA
        string strCodMoneda;

        public string CodMoneda
        {
            get { return strCodMoneda; }
            set { strCodMoneda = value; }
        }

        //OPER_CTA
        string strOperCta;

        public string OperCta
        {
            get { return strOperCta; }
            set { strOperCta = value; }
        }

        //NRO_CUENTA
        string strNroCta;

        public string NroCta
        {
            get { return strNroCta; }
            set { strNroCta = value; }
        }

        string strOperCtaTmp;

        public string OperCtaTmp
        {
            get { return strOperCtaTmp; }
            set { strOperCtaTmp = value; }
        }

        //IND_OMITVALNDOC
        string strIndOmitValnDoc;

        public string IndOmitValnDoc
        {
            get { return strIndOmitValnDoc; }
            set { strIndOmitValnDoc = value; }
        }

        //C_ENTIDAD
        string strEntidad;

        public string Entidad
        {
            get { return strEntidad; }
            set { strEntidad = value; }
        }

        //NUEVOS CAMPOS
        //BCRP_HORA
        string strBcrpHora;

        public string BcrpHora
        {
            get { return strBcrpHora; }
            set { strBcrpHora= value; }
        }

        //BCOORIG_REF
        string strBcoOrigRef;

        public string BcoOrigRef
        {
            get { return strBcoOrigRef; }
            set { strBcoOrigRef = value; }
        }

        //BCOORIG_REFSEC
        string strBcoOrigRefSec;

        public string BcoOrigRefSec
        {
            get { return strBcoOrigRefSec; }
            set { strBcoOrigRefSec = value; }
        }

        //CTADEST_NROCTA
        string strCtaDestNroCta;

        public string CtaDestNroCta
        {
            get { return strCtaDestNroCta; }
            set { strCtaDestNroCta = value; }
        }

        //CTADEST_BCOCTA
        string strCtaDestBcoCta;

        public string CtaDestBcoCta
        {
            get { return strCtaDestBcoCta; }
            set { strCtaDestBcoCta = value; }
        }

        //CTADEST_SUBCTA
        string strCtaDestSubCta;

        public string CtaDestSubCta
        {
            get { return strCtaDestSubCta; }
            set { strCtaDestSubCta = value; }
        }

        //CTADEST_MONCTA
        string strCtaDestMonCta;

        public string CtaDestMonCta
        {
            get { return strCtaDestMonCta; }
            set { strCtaDestMonCta = value; }
        }
        
        //OPER_COD
        string strOperCod;

        public string OperCod
        {
            get { return strOperCod; }
            set { strOperCod = value; }
        }

        //OPER_OBS
        string strOperSBS;

        public string OperSBS
        {
            get { return strOperSBS; }
            set { strOperSBS = value; }
        }

        //OPER_FIRMA
        string strOperFirma;

        public string OperFirma
        {
            get { return strOperFirma; }
            set { strOperFirma = value; }
        }

        //OPER_MODO_TRANS
        string strOperModoTrans;

        public string OperModoTrans
        {
            get { return strOperModoTrans; }
            set { strOperModoTrans = value; }
        }

        //OPER_PROCEDENCIA
        string strOperProcedencia;

        public string OperProcedencia
        {
            get { return strOperProcedencia; }
            set { strOperProcedencia = value; }
        }

        //ADES
        string strADES;

        public string ADES
        {
            get { return strADES; }
            set { strADES = value; }
        }

        //GENERO_ADES
        string strGeneroADES;

        public string GeneroADES
        {
            get { return strGeneroADES; }
            set { strGeneroADES = value; }
        }

        //CODBANCODESTINO
        string strCodBancoDestino;

        public string CodBancoDestino
        {
            get { return strCodBancoDestino; }
            set { strCodBancoDestino = value; }
        }

        //CUENTAORIGEN
        string strCuentaOrigen;

        public string CuentaOrigen
        {
            get { return strCuentaOrigen; }
            set { strCuentaOrigen = value; }
        }

        //CUENTADESTINO
        string strCuentaDestino;

        public string CuentaDestino
        {
            get { return strCuentaDestino; }
            set { strCuentaDestino = value; }
        }

        //TIPOCAMBIO
        string strTipoCambio;

        public string TipoCambio
        {
            get { return strTipoCambio; }
            set { strTipoCambio = value; }
        }

        //NUMREFORIGEN
        string strNumRefOrigen;

        public string NumRefOrigen
        {
            get { return strNumRefOrigen; }
            set { strNumRefOrigen = value; }
        }

        //NUMREFLBTRENLACE
        string strNumRefLBTREnlace;

        public string NumRefLBTREnlace
        {
            get { return strNumRefLBTREnlace; }
            set { strNumRefLBTREnlace = value; }
        }

        //PRIORIDAD
        string strPrioridad;

        public string Prioridad
        {
            get { return strPrioridad; }
            set { strPrioridad= value; }
        }

        //CONFIRMAABONO
        string strConfirmaAbono;

        public string ConfirmaAbono
        {
            get { return strConfirmaAbono; }
            set { strConfirmaAbono = value; }
        }

        //ESTADOLIQUIDACION
        string strEstadoLiquidacion;

        public string EstadoLiquidacion
        {
            get { return strEstadoLiquidacion; }
            set { strEstadoLiquidacion = value; }
        }

        //CCIORDENANTE
        string strCCIOrdenante;

        public string CCIOrdenante
        {
            get { return strCCIOrdenante; }
            set { strCCIOrdenante = value; }
        }

        //NOMBREORDENANTE
        string strNombreOrdenante;

        public string NombreOrdenante
        {
            get { return strNombreOrdenante; }
            set { strNombreOrdenante = value; }
        }

        //DIRECCIONORDENANTE
        string strDireccionOrdenante;

        public string DireccionOrdenante
        {
            get { return strDireccionOrdenante; }
            set { strDireccionOrdenante  = value; }
        }

        //CCIBENEFICIARIO
        string strCCIBeneficiario;

        public string CCIBeneficiario
        {
            get { return strCCIBeneficiario; }
            set { strCCIBeneficiario = value; }
        }

        //NOMBREBENEFICIARIO
        string strNombreBeneficiario;

        public string NombreBeneficiario
        {
            get { return strNombreBeneficiario; }
            set { strNombreBeneficiario = value; }
        }

        //DIRECCIONBENEFICIARIO
        string strDireccionBeneficiario;

        public string DireccionBeneficiario
        {
            get { return strDireccionBeneficiario; }
            set { strDireccionBeneficiario = value; }
        }

        //TIPODOCBENEFICIARIO
        string strTipoDocBeneficiario;

        public string TipoDocBeneficiario
        {
            get { return strTipoDocBeneficiario; }
            set { strTipoDocBeneficiario = value; }
        }

        //NUMDOCBENEFICIARIO
        string strNumDocBeneficiario;

        public string NumDocBeneficiario
        {
            get { return strNumDocBeneficiario; }
            set { strNumDocBeneficiario = value; }
        }

        //OPER_MONTO_DESTINO
        string strOperMontoDestino;

        public string OperMontoDestino
        {
            get { return strOperMontoDestino; }
            set { strOperMontoDestino = value; }
        }

        //COD_TRAMA_AUDITORIA
        string strCodTramaAuditoria;

        public string CodTramaAuditoria
        {
            get { return strCodTramaAuditoria; }
            set { strCodTramaAuditoria = value; }
        }

        //ESTADO_DEBITO
        string strEstadoDebito;

        public string EstadoDebito
        {
            get { return strEstadoDebito; }
            set { strEstadoDebito = value; }
        }

        //ESTADO_CREDITO
        string strEstadoCredito;

        public string EstadoCredito
        {
            get { return strEstadoCredito; }
            set { strEstadoCredito = value; }
        }

        //N_FECTIME
        string strNFecTime;

        public string NFecTime
        {
            get { return strNFecTime; }
            set { strNFecTime = value; }
        }

        //COD_SERVICIO
        string strCodServicio;

        public string CodServicio
        {
            get { return strCodServicio; }
            set { strCodServicio = value; }
        }

        //TIPO_REGISTRO
        string strTipoRegistro;

        public string TipoRegistro
        {
            get { return strTipoRegistro; }
            set { strTipoRegistro = value; }
        }

        //ABONO_MANUAL
        string strAbonoManual;

        public string AbonoManual
        {
            get { return strAbonoManual; }
            set { strAbonoManual = value; }
        }

        //MODALIDAD
        string strModalidad;

        public string Modalidad
        {
            get { return strModalidad; }
            set { strModalidad= value; }
        }

        //CAV_CODIGOSAB
        string strCavCodigoSAB;

        public string CavCodigoSAB
        {
            get { return strCavCodigoSAB; }
            set { strCavCodigoSAB = value; }
        }

        //CAV_CTAINTERSAB
        string strCavCtaInterSAB;

        public string CavCtaInterSAB
        {
            get { return strCavCtaInterSAB; }
            set { strCavCtaInterSAB = value; }
        }

        //CAV_FECNEGOCIACION
        string strCavFecNegociacion;

        public string CavFecNegociacion
        {
            get { return strCavFecNegociacion; }
            set { strCavFecNegociacion = value; }
        }

        //CAV_NUMREFCAVALI
        string strCavNumRefCavali;

        public string CavNumRefCavali
        {
            get { return strCavNumRefCavali; }
            set { strCavNumRefCavali = value; }
        }

        //CAV_TIPOPARTICIPANTE
        string strCavTipoParticipante;

        public string CavTipoParticipante
        {
            get { return strCavTipoParticipante; }
            set { strCavTipoParticipante = value; }
        }

        //COLORREGISTRO
        string strColorRegistro;

        public string ColorRegistro
        {
            get { return strColorRegistro; }
            set { strColorRegistro = value; }
        }

        //IND_CORPORATIVO
        string strIndCorporativo;

        public string IndCorporativo
        {
            get { return strIndCorporativo; }
            set { strIndCorporativo = value; }
        }

        //IND_CORE
        string strIndCore;

        public string IndCore
        {
            get { return strIndCore; }
            set { strIndCore = value; }
        }

        //VALNDOC_JUSTIF
        string strValNdocJustif;

        public string ValNdocJustif
        {
            get { return strValNdocJustif; }
            set { strValNdocJustif = value; }
        }

        //FEC_RECEPCION
        string strFecRecepcion;

        public string FecRecepcion
        {
            get { return strFecRecepcion; }
            set { strFecRecepcion = value; }
        }

        //FEC_REGISTRO
        string strFecRegistro;

        public string FecRegistro
        {
            get { return strFecRegistro; }
            set { strFecRegistro = value; }
        }

        //IND_FLUJO
        string strIndFlujo;

        public string IndFlujo
        {
            get { return strIndFlujo; }
            set { strIndFlujo = value; }
        }

        //OBS_CLI
        string strObsCli;

        public string ObsCli
        {
            get { return strObsCli; }
            set { strObsCli = value; }
        }

        //CIERRE_BATCH
        string strCierreBatch;

        public string CierreBatch
        {
            get { return strCierreBatch; }
            set { strCierreBatch = value; }
        }

        //CITISCREENING
        string strCitiscreening;

        public string Citiscreening
        {
            get { return strCitiscreening; }
            set { strCitiscreening = value; }
        }

        //SEC_CITISCREENING
        string strSecCitiscreening;

        public string SecCitiscreening
        {
            get { return strSecCitiscreening; }
            set { strSecCitiscreening = value; }
        }

    }
}
//hh72295:20170117:F: ADECUACION CITISCREENING EN OPERACIONES DE ENTRADA
