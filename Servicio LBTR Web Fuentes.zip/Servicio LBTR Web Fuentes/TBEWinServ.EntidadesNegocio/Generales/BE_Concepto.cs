using System;
using System.Collections.Generic;
using System.Text;

namespace TBEWinServ.EntidadesNegocio.Generales
{
    public class BE_Concepto
    {
        public BE_Concepto() { }

        public BE_Concepto(string prmCodConcepto) 
        {
            strCodConcepto = prmCodConcepto;
        }

        private string strCodConcepto;

        public string CodConcepto
        {
            get { return strCodConcepto; }
            set { strCodConcepto = value; }
        }

        private string strDescripcion;

        public string Descripcion
        {
            get { return strDescripcion; }
            set { strDescripcion = value; }
        }

        private bool blnUsaDatosCliente = false;

        public bool UsaDatosCliente
        {
            get { return blnUsaDatosCliente; }
            set { blnUsaDatosCliente = value; }
        }

        private bool blnUsaBCosmos = false;

        public bool UsaBCosmos
        {
            get { return blnUsaBCosmos; }
            set { blnUsaBCosmos = value; }
        }

        private bool blnEsCavali = false;

        public bool EsCavali
        {
            get { return blnEsCavali; }
            set { blnEsCavali = value; }
        }

        private string strMonCod;

        public string MonCod
        {
            get { return strMonCod; }
            set { strMonCod = value; }
        }
                        
        private string strCodServicio;

        public string CodServicio
        {
            get { return strCodServicio; }
            set { strCodServicio = value; }
        }
    }
}
