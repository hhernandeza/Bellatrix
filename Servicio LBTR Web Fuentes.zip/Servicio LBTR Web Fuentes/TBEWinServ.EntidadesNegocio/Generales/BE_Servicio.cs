using System;
using System.Collections.Generic;
using System.Text;

namespace TBEWinServ.EntidadesNegocio.Generales
{
    [Serializable]
    public class BE_Servicio
    {
        public BE_Servicio() { }

        private string strCodigo;

        public string Codigo
        {
            get { return strCodigo; }
            set { strCodigo = value; }
        }

        private string strNombre;

        public string Nombre
        {
            get { return strNombre; }
            set { strNombre = value; }
        }

        private bool blnHabilitado;

        public bool Habilitado
        {
            get { return blnHabilitado; }
            set { blnHabilitado = value; }
        }
               
    }       

}
