using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using System.IO;

namespace TBEWinServ.EntidadesNegocio.Generales
{
    [Serializable]
    public class BE_DatosCliente
    {
        public BE_DatosCliente() { }

        #region Propiedades

        private string strCCIOrdenante;

        public string CCIOrdenante
        {
            get { return strCCIOrdenante; }
            set { strCCIOrdenante = value; }
        }

        private string strNombreOrdenante;

        public string NombreOrdenante
        {
            get { return strNombreOrdenante; }
            set { strNombreOrdenante = value; }
        }

        private string strDireccionOrdenante;

        public string DireccionOrdenante
        {
            get { return strDireccionOrdenante; }
            set { strDireccionOrdenante = value; }
        }

        private string strTipoDocOrdenante;

        public string TipoDocOrdenante
        {
            get { return strTipoDocOrdenante; }
            set { strTipoDocOrdenante = value; }
        }

        private string strNumDocOrdenante;

        public string NumDocOrdenante
        {
            get { return strNumDocOrdenante; }
            set { strNumDocOrdenante = value; }
        }

        private string strCCIBeneficiario;

        public string CCIBeneficiario
        {
            get { return strCCIBeneficiario; }
            set { strCCIBeneficiario = value; }
        }

        private string strNombreBeneficiario;

        public string NombreBeneficiario
        {
            get { return strNombreBeneficiario; }
            set { strNombreBeneficiario = value; }
        }

        private string strDireccionBeneficiario;

        public string DireccionBeneficiario
        {
            get { return strDireccionBeneficiario; }
            set { strDireccionBeneficiario = value; }
        }

        private string strTipoDocBeneficiario;

        public string TipoDocBeneficiario
        {
            get { return strTipoDocBeneficiario; }
            set { strTipoDocBeneficiario = value; }
        }

        private string strNumDocBeneficiario;

        public string NumDocBeneficiario
        {
            get { return strNumDocBeneficiario; }
            set { strNumDocBeneficiario = value; }
        }

        private string strIndicadorITF;

        public string IndicadorITF
        {
            get { return strIndicadorITF; }
            set { strIndicadorITF = value; }
        }

        private string strObservaciones;

        public string Observaciones
        {
            get { return strObservaciones; }
            set { strObservaciones = value; }
        }

        private string strChrEntidad;

        public string ChrEntidad
        {
            get { return strChrEntidad; }
            set { strChrEntidad = value; }
        }

        #endregion

        public override string ToString()
        {
            StringBuilder sbTextoXML = new StringBuilder();

            sbTextoXML.Append("<cciOrdenante>");
            sbTextoXML.Append(!String.IsNullOrEmpty(strCCIOrdenante)? strCCIOrdenante : "");
            sbTextoXML.Append("</cciOrdenante>");

            sbTextoXML.Append("<nombreOrdenante>");
            sbTextoXML.Append(!String.IsNullOrEmpty(strNombreOrdenante) ? strNombreOrdenante : "");
            sbTextoXML.Append("</nombreOrdenante>");

            sbTextoXML.Append("<direccionOrdenante>");
            sbTextoXML.Append(!String.IsNullOrEmpty(strDireccionOrdenante) ? strDireccionOrdenante : "");
            sbTextoXML.Append("</direccionOrdenante>");

            sbTextoXML.Append("<tipoDocOrdenante>");
            sbTextoXML.Append(!String.IsNullOrEmpty(strTipoDocOrdenante) ? strTipoDocOrdenante : "");
            sbTextoXML.Append("</tipoDocOrdenante>");

            sbTextoXML.Append("<numDocOrdenante>");
            sbTextoXML.Append(!String.IsNullOrEmpty(strNumDocOrdenante) ? strNumDocOrdenante : "");
            sbTextoXML.Append("</numDocOrdenante>");

            sbTextoXML.Append("<cciBeneficiario>");
            sbTextoXML.Append(!String.IsNullOrEmpty(strCCIBeneficiario) ? strCCIBeneficiario : "");
            sbTextoXML.Append("</cciBeneficiario>");

            sbTextoXML.Append("<nombreBeneficiario>");
            sbTextoXML.Append(!String.IsNullOrEmpty(strNombreBeneficiario) ? strNombreBeneficiario : "");
            sbTextoXML.Append("</nombreBeneficiario>");

            sbTextoXML.Append("<direccionBeneficiario>");
            sbTextoXML.Append(!String.IsNullOrEmpty(strDireccionBeneficiario) ? strDireccionBeneficiario : "");
            sbTextoXML.Append("</direccionBeneficiario>");
                        
            sbTextoXML.Append("<tipoDocBeneficiario>");
            sbTextoXML.Append(!String.IsNullOrEmpty(strTipoDocBeneficiario) ? strTipoDocBeneficiario : "");
            sbTextoXML.Append("</tipoDocBeneficiario>");

            sbTextoXML.Append("<numDocBeneficiario>");
            sbTextoXML.Append(!String.IsNullOrEmpty(strNumDocBeneficiario) ? strNumDocBeneficiario : "");
            sbTextoXML.Append("</numDocBeneficiario>");

            sbTextoXML.Append("<indicadorItf>");
            sbTextoXML.Append(!String.IsNullOrEmpty(strIndicadorITF) ? strIndicadorITF : "");
            sbTextoXML.Append("</indicadorItf>");

            sbTextoXML.Append("<observaciones>");
            sbTextoXML.Append(!String.IsNullOrEmpty(strObservaciones) ? strObservaciones : "");
            sbTextoXML.Append("</observaciones>");

            return sbTextoXML.ToString();
        }
                
        public static string ArmarDatosCliente(string prmDataCliente, string prmKsim, string prmFirmaDatosCliente) {
            string strDatosCliente = "<dataCliente>" + prmDataCliente + "</dataCliente>" +
                                  "<ksimDataCliente>" + prmKsim + "</ksimDataCliente>" +
                                  "<firmaDataCliente>" + prmFirmaDatosCliente + "</firmaDataCliente>";

            return strDatosCliente;
        }

        //Usado en Avisos de Afectacion

        public static BE_ContenidoDatosCliente ObtenerContenidoDatosCliente(string prmDatosCliente) 
        {
            BE_ContenidoDatosCliente oDatosCliente = null;
            XmlReader reader = null;
            string strContenido = null;

            try
            {
                oDatosCliente = new BE_ContenidoDatosCliente();
                                
                strContenido = "<?xml version=\"1.0\" encoding=\"ISO-8859-1\"?><datoscliente>{0}</datoscliente>";

                if (!String.IsNullOrEmpty(prmDatosCliente))
                {
                    reader = XmlReader.Create(new StringReader(string.Format(strContenido, prmDatosCliente)));
                    reader.MoveToContent();

                    while (!reader.EOF)
                    {
                        if (reader.NodeType == XmlNodeType.Element)
                        {
                            if (reader.Name.ToLower() == "datacliente")
                                oDatosCliente.DataClienteCifrada = reader.ReadInnerXml();
                            else if (reader.Name.ToLower() == "ksimdatacliente")
                                oDatosCliente.KsimCifrada = reader.ReadInnerXml();
                            else if (reader.Name.ToLower() == "firmadatacliente")
                                oDatosCliente.FirmaDataCliente = reader.ReadInnerXml();
                            else
                                reader.Read();
                        }
                        else
                        {
                            reader.Read();
                        }

                    }

                    reader.Close();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return oDatosCliente;        
        }

        public static BE_DatosCliente ObtenerDataClienteDesdeXML(string prmDataClienteXML)
        {
            BE_DatosCliente oDatosCliente = new BE_DatosCliente();

            if (String.IsNullOrEmpty(prmDataClienteXML)) return oDatosCliente;

            prmDataClienteXML = "<?xml version=\"1.0\" encoding=\"ISO-8859-1\"?><datacliente>" + prmDataClienteXML + "</datacliente>";
                        
            XmlReader reader = null;
            
            try
            {
                reader = XmlReader.Create(new StringReader(prmDataClienteXML));

                reader.MoveToContent();

                while (!reader.EOF)
                {
                    if (reader.NodeType == XmlNodeType.Element)
                    {
                        if (reader.Name.ToLower() == "cciordenante")
                        {
                            oDatosCliente.CCIOrdenante = reader.ReadString();
                            if (!String.IsNullOrEmpty(oDatosCliente.CCIOrdenante)) oDatosCliente.CCIOrdenante = oDatosCliente.CCIOrdenante.Trim();
                        }
                        else if (reader.Name.ToLower() == "nombreordenante")
                        {
                            oDatosCliente.NombreOrdenante = reader.ReadString();
                            if (!String.IsNullOrEmpty(oDatosCliente.NombreOrdenante)) oDatosCliente.NombreOrdenante = oDatosCliente.NombreOrdenante.Trim();
                        }
                        else if (reader.Name.ToLower() == "direccionordenante")
                        {
                            oDatosCliente.DireccionOrdenante = reader.ReadString();
                            if (!String.IsNullOrEmpty(oDatosCliente.DireccionOrdenante)) oDatosCliente.DireccionOrdenante = oDatosCliente.DireccionOrdenante.Trim();
                        }
                        else if (reader.Name.ToLower() == "tipodocordenante")
                        {
                            oDatosCliente.TipoDocOrdenante = reader.ReadString();
                            if (!String.IsNullOrEmpty(oDatosCliente.TipoDocOrdenante)) oDatosCliente.TipoDocOrdenante = oDatosCliente.TipoDocOrdenante.Trim();
                        }
                        else if (reader.Name.ToLower() == "numdocordenante")
                        {
                            oDatosCliente.NumDocOrdenante = reader.ReadString();
                            if (!String.IsNullOrEmpty(oDatosCliente.NumDocOrdenante)) oDatosCliente.NumDocOrdenante = oDatosCliente.NumDocOrdenante.Trim();
                        }
                        else if (reader.Name.ToLower() == "ccibeneficiario")
                        {
                            oDatosCliente.CCIBeneficiario = reader.ReadString();
                            if (!String.IsNullOrEmpty(oDatosCliente.CCIBeneficiario))
                                oDatosCliente.CCIBeneficiario = oDatosCliente.CCIBeneficiario.Trim();
                        }
                        else if (reader.Name.ToLower() == "nombrebeneficiario")
                        {
                            oDatosCliente.NombreBeneficiario = reader.ReadString();
                            if (!String.IsNullOrEmpty(oDatosCliente.NombreBeneficiario)) oDatosCliente.NombreBeneficiario = oDatosCliente.NombreBeneficiario.Trim();
                        }
                        else if (reader.Name.ToLower() == "direccionbeneficiario")
                        {
                            oDatosCliente.DireccionBeneficiario = reader.ReadString();
                            if (!String.IsNullOrEmpty(oDatosCliente.DireccionBeneficiario)) oDatosCliente.DireccionBeneficiario = oDatosCliente.DireccionBeneficiario.Trim();
                        }
                        else if (reader.Name.ToLower() == "tipodocbeneficiario")
                        {
                            oDatosCliente.TipoDocBeneficiario = reader.ReadString();
                            if (!String.IsNullOrEmpty(oDatosCliente.TipoDocBeneficiario)) oDatosCliente.TipoDocBeneficiario = oDatosCliente.TipoDocBeneficiario.Trim();
                        }
                        else if (reader.Name.ToLower() == "numdocbeneficiario")
                        {
                            oDatosCliente.NumDocBeneficiario = reader.ReadString();
                            if (!String.IsNullOrEmpty(oDatosCliente.NumDocBeneficiario)) oDatosCliente.NumDocBeneficiario = oDatosCliente.NumDocBeneficiario.Trim();
                        }
                        else if (reader.Name.ToLower() == "indicadoritf")
                        {
                            oDatosCliente.IndicadorITF = reader.ReadString();
                            if (!String.IsNullOrEmpty(oDatosCliente.IndicadorITF)) oDatosCliente.IndicadorITF = oDatosCliente.IndicadorITF.Trim();
                        }
                        else if (reader.Name.ToLower() == "observaciones")
                        {
                            oDatosCliente.Observaciones = reader.ReadString();
                            if (!String.IsNullOrEmpty(oDatosCliente.Observaciones)) oDatosCliente.Observaciones = oDatosCliente.Observaciones.Trim();
                        }
                    }

                    reader.Read();                        
                }

                reader.Close();
            }
            catch (Exception ex)
            {
                oDatosCliente = new BE_DatosCliente();
                throw ex;
            }

            return oDatosCliente;
        }

    }

    [Serializable]
    public class BE_ContenidoDatosCliente {
        public string DataClienteCifrada;
        public string KsimCifrada;
        public string FirmaDataCliente;
    }
}
