using System;
using System.Collections.Generic;
using System.Text;

namespace TBEWinServ.EntidadesNegocio.Generales
{
    [Serializable]
    public class BE_ConfiguracionCliente
    {
        public string Nombre;
        public string Valor;
    }
}
