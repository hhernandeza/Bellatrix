using System;
using System.Collections.Generic;
using System.Text;

namespace TBEWinServ.EntidadesNegocio.Generales
{
    public class BE_FILE01
    {
        private String strBaseNumber;

        public String BaseNumber
        {
            get { return strBaseNumber; }
            set { strBaseNumber = value; }
        }

        private String strRUC;

        public String RUC
        {
            get { return strRUC; }
            set { strRUC = value; }
        }

    }
}
