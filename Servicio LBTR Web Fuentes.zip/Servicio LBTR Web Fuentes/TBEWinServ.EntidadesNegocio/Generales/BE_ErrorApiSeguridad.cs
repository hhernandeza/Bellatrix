using System;
using System.Collections.Generic;
using System.Text;
using TBEWinServ.Utilitarios;

namespace TBEWinServ.EntidadesNegocio.Generales
{
    public class BE_ErrorApiSeguridad
    {
        private String strCodigoError;

        public String CodigoError
        {
            get { return strCodigoError; }
            set { strCodigoError = value; }
        }

        private String strDescripcionError;

        public String DescripcionError
        {
            get { return strDescripcionError; }
            set { strDescripcionError = value; }
        }

        private String strAccionATomar;

        public String AccionATomar
        {
            get { return strAccionATomar; }
            set { strAccionATomar = value; }
        }

        private String strOrigen;

        public String Origen
        {
            get { return strOrigen; }
            set { strOrigen = value; }
        }

        private String strNivel;

        public String Nivel
        {
            get { return strNivel; }
            set { strNivel = value; }
        }

        private bool blnRequiereReconexion = false;

        public bool RequiereReconexion
        {
            get { return blnRequiereReconexion; }
            set { blnRequiereReconexion = value; }
        }

        //Opcionales por el momento

        private String strFuncionApiOrigen;

        public String FuncionApiOrigen
        {
            get { return strFuncionApiOrigen; }
            set { strFuncionApiOrigen = value; }
        }

        private String strTipoError;

        public String TipoError
        {
            get { return strTipoError; }
            set { strTipoError = value; }
        }

        //---------------------------

        public override string ToString()
        {
            StringBuilder sbTexto = new StringBuilder();

            sbTexto.AppendLine("Error retornado por el API de seguridad:");
            sbTexto.Append("Codigo Error: [");
            sbTexto.Append(strCodigoError);
            sbTexto.Append("]. Descripcion: ");
            sbTexto.AppendLine(strDescripcionError);
            sbTexto.Append("Accion a tomar: ");
            sbTexto.AppendLine(strAccionATomar);
            sbTexto.Append("Reconexion: ");
            sbTexto.Append(blnRequiereReconexion.ToString());
            sbTexto.Append(", Nivel: ");
            sbTexto.Append(strNivel);
            sbTexto.Append(", Origen: ");
            sbTexto.Append(strOrigen);
            sbTexto.Append(", Tipo Error: ");
            sbTexto.Append(strTipoError);
            if (!String.IsNullOrEmpty(strTipoError))
            {
                if (strTipoError.Equals(TipoErrorApiSeguridad.Particular))
                {
                    sbTexto.Append(", Funcion Api Origen: ");
                    sbTexto.Append(strFuncionApiOrigen);
                }
            }

            return sbTexto.ToString();
        }
        
    }
}
