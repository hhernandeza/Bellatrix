using System;
using System.Collections.Generic;
using System.Text;

namespace TBEWinServ.EntidadesNegocio.Generales
{
    public class BE_LBTR_PARAM
    {
        private string strCodParam;

        public string CodParam
        {
            get { return strCodParam; }
            set { strCodParam = value; }
        }

        private string strValor;

        public string Valor
        {
            get { return strValor; }
            set { strValor = value; }
        }

        private int? intIndiceKPriCiti;

        public int? IndiceKPriCiti
        {
            get { return intIndiceKPriCiti; }
            set { intIndiceKPriCiti = value; }
        }

        private string strFecha;

        public string Fecha
        {
            get { return strFecha; }
            set { strFecha = value; }
        }

    }
}
