using System;
using System.Collections.Generic;
using System.Text;

namespace TBEWinServ.EntidadesNegocio.Generales
{
    [Serializable]
    public class BE_Banco
    {

        public BE_Banco() { }

        public BE_Banco(string prmCodBanco) {
            strCodBanco = prmCodBanco;
        }

        private string strCodBanco;

        public string CodBanco
        {
            get { return strCodBanco; }
            set { strCodBanco = value; }
        }

        private string strNomBancoBCR;

        public string NomBancoBCR
        {
            get { return strNomBancoBCR; }
            set { strNomBancoBCR = value; }
        }

        private string strNomBancoCit;

        public string NomBancoCit
        {
            get { return strNomBancoCit; }
            set { strNomBancoCit = value; }
        }

        private int? indiceKPub;

        public int? IndiceKPub
        {
            get { return indiceKPub; }
            set { indiceKPub = value; }
        }

        private int? indiceKPri;

        public int? IndiceKPri
        {
            get { return indiceKPri; }
            set { indiceKPri = value; }
        }

        private string strCuentaMatriz;

        public string CuentaMatriz
        {
            get { return strCuentaMatriz; }
            set { strCuentaMatriz = value; }
        }
                
    }
}
