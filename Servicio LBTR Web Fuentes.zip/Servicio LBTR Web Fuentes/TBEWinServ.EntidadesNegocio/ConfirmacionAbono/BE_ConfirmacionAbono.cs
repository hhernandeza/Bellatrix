using System;
using System.Collections.Generic;
using System.Text;
using TBEWinServ.EntidadesNegocio.Generales;

namespace TBEWinServ.EntidadesNegocio.ConfirmacionAbono
{
    [Serializable]
    public class BE_ConfirmacionAbono
    {
        public BE_ConfirmacionAbono() { }

        private string strFechaLiquidacio;

        public string FechaLiquidacion
        {
            get { return strFechaLiquidacio; }
            set { strFechaLiquidacio = value; }
        }
        
        private string strNumRefLBTR;

        public string NumRefLBTR
        {
            get { return strNumRefLBTR; }
            set { strNumRefLBTR = value; }
        }

        private string strEstado;

        public string Estado
        {
            get { return strEstado; }
            set { strEstado = value; }
        }

        private string strEstadoOriginal;

        public string EstadoOriginal
        {
            get { return strEstadoOriginal; }
            set { strEstadoOriginal = value; }
        }

        private string strConfirmaAbono;

        public string ConfirmaAbono
        {
            get { return strConfirmaAbono; }
            set { strConfirmaAbono = value; }
        }
                
    }
}
