using System;
using System.Collections.Generic;
using System.Text;
using TBEWinServ.EntidadesNegocio.Generales;

namespace TBEWinServ.EntidadesNegocio.Transferencia
{
    [Serializable]
    public class BE_Transferencia
    {
        public BE_Transferencia() { }

        public BE_Transferencia(string prmNumRefLBTR) 
        {
            strNumRefLBTR = prmNumRefLBTR;
        }

        //--------------------------------------- No enviados en la trama al BCRP
        private string strTRANSACT;

        public string TRANSACT
        {
            get { return strTRANSACT; }
            set { strTRANSACT = value; }
        }

        private string strSEC;

        public string SEC
        {
            get { return strSEC; }
            set { strSEC = value; }
        }

        private string strCodBancoDestino;

        public string CodBancoDestino
        {
            get { return strCodBancoDestino; }
            set { strCodBancoDestino = value; }
        }

        private string strIdConsulta;

        public string IdConsulta
        {
            get { return strIdConsulta; }
            set { strIdConsulta = value; }
        }

        private string strCodTramaAuditoria;

        public string CodTramaAuditoria
        {
            get { return strCodTramaAuditoria; }
            set { strCodTramaAuditoria = value; }
        }

        private string strFecConsulta;

        public string FecConsulta
        {
            get { return strFecConsulta; }
            set { strFecConsulta = value; }
        }

        private string strFirma;

        public string Firma
        {
            get { return strFirma; }
            set { strFirma = value; }
        }

        /*private bool _blnBloquear = false;

        public bool blnBloquear
        {
            get { return _blnBloquear; }
            set { _blnBloquear = value; }
        }

        private string strBloqueadoPor = "";

        public string BloqueadoPor
        {
            get { return strBloqueadoPor; }
            set { strBloqueadoPor = value; }
        }*/

        private string strTransferidoPor = "";

        public string TransferidoPor
        {
            get { return strTransferidoPor; }
            set { strTransferidoPor = value; }
        }
                                
        //----------------------------------------

        private string strCodConcepto;

        public string CodConcepto
        {
            get { return strCodConcepto; }
            set { strCodConcepto = value; }
        }

        private DateTime? dFechaLiquidacion;

        /// <summary>
        /// Usado cuando se obtiene el valor del campo fecha aceptado de t_desa
        /// </summary>
        public DateTime? FechaLiquidacion
        {
            get { return dFechaLiquidacion; }
            set { dFechaLiquidacion = value; }
        }

        private string strCuentaOrigen;

        public string CuentaOrigen
        {
            get { return strCuentaOrigen; }
            set { strCuentaOrigen = value; }
        }

        private string strCuentaDestino;

        public string CuentaDestino
        {
            get { return strCuentaDestino; }
            set { strCuentaDestino = value; }
        }

        private decimal? decMonto;

        public decimal? Monto
        {
            get { return decMonto; }
            set { decMonto = value; }
        }

        private string strNumRefOrigen;

        public string NumRefOrigen
        {
            get { return strNumRefOrigen; }
            set { strNumRefOrigen = value; }
        }

        private string strInstruccionesPago;

        public string InstruccionesPago
        {
            get { return strInstruccionesPago; }
            set { strInstruccionesPago = value; }
        }

        private string strModalidad;

        public string Modalidad
        {
            get { return strModalidad; }
            set { strModalidad = value; }
        }

        private int? nPrioridad;

        public int? Prioridad
        {
            get { return nPrioridad; }
            set { nPrioridad = value; }
        }
                
        private string strNumRefLBTR;

        public string NumRefLBTR
        {
            get { return strNumRefLBTR; }
            set { strNumRefLBTR = value; }
        }

        private string strNumRefLBTREnlace;

        public string NumRefLBTREnlace
        {
            get { return strNumRefLBTREnlace; }
            set { strNumRefLBTREnlace = value; }
        }
        
        private DateTime? dFecRefLBTREnlace;

        public DateTime? FecRefLBTREnlace
        {
            get { return dFecRefLBTREnlace; }
            set { dFecRefLBTREnlace = value; }
        }

        private string strEstado;

        public string Estado
        {
            get { return strEstado; }
            set { strEstado = value; }
        }

        private string strEstadoOriginal;

        public string EstadoOriginal
        {
            get { return strEstadoOriginal; }
            set { strEstadoOriginal = value; }
        }
                                        
        private BE_DatosCliente oDatosCliente = null;

        public BE_DatosCliente DatosCliente
        {
            get { return oDatosCliente; }
            set { oDatosCliente = value; }
        }

        private DateTime? dFechaRegistradoBCRP;

        public DateTime? FechaRegistradoBCRP
        {
            get { return dFechaRegistradoBCRP; }
            set { dFechaRegistradoBCRP = value; }
        }

        private DateTime? dFechaEnEspera;

        public DateTime? FechaEnEspera
        {
            get { return dFechaEnEspera; }
            set { dFechaEnEspera = value; }
        }

        private DateTime? dFechaEnviado;

        public DateTime? FechaEnviado
        {
            get { return dFechaEnviado; }
            set { dFechaEnviado = value; }
        }

        private DateTime? dFechaReEnviado;

        public DateTime? FechaReEnviado
        {
            get { return dFechaReEnviado; }
            set { dFechaReEnviado = value; }
        }

        private DateTime? dFechaAceptado;

        /// <summary>
        /// Usado cuando se va a actualizar/registrar el campo fecha estado de la tabla t_desa
        /// </summary>
        public DateTime? FechaAceptado
        {
            get { return dFechaAceptado; }
            set { dFechaAceptado = value; }
        }

        private DateTime? dFechaAnulado;

        public DateTime? FechaAnulado
        {
            get { return dFechaAnulado; }
            set { dFechaAnulado = value; }
        }

        private DateTime? dFechaErrorTrx;

        public DateTime? FechaErrorTrx
        {
            get { return dFechaErrorTrx; }
            set { dFechaErrorTrx = value; }
        }

        private string strConfirmaAbono;

        public string ConfirmaAbono
        {
            get { return strConfirmaAbono; }
            set { strConfirmaAbono = value; }
        }

        private string strTipoIngreso = null;

        public string TipoIngreso
        {
            get { return strTipoIngreso; }
            set { strTipoIngreso = value; }
        }
                                
        private string strSistemaOrigen = null;

        public string SistemaOrigen
        {
            get { return strSistemaOrigen; }
            set { strSistemaOrigen = value; }
        }

        private string strEstadoReinstate;

        public string EstadoReinstate
        {
            get { return strEstadoReinstate; }
            set { strEstadoReinstate = value; }
        }

        private string strFlagAccesoFxSTP;

        public string FlagAccesoFxSTP
        {
            get { return strFlagAccesoFxSTP; }
            set { strFlagAccesoFxSTP = value; }
        }

        public override string ToString()
        {
            StringBuilder sbTexto = new StringBuilder();

            sbTexto.Append("TRANSACT: ");
            sbTexto.AppendLine(!String.IsNullOrEmpty(TRANSACT) ? TRANSACT : "");

            sbTexto.Append("SEC: ");
            sbTexto.AppendLine(!String.IsNullOrEmpty(SEC) ? SEC : "");

            sbTexto.Append("CodConcepto: ");
            sbTexto.AppendLine(!String.IsNullOrEmpty(CodConcepto) ? CodConcepto : "");

            sbTexto.Append("FechaLiquidacion: ");
            sbTexto.AppendLine(FechaLiquidacion.HasValue ? FechaLiquidacion.Value.ToString() : "");

            sbTexto.Append("CuentaOrigen: ");
            sbTexto.AppendLine(!String.IsNullOrEmpty(CuentaOrigen) ? CuentaOrigen : "");

            sbTexto.Append("CuentaDestino: ");
            sbTexto.AppendLine(!String.IsNullOrEmpty(CuentaDestino) ? CuentaDestino : "");

            sbTexto.Append("Monto: ");
            sbTexto.AppendLine(Monto.HasValue ? Monto.Value.ToString() : "");

            sbTexto.Append("NumRefOrigen: ");
            sbTexto.AppendLine(!String.IsNullOrEmpty(NumRefOrigen) ? NumRefOrigen : "");

            sbTexto.Append("InstruccionesPago: ");
            sbTexto.AppendLine(!String.IsNullOrEmpty(InstruccionesPago) ? InstruccionesPago : "");

            sbTexto.Append("Modalidad: ");
            sbTexto.AppendLine(!String.IsNullOrEmpty(Modalidad) ? Modalidad : "");

            sbTexto.Append("Prioridad: ");
            sbTexto.AppendLine(Prioridad.HasValue ? Prioridad.Value.ToString() : "");

            sbTexto.Append("NumRefLBTR: ");
            sbTexto.AppendLine(!String.IsNullOrEmpty(NumRefLBTR) ? NumRefLBTR : "");

            sbTexto.Append("FecRefLBTREnlace: ");
            sbTexto.AppendLine(FecRefLBTREnlace.HasValue ? FecRefLBTREnlace.Value.ToString() : "");

            sbTexto.Append("Estado: ");
            sbTexto.AppendLine(!String.IsNullOrEmpty(Estado) ? Estado : "");

            //sbTexto.AppendLine("DatosCliente: ");
            //sbTexto.AppendLine(oDatosCliente.ToString());

            return sbTexto.ToString();
        }

    }
        
}
