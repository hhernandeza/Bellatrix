﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TBEWinServ.EntidadesNegocio.EnvioBCosmos
{
    public class BE_TransferenciaMQ
    {
        Int64 nSecuencia;

        public Int64 Secuencia
        {
            get { return nSecuencia; }
            set { nSecuencia = value; }
        }

        string strBcrpRefer;

        public string BcrpRefer
        {
            get { return strBcrpRefer; }
            set { strBcrpRefer = value; }
        }

        string strRespBCosmos;

        public string RespBCosmos
        {
            get { return strRespBCosmos; }
            set { strRespBCosmos = value; }
        }

        Int64? nTokenId;

        public Int64? TokenId
        {
            get { return nTokenId; }
            set { nTokenId = value; }
        }

        DateTime? dtFechaOrigen;

        public DateTime? FechaOrigen
        {
            get { return dtFechaOrigen; }
            set { dtFechaOrigen = value; }
        }

        DateTime? dtFechaDestino;

        public DateTime? FechaDestino
        {
            get { return dtFechaDestino; }
            set { dtFechaDestino = value; }
        }

        string strTramaInput;

        public string TramaInput
        {
            get { return strTramaInput; }
            set { strTramaInput = value; }
        }

        string strTramaOuput;

        public string TramaOuput
        {
            get { return strTramaOuput; }
            set { strTramaOuput = value; }
        }

        string strSistemaOrigen;

        public string SistemaOrigen
        {
            get { return strSistemaOrigen; }
            set { strSistemaOrigen = value; }
        }

        string strMessageId;

        public string MessageId
        {
            get { return strMessageId; }
            set { strMessageId = value; }
        }
    }
}
