﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TBEWinServ.EntidadesNegocio.EnvioBCosmos
{
    public class BE_EnvioBCosmos
    {
        string strBcrpRefer;

        public string BcrpRefer
        {
            get { return strBcrpRefer; }
            set { strBcrpRefer = value; }
        }

        string strFecha;

        public string Fecha
        {
            get { return strFecha; }
            set { strFecha = value; }
        }

        string strBcoOrig;

        public string BcoOrig
        {
            get { return strBcoOrig; }
            set { strBcoOrig = value; }
        }

        string strOperMonto;

        public string OperMonto
        {
            get { return strOperMonto; }
            set { strOperMonto = value; }
        }

        string strIndicadorItf;

        public string IndicadorItf
        {
            get { return strIndicadorItf; }
            set { strIndicadorItf = value; }
        }

        string strNumDocOrdenante;

        public string NumDocOrdenante
        {
            get { return strNumDocOrdenante; }
            set { strNumDocOrdenante = value; }
        }

        string strTipoDocOrdenante;

        public string TipoDocOrdenante
        {
            get { return strTipoDocOrdenante; }
            set { strTipoDocOrdenante = value; }
        }

        string strCodMoneda;

        public string CodMoneda
        {
            get { return strCodMoneda; }
            set { strCodMoneda = value; }
        }

        string strOperCta;

        public string OperCta
        {
            get { return strOperCta; }
            set { strOperCta = value; }
        }

        string strNroCta;

        public string NroCta
        {
            get { return strNroCta; }
            set { strNroCta = value; }
        }

        string strOperCtaTmp;

        public string OperCtaTmp
        {
            get { return strOperCtaTmp; }
            set { strOperCtaTmp = value; }
        }

        string strIndOmitValnDoc;

        public string IndOmitValnDoc
        {
            get { return strIndOmitValnDoc; }
            set { strIndOmitValnDoc = value; }
        }

        string strEntidad;

        public string Entidad
        {
            get { return strEntidad; }
            set { strEntidad = value; }
        }

    }
}
