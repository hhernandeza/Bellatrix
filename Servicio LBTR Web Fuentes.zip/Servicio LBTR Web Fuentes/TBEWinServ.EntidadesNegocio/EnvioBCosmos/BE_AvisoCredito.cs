﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TBEWinServ.EntidadesNegocio.EnvioBCosmos
{
    public class BE_AvisoCredito
    {
        private string strBcrpRef;

        public string BcrpRef
        {
            get { return strBcrpRef; }
            set { strBcrpRef = value; }
        }

        private string strNroCta;

        public string NroCta
        {
            get { return strNroCta; }
            set { strNroCta = value; }
        }

        private string strBase;

        public string Base
        {
            get { return strBase; }
            set { strBase = value; }
        }

        private string strMoneda;

        public string Moneda
        {
            get { return strMoneda; }
            set { strMoneda = value; }
        }

        private decimal dMonExt;

        public decimal MonExt
        {
            get { return dMonExt; }
            set { dMonExt = value; }
        }

        private decimal dMonLoc;

        public decimal MonLoc
        {
            get { return dMonLoc; }
            set { dMonLoc = value; }
        }

        private string strFecha;

        public string Fecha
        {
            get { return strFecha; }
            set { strFecha = value; }
        }

        private string strBcoOrigen;

        public string BcoOrigen
        {
            get { return strBcoOrigen; }
            set { strBcoOrigen = value; }
        }
    }
}
