﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TBEWinServ.EntidadesNegocio.EnvioBCosmos
{
    public class BE_DatosOperacion
    {
        private string strBcrpRefer;

        public string BcrpRefer
        {
            get { return strBcrpRefer; }
            set { strBcrpRefer = value; }
        }

        private string strFecha;

        public string Fecha
        {
            get { return strFecha; }
            set { strFecha = value; }
        }

        private string strHora;

        public string Hora
        {
            get { return strHora; }
            set { strHora = value; }
        }

        private string strBcoOrig;

        public string BcoOrig
        {
            get { return strBcoOrig; }
            set { strBcoOrig = value; }
        }

        private string strMoneda;

        public string Moneda
        {
            get { return strMoneda; }
            set { strMoneda = value; }
        }

        private string strMonto;

        public string Monto
        {
            get { return strMonto; }
            set { strMonto = value; }
        }

        private string strOperCta;

        public string OperCta
        {
            get { return strOperCta; }
            set { strOperCta = value; }
        }

        private string strClasificacion;

        public string Clasificacion
        {
            get { return strClasificacion; }
            set { strClasificacion = value; }
        }

        private string strConcepto;

        public string Concepto
        {
            get { return strConcepto; }
            set { strConcepto = value; }
        }

        private string strOrdenante;

        public string Ordenante
        {
            get { return strOrdenante; }
            set { strOrdenante = value; }
        }

        private string strBeneficiario;

        public string Beneficiario
        {
            get { return strBeneficiario; }
            set { strBeneficiario = value; }
        }

        private string strBcoOrigRef;

        public string BcoOrigRef
        {
            get { return strBcoOrigRef; }
            set { strBcoOrigRef = value; }
        }

        private string strBcoOrigRefSec;

        public string BcoOrigRefSec
        {
            get { return strBcoOrigRefSec; }
            set { strBcoOrigRefSec = value; }
        }

        private string strCciBeneficiario;

        public string CciBeneficiario
        {
            get { return strCciBeneficiario; }
            set { strCciBeneficiario = value; }
        }

        private string strIndicadorItf;

        public string IndicadorItf
        {
            get { return strIndicadorItf; }
            set { strIndicadorItf = value; }
        }
        //Agregado por WZ
        private string strTipoDocBeneficiario;

        public string TipoDocBeneficiario
        {
            get { return strTipoDocBeneficiario; }
            set { strTipoDocBeneficiario = value; }
        }

        private string strNumDocBeneficiario;

        public string NumDocBeneficiario
        {
            get { return strNumDocBeneficiario; }
            set { strNumDocBeneficiario = value; }
        }
        private string strRefTBE;

        public string RefTBE
        {
            get { return strRefTBE; }
            set { strRefTBE = value; }
        }

        private string strObservacion;

        public string Observacion
        {
            get { return strObservacion; }
            set { strObservacion = value; }
        }
    }
}
