﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TBEWinServ.EntidadesNegocio.EnvioBCosmos
{
    /// <summary>
    /// Clase entidad que almacena los datos de las tramas enviadas y recibidas por MQ
    /// </summary>
    public class BE_TramaMQ
    {
        private Int64? nTokenId;

        /// <summary>
        /// Identificador de la trama
        /// </summary>
        public Int64? TokenId
        {
            get { return nTokenId; }
            set { nTokenId = value; }
        }

        private string strOrigenToken;

        /// <summary>
        /// Origen de la trama I=Input / O=Output
        /// </summary>
        public string OrigenToken
        {
            get { return strOrigenToken; }
            set { strOrigenToken = value; }
        }

        private DateTime? dtFechaOrigen;

        /// <summary>
        /// Fecha en la que se envió o recibió la trama
        /// </summary>
        public DateTime? FechaOrigen
        {
            get { return dtFechaOrigen; }
            set { dtFechaOrigen = value; }
        }

        private string strTrama;

        /// <summary>
        /// Contenido de trama
        /// </summary>
        public string Trama
        {
            get { return strTrama; }
            set { strTrama = value; }
        }

        private string strSistemaOrigen;

        /// <summary>
        /// Sistema origen de la trama. Por defecto es 1 (STB)
        /// </summary>
        public string SistemaOrigen
        {
            get { return strSistemaOrigen; }
            set { strSistemaOrigen = value; }
        }

        private string strMsgId;

        /// <summary>
        /// Mensaje de confirmación de envío y respuesta del servicio MQ
        /// </summary>
        public string MsgId
        {
            get { return strMsgId; }
            set { strMsgId = value; }
        }
    }
}
