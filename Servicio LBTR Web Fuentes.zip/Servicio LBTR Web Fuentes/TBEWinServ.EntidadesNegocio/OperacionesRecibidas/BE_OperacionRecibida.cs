using System;
using System.Collections.Generic;
using System.Text;
using TBEWinServ.EntidadesNegocio.Generales;

namespace TBEWinServ.EntidadesNegocio.OperacionesRecibidas
{
    [Serializable]
    public class BE_OperacionRecibida
    {
        public BE_OperacionRecibida() { }

        public BE_OperacionRecibida(string prmNumRefLBTR) {
            strNumRefLBTR = prmNumRefLBTR;
        }

        private string strTrama;

        public string Trama
        {
            get { return strTrama; }
            set { strTrama = value; }
        }
        
        private string strHashcode;

        public string Hashcode
        {
            get { return strHashcode; }
            set { strHashcode = value; }
        }
        
        private string strFirma;

        public string Firma
        {
            get { return strFirma; }
            set { strFirma = value; }
        }

        private string strCodTramaAuditoria;

        public string CodTramaAuditoria
        {
            get { return strCodTramaAuditoria; }
            set { strCodTramaAuditoria = value; }
        }
                
        private string strCodBancoDestino;

        public string CodBancoDestino
        {
            get { return strCodBancoDestino; }
            set { strCodBancoDestino = value; }
        }

        private string strCodBancoOrigen;

        public string CodBancoOrigen
        {
            get { return strCodBancoOrigen; }
            set { strCodBancoOrigen = value; }
        }
        
        private string strCodConcepto;

        public string CodConcepto
        {
            get { return strCodConcepto; }
            set { strCodConcepto = value; }
        }

        private string strCodigoSAB;

        public string CodigoSAB
        {
            get { return strCodigoSAB; }
            set { strCodigoSAB = value; }
        }

        private string strCodServicio;

        public string CodServicio
        {
            get { return strCodServicio; }
            set { strCodServicio = value; }
        }
                
        private string strCodMoneda;

        public string CodMoneda
        {
            get { return strCodMoneda; }
            set { strCodMoneda = value; }
        }

        private string strCuentaDestino;

        public string CuentaDestino
        {
            get { return strCuentaDestino; }
            set { strCuentaDestino = value; }
        }

        private string strCuentaInterbancariaSAB;

        public string CuentaInterbancariaSAB
        {
            get { return strCuentaInterbancariaSAB; }
            set { strCuentaInterbancariaSAB = value; }
        }
        
        private string strCuentaOrigen;

        public string CuentaOrigen
        {
            get { return strCuentaOrigen; }
            set { strCuentaOrigen = value; }
        }

        private BE_DatosCliente oDatosCliente = new BE_DatosCliente();

        public BE_DatosCliente DatosCliente
        {
            get { return oDatosCliente; }
            set { oDatosCliente = value; }
        }

        private string strDatosCliente;

        public string StrDatosCliente
        {
            get { return strDatosCliente; }
            set { strDatosCliente = value; }
        }
        
        private string strEstadoLiquidacion;

        public string EstadoLiquidacion
        {
            get { return strEstadoLiquidacion; }
            set { strEstadoLiquidacion = value; }
        }

        private string strFechaLiquidacion;

        public string FechaLiquidacion
        {
            get { return strFechaLiquidacion; }
            set { strFechaLiquidacion = value; }
        }

        private string strFechaNegociacionCavali;

        public string FechaNegociacionCavali
        {
            get { return strFechaNegociacionCavali; }
            set { strFechaNegociacionCavali = value; }
        }

        private string strHoraLiquidacion = "";

        public string HoraLiquidacion
        {
            get { return strHoraLiquidacion; }
            set { strHoraLiquidacion = value; }
        }

        private string strInstruccionesPago;

        public string InstruccionesPago
        {
            get { return strInstruccionesPago; }
            set { strInstruccionesPago = value; }
        }

        private string strModalidad;

        public string Modalidad
        {
            get { return strModalidad; }
            set { strModalidad = value; }
        }

        private string strMontoOperacionDestino;

        public string MontoOperacionDestino
        {
            get { return strMontoOperacionDestino; }
            set { strMontoOperacionDestino = value; }
        }
                
        private string strMontoOperacionOrigen;

        public string MontoOperacionOrigen
        {
            get { return strMontoOperacionOrigen; }
            set { strMontoOperacionOrigen = value; }
        }

        private string strNumRefCavali;

        public string NumRefCavali
        {
            get { return strNumRefCavali; }
            set { strNumRefCavali = value; }
        }

        private string strNumRefLBTR;

        public string NumRefLBTR
        {
            get { return strNumRefLBTR; }
            set { strNumRefLBTR = value; }
        }

        private string strNumRefOrigen;

        public string NumRefOrigen
        {
            get { return strNumRefOrigen; }
            set { strNumRefOrigen = value; }
        }
                
        private string strTipoCambio;

        public string TipoCambio
        {
            get { return strTipoCambio; }
            set { strTipoCambio = value; }
        }

        private string strTipoParticipanteCavali;

        public string TipoParticipanteCavali
        {
            get { return strTipoParticipanteCavali; }
            set { strTipoParticipanteCavali = value; }
        }

        private string strTipoRegistro;

        public string TipoRegistro
        {
            get { return strTipoRegistro; }
            set { strTipoRegistro = value; }
        }

        private string strColorRegistro;

        public string ColorRegistro
        {
            get { return strColorRegistro; }
            set { strColorRegistro = value; }
        }

        private string strIndCorporativo;

        public string IndCorporativo
        {
            get { return strIndCorporativo; }
            set { strIndCorporativo = value; }
        }

        private string strIndCORE;

        public string IndCORE
        {
            get { return strIndCORE; }
            set { strIndCORE = value; }
        }

        private bool blnUsarCuentaTramite = false;

        public bool UsarCuentaTramite
        {
            get { return blnUsarCuentaTramite; }
            set { blnUsarCuentaTramite = value; }
        }

        private string strCuentaTramite;

        public string CuentaTramite
        {
            get { return strCuentaTramite; }
            set { strCuentaTramite = value; }
        }
        
          
        //Usados en otras circunstancias....

        private string strNumRefLBTREnlace;

        public string NumRefLBTREnlace
        {
            get { return strNumRefLBTREnlace; }
            set { strNumRefLBTREnlace = value; }
        }
        
        private string strPrioridad;

        public string Prioridad
        {
            get { return strPrioridad; }
            set { strPrioridad = value; }
        }       

        private string strConfirmaAbono;

        public string ConfirmaAbono
        {
            get { return strConfirmaAbono; }
            set { strConfirmaAbono = value; }
        }       

        private string strADES;

        public string ADES
        {
            get { return strADES; }
            set { strADES = value; }
        }

        private string _strFechaHoraRecepcion;

        public string strFechaHoraRecepcion
        {
            get { return _strFechaHoraRecepcion; }
            set { _strFechaHoraRecepcion = value; }
        }

        private string _strFechaHoraRegistro;

        public string strFechaHoraRegistro
        {
            get { return _strFechaHoraRegistro; }
            set { _strFechaHoraRegistro = value; }
        }

        private string _strFlujoRegistro;

        public string strFlujoRegistro
        {
            get { return _strFlujoRegistro; }
            set { _strFlujoRegistro = value; }
        }
                        
        public override string ToString()
        {
            StringBuilder sbTexto = new StringBuilder();
                        
            sbTexto.Append("CodBancoDestino: ");
            sbTexto.AppendLine(!String.IsNullOrEmpty(CodBancoDestino) ? CodBancoDestino : "");

            sbTexto.Append("CodBancoOrigen: ");
            sbTexto.AppendLine(!String.IsNullOrEmpty(CodBancoOrigen) ? CodBancoOrigen : "");

            sbTexto.Append("CodConcepto: ");
            sbTexto.AppendLine(!String.IsNullOrEmpty(CodConcepto) ? CodConcepto : "");

            sbTexto.Append("CodMoneda: ");
            sbTexto.AppendLine(!String.IsNullOrEmpty(CodMoneda) ? CodMoneda : "");

            sbTexto.Append("CodServicio: ");
            sbTexto.AppendLine(!String.IsNullOrEmpty(CodServicio) ? CodServicio : "");

            sbTexto.Append("CodigoSAB: ");
            sbTexto.AppendLine(!String.IsNullOrEmpty(CodigoSAB) ? CodigoSAB : "");

            sbTexto.Append("CuentaDestino: ");
            sbTexto.AppendLine(!String.IsNullOrEmpty(CuentaDestino) ? CuentaDestino : "");

            sbTexto.Append("CuentaInterbancariaSAB: ");
            sbTexto.AppendLine(!String.IsNullOrEmpty(CuentaInterbancariaSAB) ? CuentaInterbancariaSAB : "");

            sbTexto.Append("CuentaOrigen: ");
            sbTexto.AppendLine(!String.IsNullOrEmpty(CuentaOrigen) ? CuentaOrigen : "");

            sbTexto.Append("EstadoLiquidacion: ");
            sbTexto.AppendLine(!String.IsNullOrEmpty(EstadoLiquidacion) ? EstadoLiquidacion : "");

            sbTexto.Append("FechaLiquidacion: ");
            sbTexto.AppendLine(!String.IsNullOrEmpty(FechaLiquidacion) ? FechaLiquidacion : "");

            sbTexto.Append("FechaNegociacionCavali: ");
            sbTexto.AppendLine(!String.IsNullOrEmpty(FechaNegociacionCavali) ? FechaNegociacionCavali : "");

            sbTexto.Append("HoraLiquidacion: ");
            sbTexto.AppendLine(!String.IsNullOrEmpty(HoraLiquidacion) ? HoraLiquidacion : "");

            sbTexto.Append("InstruccionesPago: ");
            sbTexto.AppendLine(!String.IsNullOrEmpty(InstruccionesPago) ? InstruccionesPago : "");

            sbTexto.Append("Modalidad: ");
            sbTexto.AppendLine(!String.IsNullOrEmpty(Modalidad) ? Modalidad : "");

            sbTexto.Append("MontoOperacionOrigen: ");
            sbTexto.AppendLine(!String.IsNullOrEmpty(MontoOperacionOrigen) ? MontoOperacionOrigen : "");

            sbTexto.Append("MontoOperacionDestino: ");
            sbTexto.AppendLine(!String.IsNullOrEmpty(MontoOperacionDestino) ? MontoOperacionDestino : "");

            sbTexto.Append("NumRefCavali: ");
            sbTexto.AppendLine(!String.IsNullOrEmpty(NumRefCavali) ? NumRefCavali : "");

            sbTexto.Append("NumRefLBTREnlace: ");
            sbTexto.AppendLine(!String.IsNullOrEmpty(NumRefLBTREnlace) ? NumRefLBTREnlace : "");

            sbTexto.Append("NumRefOrigen: ");
            sbTexto.AppendLine(!String.IsNullOrEmpty(NumRefOrigen) ? NumRefOrigen : "");

            sbTexto.Append("TipoCambio: ");
            sbTexto.AppendLine(!String.IsNullOrEmpty(TipoCambio) ? TipoCambio : "");
                        
            sbTexto.Append("TipoParticipanteCavali: ");
            sbTexto.AppendLine(!String.IsNullOrEmpty(TipoParticipanteCavali) ? TipoParticipanteCavali : "");

            sbTexto.Append("TipoRegistro: ");
            sbTexto.AppendLine(!String.IsNullOrEmpty(TipoRegistro) ? TipoRegistro : "");            

            sbTexto.Append("Ades: ");
            sbTexto.AppendLine(!String.IsNullOrEmpty(ADES) ? ADES : "");

            sbTexto.Append("IndCORE: ");
            sbTexto.AppendLine(!String.IsNullOrEmpty(IndCORE) ? IndCORE : "");

            sbTexto.Append("IndCorporativo: ");
            sbTexto.AppendLine(!String.IsNullOrEmpty(IndCorporativo) ? IndCorporativo : "");

            sbTexto.Append("ColorRegistro: ");
            sbTexto.AppendLine(!String.IsNullOrEmpty(ColorRegistro) ? ColorRegistro : "");

            sbTexto.Append("CodTramaAuditoria: ");
            sbTexto.AppendLine(!String.IsNullOrEmpty(CodTramaAuditoria) ? CodTramaAuditoria : "");

            sbTexto.AppendLine("DatosCliente: [");
            sbTexto.AppendLine(oDatosCliente.ToString());
            sbTexto.Append("]");

            return sbTexto.ToString();
        }
        
    }
}
