using System;
using System.Collections.Generic;
using System.Text;
using TBEWinServ.EntidadesNegocio.Generales;

namespace TBEWinServ.EntidadesNegocio.ConsultasBCRP
{
    public class BE_OperacionRecibidaConsulta
    {
        public BE_OperacionRecibidaConsulta() { }

        private string strIdConsulta;

        public string IdConsulta
        {
            get { return strIdConsulta; }
            set { strIdConsulta = value; }
        }

        private string strFecConsulta;

        public string FecConsulta
        {
            get { return strFecConsulta; }
            set { strFecConsulta = value; }
        }

        private string strTipoConsulta;

        public string TipoConsulta
        {
            get { return strTipoConsulta; }
            set { strTipoConsulta = value; }
        }
                
        private string strCodBancoOrigen;

        public string CodBancoOrigen
        {
            get { return strCodBancoOrigen; }
            set { strCodBancoOrigen = value; }
        }

        private string strCodBancoDestino;

        public string CodBancoDestino
        {
            get { return strCodBancoDestino; }
            set { strCodBancoDestino = value; }
        }

        private string strCodConcepto;

        public string CodConcepto
        {
            get { return strCodConcepto; }
            set { strCodConcepto = value; }
        }

        private string strCodMoneda;

        public string CodMoneda
        {
            get { return strCodMoneda; }
            set { strCodMoneda = value; }
        }

        private string strCodServicio;

        public string CodServicio
        {
            get { return strCodServicio; }
            set { strCodServicio = value; }
        }
        
        private string strCuentaOrigen;

        public string CuentaOrigen
        {
            get { return strCuentaOrigen; }
            set { strCuentaOrigen = value; }
        }

        private string strCuentaDestino;

        public string CuentaDestino
        {
            get { return strCuentaDestino; }
            set { strCuentaDestino = value; }
        }

        private string strMontoOperacion;

        public string MontoOperacion
        {
            get { return strMontoOperacion; }
            set { strMontoOperacion = value; }
        }

        private string strMontoOperacionDestino;

        public string MontoOperacionDestino
        {
            get { return strMontoOperacionDestino; }
            set { strMontoOperacionDestino = value; }
        }
        
        private string strTipoCambio;

        public string TipoCambio
        {
            get { return strTipoCambio; }
            set { strTipoCambio = value; }
        }

        private string strNumRefOrigen;

        public string NumRefOrigen
        {
            get { return strNumRefOrigen; }
            set { strNumRefOrigen = value; }
        }

        private string strNumRefEnlace;

        public string NumRefEnlace
        {
            get { return strNumRefEnlace; }
            set { strNumRefEnlace = value; }
        }

        private string strFechaLiquidacion;

        public string FechaLiquidacion
        {
            get { return strFechaLiquidacion; }
            set { strFechaLiquidacion = value; }
        }

        private string strHoraLiquidacion = "";

        public string HoraLiquidacion
        {
            get { return strHoraLiquidacion; }
            set { strHoraLiquidacion = value; }
        }

        private string strPrioridad;

        public string Prioridad
        {
            get { return strPrioridad; }
            set { strPrioridad = value; }
        }

        private string strNumRefLBTR;

        public string NumRefLBTR
        {
            get { return strNumRefLBTR; }
            set { strNumRefLBTR = value; }
        }

        private string strConfirmaAbono;

        public string ConfirmaAbono
        {
            get { return strConfirmaAbono; }
            set { strConfirmaAbono = value; }
        }

        private string strEstado;

        public string Estado
        {
            get { return strEstado; }
            set { strEstado = value; }
        }

        private string strInstruccionesPago;

        public string InstruccionesPago
        {
            get { return strInstruccionesPago; }
            set { strInstruccionesPago = value; }
        }

        private string strCodTramaAuditoria;

        public string CodTramaAuditoria
        {
            get { return strCodTramaAuditoria; }
            set { strCodTramaAuditoria = value; }
        }

        private string strModalidad;

        public string Modalidad
        {
            get { return strModalidad; }
            set { strModalidad = value; }
        }

        private string strTipoRegistro;

        public string TipoRegistro
        {
            get { return strTipoRegistro; }
            set { strTipoRegistro = value; }
        }
                
        private BE_DatosCliente oDatosCliente = new BE_DatosCliente();

        public BE_DatosCliente DatosCliente
        {
            get { return oDatosCliente; }
            set { oDatosCliente = value; }
        }

    }
}
