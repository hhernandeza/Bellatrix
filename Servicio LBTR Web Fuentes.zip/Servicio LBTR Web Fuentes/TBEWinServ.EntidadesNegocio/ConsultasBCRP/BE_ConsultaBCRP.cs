using System;
using System.Collections.Generic;
using System.Text;

namespace TBEWinServ.EntidadesNegocio.ConsultasBCRP
{
    [Serializable]
    public class BE_ConsultaBCRP
    {
        public BE_ConsultaBCRP() { }
                
        //Inicio Identificador Consulta
        private string strIdConsulta;

        public string IdConsulta
        {
            get { return strIdConsulta; }
            set { strIdConsulta = value; }
        }

        private string strFechaConsulta;

        public string FechaConsulta
        {
            get { return strFechaConsulta; }
            set { strFechaConsulta = value; }
        }

        private string strTipoConsulta;

        public string TipoConsulta
        {
            get { return strTipoConsulta; }
            set { strTipoConsulta = value; }
        }

        //Fin Identificador Consulta

        //Inicio Parametros de Consulta
        private string strFechaLiquidacion;

        public string FechaLiquidacion
        {
            get { return strFechaLiquidacion; }
            set { strFechaLiquidacion = value; }
        }

        private string strNumeroCuenta;

        public string NumeroCuenta
        {
            get { return strNumeroCuenta; }
            set { strNumeroCuenta = value; }
        }
        
        //Fin Parametros de Consulta

    }
}
