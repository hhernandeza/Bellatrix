using System;
using System.Collections.Generic;
using System.Text;

namespace TBEWinServ.EntidadesNegocio.ConsultasBCRP
{
    public class BE_SaldoCtaCte
    {
        public BE_SaldoCtaCte() { }

        private string strIdConsulta;

        public string IdConsulta
        {
            get { return strIdConsulta; }
            set { strIdConsulta = value; }
        }

        private string strFecConsulta;

        public string FecConsulta
        {
            get { return strFecConsulta; }
            set { strFecConsulta = value; }
        }

        private string strFechaSaldo;

        public string FechaSaldo
        {
            get { return strFechaSaldo; }
            set { strFechaSaldo = value; }
        }

        private string strCodEntidad;

        public string CodEntidad
        {
            get { return strCodEntidad; }
            set { strCodEntidad = value; }
        }

        private string strNumCuenta;

        public string NumCuenta
        {
            get { return strNumCuenta; }
            set { strNumCuenta = value; }
        }

        private string strSaldoInicial;

        public string SaldoInicial
        {
            get { return strSaldoInicial; }
            set { strSaldoInicial = value; }
        }

        private string strSaldoActual;

        public string SaldoActual
        {
            get { return strSaldoActual; }
            set { strSaldoActual = value; }
        }

        private string strTotalCargos;

        public string TotalCargos
        {
            get { return strTotalCargos; }
            set { strTotalCargos = value; }
        }

        private string strTotalAbonos;

        public string TotalAbonos
        {
            get { return strTotalAbonos; }
            set { strTotalAbonos = value; }
        }

    }
}
