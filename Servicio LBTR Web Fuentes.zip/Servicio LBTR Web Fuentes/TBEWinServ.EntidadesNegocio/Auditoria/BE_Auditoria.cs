using System;
using System.Collections.Generic;
using System.Text;

namespace TBEWinServ.EntidadesNegocio.Auditoria
{
    public class BE_Auditoria
    {
        private string strCodTramaAuditoria;

        public string CodTramaAuditoria
        {
            get { return strCodTramaAuditoria; }
            set { strCodTramaAuditoria = value; }
        }

        private DateTime fecOperacion;

        public DateTime FecOperacion
        {
            get { return fecOperacion; }
            set { fecOperacion = value; }
        }

        private string strTipoOperacion;

        public string TipoOperacion
        {
            get { return strTipoOperacion; }
            set { strTipoOperacion = value; }
        }

        private string strTrama;

        public string Trama
        {
            get { return strTrama; }
            set { strTrama = value; }
        }

        private string strTramaEnClaro;

        public string TramaEnClaro
        {
            get { return strTramaEnClaro; }
            set { strTramaEnClaro = value; }
        }

        private string strCodBancoOri;

        public string CodBancoOri
        {
            get { return strCodBancoOri; }
            set { strCodBancoOri = value; }
        }

        private string strCodBancoDest;

        public string CodBancoDest
        {
            get { return strCodBancoDest; }
            set { strCodBancoDest = value; }
        }
        
        private int? indKPubBanco;

        public int? IndiceKPubBanco
        {
            get { return indKPubBanco; }
            set { indKPubBanco = value; }
        }

        private int? indKPubBCRP;

        public int? IndiceKPubBCRP
        {
            get { return indKPubBCRP; }
            set { indKPubBCRP = value; }
        }

        private int? indKPriCiti;

        public int? IndiceKPriCiti
        {
            get { return indKPriCiti; }
            set { indKPriCiti = value; }
        }

        private DateTime? fecOperacionIni;

        public DateTime? FecOperacionIni
        {
            get { return fecOperacionIni; }
            set { fecOperacionIni = value; }
        }

        private DateTime? fecOperacionFin;

        public DateTime? FecOperacionFin
        {
            get { return fecOperacionFin; }
            set { fecOperacionFin = value; }
        }

        private string strFirma;

        public string Firma
        {
            get { return strFirma; }
            set { strFirma = value; }
        }

        public BE_Auditoria() { }

        public BE_Auditoria(string prmCodTramaAuditoria) 
        {
            strCodTramaAuditoria = prmCodTramaAuditoria;
        }
                
    }
}
