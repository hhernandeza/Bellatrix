﻿using System;
using System.Collections.Generic;
using System.Text;
using TBEWinServ.EntidadesNegocio.Generales;

namespace TBEWinServ.EntidadesNegocio.CompraVenta
{
    //InstruirCompraVenta() al BCRP
    [Serializable]
    public class BE_CompraVentaSalidas
    {
        public BE_CompraVentaSalidas() { }

        public BE_CompraVentaSalidas(string prmNumRefLBTR) 
        {
            NUM_REF_ORIGEN = prmNumRefLBTR;
        }

        Int32? nID_LBTR_SALIDAS;

        public Int32? ID_LBTR_SALIDAS
        {
            get { return nID_LBTR_SALIDAS; }
            set { nID_LBTR_SALIDAS = value; }
        }

        string strCOD_SERVICIO;

        public string COD_SERVICIO
        {
            get { return strCOD_SERVICIO; }
            set { strCOD_SERVICIO = value; }
        }
        string strSID;

        public string SID
        {
            get { return strSID; }
            set { strSID = value; }
        }

        string strCOD_CONCEPTO;

        public string COD_CONCEPTO
        {
            get { return strCOD_CONCEPTO; }
            set { strCOD_CONCEPTO = value; }
        }

        string strBCO_ORIGEN;

        public string BCO_ORIGEN
        {
            get { return strBCO_ORIGEN; }
            set { strBCO_ORIGEN = value; }
        }

        string strBCO_DESTINO;

        public string BCO_DESTINO
        {
            get { return strBCO_DESTINO; }
            set { strBCO_DESTINO = value; }
        }

        string strCTA_DESTINO;

        public string CTA_DESTINO
        {
            get { return strCTA_DESTINO; }
            set { strCTA_DESTINO = value; }
        }

        string strCTA_ORIGEN;

        public string CTA_ORIGEN
        {
            get { return strCTA_ORIGEN; }
            set { strCTA_ORIGEN = value; }
        }

        DateTime? dtFECHA_LIQUIDACION;

        public DateTime? FECHA_LIQUIDACION
        {
            get { return dtFECHA_LIQUIDACION; }
            set { dtFECHA_LIQUIDACION = value; }
        }

        string strINSTRUCCIONES_PAGO;

        public string INSTRUCCIONES_PAGO
        {
            get { return strINSTRUCCIONES_PAGO; }
            set { strINSTRUCCIONES_PAGO = value; }
        }

        decimal? dcMONTO_ME;

        public decimal? MONTO_ME
        {
            get { return dcMONTO_ME; }
            set { dcMONTO_ME = value; }
        }

        decimal? dcMONTO_MN;

        public decimal? MONTO_MN
        {
            get { return dcMONTO_MN; }
            set { dcMONTO_MN = value; }
        }

        string str_NUM_REF_ORIGEN;

        public string NUM_REF_ORIGEN
        {
            get { return str_NUM_REF_ORIGEN; }
            set { str_NUM_REF_ORIGEN = value; }
        }

        string str_NUM_REF_LBTR_CV;

        public string NUM_REF_LBTR_CV
        {
            get { return str_NUM_REF_LBTR_CV; }
            set { str_NUM_REF_LBTR_CV = value; }
        }

        decimal? dcTIPO_CAMBIO;

        public decimal? TIPO_CAMBIO
        {
            get { return dcTIPO_CAMBIO; }
            set { dcTIPO_CAMBIO = value; }
        }

        DateTime? dtFECHA_CARGADO;

        public DateTime? FECHA_CARGADO
        {
            get { return dtFECHA_CARGADO; }
            set { dtFECHA_CARGADO = value; }
        }

        DateTime? dtFECHA_PROCESO_ENVIADO;

        public DateTime? FECHA_PROCESO_ENVIADO
        {
            get { return dtFECHA_PROCESO_ENVIADO; }
            set { dtFECHA_PROCESO_ENVIADO = value; }
        }

        DateTime? dtFECHA_ENVIO_ESPERA;

        public DateTime? FECHA_ENVIO_ESPERA
        {
            get { return dtFECHA_ENVIO_ESPERA; }
            set { dtFECHA_ENVIO_ESPERA = value; }
        }

        DateTime? dtFECHA_ENVIADO_ANULADO;

        public DateTime? FECHA_ENVIADO_ANULADO
        {
            get { return dtFECHA_ENVIADO_ANULADO; }
            set { dtFECHA_ENVIADO_ANULADO = value; }
        }

        DateTime? dtFECHA_ENVIADO_ERROR;

        public DateTime? FECHA_ENVIADO_ERROR
        {
            get { return dtFECHA_ENVIADO_ERROR; }
            set { dtFECHA_ENVIADO_ERROR = value; }
        }

        DateTime? dtFECHA_REGISTRADO_BCRP;

        public DateTime? FECHA_REGISTRADO_BCRP
        {
            get { return dtFECHA_REGISTRADO_BCRP; }
            set { dtFECHA_REGISTRADO_BCRP = value; }
        }

        string strESTADO_LBTR;

        public string ESTADO_LBTR
        {
            get { return strESTADO_LBTR; }
            set { strESTADO_LBTR = value; }
        }

        string strESTADO_ENVIO;

        public string ESTADO_ENVIO
        {
            get { return strESTADO_ENVIO; }
            set { strESTADO_ENVIO = value; }
        }

        //Para la respuesta del BCRP
        //string strRptaEstadoBCRP;

        //public string RptaEstadoBCRP
        //{
        //    get { return strRptaEstadoBCRP; }
        //    set { strRptaEstadoBCRP = value; }
        //}

        string strNUM_REF_LBTR;//LQ

        public string NUM_REF_LBTR
        {
            get { return strNUM_REF_LBTR; }
            set { strNUM_REF_LBTR = value; }
        }

        string strTIPO_INGRESO;

        public string TIPO_INGRESO
        {
            get { return strTIPO_INGRESO; }
            set { strTIPO_INGRESO = value; }
        }

        string strMENSAJE_LBTR;//LQ

        public string MENSAJE_LBTR
        {
            get { return strMENSAJE_LBTR; }
            set { strMENSAJE_LBTR = value; }
        }

        string strCODIGO_ERROR_LBTR;
        public string CODIGO_ERROR_LBTR
        {
            get { return strCODIGO_ERROR_LBTR; }
            set { strCODIGO_ERROR_LBTR = value; }
        }

        //adicionales
        private string strFIRMA;

        public string FIRMA
        {
            get { return strFIRMA; }
            set { strFIRMA = value; }
        }
    }
}
