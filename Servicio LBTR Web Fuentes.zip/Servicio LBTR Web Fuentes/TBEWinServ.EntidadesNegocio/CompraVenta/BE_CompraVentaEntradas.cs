﻿using System;
using System.Collections.Generic;
using System.Text;
using TBEWinServ.EntidadesNegocio.Generales;

namespace TBEWinServ.EntidadesNegocio.CompraVenta
{
    [Serializable]
    public class BE_CompraVentaEntradas
    {
        public BE_CompraVentaEntradas() { }

        public BE_CompraVentaEntradas(string prmNumRefLBTR) 
        {
            strNumRefLBTR = prmNumRefLBTR;
        }

        string strCodBancoDestino;

        public string CodBancoDestino
        {
            get { return strCodBancoDestino; }
            set { strCodBancoDestino = value; }
        }

        string strCodBancoOrigen;

        public string CodBancoOrigen
        {
            get { return strCodBancoOrigen; }
            set { strCodBancoOrigen = value; }
        }

        string strCodConcepto;

        public string CodConcepto
        {
            get { return strCodConcepto; }
            set { strCodConcepto = value; }
        }

        string strCodMoneda;

        public string CodMoneda
        {
            get { return strCodMoneda; }
            set { strCodMoneda = value; }
        }

        string strCodSAB;

        public string CodSAB
        {
            get { return strCodSAB; }
            set { strCodSAB = value; }
        }

        string strCodServicio;

        public string CodServicio
        {
            get { return strCodServicio; }
            set { strCodServicio = value; }
        }

        string strCtaInterbancariaSAB;

        public string CtaInterbancariaSAB
        {
            get { return strCtaInterbancariaSAB; }
            set { strCtaInterbancariaSAB = value; }
        }

        string strCtaDestino;

        public string CtaDestino
        {
            get { return strCtaDestino; }
            set { strCtaDestino = value; }
        }

        string strCtaOrigen;

        public string CtaOrigen
        {
            get { return strCtaOrigen; }
            set { strCtaOrigen = value; }
        }

        string strEstado;

        public string Estado
        {
            get { return strEstado; }
            set { strEstado = value; }
        }

        string strFechaLiquidacion;

        public string FechaLiquidacion
        {
            get { return strFechaLiquidacion; }
            set { strFechaLiquidacion = value; }
        }

        string strFechaNegociacionCavali;

        public string FechaNegociacionCavali
        {
            get { return strFechaNegociacionCavali; }
            set { strFechaNegociacionCavali = value; }
        }

        string strHoraLiquidacion;

        public string HoraLiquidacion
        {
            get { return strHoraLiquidacion; }
            set { strHoraLiquidacion = value; }
        }

        string strInstruccionesPago;

        public string InstruccionesPago
        {
            get { return strInstruccionesPago; }
            set { strInstruccionesPago = value; }
        }

        string strModalidad;

        public string Modalidad
        {
            get { return strModalidad; }
            set { strModalidad = value; }
        }

        string strMontoDestino;

        public string MontoDestino
        {
            get { return strMontoDestino; }
            set { strMontoDestino = value; }
        }

        string strMontoOrigen;

        public string MontoOrigen
        {
            get { return strMontoOrigen; }
            set { strMontoOrigen = value; }
        }

        string strNumRefCavali;

        public string NumRefCavali
        {
            get { return strNumRefCavali; }
            set { strNumRefCavali = value; }
        }

        string strNumRefLBTR;

        public string NumRefLBTR
        {
            get { return strNumRefLBTR; }
            set { strNumRefLBTR = value; }
        }

        string strNumRefLBTREnlace;

        public string NumRefLBTREnlace
        {
            get { return strNumRefLBTREnlace; }
            set { strNumRefLBTREnlace = value; }
        }

        string strNumRefOrigen;

        public string NumRefOrigen
        {
            get { return strNumRefOrigen; }
            set { strNumRefOrigen = value; }
        }

        string strTipoCambio;

        public string TipoCambio
        {
            get { return strTipoCambio; }
            set { strTipoCambio = value; }
        }

        string strTipoParticipanteCavali;

        public string TipoParticipanteCavali
        {
            get { return strTipoParticipanteCavali; }
            set { strTipoParticipanteCavali = value; }
        }

        string strTipoRegistro;

        public string TipoRegistro
        {
            get { return strTipoRegistro; }
            set { strTipoRegistro = value; }
        }

        string strDatoCliente; //FLAG

        public string DatoCliente
        {
            get { return strDatoCliente; }
            set { strDatoCliente = value; }
        }

        string strEstadoProceso;

        public string EstadoProceso
        {
            get { return strEstadoProceso; }
            set { strEstadoProceso = value; }
        }

        string strFechaRecepcion;

        public string FechaRecepcion
        {
            get { return strFechaRecepcion; }
            set { strFechaRecepcion = value; }
        }

        private string strFirma;

        public string Firma
        {
            get { return strFirma; }
            set { strFirma = value; }
        }

        //Campos extra

        private string strFlujoRegistro;

        public string FlujoRegistro
        {
            get { return strFlujoRegistro; }
            set { strFlujoRegistro = value; }
        }




    }
}
