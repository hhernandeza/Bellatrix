using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using TBEWinServ.EntidadesNegocio.Generales;

namespace TBEWinServ.FachadaRemotingCliente
{
    public class ConfiguracionCliente
    {
        public static List<BE_ConfiguracionCliente> ObtenerConfiguracionCliente(string prmRutaArchivo)
        {

            XmlTextReader reader = new XmlTextReader(prmRutaArchivo);
            List<BE_ConfiguracionCliente> lstConfiguracionCliente = new List<BE_ConfiguracionCliente>();
            BE_ConfiguracionCliente oConfiguracion = null;

            try
            {
                while (reader.Read())
                {

                    if (reader.NodeType == XmlNodeType.Element)
                    {
                        if (reader.Name == "Parametro")
                        {
                            oConfiguracion = new BE_ConfiguracionCliente();
                            oConfiguracion.Nombre = reader.GetAttribute("Nombre");
                            oConfiguracion.Valor = reader.GetAttribute("Valor");

                            lstConfiguracionCliente.Add(oConfiguracion);
                        }
                    }

                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (reader != null) reader.Close();
            }

            return lstConfiguracionCliente;
        }

        public static string ObtenerParametro(string prmRutaArchivo, string prmNombreParametro)
        {
            List<BE_ConfiguracionCliente> lstListaConfiguracion = ObtenerConfiguracionCliente(prmRutaArchivo);

            if (lstListaConfiguracion == null) return null;

            BE_ConfiguracionCliente oBusConfig = lstListaConfiguracion.Find(delegate(BE_ConfiguracionCliente oConfig) { return oConfig.Nombre == prmNombreParametro; });

            if (oBusConfig != null) return oBusConfig.Valor;

            return null;
        }

    }
}
