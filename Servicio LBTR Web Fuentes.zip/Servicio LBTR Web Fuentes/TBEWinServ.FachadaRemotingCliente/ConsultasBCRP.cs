using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Runtime.InteropServices;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Channels.Tcp;
using TBEWinServ.RemotingInterfaces;
using TBEWinServ.EntidadesNegocio.ConsultasBCRP;

namespace TBEWinServ.FachadaRemotingCliente
{
    [Guid("C2AD6135-798A-41b1-8595-4607E15484F1")]
    public class ConsultasBCRP
    {
        private IConsultasBCRP _Proxy_ConsultasBCRP;
        private string strRutaAssembly;
        private string strRutaArchivoConfiguracion;
        private string strTcpURL;
        private string strRutaLog;

        public ConsultasBCRP() 
        {
            try
            {
                strRutaAssembly = Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location);
                strRutaArchivoConfiguracion = strRutaAssembly + "\\TBEWinServ.FachadaRemotingCliente.xml";

                strTcpURL = ConfiguracionCliente.ObtenerParametro(strRutaArchivoConfiguracion, "tcpURL");
                strRutaLog = ConfiguracionCliente.ObtenerParametro(strRutaArchivoConfiguracion, "RutaLog");

                TcpClientChannel channel = new TcpClientChannel();

                if (ChannelServices.GetChannel(channel.ChannelName) == null)
                    ChannelServices.RegisterChannel(channel);

                _Proxy_ConsultasBCRP = (IConsultasBCRP)Activator.GetObject
                (
                    typeof(IConsultasBCRP), strTcpURL + "/" + ServiciosConocidos.ConsultasBCRP
                );

                LogCliente.EscribirLog(strRutaLog, "Se inicializo correctamente la clase TBEWinServ.FachadaRemotingCliente.ConsultasBCRP");
            }
            catch (Exception ex)
            {
                LogCliente.EscribirLog(strRutaLog, "Error al inicializar la clase TBEWinServ.FachadaRemotingCliente.ConsultasBCRP. \r\n\r\nMensaje: " + ex.Message + "\r\n\r\n" + ex.StackTrace);
            }        
        }

        public int ConsultarOperacionesOtorgadas(string prmIdConsulta, string prmFechaLiquidacion)
        {
            int nRespuesta = 0;

            try
            {
                LogCliente.EscribirLog(strRutaLog, "Se invoco al metodo ConsultarOperacionesOtorgadas de la clase TBEWinServ.FachadaRemotingCliente.ConsultasBCRP");

                BE_ConsultaBCRP oParamCons = new BE_ConsultaBCRP();
                oParamCons.FechaLiquidacion = prmFechaLiquidacion;
                oParamCons.IdConsulta = prmIdConsulta;

                nRespuesta = _Proxy_ConsultasBCRP.ConsultarOperacionesOtorgadas(oParamCons);
            }
            catch (Exception ex)
            {
                LogCliente.EscribirLog(strRutaLog, "Error en el metodo ConsultarOperacionesOtorgadas de la clase TBEWinServ.FachadaRemotingCliente.ConsultasBCRP. \r\n\r\nMensaje: " + ex.Message + "\r\n\r\n" + ex.StackTrace);
                nRespuesta = -1;
            }

            return nRespuesta;
        }

        public int ConsultarOperacionesRecibidas(string prmIdConsulta, 
                                                    string prmFechaLiquidacion, 
                                                    string prmUsarLlavesHistoricas)
        {
            int nRespuesta = 0;
            bool blnUsarLlavesActuales = true;

            try
            {
                LogCliente.EscribirLog(strRutaLog, "Se invoco al metodo ConsultarOperacionesRecibidas de la clase TBEWinServ.FachadaRemotingCliente.ConsultasBCRP");

                if (!String.IsNullOrEmpty(prmUsarLlavesHistoricas))
                {
                    if (prmUsarLlavesHistoricas.Equals("1"))
                    {
                        blnUsarLlavesActuales = false;
                    }
                }

                BE_ConsultaBCRP oParamCons = new BE_ConsultaBCRP();
                oParamCons.FechaLiquidacion = prmFechaLiquidacion;
                oParamCons.IdConsulta = prmIdConsulta;

                nRespuesta = _Proxy_ConsultasBCRP.ConsultarOperacionesRecibidas(oParamCons, blnUsarLlavesActuales);
            }
            catch (Exception ex)
            {
                LogCliente.EscribirLog(strRutaLog, "Error en el metodo ConsultarOperacionesRecibidas de la clase TBEWinServ.FachadaRemotingCliente.ConsultasBCRP. \r\n\r\nMensaje: " + ex.Message + "\r\n\r\n" + ex.StackTrace);
                nRespuesta = -1;
            }

            return nRespuesta;
        }

        public int ConsultarSaldosCtaCte(string prmIdConsulta, string prmFecha, string prmNumeroCuenta)
        {
            int nRespuesta = 0;

            try
            {
                LogCliente.EscribirLog(strRutaLog, "Se invoco al metodo ConsultarSaldosCtaCte de la clase TBEWinServ.FachadaRemotingCliente.ConsultasBCRP");

                BE_ConsultaBCRP oParamCons = new BE_ConsultaBCRP();
                oParamCons.IdConsulta = prmIdConsulta;
                oParamCons.FechaLiquidacion = prmFecha;
                oParamCons.NumeroCuenta = prmNumeroCuenta;

                nRespuesta = _Proxy_ConsultasBCRP.ConsultarSaldosCtaCte(oParamCons);
            }
            catch (Exception ex)
            {
                LogCliente.EscribirLog(strRutaLog, "Error en el metodo ConsultarSaldosCtaCte de la clase TBEWinServ.FachadaRemotingCliente.ConsultasBCRP. \r\n\r\nMensaje: " + ex.Message + "\r\n\r\n" + ex.StackTrace);
                nRespuesta = -1;
            }

            return nRespuesta;
        }

    }
}
