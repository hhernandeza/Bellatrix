using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Runtime.InteropServices;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Channels.Tcp;
using TBEWinServ.RemotingInterfaces;

namespace TBEWinServ.FachadaRemotingCliente
{
    [Guid("029B8D16-A737-43b2-B1DC-74EEC07C36A0")]
    public class Auditoria
    {
        private IAuditoria _Proxy_ConsultasBCRP;
        private string strRutaAssembly;
        private string strRutaArchivoConfiguracion;
        private string strTcpURL;
        private string strRutaLog;

        public Auditoria() 
        {
            try
            {
                strRutaAssembly = Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location);
                strRutaArchivoConfiguracion = strRutaAssembly + "\\TBEWinServ.FachadaRemotingCliente.xml";

                strTcpURL = ConfiguracionCliente.ObtenerParametro(strRutaArchivoConfiguracion, "tcpURL");
                strRutaLog = ConfiguracionCliente.ObtenerParametro(strRutaArchivoConfiguracion, "RutaLog");

                TcpClientChannel channel = new TcpClientChannel();

                if (ChannelServices.GetChannel(channel.ChannelName) == null)
                    ChannelServices.RegisterChannel(channel);

                _Proxy_ConsultasBCRP = (IAuditoria)Activator.GetObject
                (
                    typeof(IAuditoria), strTcpURL + "/" + ServiciosConocidos.Auditoria
                );

                LogCliente.EscribirLog(strRutaLog, "Se inicializo correctamente la clase TBEWinServ.FachadaRemotingCliente.Auditoria");
            }
            catch (Exception ex)
            {
                LogCliente.EscribirLog(strRutaLog, "Error al inicializar la clase TBEWinServ.FachadaRemotingCliente.Auditoria. \r\n\r\nMensaje: " + ex.Message + "\r\n\r\n" + ex.StackTrace);
            }        
        }

        public int ConsultarAuditoria(string prmIdConsulta, string prmTipoOperacion, string prmEstados, 
                                        string prmFechaIni, string prmFechaFin, string prmCodBanco, 
                                        string prmCodConcepto, string prmUsarLlavesHistoricas)
        {
            int nRespuesta = 0;
            bool blnUsarLlavesActuales = true;

            try
            {
                LogCliente.EscribirLog(strRutaLog, "Se invoco al metodo ConsultarAuditoria de la clase TBEWinServ.FachadaRemotingCliente.Auditoria");

                if (!String.IsNullOrEmpty(prmUsarLlavesHistoricas))
                {
                    if (prmUsarLlavesHistoricas.Equals("1"))
                    {
                        blnUsarLlavesActuales = false;
                    }
                }

                nRespuesta = _Proxy_ConsultasBCRP.ConsultarAuditoria(prmIdConsulta, prmTipoOperacion, prmEstados, 
                                                                        prmFechaIni, prmFechaFin, prmCodBanco,
                                                                        prmCodConcepto, blnUsarLlavesActuales);
            }
            catch (Exception ex)
            {
                LogCliente.EscribirLog(strRutaLog, "Error en el metodo ConsultarAuditoria de la clase TBEWinServ.FachadaRemotingCliente.Auditoria. \r\n\r\nMensaje: " + ex.Message + "\r\n\r\n" + ex.StackTrace);
                nRespuesta = -1;
            }

            return nRespuesta;        
        }
    }
}
