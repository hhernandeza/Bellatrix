using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace TBEWinServ.FachadaRemotingCliente
{
    public class LogCliente
    {
        public static void EscribirLog(string prmRutaLog, string prmContenido)
        {
            try
            {
                if (!prmRutaLog.EndsWith(@"\")) prmRutaLog += @"\";

                prmRutaLog += "TBEWinServCliente_" + DateTime.Today.ToString("yyyyMMdd") + ".txt";

                File.AppendAllText(prmRutaLog, "\r\n\r\n" + DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss") + ": " + prmContenido, Encoding.Unicode);
            }
            catch { }
        }
    }
}
