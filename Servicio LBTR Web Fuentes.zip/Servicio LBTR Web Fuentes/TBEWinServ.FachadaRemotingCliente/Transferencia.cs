using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Runtime.InteropServices;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Channels.Tcp;
using TBEWinServ.RemotingInterfaces;
using TBEWinServ.EntidadesNegocio.Transferencia;

namespace TBEWinServ.FachadaRemotingCliente
{
    [Guid("18268435-A291-4cca-8F3B-E9C082E0CB47")]
    public class Transferencia
    {
        private ITransferencia _Proxy_Transferencia;
        private string strRutaAssembly;
        private string strRutaArchivoConfiguracion;
        private string strTcpURL;
        private string strRutaLog;

        public Transferencia() 
        {
            try
            {
                strRutaAssembly = Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location);
                strRutaArchivoConfiguracion = strRutaAssembly + "\\TBEWinServ.FachadaRemotingCliente.xml";

                strTcpURL = ConfiguracionCliente.ObtenerParametro(strRutaArchivoConfiguracion, "tcpURL");
                strRutaLog = ConfiguracionCliente.ObtenerParametro(strRutaArchivoConfiguracion, "RutaLog");

                TcpClientChannel channel = new TcpClientChannel();

                if (ChannelServices.GetChannel(channel.ChannelName) == null)
                    ChannelServices.RegisterChannel(channel);

                _Proxy_Transferencia = (ITransferencia)Activator.GetObject
                (
                    typeof(ITransferencia), strTcpURL + "/" + ServiciosConocidos.Transferencia
                );

                LogCliente.EscribirLog(strRutaLog, "Se inicializo correctamente la clase TBEWinServ.FachadaRemotingCliente.Transferencia");
            }
            catch (Exception ex)
            {
                LogCliente.EscribirLog(strRutaLog, "Error al inicializar la clase TBEWinServ.FachadaRemotingCliente.Transferencia. \r\n\r\nMensaje: " + ex.Message + "\r\n\r\n" + ex.StackTrace);
            }
        
        }
                
        public int EnviarTransferencia(string prmTransact, string prmSEC, string prmTransferidoPor) 
        {
            int nRespuesta = 0;

            try
            {
                LogCliente.EscribirLog(strRutaLog, "Se invoco al metodo EnviarTransferencia de la clase TBEWinServ.FachadaRemotingCliente.Transferencia");

                BE_Transferencia oParamTransf = new BE_Transferencia();
                oParamTransf.TRANSACT = prmTransact;
                oParamTransf.SEC = prmSEC;
                oParamTransf.TransferidoPor = prmTransferidoPor;

                nRespuesta = _Proxy_Transferencia.EnviarTransferencia(oParamTransf);
            }
            catch (Exception ex)
            {
                LogCliente.EscribirLog(strRutaLog, "Error en el metodo EnviarTransferencia de la clase TBEWinServ.FachadaRemotingCliente.Transferencia. \r\n\r\nMensaje: " + ex.Message + "\r\n\r\n" + ex.StackTrace);
                nRespuesta = - 1;
            }

            return nRespuesta;
        }
        
        public int AnularOperacionPendiente(string prmNumRefLBTR)
        {
            int nRespuesta = 0;

            try
            {
                LogCliente.EscribirLog(strRutaLog, "Se invoco al metodo AnularOperacionPendiente de la clase TBEWinServ.FachadaRemotingCliente.Transferencia");

                nRespuesta = _Proxy_Transferencia.AnularOperacionPendiente(prmNumRefLBTR);
            }
            catch (Exception ex)
            {
                LogCliente.EscribirLog(strRutaLog, "Error en el metodo AnularOperacionPendiente de la clase TBEWinServ.FachadaRemotingCliente.Transferencia. \r\n\r\nMensaje: " + ex.Message + "\r\n\r\n" + ex.StackTrace);
                nRespuesta = -1;
            }

            return nRespuesta;
        }

        public int ConfirmarAbonoCliente(string prmNumRefLBTR) 
        {
            int nRespuesta = 0;

            try
            {
                LogCliente.EscribirLog(strRutaLog, "Se invoco al metodo ConfirmarAbonoCliente de la clase TBEWinServ.FachadaRemotingCliente.Transferencia");
                                
                nRespuesta = _Proxy_Transferencia.ConfirmarAbonoCliente(prmNumRefLBTR);
            }
            catch (Exception ex)
            {
                LogCliente.EscribirLog(strRutaLog, "Error en el metodo ConfirmarAbonoCliente de la clase TBEWinServ.FachadaRemotingCliente.Transferencia. \r\n\r\nMensaje: " + ex.Message + "\r\n\r\n" + ex.StackTrace);
                nRespuesta = -1;
            }

            return nRespuesta;
        }
    }
}
