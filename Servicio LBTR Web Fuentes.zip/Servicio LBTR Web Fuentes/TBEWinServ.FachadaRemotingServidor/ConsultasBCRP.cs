using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using TBEWinServ.RemotingInterfaces;
using TBEWinServ.EntidadesNegocio.ConsultasBCRP;
using TBEWinServ.LogicaNegocio;
using TBEWinServ.Utilitarios;

namespace TBEWinServ.FachadaRemotingServidor
{
    public class ConsultasBCRP : MarshalByRefObject, IConsultasBCRP
    {
        
        public int ConsultarOperacionesOtorgadas(BE_ConsultaBCRP prmConsultaBCRP)
        {
            string strHashcode = Utilitario.GenerarCodigo(15);
            BL_ConsultasBCRP oBLCons = new BL_ConsultasBCRP(strHashcode);
            return oBLCons.ConsultarOperacionesOtorgadas(prmConsultaBCRP);
        }

        public int ConsultarOperacionesRecibidas(BE_ConsultaBCRP prmConsultaBCRP, bool blnUsarLlavesActuales)
        {
            string strHashcode = Utilitario.GenerarCodigo(15);
            BL_ConsultasBCRP oBLCons = new BL_ConsultasBCRP(strHashcode);
            return oBLCons.ConsultarOperacionesRecibidas(prmConsultaBCRP, blnUsarLlavesActuales);
        }

        public int ConsultarSaldosCtaCte(BE_ConsultaBCRP prmConsultaBCRP)
        {
            string strHashcode = Utilitario.GenerarCodigo(15);
            BL_ConsultasBCRP oBLCons = new BL_ConsultasBCRP(strHashcode);
            return oBLCons.ConsultarSaldosCtaCte(prmConsultaBCRP);
        }

    }
}
