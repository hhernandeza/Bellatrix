using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using TBEWinServ.RemotingInterfaces;
using TBEWinServ.EntidadesNegocio.Transferencia;
using TBEWinServ.LogicaNegocio;
using TBEWinServ.Utilitarios;

namespace TBEWinServ.FachadaRemotingServidor
{
    public class Transferencia : MarshalByRefObject, ITransferencia
    {        
        public int EnviarTransferencia(BE_Transferencia prmTransferencia)
        {
            string strHashcode = Utilitario.GenerarCodigo(15);
            BL_Transferencia oBLTransf = new BL_Transferencia(strHashcode);
            return oBLTransf.EnviarTransferencia(prmTransferencia);
        }

        public int ConfirmarAbonoCliente(string prmNumRefLBTR) 
        {
            string strHashcode = Utilitario.GenerarCodigo(15);
            BL_ConfirmacionAbono oBLConf = new BL_ConfirmacionAbono(strHashcode);
            return oBLConf.ConfirmarAbonoCliente(prmNumRefLBTR, false);
        }

        public int AnularOperacionPendiente(string prmNumRefLBTR)
        {
            string strHashcode = Utilitario.GenerarCodigo(15);
            BL_Transferencia oBLTransf = new BL_Transferencia(strHashcode);
            return oBLTransf.AnularOperacionPendiente(prmNumRefLBTR);
        }
    }
}
