using System;
using System.Collections.Generic;
using System.Text;
using System.Configuration;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Channels.Tcp;
using System.Threading;
using TBEWinServ.RemotingInterfaces;
using TBEWinServ.Utilitarios;

namespace TBEWinServ.FachadaRemotingServidor
{
    public class ServicioRemoting
    {
        private int Port = -1;
        private TcpServerChannel Canal;

        public void HabilitarEscucha()
        {
            try
            {
                string strPort = ConfigurationManager.AppSettings["NET_REMOTING_SERVER_PORT"];
                Port = int.Parse(strPort);
            }
            catch
            {
                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS, 
                    Utilitario.RetornaHashCode(Thread.CurrentThread.GetHashCode()), "ServicioRemoting",
                    "Error de configuracion, el valor para NET_REMOTING_SERVER_PORT no es valido.", true);
                return;
            }

            try
            {
                Canal = new TcpServerChannel(Port);
                ChannelServices.RegisterChannel(Canal);

                WellKnownServiceTypeEntry remObj;

                remObj = new WellKnownServiceTypeEntry(typeof(Transferencia),
                                                        ServiciosConocidos.Transferencia,
                                                        WellKnownObjectMode.SingleCall);
                RemotingConfiguration.RegisterWellKnownServiceType(remObj);

                remObj = new WellKnownServiceTypeEntry(typeof(ConsultasBCRP),
                                                        ServiciosConocidos.ConsultasBCRP,
                                                        WellKnownObjectMode.SingleCall);
                RemotingConfiguration.RegisterWellKnownServiceType(remObj);

                remObj = new WellKnownServiceTypeEntry(typeof(Auditoria),
                                                        ServiciosConocidos.Auditoria,
                                                        WellKnownObjectMode.SingleCall);
                RemotingConfiguration.RegisterWellKnownServiceType(remObj);

                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS, 
                    Utilitario.RetornaHashCode(Thread.CurrentThread.GetHashCode()),
                    "ServicioRemoting.HabilitarEscucha",
                    "Se habilita el listener ServicioRemoting correctamente.", false);
            }
            catch (Exception ex)
            {
                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS, 
                    Utilitario.RetornaHashCode(Thread.CurrentThread.GetHashCode()),
                    "ServicioRemoting.HabilitarEscucha",
                    "Error al habilitar el listener: " + ex.Message + "; StackTrace: " + ex.StackTrace, true);
            }
        }

        public void DeshabilitarEscucha()
        {
            if (Canal != null)
            {
                try
                {
                    ChannelServices.UnregisterChannel(Canal);

                    LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS, 
                        Utilitario.RetornaHashCode(Thread.CurrentThread.GetHashCode()),
                        "ServicioRemoting.DeshabilitarEscucha",
                        "Se deshabilita el listener ServicioRemoting correctamente.", false);
                }
                catch (Exception ex)
                {
                    LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS, 
                        Utilitario.RetornaHashCode(Thread.CurrentThread.GetHashCode()),
                        "ServicioRemoting.DeshabilitarEscucha",
                        "Error al deshabilitar el listener ServicioRemoting: " + ex.Message + "; StackTrace: " + ex.StackTrace, true);
                }
            }
        }
    }
}
