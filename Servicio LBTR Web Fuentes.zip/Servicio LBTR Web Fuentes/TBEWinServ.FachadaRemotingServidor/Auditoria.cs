using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using TBEWinServ.RemotingInterfaces;
using TBEWinServ.LogicaNegocio;
using TBEWinServ.Utilitarios;

namespace TBEWinServ.FachadaRemotingServidor
{
    public class Auditoria : MarshalByRefObject, IAuditoria
    {

        public int ConsultarAuditoria(string prmIdConsulta, string prmTipoOperacion, string prmEstados,
                                        string prmFechaIni, string prmFechaFin, string prmCodBanco,
                                        string prmCodConcepto, bool blnUsarLlavesActuales)
        {
            string strHashcode = Utilitario.GenerarCodigo(15);
            BL_Auditoria oBLSeg = new BL_Auditoria(strHashcode);
            return oBLSeg.ConsultarAuditoria(prmIdConsulta, prmTipoOperacion, prmEstados, 
                                                prmFechaIni, prmFechaFin, prmCodBanco,
                                                prmCodConcepto, blnUsarLlavesActuales);
        }
    }
}
