using System;
using System.Collections.Generic;
using System.Text;
using System.Web.Services.Protocols;
using System.Configuration;
using TBEWinServ.Utilitarios;

namespace TBEWinServ.Componentes
{
    public class WS_LBTRAutenticacionService
    {
        private string strHashcode = "";

        public WS_LBTRAutenticacionService(string prmHashcode)
        {
            strHashcode = prmHashcode;
        }

        public string Logon(string prmCodigo, string prmPassword, string prmKSim, string prmFirma)
        {
            string strSID = null;

            try
            {
                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS, strHashcode, 
                    "WS_LBTRAutenticacionService.Logon",
                    "Se invoca a la funcion logon del web service LBTRAutenticacion.", false);
                                
                LBTRAutenticacionService.LBTRAutenticacionService oWS_LBTRAut = new LBTRAutenticacionService.LBTRAutenticacionService();
                oWS_LBTRAut.Timeout = Globales.LBTRSERVICES_TIMEOUT;
                strSID = oWS_LBTRAut.logon(prmCodigo, prmPassword, prmKSim, prmFirma);

                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS, strHashcode,
                    "WS_LBTRAutenticacionService.Logon",
                    "Se recibio la respuesta del servicio web.", false);
            }
            catch (SoapException ex)
            {
                string strCodigoError = "";
                string strMensajeError = "";
                System.Xml.XmlElement xmle = null;

                try
                {
                    if (ex != null && ex.Detail != null)
                    {
                        xmle = ex.Detail["ns2:LBTRServiceFault"];
                        if (xmle == null) xmle = ex.Detail["ns2:LBTRSessionFault"];
                        if (xmle != null)
                        {
                            strCodigoError = xmle.ChildNodes[0].InnerText;
                            strMensajeError = xmle.ChildNodes[1].InnerText;
                        }
                    }
                    else
                    {
                        strCodigoError = "BCRP";
                        strMensajeError = "El mensaje de respuesta de error es nulo.";
                    }
                }
                catch (Exception subex)
                {
                    strCodigoError = "BCRP";
                    strMensajeError = "Error al recepcionar la respuesta de error del BCRP: " + subex.Message + "; " + subex.StackTrace;
                }

                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS, strHashcode,
                    "WS_LBTRAutenticacionService.Logon",
                    "El servicio web LBTR retorno el error con Codigo: " + strCodigoError +
                    ". Mensaje: " + strMensajeError, true);

                if (!String.IsNullOrEmpty(strCodigoError))
                {
                    if (strCodigoError.Equals(Constantes.SERVICIOLBTR_SESION_YA_ACTIVA))
                    {
                        LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS, strHashcode,
                            "WS_LBTRAutenticacionService.Logon",
                            "Como el codigo de error es [" + strCodigoError + "] - Institucion ya tiene una sesion activa" +
                            ", se procedera a realizar un Logoff para asi intentar el Logon y obtener un SID nuevo y usarlo en el sistema.", true);

                        Globales.SID = null;
                        Logoff(prmCodigo, prmPassword, prmKSim, prmFirma);
                    }
                }

            }
            catch (Exception ex)
            {
                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS, strHashcode,
                    "WS_LBTRAutenticacionService.Logon",
                    "Error: " + ex.Message + ". " + ex.StackTrace, true);
            }
            
            return strSID;
        }

        public bool Logoff(string prmCodigo, string prmPassword, string prmKSim, string prmFirma)
        {
            bool blnRespuesta = false;

            try
            {
                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS, strHashcode, 
                    "WS_LBTRAutenticacionService.Logoff",
                    "Se invoca a la funcion logoff del web service LBTRAutenticacion.", false);
                                
                LBTRAutenticacionService.LBTRAutenticacionService oWS_LBTRAut = new LBTRAutenticacionService.LBTRAutenticacionService();
                oWS_LBTRAut.Timeout = Globales.LBTRSERVICES_TIMEOUT;
                blnRespuesta = oWS_LBTRAut.logoff(prmCodigo, prmPassword, prmKSim, prmFirma);

                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS, strHashcode,
                    "WS_LBTRAutenticacionService.Logoff",
                    "Se recibio la respuesta del servicio web.", false);
            }
            catch (SoapException ex)
            {
                string strCodigoError = "";
                string strMensajeError = "";
                System.Xml.XmlElement xmle = null;

                try
                {
                    if (ex != null && ex.Detail != null)
                    {
                        xmle = ex.Detail["ns2:LBTRServiceFault"];
                        if (xmle == null) xmle = ex.Detail["ns2:LBTRSessionFault"];
                        if (xmle != null)
                        {
                            strCodigoError = xmle.ChildNodes[0].InnerText;
                            strMensajeError = xmle.ChildNodes[1].InnerText;
                        }
                    }
                    else
                    {
                        strCodigoError = "BCRP";
                        strMensajeError = "El mensaje de respuesta de error es nulo.";
                    }
                }
                catch (Exception subex)
                {
                    strCodigoError = "BCRP";
                    strMensajeError = "Error al recepcionar la respuesta de error del BCRP: " + subex.Message + "; " + subex.StackTrace;
                }

                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS, strHashcode,
                    "WS_LBTRAutenticacionService.Logoff",
                    "El servicio web LBTR retorno el error con Codigo: " + strCodigoError +
                    ". Mensaje: " + strMensajeError, true);

            }
            catch (Exception ex)
            {                
                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS, strHashcode,
                    "WS_LBTRAutenticacionService.Logoff",
                    "Error: " + ex.Message + ". " + ex.StackTrace, true);
            }
            
            return blnRespuesta;        
        }

    }
}
