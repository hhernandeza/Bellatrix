using System;
using System.Collections.Generic;
using System.Text;
using System.Configuration;
using System.Web.Services.Protocols;
using TBEWinServ.Utilitarios;
using TBEWinServ.Componentes.LBTRTransferenciaService;

namespace TBEWinServ.Componentes
{
    public class WS_LBTRTransferenciaService
    {
        private string strHashcode = "";

        public WS_LBTRTransferenciaService(string prmHashcode) 
        {
            strHashcode = prmHashcode;
        }

        #region Metodos para InstruirTransferencia

        public event EventHandler<RespuestaBCRPEventArgs> InstruirTransferenciaRespuestaRecibida;
        public event EventHandler<TransferenciaEventArgs> OnInstruirTransferenciaError;

        public int InstruirTransferencia(string prmSID, datosTransferencia prmDatosTransf, 
                                            string prmFirma, TransferenciaID prmTransferenciaId)
        {
            int nRetorno = 0;
            LBTRTransferenciaService.respuestaLBTR oRespuestaLBTR = null;

            try
            {
                LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.ENVIO_TRANSFERENCIAS, strHashcode, 
                    "WS_LBTRTransferenciaService.InstruirTransferencia",
                    "Se invoca a la funcion instruirTransferencia del web service LBTRTransferencia.", false);

                if (String.IsNullOrEmpty(prmSID)) throw new Exception("El SID es nulo o vacio.");

                LBTRTransferenciaService.LBTRTransferenciaService oWS_LBTRTransf = new LBTRTransferenciaService.LBTRTransferenciaService();
                oWS_LBTRTransf.Timeout = Globales.LBTRSERVICES_TIMEOUT;
                oRespuestaLBTR = oWS_LBTRTransf.instruirTransferencia(prmSID, prmDatosTransf, prmFirma);                    
                LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.ENVIO_TRANSFERENCIAS, strHashcode,
                    "WS_LBTRTransferenciaService.InstruirTransferencia",
                    "Termino ejecucion del metodo instruirTransferencia.", false);
                this.InstruirTransferenciaRespuestaRecibida(this, new RespuestaBCRPEventArgs(oRespuestaLBTR.estado, oRespuestaLBTR.numRefLBTR, prmTransferenciaId));

                LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.ENVIO_TRANSFERENCIAS, strHashcode, 
                    "WS_LBTRTransferenciaService.InstruirTransferencia",
                    "Se recibio la respuesta de la transferencia " + prmTransferenciaId.Transact + ".", false);

                nRetorno = 1;
            }
            catch (SoapException ex)
            {
                string strCodigoError = "";
                string strMensajeError = "";
                System.Xml.XmlElement xmle = null;

                try
                {
                    if (ex != null && ex.Detail != null)
                    {
                        xmle = ex.Detail["ns2:LBTRServiceFault"];
                        if (xmle == null) xmle = ex.Detail["ns2:LBTRSessionFault"];
                        if (xmle != null)
                        {
                            strCodigoError = xmle.ChildNodes[0].InnerText;
                            strMensajeError = xmle.ChildNodes[1].InnerText;
                        }
                    }
                    else
                    {
                        strCodigoError = "BCRP";
                        strMensajeError = "El mensaje de respuesta de error es nulo.";
                    }
                }
                catch (Exception subex)
                {
                    strCodigoError = "BCRP";
                    strMensajeError = "Error al recepcionar la respuesta de error del BCRP: " + subex.Message + "; " + subex.StackTrace;
                }

                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.ENVIO_TRANSFERENCIAS, strHashcode,
                    "WS_LBTRTransferenciaService.InstruirTransferencia",
                    "Transaccion: " + prmTransferenciaId.Transact + " Sec: " + prmTransferenciaId.SEC +
                    ". El servicio web LBTR retorno el error con Codigo: " + strCodigoError +
                    ". Mensaje: " + strMensajeError, true);

                this.OnInstruirTransferenciaError(this, new TransferenciaEventArgs(prmTransferenciaId, strCodigoError, strMensajeError));
            }
            catch (Exception ex)
            {
                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.ENVIO_TRANSFERENCIAS, strHashcode, 
                    "WS_LBTRTransferenciaService.InstruirTransferencia",
                    "Transaccion: " + prmTransferenciaId.Transact + " Sec: " + prmTransferenciaId.SEC + 
                    ". Error: " + ex.Message + ". " + ex.StackTrace, true);

                this.OnInstruirTransferenciaError(this, new TransferenciaEventArgs(prmTransferenciaId, "", ex.Message));
            }

            return nRetorno;
        }
                
        #endregion

        #region Metodos para ConfirmarAbonoCliente

        public event EventHandler<RespuestaBCRPEventArgs> ConfirmarAbonoClienteRespuestaRecibida;
        public event EventHandler<ConfirmacionAbonoEventArgs> OnConfirmacionAbonoError;

        public int ConfirmarAbonoCliente(string prmSID, OperacionID prmOperacionID, string prmFirma)
        {
            int nRetorno = 0;
            LBTRTransferenciaService.respuestaLBTR oRespuestaLBTR = null;

            try
            {
                LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.CONFIRMACION_ABONO, strHashcode, 
                    "WS_LBTRTransferenciaService.ConfirmarAbonoCliente",                                        
                    "Se invoca a la funcion confirmarAbonoCliente del web service LBTRTransferencia.", false);

                if (String.IsNullOrEmpty(prmSID)) throw new Exception("El SID es nulo o vacio.");
                                
                LBTRTransferenciaService.LBTRTransferenciaService oWS_LBTRTransf = new LBTRTransferenciaService.LBTRTransferenciaService();
                oWS_LBTRTransf.Timeout = Globales.LBTRSERVICES_TIMEOUT;
                oRespuestaLBTR = oWS_LBTRTransf.confirmarAbonoCliente(prmSID, prmOperacionID.NumRefLBTR, prmFirma);
                this.ConfirmarAbonoClienteRespuestaRecibida(this, new RespuestaBCRPEventArgs(oRespuestaLBTR.estado, oRespuestaLBTR.numRefLBTR, prmOperacionID));

                LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.CONFIRMACION_ABONO, strHashcode,
                    "WS_LBTRTransferenciaService.ConfirmarAbonoCliente",
                    "Se recibio la respuesta de la confirmacion del abono " + prmOperacionID.NumRefLBTR + ".", false);

                nRetorno = 1;
            }
            catch (SoapException ex)
            {
                string strCodigoError = "";
                string strMensajeError = "";
                System.Xml.XmlElement xmle = null;

                try
                {
                    if (ex != null && ex.Detail != null)
                    {
                        xmle = ex.Detail["ns2:LBTRServiceFault"];
                        if (xmle == null) xmle = ex.Detail["ns2:LBTRSessionFault"];
                        if (xmle != null)
                        {
                            strCodigoError = xmle.ChildNodes[0].InnerText;
                            strMensajeError = xmle.ChildNodes[1].InnerText;
                        }
                    }
                    else
                    {
                        strCodigoError = "BCRP";
                        strMensajeError = "El mensaje de respuesta de error es nulo.";
                    }
                }
                catch (Exception subex)
                {
                    strCodigoError = "BCRP";
                    strMensajeError = "Error al recepcionar la respuesta de error del BCRP: " + subex.Message + "; " + subex.StackTrace;
                }

                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.CONFIRMACION_ABONO, strHashcode,
                    "WS_LBTRTransferenciaService.ConfirmarAbonoCliente",
                    "NumRefLBTR: " + prmOperacionID.NumRefLBTR +
                    ". El servicio web LBTR retorno el error con Codigo: " + strCodigoError +
                    ". Mensaje: " + strMensajeError, true);

                this.OnConfirmacionAbonoError(this, new ConfirmacionAbonoEventArgs(prmOperacionID, strCodigoError, strMensajeError));
            }
            catch (Exception ex)
            {
                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.CONFIRMACION_ABONO, strHashcode,
                    "WS_LBTRTransferenciaService.ConfirmarAbonoCliente",
                    "NumRefLBTR: " + prmOperacionID.NumRefLBTR + ". Error: " + ex.Message + ". " + ex.StackTrace, true);

                this.OnConfirmacionAbonoError(this, new ConfirmacionAbonoEventArgs(prmOperacionID, "", ex.Message));
            }

            return nRetorno;
        }
       
        #endregion

    }

    public class TransferenciaEventArgs : EventArgs
    {
        public TransferenciaID TransferenciaId;
        public string CodigoError;
        public string MensajeError;

        public TransferenciaEventArgs(TransferenciaID prmTransferenciaId) 
        {
            TransferenciaId = prmTransferenciaId;
        }

        public TransferenciaEventArgs(TransferenciaID prmTransferenciaId, string prmCodigoError, string prmMensajeError)
        {
            TransferenciaId = prmTransferenciaId;
            CodigoError = prmCodigoError;
            MensajeError = prmMensajeError;
        }

    }

    public class ConfirmacionAbonoEventArgs : EventArgs
    {
        public OperacionID OperacionId;
        public string CodigoError;
        public string MensajeError;

        public ConfirmacionAbonoEventArgs(OperacionID prmOperacionId)
        {
            OperacionId = prmOperacionId;
        }

        public ConfirmacionAbonoEventArgs(OperacionID prmOperacionId, string prmCodigoError, string prmMensajeError)
        {
            OperacionId = prmOperacionId;
            CodigoError = prmCodigoError;
            MensajeError = prmMensajeError;
        }
    }

    public class RespuestaBCRPEventArgs : EventArgs
    {
        public string strEstado;
        public string strNumRefLBTR;
        public TransferenciaID TransferenciaId;
        public OperacionID OperacionId;

        public RespuestaBCRPEventArgs(string prmEstado, string prmNumRefLBTR, TransferenciaID prmTransferenciaId)
        {
            strEstado = prmEstado;
            strNumRefLBTR = prmNumRefLBTR;
            TransferenciaId = prmTransferenciaId;
        }

        public RespuestaBCRPEventArgs(string prmEstado, string prmNumRefLBTR, OperacionID prmOperacionId)
        {
            strEstado = prmEstado;
            strNumRefLBTR = prmNumRefLBTR;
            OperacionId = prmOperacionId;
        }

        public RespuestaBCRPEventArgs(string prmEstado, string prmNumRefLBTR)
        {
            strEstado = prmEstado;
            strNumRefLBTR = prmNumRefLBTR;
        }

    }

    public class TransferenciaID {
        public string Transact;
        public string SEC;
        public string EstadoOriginal;
    }

    public class OperacionID {
        public string NumRefLBTR;
        public string EstadoOriginal;
    }
}
