﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Configuration;
using System.Web.Services.Protocols;
using TBEWinServ.Utilitarios;
using TBEWinServ.Componentes.LBTRCompraVentaService;

namespace TBEWinServ.Componentes
{
    public class WS_LBTRCompraVentaService
    {
        private string strHashcode = "";

        public WS_LBTRCompraVentaService(string prmHashcode) 
        {
            strHashcode = prmHashcode;
        }

        #region Metodos para InstruirCompraVentaME

        public event EventHandler<RespuestaCompraVentaBCRPEventArgs> SalidasCompraVentaRespuestaRecibida;
        public event EventHandler<CompraVentaEventArgs> OnSalidasCompraVentaError;

        public int InstruirCompraVenta(string prmSID, datosCompraVentaME prmDatosCompraVenta,
                                       string prmFirma, CompraVentaID prmCompraVentaId)
        {
            int nRetorno = 0;
            LBTRCompraVentaService.respuestaLBTR oREspuestaCompraVentaLBTR = null;
            
            try
            {
                LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.SALIDAS_COMPRAVENTA, strHashcode,
                    "WS_LBTRCompraVentaService.InstruirCompraVenta",
                    "Se invoca a la funcion instruirCompraVenta del web service LBTRCompraVenta.", false);

                if (String.IsNullOrEmpty(prmSID)) throw new Exception("El SID es nulo o vacio.");

                LBTRCompraVentaService.LBTRCompraVentaMEService oWS_LBTRCOmpraVenta = new LBTRCompraVentaService.LBTRCompraVentaMEService();

                oWS_LBTRCOmpraVenta.Timeout = Globales.LBTRSERVICES_TIMEOUT;
                oREspuestaCompraVentaLBTR = oWS_LBTRCOmpraVenta.instruirCompraVentaME(prmSID, prmDatosCompraVenta, prmFirma);

                LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.SALIDAS_COMPRAVENTA, strHashcode,
                    "WS_LBTRCompraVentaService.InstruirCompraVenta",
                    "Termino ejecucion del metodo InstruirCompraVenta.", false);
                this.SalidasCompraVentaRespuestaRecibida(this, new RespuestaCompraVentaBCRPEventArgs(oREspuestaCompraVentaLBTR.estado, oREspuestaCompraVentaLBTR.numRefLBTR, prmCompraVentaId));

                LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.SALIDAS_COMPRAVENTA, strHashcode,
                    "WS_LBTRCompraVentaService.InstruirCompraVenta",
                    "Se recibio la respuesta de la CompraVentaME [ID_LBTR_ENTRADAS]: " + prmCompraVentaId.ID_LBTR_SALIDAS + ", [NUM_REF_ORIGEN]: " + prmCompraVentaId.NUM_REF_ORIGEN +".", false);

                nRetorno = 1;
            }
            catch (SoapException ex)
            {
                string strCodigoError = "";
                string strMensajeError = "";
                System.Xml.XmlElement xmle = null;

                try
                {
                    if (ex != null && ex.Detail != null)
                    {
                        xmle = ex.Detail["ns2:LBTRServiceFault"];
                        if (xmle == null) xmle = ex.Detail["ns2:LBTRSessionFault"];
                        if (xmle != null)
                        {
                            strCodigoError = xmle.ChildNodes[0].InnerText;
                            strMensajeError = xmle.ChildNodes[1].InnerText;
                        }
                    }
                    else
                    {
                        strCodigoError = "BCRP";
                        strMensajeError = "El mensaje de respuesta de error es nulo.";
                    }
                }
                catch (Exception subex)
                {
                    strCodigoError = "BCRP";
                    strMensajeError = "Error al recepcionar la respuesta de error del BCRP: " + subex.Message + "; " + subex.StackTrace;
                }
                if (!Globales.ERRORES_PARA_REENVIO.Contains(strCodigoError))
                {
                    LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SALIDAS_COMPRAVENTA, strHashcode,
                       "WS_LBTRCompraVentaService.InstruirCompraVenta",
                       "Operacion: " + prmCompraVentaId.ID_LBTR_SALIDAS + " NumRefOrigen: " + prmCompraVentaId.NUM_REF_ORIGEN +
                       ". El servicio web LBTR retorno el error con Codigo: " + strCodigoError +
                       ". Mensaje: " + strMensajeError, true);
                }
                else 
                {
                    LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SALIDAS_COMPRAVENTA, strHashcode,
                          "WS_LBTRCompraVentaService.InstruirCompraVenta",
                          "Operacion: " + prmCompraVentaId.ID_LBTR_SALIDAS + " NumRefOrigen: " + prmCompraVentaId.NUM_REF_ORIGEN +
                          ". El servicio web LBTR retorno el error con Codigo: " + strCodigoError +
                          ". Mensaje: " + strMensajeError, false);
                }

                this.OnSalidasCompraVentaError(this, new CompraVentaEventArgs(prmCompraVentaId, strCodigoError, strMensajeError));
            }
            catch (Exception ex)
            {
                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SALIDAS_COMPRAVENTA, strHashcode,
                    "WS_LBTRTransferenciaService.InstruirTransferencia",
                    "Transaccion: " + prmCompraVentaId.ID_LBTR_SALIDAS + " Sec: " + prmCompraVentaId.NUM_REF_ORIGEN +
                    ". Error: " + ex.Message + ". " + ex.StackTrace, true);

                this.OnSalidasCompraVentaError(this, new CompraVentaEventArgs(prmCompraVentaId, "", ex.Message));
            }
            return nRetorno;
        }

        #endregion

        #region Metodos para ConfirmarCompraVentaME

        //public event EventHandler<RespuestaCompraVentaBCRPEventArgs> ConfirmaCompraVentaRespuestaRecibida;
        //public event EventHandler<CompraVentaEventArgs> oWSTransf_OnSalidasCompraVentaError;

        public int ConfirmarConpraVenta(string prmSID, datosCompraVentaME prmDatosCompraVenta,
                                        string prmFirma, CompraVentaID prmCompraVentaId) 
        {  
            int nRetorno = 0;                    
            LBTRCompraVentaService.respuestaLBTR oRespuestaCompraVentaLBTR = null;

            try
            {
                LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.CONFIRMACION_COMPRAVENTA, strHashcode,
                    "WS_LBTRCompraVentaService.ConfirmarConpraVenta",
                    "Se invoca a la funcion ConfirmarConpraVenta del web service LBTRCompraVenta.", false);
            
                if (String.IsNullOrEmpty(prmSID)) throw new Exception("El SID es nulo o vacio.");

                LBTRCompraVentaService.LBTRCompraVentaMEService oWS_LBTRCompraVenta = new LBTRCompraVentaService.LBTRCompraVentaMEService();
                oWS_LBTRCompraVenta.Timeout = Globales.LBTRSERVICES_TIMEOUT;
                oRespuestaCompraVentaLBTR = oWS_LBTRCompraVenta.confirmarCompraVentaME(prmSID, prmDatosCompraVenta, prmFirma);

                this.SalidasCompraVentaRespuestaRecibida(this, new RespuestaCompraVentaBCRPEventArgs(oRespuestaCompraVentaLBTR.estado, oRespuestaCompraVentaLBTR.numRefLBTR, prmCompraVentaId));

                LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.CONFIRMACION_COMPRAVENTA, strHashcode,
                    "WS_LBTRCompraVentaService.ConfirmarConpraVenta",
                    "Se recibio la respuesta de la confirmacion de la CompraVenta: " + prmDatosCompraVenta.numRefLBTRCV+ ".", false);

                nRetorno = 1;
            }
            catch (SoapException ex)
            {
                string strCodigoError = "";
                string strMensajeError = "";
                System.Xml.XmlElement xmle = null;

                try
                {
                    if (ex != null && ex.Detail != null)
                    {
                        xmle = ex.Detail["ns2:LBTRServiceFault"];
                        if (xmle == null) xmle = ex.Detail["ns2:LBTRSessionFault"];
                        if (xmle != null)
                        {
                            strCodigoError = xmle.ChildNodes[0].InnerText;
                            strMensajeError = xmle.ChildNodes[1].InnerText;
                        }
                    }
                    else
                    {
                        strCodigoError = "BCRP";
                        strMensajeError = "El mensaje de respuesta de error es nulo.";
                    }
                }
                catch (Exception subex)
                {
                    strCodigoError = "BCRP";
                    strMensajeError = "Error al recepcionar la respuesta de error del BCRP: " + subex.Message + "; " + subex.StackTrace;
                }

                if (!Globales.ERRORES_PARA_REENVIO.Contains(strCodigoError))
                {
                    LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.CONFIRMACION_COMPRAVENTA, strHashcode,
                   "WS_LBTRCompraVentaService.ConfirmarConpraVenta",
                   "NumRefLBTR: " + prmDatosCompraVenta.numRefLBTRCV +
                   ". El servicio web LBTR retorno el error con Codigo: " + strCodigoError +
                   ". Mensaje: " + strMensajeError, true);
                }
                else
                {
                    LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.CONFIRMACION_COMPRAVENTA, strHashcode,
                   "WS_LBTRCompraVentaService.ConfirmarConpraVenta",
                   "NumRefLBTR: " + prmDatosCompraVenta.numRefLBTRCV +
                   ". El servicio web LBTR retorno el error con Codigo: " + strCodigoError +
                   ". Mensaje: " + strMensajeError, false);
                }

                this.OnSalidasCompraVentaError(this, new CompraVentaEventArgs(prmCompraVentaId, strCodigoError, strMensajeError));
            }
            catch (Exception ex)
            {
                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.CONFIRMACION_ABONO, strHashcode,
                    "WS_LBTRCompraVentaService.ConfirmarConpraVenta",
                    "NumRefLBTR: " + prmDatosCompraVenta.numRefLBTRCV + ". Error: " + ex.Message + ". " + ex.StackTrace, true);

                this.OnSalidasCompraVentaError(this, new CompraVentaEventArgs(prmCompraVentaId, "", ex.Message));
            }

            return nRetorno;
        }
        #endregion
    }

    public class RespuestaCompraVentaBCRPEventArgs : EventArgs
    {
        public string strEstado;
        public string strNumRefLBTR;
        public CompraVentaID CompraVentaId;

        public RespuestaCompraVentaBCRPEventArgs(string prmEstado, string prmNumRefLBTR, CompraVentaID prmCompraVentaId)
        {
            strEstado = prmEstado;
            strNumRefLBTR = prmNumRefLBTR;
            CompraVentaId = prmCompraVentaId;
        }

        public RespuestaCompraVentaBCRPEventArgs(string prmEstado, string prmNumRefLBTR)
        {
            strEstado = prmEstado;
            strNumRefLBTR = prmNumRefLBTR;
        }
    }

    public class CompraVentaEventArgs : EventArgs
    {
        public CompraVentaID CompraVentaId;
        public string CodigoError;
        public string MensajeError;

        public CompraVentaEventArgs(CompraVentaID prmCompraVenta)
        {
            CompraVentaId = prmCompraVenta;
        }

        public CompraVentaEventArgs(CompraVentaID prmCompraVenta, string prmCodigoError, string prmMensajeError)
        {
            CompraVentaId = prmCompraVenta;
            CodigoError = prmCodigoError;
            MensajeError = prmMensajeError;
        }
    }

    public class CompraVentaID
    {
        public Int32? ID_LBTR_SALIDAS;
        public string NUM_REF_ORIGEN;
        public string ESTADO_ENVIO;
    }
}
