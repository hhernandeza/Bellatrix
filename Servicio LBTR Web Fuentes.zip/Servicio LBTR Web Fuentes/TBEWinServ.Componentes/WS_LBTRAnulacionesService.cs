using System;
using System.Collections.Generic;
using System.Text;
using System.Configuration;
using System.Web.Services.Protocols;
using TBEWinServ.Utilitarios;
using TBEWinServ.Componentes.LBTRAnulacionesService;

namespace TBEWinServ.Componentes
{
    public class WS_LBTRAnulacionesService
    {
        private string strHashcode = "";

        public WS_LBTRAnulacionesService(string prmHashcode) 
        {
            strHashcode = prmHashcode;
        }

        public event EventHandler<RespuestaBCRPEventArgs> AnularOperacionPendienteRespuestaRecibida;
        public event EventHandler<AnularOperacionPendienteEventArgs> OnAnularOperacionPendienteError;

        public int AnularOperacionPendiente(string prmSID, OperacionID prmOperacionID, string prmFirma) 
        {
            int nRetorno = 0;
            LBTRAnulacionesService.respuestaLBTR oRespuestaLBTR = null;

            try
            {
                LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.ANULACION_OPERACION, strHashcode,
                    "WS_LBTRAnulacionesService.AnularOperacionPendiente",
                    "Se invoca a la funcion AnularOperacionPendiente del web service LBTRAnulacionesService.", false);

                if (String.IsNullOrEmpty(prmSID)) throw new Exception("El SID es nulo o vacio.");
                                
                LBTRAnulacionesService.LBTRAnulacionesService oWS_LBTRAnul = new LBTRAnulacionesService.LBTRAnulacionesService();
                oWS_LBTRAnul.Timeout = Globales.LBTRSERVICES_TIMEOUT;
                oRespuestaLBTR = oWS_LBTRAnul.anularOperacionPendiente(prmSID, prmOperacionID.NumRefLBTR, prmFirma);
                this.AnularOperacionPendienteRespuestaRecibida(this, new RespuestaBCRPEventArgs(oRespuestaLBTR.estado, oRespuestaLBTR.numRefLBTR, prmOperacionID));                

                LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.ANULACION_OPERACION, strHashcode,
                    "WS_LBTRAnulacionesService.AnularOperacionPendiente",
                    "Se recibio la respuesta de la anulacion de la operacion " + prmOperacionID.NumRefLBTR + ".", false);

                nRetorno = 1;
            }
            catch (SoapException ex)
            {
                string strCodigoError = "";
                string strMensajeError = "";
                System.Xml.XmlElement xmle = null;

                try
                {
                    if (ex != null && ex.Detail != null)
                    {
                        xmle = ex.Detail["ns2:LBTRServiceFault"];
                        if (xmle == null) xmle = ex.Detail["ns2:LBTRSessionFault"];
                        if (xmle != null)
                        {
                            strCodigoError = xmle.ChildNodes[0].InnerText;
                            strMensajeError = xmle.ChildNodes[1].InnerText;
                        }
                    }
                    else
                    {
                        strCodigoError = "BCRP";
                        strMensajeError = "El mensaje de respuesta de error es nulo.";
                    }
                }
                catch (Exception subex)
                {
                    strCodigoError = "BCRP";
                    strMensajeError = "Error al recepcionar la respuesta de error del BCRP: " + subex.Message + "; " + subex.StackTrace;
                }

                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.ANULACION_OPERACION, strHashcode,
                    "WS_LBTRAnulacionesService.AnularOperacionPendiente",
                    "NumRefLBTR: " + prmOperacionID.NumRefLBTR +
                    ". El servicio web LBTR retorno el error con Codigo: " + strCodigoError +
                    ". Mensaje: " + strMensajeError, false);

                this.OnAnularOperacionPendienteError(this, new AnularOperacionPendienteEventArgs(prmOperacionID, strCodigoError, strMensajeError));
            }
            catch (Exception ex)
            {                
                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.ANULACION_OPERACION, strHashcode,
                    "WS_LBTRAnulacionesService.AnularOperacionPendiente",
                    "NumRefLBTR: " + prmOperacionID.NumRefLBTR + ". Error: " + ex.Message + ". " + ex.StackTrace, true);

                this.OnAnularOperacionPendienteError(this, new AnularOperacionPendienteEventArgs(prmOperacionID, "", ex.Message));
            }

            return nRetorno;
        }

    }

    public class AnularOperacionPendienteEventArgs : EventArgs
    {
        public OperacionID OperacionId;
        public string CodigoError;
        public string MensajeError;

        public AnularOperacionPendienteEventArgs(OperacionID prmOperacionId)
        {
            OperacionId = prmOperacionId;
        }

        public AnularOperacionPendienteEventArgs(OperacionID prmOperacionId, string prmCodigoError, string prmMensajeError)
        {
            OperacionId = prmOperacionId;
            CodigoError = prmCodigoError;
            MensajeError = prmMensajeError;
        }
    }
}
