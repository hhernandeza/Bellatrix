using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using TBEWinServ.Utilitarios;

namespace TBEWinServ.Componentes
{
    public static class WS_LBTRAvisoOperacionesService
    {
        public static void RecibirAvisoOperacion(LBTRAvisoOperacionesService.avisoOperacionLBTR prmAvisoOperacionLBTR, string prmFirma)
        {

            try
            {
                LBTRAvisoOperacionesService.LBTRAvisoOperacionesService oWS_LBTRCliente = new LBTRAvisoOperacionesService.LBTRAvisoOperacionesService();
                oWS_LBTRCliente.Timeout = Globales.LBTRSERVICES_TIMEOUT;
                oWS_LBTRCliente.recibirAvisoOperacion(prmAvisoOperacionLBTR, prmFirma);
            }
            catch (Exception ex)
            {
                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS, 
                    Utilitario.RetornaHashCode(Thread.CurrentThread.GetHashCode()), 
                    "WS_LBTRAvisoOperacionesService.RecibirAvisoOperacion", 
                    "Error: " + ex.Message + ". " + ex.StackTrace, true);
            }

        }

    }
}
