﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using System.IO;
using TBEWinServ.Utilitarios;

using Andromeda.PAR;

namespace TBEWinServ.Componentes
{
    public class PARCertificate
    {
        #region Propiedades

        private string strURL;

        public string URL
        {
            get { return strURL; }
            set { strURL = value; }
        }

        private string strThumbPrint;

        public string ThumbPrint
        {
            get { return strThumbPrint; }
            set { strThumbPrint = value; }
        }

        private string strSystemName;

        public string SystemName
        {
            get { return strSystemName; }
            set { strSystemName = value; }
        }

        private string strAccountName;

        public string AccountName
        {
            get { return strAccountName; }
            set { strAccountName = value; }
        }

        private bool blnReintentar = false;

        public bool Reintentar
        {
            get { return blnReintentar; }
        }

        #endregion

        public PARCertificate(string prmURL, string prmThumbPrintFile, string prmSystemName)
        {
            strURL = prmURL;
            strThumbPrint = prmThumbPrintFile;
            strSystemName = prmSystemName;            
        }

        public string GetPassword(string prmAccountName)
        {
            string strPassword = null;
            blnReintentar = false;
            try
            {                
                
                PAR par = new PAR(strURL, strThumbPrint);
                strPassword = par.Authenticate(strSystemName, prmAccountName); 

                LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.PAR,
                    Globales.HASHCODE_thrInicioFinDia,
                    "PARCertificate.GetPassword",
                    "Password Repository retornó correctamente el password.", false);

            }
            catch(Exception ex) 
            {
                blnReintentar = true;
                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.PAR,
                    Globales.HASHCODE_thrInicioFinDia,
                    "PARCertificate.GetPassword",
                    "Error, mensaje: " + ex.Message + "; StackTrace: " + ex.StackTrace, true);
            }
            if (blnReintentar)
            {
                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.PAR,
                    Globales.HASHCODE_thrInicioFinDia,
                    "PARCertificate.GetPassword",
                    "Problemas con el Password Repository, se procedera a reintentar luego.", false);
            }
            return strPassword;
        }

        public string GetPassword(string prmAccountName, int prmMaxPasswordLength)
        {
            string strPassword = null;
            blnReintentar = false;
            try
            {
                PAR par = new PAR(strURL, strThumbPrint);
                //hh72295:20160802:INI: FIX PARA QUE NO RECORTE LOS PRIMEROS 30 SI NO QUE SEA EL PWD SIN BLANCOS A LOS COSTADOS
                //strPassword = par.Authenticate(strSystemName, prmAccountName).Substring(0, prmMaxPasswordLength);
                strPassword = par.Authenticate(strSystemName, prmAccountName).Trim();
                //hh72295:20160802:FIN: FIX PARA QUE NO RECORTE LOS PRIMEROS 30 SI NO QUE SEA EL PWD SIN BLANCOS A LOS COSTADOS
                
                LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.PAR,
                    Globales.HASHCODE_thrInicioFinDia,
                    "PARCertificate.GetPassword",
                    "Password Repository retornó correctamente el password.", false);

            }
            catch (Exception ex)
            {
                blnReintentar = true;
                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.PAR,
                    Globales.HASHCODE_thrInicioFinDia,
                    "PARCertificate.GetPassword",
                    "Error, mensaje: " + ex.Message + "; StackTrace: " + ex.StackTrace, true);
            }
            if (blnReintentar)
            {
                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.PAR,
                    Globales.HASHCODE_thrInicioFinDia,
                    "PARCertificate.GetPassword",
                    "Problemas con el Password Repository, se procedera a reintentar luego.", false);
            }
            return strPassword;
        }
    }
}
