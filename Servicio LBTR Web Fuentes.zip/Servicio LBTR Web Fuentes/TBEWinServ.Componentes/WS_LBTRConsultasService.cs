using System;
using System.Collections.Generic;
using System.Text;
using System.Configuration;
using System.Web.Services.Protocols;
using TBEWinServ.Utilitarios;
using TBEWinServ.Componentes.LBTRConsultasService;

namespace TBEWinServ.Componentes
{
    public class WS_LBTRConsultasService
    {
        private string strHashcode = "";

        public WS_LBTRConsultasService(string prmHashcode) {
            strHashcode = prmHashcode;
        }

        #region Consultar Operaciones Recibidas

        public event EventHandler<ConsultarOperacionesEventArgs> OnConsultarOperacionError;

        public beanOperacion[] ConsultarOperaciones(string prmTipoConsulta, string prmSID, 
                                                        DateTime? prmFechaLiquidacion, string prmIdConsulta) 
        {
            beanOperacion[] arrOperaciones = null;

            try
            {
                LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.CONSULTAS_BCRP, strHashcode,
                    "WS_LBTRConsultasService.ConsultarOperaciones",
                    "Se invoca a la funcion del web service LBTRConsultas.", false);

                if (String.IsNullOrEmpty(prmSID)) throw new Exception("El SID es nulo o vacio.");
                                
                LBTRConsultasService.LBTRConsultasService oWS_LBTRCons = new LBTRConsultasService.LBTRConsultasService();

                if (prmFechaLiquidacion.HasValue)
                {
                    if(prmTipoConsulta == TipoOperacion.AvisoAfectacionOpeRec)
                        arrOperaciones = oWS_LBTRCons.lbtr_OperacionesRecibidas(prmSID, prmFechaLiquidacion.Value, true);
                    else if(prmTipoConsulta == TipoOperacion.AvisoAfectacionOpeOtor)
                        arrOperaciones = oWS_LBTRCons.lbtr_OperacionesOtorgadas(prmSID, prmFechaLiquidacion.Value, true);

                    if (arrOperaciones != null)
                    {
                        LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.CONSULTAS_BCRP, strHashcode,
                            "WS_LBTRConsultasService.ConsultarOperaciones",
                            "La consulta al BCRP retorno (" + arrOperaciones.Length.ToString() + ") registros.", false);
                    }
                    else
                    {
                        LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.CONSULTAS_BCRP, strHashcode,
                            "WS_LBTRConsultasService.ConsultarOperaciones",
                            "La consulta al BCRP retorno null.", false);
                    }
                }

                LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.CONSULTAS_BCRP, strHashcode,
                    "WS_LBTRConsultasService.ConsultarOperaciones",
                    "Se recibio la respuesta de la consulta de operaciones con fecha " + prmFechaLiquidacion.Value.ToString("yyyyMMdd"), false);
            }
            catch (SoapException ex)
            {
                string strCodigoError = "";
                string strMensajeError = "";
                System.Xml.XmlElement xmle = null;

                try
                {
                    if (ex != null && ex.Detail != null)
                    {
                        xmle = ex.Detail["ns2:LBTRServiceFault"];
                        if (xmle == null) xmle = ex.Detail["ns2:LBTRSessionFault"];
                        if (xmle != null)
                        {
                            strCodigoError = xmle.ChildNodes[0].InnerText;
                            strMensajeError = xmle.ChildNodes[1].InnerText;
                        }
                    }
                    else
                    {
                        strCodigoError = "BCRP";
                        strMensajeError = "El mensaje de respuesta de error es nulo.";
                    }
                }
                catch (Exception subex)
                {
                    strCodigoError = "BCRP";
                    strMensajeError = "Error al recepcionar la respuesta de error del BCRP: " + subex.Message + "; " + subex.StackTrace;
                }

                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.CONSULTAS_BCRP, strHashcode,
                    "WS_LBTRConsultasService.ConsultarOperaciones",
                    "IdConsulta: " + prmIdConsulta + " Tipo Consulta: " + prmTipoConsulta +
                    " Fecha Liquidacion: " + (prmFechaLiquidacion.HasValue ? prmFechaLiquidacion.Value.ToString("yyyyMMdd") : "") +
                    ". El servicio web LBTR retorno el error con Codigo: " + strCodigoError +
                    ". Mensaje: " + strMensajeError, true);

                this.OnConsultarOperacionError(this, new ConsultarOperacionesEventArgs(prmIdConsulta, strCodigoError, strMensajeError));
            }
            catch (Exception ex)
            {                
                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.CONSULTAS_BCRP, strHashcode,
                    "WS_LBTRConsultasService.ConsultarOperaciones",
                    "Error: " + ex.Message + ". " + ex.StackTrace, true);

                this.OnConsultarOperacionError(this, new ConsultarOperacionesEventArgs(prmIdConsulta, "", ex.Message));
            }

            return arrOperaciones;        
        }
            
        #endregion

        #region Consultar Saldos Cuenta Corriente

        public event EventHandler<ConsultarSaldosCtaCteEventArgs> OnConsultarSaldosCtaCteError;

        public beanSaldoCtaCte[] ConsultarSaldosCtaCte(string prmSID, string prmNumCuenta,
                                                        DateTime? prmFecha, string prmIdConsulta) 
        {
            beanSaldoCtaCte[] arrSaldoCtaCte = null;

            try
            {
                LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.CONSULTAS_BCRP, strHashcode, 
                    "WS_LBTRConsultasService.ConsultarSaldosCtaCte",
                    "Se invoca a la funcion Lbtr_SaldosCtaCte del web service LBTRConsultas.", false);

                if (String.IsNullOrEmpty(prmSID)) throw new Exception("El SID es nulo o vacio.");
                                
                LBTRConsultasService.LBTRConsultasService oWS_LBTRCons = new LBTRConsultasService.LBTRConsultasService();

                if (prmFecha.HasValue && !String.IsNullOrEmpty(prmNumCuenta))
                {
                    arrSaldoCtaCte = oWS_LBTRCons.lbtr_SaldosCtaCte(prmSID, prmNumCuenta, prmFecha.Value, true);
                }

                LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.CONSULTAS_BCRP, strHashcode, 
                    "WS_LBTRConsultasService.ConsultarSaldosCtaCte",
                    "Se recibio la respuesta de la consulta de saldos cta cte con fecha " + prmFecha.Value.ToString("yyyyMMdd") + " y nro cuenta " + prmNumCuenta + ".", false);
            }
            catch (SoapException ex)
            {
                string strCodigoError = "";
                string strMensajeError = "";
                System.Xml.XmlElement xmle = null;

                try
                {
                    if (ex != null && ex.Detail != null)
                    {
                        xmle = ex.Detail["ns2:LBTRServiceFault"];
                        if (xmle == null) xmle = ex.Detail["ns2:LBTRSessionFault"];
                        if (xmle != null)
                        {
                            strCodigoError = xmle.ChildNodes[0].InnerText;
                            strMensajeError = xmle.ChildNodes[1].InnerText;
                        }
                    }
                    else
                    {
                        strCodigoError = "BCRP";
                        strMensajeError = "El mensaje de respuesta de error es nulo.";
                    }
                }
                catch (Exception subex)
                {
                    strCodigoError = "BCRP";
                    strMensajeError = "Error al recepcionar la respuesta de error del BCRP: " + subex.Message + "; " + subex.StackTrace;
                }

                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.CONSULTAS_BCRP, strHashcode,
                    "WS_LBTRConsultasService.ConsultarSaldosCtaCte",
                    "IdConsulta: " + prmIdConsulta + " Num. Cuenta: " + prmNumCuenta +
                    " Fecha: " + (prmFecha.HasValue ? prmFecha.Value.ToString("yyyyMMdd") : "") +
                    ". El servicio web LBTR retorno el error con Codigo: " + strCodigoError +
                    ". Mensaje: " + strMensajeError, true);

                this.OnConsultarSaldosCtaCteError(this, new ConsultarSaldosCtaCteEventArgs(prmIdConsulta, strCodigoError, strMensajeError));
            }
            catch (Exception ex)
            {
                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.CONSULTAS_BCRP, strHashcode,
                    "WS_LBTRConsultasService.ConsultarSaldosCtaCte",
                    "Error: " + ex.Message + ". " + ex.StackTrace, true);

                this.OnConsultarSaldosCtaCteError(this, new ConsultarSaldosCtaCteEventArgs(prmIdConsulta, "", ex.Message));
            }

            return arrSaldoCtaCte;
        }
                
        #endregion

    }
        
    public class ConsultarOperacionesEventArgs : EventArgs
    {
        public string IdConsulta;
        public string CodigoError;
        public string MensajeError;

        public ConsultarOperacionesEventArgs(string prmIdConsulta)
        {
            IdConsulta = prmIdConsulta;
        }

        public ConsultarOperacionesEventArgs(string prmIdConsulta, string prmCodigoError, string prmMensajeError)
        {
            IdConsulta = prmIdConsulta;
            CodigoError = prmCodigoError;
            MensajeError = prmMensajeError;
        }

    }

    public class ConsultarSaldosCtaCteEventArgs : EventArgs
    {
        public string IdConsulta;
        public string CodigoError;
        public string MensajeError;

        public ConsultarSaldosCtaCteEventArgs(string prmIdConsulta)
        {
            IdConsulta = prmIdConsulta;
        }

        public ConsultarSaldosCtaCteEventArgs(string prmIdConsulta, string prmCodigoError, string prmMensajeError)
        {
            IdConsulta = prmIdConsulta;
            CodigoError = prmCodigoError;
            MensajeError = prmMensajeError;
        }

    }
    
}
