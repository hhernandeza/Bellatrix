using System;
using System.Collections.Generic;
using System.Text;
using System.Web.Services.Protocols;
using System.Security.Cryptography.X509Certificates;
using System.Configuration;
using System.Xml;
using System.IO;
using TBEWinServ.Utilitarios;

namespace TBEWinServ.Componentes
{
    public class WS_PasswordSafe
    {
        #region Propiedades

        private string strDefinition;

        public string Definition
        {
            get { return strDefinition; }
            set { strDefinition = value; }
        }

        private string strHost;

        public string Host
        {
            get { return strHost; }
            set { strHost = value; }
        }

        private bool blnUseCertificate;

        public bool UseCertificate
        {
            get { return blnUseCertificate; }
            set { blnUseCertificate = value; }
        }

        private string strCCIssuer;

        public string CCIssuer
        {
            get { return strCCIssuer; }
            set { strCCIssuer = value; }
        }

        private string strCCSubject;

        public string CCSubject
        {
            get { return strCCSubject; }
            set { strCCSubject = value; }
        }
        
        private string strCCSerialNumber;

        public string CCSerialNumber
        {
            get { return strCCSerialNumber; }
            set { strCCSerialNumber = value; }
        }
                        
        private bool blnReintentar = false;

        public bool Reintentar
        {
            get { return blnReintentar; }
        }

        #endregion

        public WS_PasswordSafe(string prmDefinition, string prmHost, bool prmUseCertificate, 
                                string prmCCSerialNumber, string prmCCIssuer, string prmCCSubject) 
        {
            strDefinition = prmDefinition;
            strHost = prmHost;
            blnUseCertificate = prmUseCertificate;
            strCCSerialNumber = prmCCSerialNumber;
            strCCIssuer = prmCCIssuer;
            strCCSubject = prmCCSubject;
        }

        public string GetPassword(string prmAccount) {
            string strPassword = null;
            X509Certificate2 cert = null;
            blnReintentar = false;

            try
            {                
                                                
                if (Globales.PASSWORDSAFE_USAR)
                {
                    #region Comprobacion de uso de certificado

                    if (blnUseCertificate)
                    {
                        X509Store store = new X509Store(StoreName.My, StoreLocation.LocalMachine);
                        //X509Store store = new X509Store(StoreName.AuthRoot, StoreLocation.CurrentUser);
                        X509Certificate2Collection certCol = null;

                        store.Open(OpenFlags.ReadOnly);

                        certCol = store.Certificates;

                        /*
                        Valores en el config:
                         * SerialNumber: "48A407BEB54FD80AB944A187AFC17747"
                         * Issuer: "OU=www.verisign.com/CPS Incorp.by Ref. LIABILITY LTD.(c)97 VeriSign, OU=VeriSign International Server CA - Class 3, OU=&#34;VeriSign, Inc.&#34;, O=VeriSign Trust Network"
                         * Subject: "CN=lacpeas030.lac.nsroot.net, OU=Citigroup, O=Citigroup, L=LIMA, S=LIMA, C=PE"
                        */

                        certCol = certCol.Find(X509FindType.FindBySerialNumber, strCCSerialNumber, true);
                        certCol = certCol.Find(X509FindType.FindByIssuerDistinguishedName, strCCIssuer, true);
                        certCol = certCol.Find(X509FindType.FindBySubjectDistinguishedName, strCCSubject, true);

                        if (certCol.Count > 0)
                        {
                            cert = certCol[0];
                            LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.PSAFE, 
                                Globales.HASHCODE_thrInicioFinDia, 
                                "WS_PasswordSafe.GetPassword",
                                "Se encontraron [" + certCol.Count.ToString() + "] certificados de seguridad.", false);
                        }
                        else
                            throw new Exception("Computer Certificate not found");
                    }

                    #endregion

                    System.Net.ServicePointManager.ServerCertificateValidationCallback = new System.Net.Security.RemoteCertificateValidationCallback(IgnoreCertificateErrorHandler);

                    string strRespuesta = "";
                    string strReturnCode = "", strReturnMessage = "", strReturnPassword = "";
                    PasswordSafeService.WSAPR oPSafe = new PasswordSafeService.WSAPR();
                    oPSafe.Timeout = Globales.PSAFE_TIMEOUT;
                    if (blnUseCertificate) oPSafe.ClientCertificates.Add(cert);
                    strRespuesta = oPSafe.GetPassword(strDefinition, strHost, prmAccount);

                    #region Evaluar respuesta

                    XmlReader reader = null;

                    try
                    {
                        reader = XmlReader.Create(new StringReader(strRespuesta));

                        reader.MoveToContent();

                        while (reader.Read())
                        {
                            if (reader.NodeType == XmlNodeType.Element)
                            {

                                if (reader.Name.ToLower() == "returncode")
                                    strReturnCode = reader.ReadString();
                                else if (reader.Name.ToLower() == "returnmessage")
                                    strReturnMessage = reader.ReadString();
                                else if (reader.Name.ToLower() == "password")
                                    strReturnPassword = reader.ReadString();
                            }
                        }
                        reader.Close();
                    }
                    catch (Exception ex)
                    {
                        throw ex;
                    }

                    #endregion

                    if (strReturnCode.Equals("0"))
                    {
                        strPassword = strReturnPassword;

                        LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.PSAFE, 
                            Globales.HASHCODE_thrInicioFinDia, 
                            "WS_PasswordSafe.GetPassword",
                            "El servicio web Password Safe retorno correctamente el password.", false);            
                    }
                    else
                    {
                        throw new Exception("La funcion GetPassword retorno lo siguiente: Return Code: " + strReturnCode + "; Return Message: " + strReturnMessage);
                    }

                }
                else 
                {
                    string strHostBD = ConfigurationManager.AppSettings["PSAFE_HOST_BD"];
                    string strHostLBTR = ConfigurationManager.AppSettings["PSAFE_HOST_LBTR"];

                    if (String.IsNullOrEmpty(strHostBD)) strHostBD = "";
                    if (String.IsNullOrEmpty(strHostLBTR)) strHostLBTR = "";
                    if (String.IsNullOrEmpty(strHost)) strHost = "";

                    //de prueba
                    if (strHost.Equals(strHostBD))
                        strPassword = "sultan";
                    else if (strHost.Equals(strHostLBTR))
                        strPassword = "CITIPERU";
                }
            }            
            catch (Exception ex)
            {
                blnReintentar = true;
                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.PSAFE, 
                    Globales.HASHCODE_thrInicioFinDia, 
                    "WS_PasswordSafe.GetPassword",
                    "Error, mensaje: " + ex.Message + "; StackTrace: " + ex.StackTrace, true);
            }

            if (blnReintentar) {
                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.PSAFE, 
                    Globales.HASHCODE_thrInicioFinDia, 
                    "WS_PasswordSafe.GetPassword",
                    "Problemas con el Password Safe, se procedera a reintentar luego.", false);            
            }

            return strPassword;        
        }

        private bool IgnoreCertificateErrorHandler
                                               (object sender,
                                               System.Security.Cryptography.X509Certificates.X509Certificate certificate,
                                               System.Security.Cryptography.X509Certificates.X509Chain chain,
                                               System.Net.Security.SslPolicyErrors sslPolicyErrors)
        {

            return true;
        }

    }
}
