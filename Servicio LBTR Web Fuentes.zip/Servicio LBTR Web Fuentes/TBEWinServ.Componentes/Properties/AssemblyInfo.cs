﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// La informacion general sobre un ensamblado se controla mediante el siguiente 
// conjunto de atributos. Cambie estos atributos para modificar la informacion
// asociada con un ensamblado.
[assembly: AssemblyTitle("TBEWinServ.Componentes")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("iNexxo S.A.C.")]
[assembly: AssemblyProduct("TBEWinServ.Componentes")]
[assembly: AssemblyCopyright("© iNexxo S.A.C. 2008")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// Si establece ComVisible como false hace que los tipos de este ensamblado no sean visibles 
// a los componentes COM. Si necesita obtener acceso a un tipo en este ensamblado desde 
// COM, establezca el atributo ComVisible como true en este tipo.
[assembly: ComVisible(false)]

// El siguiente GUID sirve como identificador de la biblioteca de tipos si este proyecto se expone a COM
[assembly: Guid("fe967d0d-e67a-4b0c-b026-b4471ef211b3")]

// La informacion de version de un ensamblado consta de los cuatro valores siguientes:
//
//      Version principal
//      Version secundaria 
//      Numero de version de compilacion
//      Revision
//
// Puede especificar todos los valores o puede establecer como valores predeterminados los numeros de revision y generacion 
// mediante el asterisco ('*'), como se muestra a continuacion:
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
