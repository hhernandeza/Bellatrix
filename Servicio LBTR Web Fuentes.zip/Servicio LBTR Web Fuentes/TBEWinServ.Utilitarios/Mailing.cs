using System;
using System.Collections.Generic;
using System.Configuration;
using System.Diagnostics;
using System.Text;
using System.Net.Mail;

namespace TBEWinServ.Utilitarios
{
    public class Mailing
    {
        private string strHashcode = "";
        public string De = null;
        public string Para = null;
        public string Asunto = null;
        public string ContenidoMensaje = null;

        public Mailing() { }

        public Mailing(string prmHashcode)
        {
            strHashcode = prmHashcode;
        }

        public Mailing(string prmDe, string prmPara, string prmAsunto, string prmContenidoMensaje)
        {
            De = prmDe;
            Para = prmPara;
            Asunto = prmAsunto;
            ContenidoMensaje = prmContenidoMensaje;
        }

        public void EnviarCorreo()
        {
            try
            {
                MailMessage oMessage = new MailMessage(De, Para);

                oMessage.Subject = Asunto;
                oMessage.Body = ContenidoMensaje;
                oMessage.IsBodyHtml = false;

                SmtpClient smtp = new SmtpClient();
                if (!String.IsNullOrEmpty(smtp.Host))
                {
                    smtp.SendCompleted += new SendCompletedEventHandler(smtp_SendCompleted);
                    smtp.SendAsync(oMessage, null);
                }
            }
            catch (Exception ex)
            {
                LogWriter.EscribirLog(TipoLog.Resumido, TBEWinServ.Utilitarios.TipoServicio.SERVICIO_WINDOWS, strHashcode,
                    "Mailing.EnviarCorreo", "No se pudo enviar el email. Error: " + ex.Message + ". " + ex.StackTrace, false);
            }
        }

        private void smtp_SendCompleted(object sender, System.ComponentModel.AsyncCompletedEventArgs e)
        {
            if (e.Error != null)
            {
                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS, strHashcode,
                    "Mailing.smtp_SendCompleted", "Error al intentar enviar la notificacion: " + e.Error.Message, false); 
            }
        }
    }
}
