using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Configuration;
using System.Diagnostics;

namespace TBEWinServ.Utilitarios
{
    public class LogWriter
    {

        public static void EscribirLog(TipoLog prmTipoLog, TipoServicio prmTipoServicio, string prmIdSeguimiento,
                                        string prmUbicacion, string prmContenido, bool prmEsCritico)
        {

            string strSeguimientoHabilitado = ConfigurationManager.AppSettings["LOG_MODO"];
            bool blnLogDetallado = false;
            string strDirectorioLog = ConfigurationManager.AppSettings["LOG_RUTA"];
            string strNombreLog = ConfigurationManager.AppSettings["LOG_NOMBRE"];

            #region Validaciones

            //Recortando el ID si es demasiado grande
            if (!String.IsNullOrEmpty(prmIdSeguimiento))
            {
                if (prmIdSeguimiento.Length > 15)
                {
                    prmIdSeguimiento = prmIdSeguimiento.Substring(0, 15);
                }
            }

            if (!String.IsNullOrEmpty(strSeguimientoHabilitado))
            {
                if (strSeguimientoHabilitado.ToLower().Equals("f"))
                {
                    blnLogDetallado = true;
                }
            }

            if (String.IsNullOrEmpty(strNombreLog)) return;

            if (String.IsNullOrEmpty(strDirectorioLog) || !Directory.Exists(strDirectorioLog)) return;

            if (prmTipoLog == TipoLog.Detallado)
            {
                if (!blnLogDetallado) return;
            }

            strNombreLog = DateTime.Today.ToString("yyyyMMdd") + strNombreLog + ".txt";

            #endregion

            #region Contenido

            String strHora = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
            String strOrigen = "";
            String strNivel = "SEGUIMIENTO";

            if (prmEsCritico) strNivel = "***ERROR***";

            switch (prmTipoServicio)
            {
                case TipoServicio.ENVIO_TRANSFERENCIAS:
                    strOrigen = "Transf.    ";
                    break;
                case TipoServicio.ANULACION_OPERACION:
                    strOrigen = "Anulac.    ";
                    break;
                case TipoServicio.CONFIRMACION_ABONO:
                    strOrigen = "C.Abono    ";
                    break;
                case TipoServicio.CONFIRMACION_BCOSMOS:
                    strOrigen = "SyncBCosmos";
                    break;
                case TipoServicio.AVISO_AFECTACION:
                    strOrigen = "Aviso Afect";
                    break;
                case TipoServicio.AVISO_AFECTACION_CONTING:
                    strOrigen = "A Afec Cont";
                    break;
                case TipoServicio.CONSULTAS_BCRP:
                    strOrigen = "Cons. BCRP ";
                    break;
                case TipoServicio.REGISTRO_AUDITORIA:
                    strOrigen = "Reg. Audit ";
                    break;
                case TipoServicio.CONSULTA_AUDITORIA:
                    strOrigen = "Cons. Audit";
                    break;
                case TipoServicio.SEGURIDAD:
                    strOrigen = "Seguridad  ";
                    break;
                case TipoServicio.PSAFE:
                    strOrigen = "Pwd Safe   ";
                    break;
                case TipoServicio.SERVICIO_WINDOWS:
                    strOrigen = "Srv.Windows";
                    break;
                case TipoServicio.TRAZA:
                    strOrigen = "Traza      ";
                    break;
                case TipoServicio.ENVIO_OPERACION_BCOSMOS:
                    strOrigen = "Env.BCosmos";
                    break;
                case TipoServicio.CONTINGENCIA:
                    strOrigen = "Contingencia";
                    break;
            }

            StringBuilder sbContenido = new StringBuilder();

            sbContenido.Append("\r\n");
            sbContenido.Append(prmIdSeguimiento.PadRight(15, ' '));
            sbContenido.Append(";");
            sbContenido.Append(strHora);
            sbContenido.Append(";");
            sbContenido.Append(strOrigen);
            sbContenido.Append(";");
            sbContenido.Append(strNivel);
            sbContenido.Append(";");
            sbContenido.Append(prmUbicacion);
            sbContenido.Append(";");
            sbContenido.Append(prmContenido);
            sbContenido.Append(";");

            #endregion

            #region Registro en Log

            if (!strDirectorioLog.EndsWith(@"\")) strDirectorioLog += @"\";

            DateTime dtInicio = DateTime.Now;

            while (true)
            {
                TimeSpan ts = DateTime.Now.Subtract(dtInicio);

                if (ts.Seconds >= 2) break;

                try
                {
                    File.AppendAllText(strDirectorioLog + strNombreLog, sbContenido.ToString(), Encoding.Unicode);
                    break;
                }
                catch (Exception ex)
                {
                    if (!(ex.Message.Contains("The process cannot access the file")
                        && ex.Message.Contains("because it is being used by another process")))
                    {
                        try
                        {
                            EventLog.WriteEntry("TBEWinServ", "No se pudo registrar en el log el siguiente mensaje:\r\n" + sbContenido.ToString() +
                                                                "\r\n\r\nDebido al siguiente error:\r\n" + ex.Message + "\r\n\r\n" + ex.StackTrace);
                        }
                        catch { }
                        break;
                    }
                }
            }

            #endregion

            #region Si es critico, se envia correo

            if (prmEsCritico)
            {
                try
                {
                    StringBuilder sbMensaje = new StringBuilder();
                    sbMensaje.AppendLine("Ha ocurrido un error controlado en la aplicaci�n. A continuaci�n se muestra la informaci�n del error:");
                    sbMensaje.AppendLine("");
                    sbMensaje.Append("Id de Seguimiento en el log: ");
                    sbMensaje.AppendLine(prmIdSeguimiento);
                    sbMensaje.Append("Origen: ");
                    sbMensaje.AppendLine(strOrigen);
                    sbMensaje.Append("Ubicaci�n: ");
                    sbMensaje.AppendLine(prmUbicacion);
                    sbMensaje.Append("Ruta del log a revisar: ");
                    sbMensaje.AppendLine(strDirectorioLog + strNombreLog);
                    sbMensaje.AppendLine("Contenido:");
                    sbMensaje.AppendLine(prmContenido);
                    sbMensaje.AppendLine("");
                    sbMensaje.Append("*******************************************************************************************");

                    LogWriter.Notificar(prmIdSeguimiento, sbMensaje.ToString());
                }
                catch { }
            }

            #endregion
        }

        public static void Notificar(String prmStrHashcode, String prmMensajeTexto) 
        {
            Mailing oEnvioCorreo = new Mailing(prmStrHashcode);
            oEnvioCorreo.De = ConfigurationManager.AppSettings["MAIL_ERROR_DE"];
            oEnvioCorreo.Para = ConfigurationManager.AppSettings["MAIL_ERROR_PARA"];
            oEnvioCorreo.Asunto = ConfigurationManager.AppSettings["MAIL_ERROR_ASUNTO"];            
            oEnvioCorreo.ContenidoMensaje = prmMensajeTexto;
            oEnvioCorreo.EnviarCorreo();
        }

        public static void EscribirLog(TipoLog prmTipoLog, TipoServicio prmTipoServicio, string prmIdSeguimiento,
                                string prmUbicacion, string prmContenido, NivelMensajeLog prmNivelMensajeLog)
        {

            string strSeguimientoHabilitado = ConfigurationManager.AppSettings["LOG_MODO"];
            bool blnLogDetallado = false;
            string strDirectorioLog = ConfigurationManager.AppSettings["LOG_RUTA"];
            string strNombreLog = ConfigurationManager.AppSettings["LOG_NOMBRE"];

            #region Validaciones

            //Recortando el ID si es demasiado grande
            if (!String.IsNullOrEmpty(prmIdSeguimiento))
            {
                if (prmIdSeguimiento.Length > 15)
                {
                    prmIdSeguimiento = prmIdSeguimiento.Substring(0, 15);
                }
            }

            if (!String.IsNullOrEmpty(strSeguimientoHabilitado))
            {
                if (strSeguimientoHabilitado.ToLower().Equals("f"))
                {
                    blnLogDetallado = true;
                }
            }

            if (String.IsNullOrEmpty(strNombreLog)) return;

            if (String.IsNullOrEmpty(strDirectorioLog) || !Directory.Exists(strDirectorioLog)) return;

            if (prmTipoLog == TipoLog.Detallado)
            {
                if (!blnLogDetallado) return;
            }

            strNombreLog = DateTime.Today.ToString("yyyyMMdd") + strNombreLog + ".txt";

            #endregion

            #region Contenido

            String strHora = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
            String strOrigen = "";
            String strNivel = "";

            switch (prmNivelMensajeLog)
            {
                case NivelMensajeLog.NINGUNO:
                    strNivel = "SEGUIMIENTO ";
                    break;
                case NivelMensajeLog.ERROR:
                    strNivel = "***ERROR*** ";
                    break;
                case NivelMensajeLog.NOTIFICACION:
                    strNivel = "NOTIFICACION";
                    break;
                default:
                    break;
            }

            switch (prmTipoServicio)
            {
                case TipoServicio.SERVICIO_WINDOWS:
                    strOrigen = "Srv.Windows";
                    break;
                case TipoServicio.ENVIO_OPERACION_BCOSMOS:
                    strOrigen = "Env.BCosmos";
                    break;
            }

            StringBuilder sbContenido = new StringBuilder();

            sbContenido.Append("\r\n");
            sbContenido.Append(prmIdSeguimiento.PadRight(15, ' '));
            sbContenido.Append(";");
            sbContenido.Append(strHora);
            sbContenido.Append(";");
            sbContenido.Append(strOrigen);
            sbContenido.Append(";");
            sbContenido.Append(strNivel);
            sbContenido.Append(";");
            sbContenido.Append(prmUbicacion);
            sbContenido.Append(";");
            sbContenido.Append(prmContenido);
            sbContenido.Append(";");

            #endregion

            #region Registro en Log

            if (!strDirectorioLog.EndsWith(@"\")) strDirectorioLog += @"\";

            DateTime dtInicio = DateTime.Now;

            while (true)
            {
                TimeSpan ts = DateTime.Now.Subtract(dtInicio);

                if (ts.Seconds >= 2) break;

                try
                {
                    File.AppendAllText(strDirectorioLog + strNombreLog, sbContenido.ToString(), Encoding.Unicode);
                    break;
                }
                catch (Exception ex)
                {
                    if (!(ex.Message.Contains("The process cannot access the file")
                        && ex.Message.Contains("because it is being used by another process")))
                    {
                        try
                        {
                            EventLog.WriteEntry("TBEWinServ", "No se pudo registrar en el log el siguiente mensaje:\r\n" + sbContenido.ToString() +
                                                                "\r\n\r\nDebido al siguiente error:\r\n" + ex.Message + "\r\n\r\n" + ex.StackTrace);
                        }
                        catch { }
                        break;
                    }
                }
            }

            #endregion

            #region Si es critico, se envia correo

            if (prmNivelMensajeLog == NivelMensajeLog.ERROR || prmNivelMensajeLog == NivelMensajeLog.NOTIFICACION)
            {
                try
                {
                    string strCabecera = "";

                    if (prmNivelMensajeLog == NivelMensajeLog.ERROR)
                        strCabecera = "Ha ocurrido un error controlado en la aplicaci�n. A continuaci�n se muestra la informaci�n del error:";
                    else
                        strCabecera = "El sistema LBTR ha enviado un correo con la siguiente informaci�n:";

                    StringBuilder sbMensaje = new StringBuilder();
                    sbMensaje.AppendLine(strCabecera);
                    sbMensaje.AppendLine("");
                    sbMensaje.Append("Id de Seguimiento en el log: ");
                    sbMensaje.AppendLine(prmIdSeguimiento);
                    sbMensaje.Append("Origen: ");
                    sbMensaje.AppendLine(strOrigen);
                    sbMensaje.Append("Ubicaci�n: ");
                    sbMensaje.AppendLine(prmUbicacion);
                    sbMensaje.Append("Ruta del log a revisar: ");
                    sbMensaje.AppendLine(strDirectorioLog + strNombreLog);
                    sbMensaje.AppendLine("Contenido:");
                    sbMensaje.AppendLine(prmContenido);
                    sbMensaje.AppendLine("");
                    sbMensaje.Append("*******************************************************************************************");

                    LogWriter.Notificar(prmIdSeguimiento, sbMensaje.ToString(), prmNivelMensajeLog);
                }
                catch { }
            }

            #endregion

        }

        public static void Notificar(String prmStrHashcode, String prmMensajeTexto, NivelMensajeLog prmNivelMensaje)
        {
            string strDe = string.Empty;
            string strPara = string.Empty;
            string strAsunto = string.Empty;

            if (prmNivelMensaje == NivelMensajeLog.ERROR)
            {
                strAsunto = ConfigurationManager.AppSettings["MAIL_ERROR_ASUNTO"];
                strDe = ConfigurationManager.AppSettings["MAIL_ERROR_DE"];
                strPara = ConfigurationManager.AppSettings["MAIL_ERROR_PARA"];
            }
            else if (prmNivelMensaje == NivelMensajeLog.NOTIFICACION)
            {
                strAsunto = ConfigurationManager.AppSettings["MAIL_NOTIFICACION_ASUNTO"];
                strDe = ConfigurationManager.AppSettings["MAIL_NOTIFICACION_DE"];
                strPara = Globales.MAIL_NOTIFICACION_PARA_BD != "" ? Globales.MAIL_NOTIFICACION_PARA_BD :
                          ConfigurationManager.AppSettings["MAIL_NOTIFICACION_PARA"];
            }

            if (strDe != "" && strPara != "" && strAsunto != "")
            {
                Mailing oEnvioCorreo = new Mailing(prmStrHashcode);
                oEnvioCorreo.De = strDe;
                oEnvioCorreo.Para = strPara;
                oEnvioCorreo.Asunto = strAsunto;
                oEnvioCorreo.ContenidoMensaje = prmMensajeTexto;
                oEnvioCorreo.EnviarCorreo();
            }
        }
    }

    public enum TipoLog
    {
        Resumido = 0,
        Detallado = 1
    }

}