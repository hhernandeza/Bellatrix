using System;
using System.Collections.Generic;
using System.Text;
using System.Globalization;
using System.Configuration;

namespace TBEWinServ.Utilitarios
{
    public static class Globales {
        public static string SID = "";
        public static string CADENA_CONEXION = "";
        public static string CADENA_CONEXION_PLB = "";
        //hh72295:20161104:I: ADECUACION PARA RECUPERAR PASSWORD DESDE DB STBSEGDB Y DESENCRIPTAR CON HSM 
        public static string CADENA_CONEXION_SIXSEC = "";
        //hh72295:20161104:F: ADECUACION PARA RECUPERAR PASSWORD DESDE DB STBSEGDB Y DESENCRIPTAR CON HSM
        public static string PASSWORD_BD_SYBASE = "";
        public static string PASSWORD_BD_MSSQL = "";
        public static string LBTR_PASSWORD = "";
        public static bool PASSWORDSAFE_USAR = true;//Si es false, el valor del password se esta devolviendo en el proxy PSafe en duro
        public static bool APISEGURIDAD_USAR = true; // UNDONE: Solo para pruebas SIT
        public static string HASHCODE_thrInicioFinDia = "";
        public static string HASHCODE_thrInicioFinDiaBCosmos = "";
        public static int SYNCBCOSMOS_TIMEOUT = 30;
        public static int SYNCBCOSMOS_REINTENTOS = 3;
        public static string RUTA_XML_ERRORES_APISEG = "";
        public static bool MOSTRAR_DATA_CLIENTE_LOG = false;//MODIFICAR PARAMETRO A FALSE para UAT Y PRODUCCION
        public static bool MOSTRAR_CADENA_CNX_LOG = false;
        public static bool MOSTRAR_SID_LOG_TRAZA = false;//si es false, no muestra el SID tanto en el LOG como en la traza        
        public static bool MOSTRAR_TRAZA_PSAFE = false;//si es false, no muestra la traza generada por el consumo de PSafe
        public static bool NO_MOSTRAR_TRAZA = true;//Si fuese true, no se mostrar�a traza a pesar de otro indicador(MOSTRAR_SID_LOG_TRAZA, MOSTRAR_TRAZA_PSAFE)

        public static string CONTING_BD_USER_SYBASE = "";//Valor establecido desde la consola cliente
        public static string CONTING_BD_PWD_SYBASE = "";//Valor establecido desde la consola cliente
        public static string CONTING_BD_USER_MSSQL = "";//Valor establecido desde la consola cliente
        public static string CONTING_BD_PWD_MSSQL = "";//Valor establecido desde la consola cliente
        public static int PAR_TIMEOUT = 60000;
        public static int PAR_MAX_PASSWORD_LENGTH = 0;

        public static int PSAFE_TIMEOUT = 60000;
        public static int LBTRSERVICES_TIMEOUT = 60000;
        public static List<CaracterNoValido> LstCaracteresNoValidos = new List<CaracterNoValido>();
        public static bool APISEC_CONECTADA_CONTINGENCIA = false;//Indica si el api se conecto usando datos de contingencia
        public static Dictionary<string, string> LstTransferenciasEnCurso = new Dictionary<string, string>();        
        
        //VARIABLES DE VERIFICACION DE ACTIVIDAD EN API DE SEGURIDAD
        public static double APISEC_TIEMPOMAXESPERA = 5;//En segundos, 5 por defecto configurable desde config
        public static DateTime THRINICIODIA_DTULTINVOCAPI;
        public static bool THRINICIODIA_BLNAPIINVOCADO = false;
        public static DateTime THRENVIOOPEBCRP_DTULTINVOCAPI;
        public static bool THRENVIOOPEBCRP_BLNAPIINVOCADO = false;
        public static DateTime THRCONFABONO_DTULTINVOCAPI;
        public static bool THRCONFABONO_BLNAPIINVOCADO = false;
        public static DateTime THROPEREC_DTULTINVOCAPI;
        public static bool THROPEREC_BLNAPIINVOCADO = false;
        public static DateTime THROPERECCONTING_DTULTINVOCAPI;
        public static bool THROPERECCONTING_BLNAPIINVOCADO = false;

        public static int SISTEMA_ORIGEN = 1;//Sistema origen para identificar envio de BCosmos por MQ
        public static string SISTEMA_ORIGEN_CITISCREENING = "SCREE";//Sistema origen para identificar envio de CITISCREENING por MQ
        public static string MAIL_NOTIFICACION_PARA_BD = "";
        public static List<String> ListProcesosCorreoEnviado  = new List<string>();
        public static string ERRORES_PARA_REENVIO = "";
        public static string MAIL_ERROR_PARA_BD = "";
        public static bool ENVIAR_CORREO_SALIDAS_CV = false;
        //hh72295:20170117:I: ADECUACION CITISCREENING EN OPERACIONES DE ENTRADA
        public static string MAIL_NOTIFICACION_CITISCREENING_TBE = "";
        public static string MAIL_NOTIFICACION_CITISCREENING_COMPLIANCE = "";
        //hh72295:20170117:F: ADECUACION CITISCREENING EN OPERACIONES DE ENTRADA
    }

    public class CaracterNoValido
    {
        private string strCar;

        public string Car
        {
            get { return strCar; }
            set { strCar = value; }
        }

        private string strHex;

        public string Hex
        {
            get { return strHex; }
            set { strHex = value; }
        }

        private string strCarReemp;

        public string CarReemp
        {
            get { return strCarReemp; }
            set { strCarReemp = value; }
        }

        private string strHexReemp;

        public string HexReemp
        {
            get { return strHexReemp; }
            set { strHexReemp = value; }
        }
    }

    public struct TipoEstado
    {
        public const String Liquidacion = "L";
        public const String Operacion = "O";
    }

    public struct TipoRepositorioClaves
    {
        public const string PAR = "PAR";
        public const string PSAFE = "PSAFE";
    }

    public struct Conceptos_CV
    {
        public const String Compras = "C083";
        public const String Ventas = "C082";
    }

    public struct Validacion_CompraVenta
    {
        public const String HoraCorte = "HORA";
        public const String CodigoErrores = "ERRORES";
    }

    public struct Estados
    {
        public const string REGISTRADO = "1";
        public const string CARGADO_NO_ENVIADO = "2";
        public const string POR_ENVIAR = "3";
        public const string ENVIADO = "4";
        public const string PENDIENTE_EN_ESPERA = "5"; //estado BCRP=3
        public const string PROCESADO = "6"; //ESTADO BCRP=4
        public const string ANULADO = "7"; //ESTADO BCRP=5
        public const string REENVIADO = "8";
        public const string ERROR_TRX = "0"; //ERROR INTERNO CUANDO EL BCRP RETORNA NULL
        public const string REGISTRADO_BCRP = "9"; //ESTADO INTERNO DEL BCRP=2
    }

    public struct EstadosCompraVenta
    {
        public const string REGISTRADO = "1";
        public const string ENVIADO = "2";
        public const string PENDIENTE_EN_ESPERA = "3"; //estado BCRP=3
        public const string PROCESADO = "4"; //ESTADO BCRP=4
        public const string ANULADO = "5"; //ESTADO BCRP=5
        public const string ERROR_TRX = "0"; //ERROR INTERNO CUANDO EL BCRP RETORNA NULL
    }

    public struct Constantes 
    {
        public const int SERV_INTERFACES_ID_CONFIG_MQBCOSMOS = 5;//TODO: Parametrizar
        public const int ACTUALIZAR_SERVICIOSHABILITADOS = 129;
        public const string PARAM_CODIGO_AGRUPACION = "TBESERVWIN";
        public const string PARAM_CODIGO_HORAINI = "PARAMHORAINI";
        public const string PARAM_CODIGO_HORAFIN1 = "PARAMHORAFIN1";
        public const string PARAM_CODIGO_HORAFIN2 = "PARAMHORAFIN2";
        public const string PARAM_CODIGO_BCRP = "PARAMCODBCRP";
        public const string PARAM_CODIGO_CITIBANK = "PARAMCODCITI";
        public const string PARAM_VALIDAR_FIRMA = "PARAMVALIDARFIRMA";
        public const string PARAM_CODIGO_CARACT_VALID = "0087";
        public const string PARAM_CODIGO_CTATRAMITE_MN = "0088";
        public const string PARAM_CODIGO_CTATRAMITE_ME = "0089";
        public const string SERVICIOLBTR_SESION_NO_ACTIVA = "-203";
        public const string SERVICIOLBTR_SESION_YA_ACTIVA = "-195";
        public const string SERVICIOLBTR_OPER_YA_CONFIRMADA = "-211";
        public const string INDICADOR_CONFIRMAABONO = "K";
        public const string INDICADOR_ABONO = "A";
        public const string INDICADOR_ANULACION = "N";
        public const string LBTR_PARAM_PWD_LOGON_BCRP = "0001";
        public const string PARAM_CODIGO_BCOSMOS_REQUERIMIENTOID_APERTURA = "0116";
        public const string PARAM_CODIGO_BCOSMOS_REQUERIMIENTOID_OPERACION = "0117";
        public const string PARAM_CODIGO_BCOSMOS_REQUERIMIENTOID_CIERRE = "0118";
        public const string PARAM_CODIGO_BCOSMOS_REGISTROID = "0119";
        public const string PARAM_CODIGO_BCOSMOS_ENVIROMENT = "0120";
        public const string PARAM_CODIGO_BCOSMOS_BRANCH = "0121";
        public const string PARAM_CODIGO_BCOSMOS_OPERADOR = "0122";
        public const string PARAM_CODIGO_BCOSMOS_PRODUCTO = "0123";
        public const string PARAM_CODIGO_BCOSMOS_BATCH = "0124";
        public const string PARAM_CODIGO_BCOSMOS_ESTADO_BATCH = "0125";
        public const string PARAM_CODIGO_EMAIL_NOTIFICACION = "0127";
        public const string PARAM_CODIGO_BCOSMOS_FECHA = "0128";
        public const string PARAM_CODIGO_BCOSMOS_FLAGUSOFECHA = "0129";
        public const string PARAM_CODIGO_BCOSMOS_FLAG1_USO_ADES = "0130";
        public const string PARAM_CODIGO_BCOSMOS_FLAG2_USO_ADES = "0131";
        public const string PARAM_CODIGO_BCOSMOS_MONEDASOL = "0063";
        public const string PARAM_CODIGO_BCOSMOS_MONEDADOL = "0064";
        public const string PARAM_CODIGO_BCOSMOS_TRX_DEBITO_SINAFECTO = "0967";
        public const string PARAM_CODIGO_BCOSMOS_TRX_CREDITO_SINAFECTO = "0061";
        public const string PARAM_CODIGO_BCOSMOS_TRX_DEBITO_CONAFECTO = "0999";
        public const string PARAM_CODIGO_BCOSMOS_TRX_CREDITO_CONAFECTO = "0062";
        public const string PARAM_CODIGO_BCOSMOS_EMAIL_OPE = "0132";
        public const string PARAM_CODIGO_BCOSMOS_TIPOCAMBIO = "0133";
        public const string PARAM_CODIGO_BCOSMOS_HORAINI = "PARAMHORAINIBATCH";
        public const string PARAM_CODIGO_BCOSMOS_HORAFIN1 = "PARAMHORAFIN1BATCH";
        public const string PARAM_CODIGO_BCOSMOS_HORAFIN2 = "PARAMHORAFIN2BATCH";

        public const string PARAM_CODIGO_CITISCREENING_BUSINESS_UNIT = "1001";
        public const string PARAM_CODIGO_CITISCREENING_RULE_SET = "1002";
        public const string PARAM_CODIGO_CITISCREENING_BUSINESS_USER = "1003";
        public const string PARAM_NOTIFICACION_WORKFLOW_GRUPO_TBE = "1004";
        public const string PARAM_NOTIFICACION_WORKFLOW_GRUPO_COMPLIANCE = "1005";
        public const string PARAM_CODIGO_CITISCREENING_SECUENCIA = "1006";
        public const string PARAM_CITISCREENING_NUM_MAX_REINTENTOS = "1007";

        public const string INDICADOR_APERTURA_BATCH = "A";
        public const string INDICADOR_CIERRE_BATCH = "C";
        public const string INDICADOR_TRAMA_INPUT_MQ = "I";
        public const string INDICADOR_TRAMA_OUTPUT_MQ = "O";

        public const int PARAM_RANGO_INFERIOR_BASENUMBER = 400000;
        public const int PARAM_RANGO_SUPERIOR_BASENUMBER = 599999;

        /*
        'Identificador de requerimiento de apertura'
        'Identificador de requerimiento de operacion'
        'Identificador de requerimiento de cierre'
        'Identificador de registro'
        'Environment'
        'Branch'
        'Operador'
        'Producto Valido Contra Flat28'
        'Batch'
        */

        /// <summary>
        /// Formato: yyyy/MM/dd HH:mm:ss
        /// </summary>
        public const string FORMATO_FECHALARGA = "yyyy/MM/dd HH:mm:ss";
        /// <summary>
        /// Formato: dd/MM/yyyy
        /// </summary>
        public const string FORMATO_FECHACORTA = "dd/MM/yyyy";
       
        public const int APISEGURIDAD_METODOHASH = 8;
    }
      
    public static class Utilitario 
    {
        public static string ObtenerTipoDocumentoDescripcion(string prmCodigoTipoDoc)
        {
            string strDescripcion = "Desconocido";

            switch (prmCodigoTipoDoc)
            {
                case TipoDocumento.CARNEEXTRANJ:
                    strDescripcion = "Carnet Extranjeria";
                    break;
                case TipoDocumento.DNI:
                    strDescripcion = "DNI";
                    break;
                case TipoDocumento.LIBELECT:
                    strDescripcion = "Libreta Electoral";
                    break;
                case TipoDocumento.LIBMIL:
                    strDescripcion = "Libreta Militar";
                    break;
                case TipoDocumento.PASAPORTE:
                    strDescripcion = "Pasaporte";
                    break;
                case TipoDocumento.RUC:
                    strDescripcion = "RUC";
                    break;
                default:
                    break;
            }

            return strDescripcion;
        }

        public static string ObtenerCadenaConexion(bool esSybase, string prmServidor, string prmBaseDatos,
                                                string prmPuerto, string prmUsuario, string prmPassword)
        {
            StringBuilder sbCadena = new StringBuilder();

            if (esSybase)
            {
                sbCadena.Append("Data Source=");
                sbCadena.Append(prmServidor);
                sbCadena.Append(";Port=");
                sbCadena.Append(prmPuerto);
                sbCadena.Append(";Database=");
                sbCadena.Append(prmBaseDatos);
                sbCadena.Append(";Uid=");
                sbCadena.Append(prmUsuario);
                sbCadena.Append(";Pwd=");
                sbCadena.Append(prmPassword);
                sbCadena.Append(";");
            }
            else
            {
                sbCadena.Append("Data Source=");
                sbCadena.Append(prmServidor);
                sbCadena.Append(";Initial Catalog=");
                sbCadena.Append(prmBaseDatos);
                sbCadena.Append(";User Id=");
                sbCadena.Append(prmUsuario);
                sbCadena.Append(";Password=");
                sbCadena.Append(prmPassword);
                sbCadena.Append(";");
            }

            return sbCadena.ToString();
        }

        public static bool EsConsumer(string prmBaseNumber)        
        {
            bool blnValorRetorno = false;
            
            try
            {
                double dblBaseNumber = double.Parse(prmBaseNumber);

                if (dblBaseNumber >= 400000 && dblBaseNumber <= 599999)
                {
                    blnValorRetorno = true;
                }
            }
            catch
            {
                
            }

            return blnValorRetorno;
        }

        /// <summary>
        /// Convierte un texto claro a formato hexadecimal
        /// </summary>
        /// <param name="plainText"></param>
        /// <returns></returns>
        public static string ToHexadecimal(string plainText)
        {
            char[] charArray = plainText.ToCharArray();

            StringBuilder builder = new StringBuilder();

            for (int i = 0; i < charArray.Length; i++)
            {
                int num = Convert.ToInt32(charArray[i]);
                string hex = num.ToString("X2");

                //si es un caracter raro, se reemplaza con ?
                if (hex.Length > 2) hex = "3F";

                builder.Append(hex.ToUpper());
            }

            return builder.ToString();
        }

        /// <summary>
        /// Convierte un texto con formato hexadecimal a texto claro
        /// </summary>
        /// <param name="prmHexa"></param>
        /// <returns></returns>
        public static string ToStringFromHexadecimal(string prmHexa)
        {
            String strSalida = "";
            for (int i = 0; i < prmHexa.Length; i+=2)
            {
                strSalida += Convert.ToChar(Convert.ToInt32(prmHexa.Substring(i, 2),16));
            }

            return strSalida;
        }

        /// <summary>
        /// Genera un c�digo unico de maximo 32 caracteres basado en la generacion de
        /// un GUID.
        /// </summary>
        /// <param name="nTamanho">Especifica el tama�o del codigo resultante</param>
        /// <returns>El codigo con el tama�o especificado</returns>
        public static string GenerarCodigo(int nTamanho)
        {
            if (nTamanho > 32) nTamanho = 32;
            if (nTamanho < 5) nTamanho = 5;

            //Generar codigo "unico"       
            Guid guid = Guid.NewGuid();
            String strID = guid.ToString("N");//32 caracteres

            //Reduciendolo a X caracteres
            String strID20 = strID.Substring(0, nTamanho);//Los X primeros caracteres deseados
            String strID12 = strID.Substring(nTamanho, strID.Length - nTamanho);//Los ultimos caracteres restantes

            //Combinando
            Random oRandom = new Random();
            int nTamCaracRestantes = strID12.Length;

            for (int i = 0; i < nTamCaracRestantes; i++)
            {
                //Se buscara un caracter bajo un indice (base 0) aleatorio
                int nIdx = oRandom.Next(0, strID12.Length);
                String strCaracter = strID12.Substring(nIdx, 1);
                strID12 = strID12.Remove(nIdx, 1);

                //Se busca un caracter bajo un indice aleatorio en la cadena principal (strID20)
                //el cual estara bajo condicion de ser reemplazado
                nIdx = oRandom.Next(0, strID20.Length);

                String strTomados = strCaracter + strID20.Substring(nIdx, 1);
                //Se selecciona aleatoriamente qu� caracter tomar entre los dos caracteres
                strTomados = strTomados.Substring(oRandom.Next(0, 2), 1);

                //reemplazamos el valor tomado en la cadena principal
                strID20 = strID20.Remove(nIdx, 1);
                strID20 = strID20.Insert(nIdx, strTomados);
            }

            return strID20;
        }

        public static string RetornaHashCode(int prmObjectHashCode)
        {
            decimal decValor1 = Convert.ToDecimal(prmObjectHashCode) * 2357;
            decimal decValor2 = decValor1;

            if (decValor1 > 9999)
            {
                decValor2 = Math.Round(decValor1 / 10, 0);
            }

            return decValor2.ToString();
        }

        /// <summary>
        /// Funcion que recibe un numero decimal y elimina los ceros no significativos
        /// retornando un numero en formato String
        /// </summary>
        /// <param name="prmNumero"></param>
        /// <returns></returns>
        public static string EliminarCerosNoSignificativos(decimal prmNumero)
        {
            string[] arrMonto = prmNumero.ToString().Split('.');
            string strNumeroRetornar = "";
            string strParteEntera = arrMonto[0];
            string strParteDecimal = "";

            if (arrMonto.Length == 2)
            {
                string strDecimalesInput = arrMonto[1];
                bool blnEncontroSignificativo = false;
                string strNumerosFiltrados = "";

                //eliminando ceros no significativos
                for (int i = strDecimalesInput.Length - 1; i >= 0; i--)
                {
                    string strCaracter = strDecimalesInput.Substring(i, 1);

                    if (strCaracter.Equals("0"))
                    {
                        if (!blnEncontroSignificativo)
                        {
                            strCaracter = "";
                        }
                    }
                    else
                    {
                        blnEncontroSignificativo = true;
                    }

                    strNumerosFiltrados += strCaracter;
                }

                //formando decimales
                for (int i = strNumerosFiltrados.Length - 1; i >= 0; i--)
                {
                    strParteDecimal += strNumerosFiltrados.Substring(i, 1);
                }

                if (!String.IsNullOrEmpty(strParteDecimal))
                {
                    strParteDecimal = "." + strParteDecimal;
                }
            }

            strNumeroRetornar = strParteEntera + strParteDecimal;

            return strNumeroRetornar;
        }
        
        public static DateTime FechaSinHora(DateTime prmFecha) {
            return prmFecha.Date;
        }

        public static bool ValidarHora(string prmHora)
        {
            DateTime? dtFechaHora;

            return ValidarHora(prmHora, out dtFechaHora);
        }

        public static bool ValidarHora(string prmHora, out DateTime? dtFechaHora) {
            bool blnCorrecto = false;
            dtFechaHora = null;

            try
            {
                if (String.IsNullOrEmpty(prmHora)) return false;

                DateTime dtHora = new DateTime(DateTime.Today.Year, DateTime.Today.Month, DateTime.Today.Day,
                                            int.Parse(prmHora.Substring(0, 2)), int.Parse(prmHora.Substring(3, 2)), 0);
                dtFechaHora = dtHora;
                blnCorrecto = true;
            }
            catch { }

            return blnCorrecto;
        }

        public static bool ValidarListaCodigoErrores(string prmListaErrores, out string CodigoErroresValidado)
        {
            bool blnCorrecto = false;
            CodigoErroresValidado = string.Empty;
            try
            {
                string[] arrCodigoErrores = prmListaErrores.ToString().Split(',');
               
                foreach ( string codigo in arrCodigoErrores)
                {
                    CodigoErroresValidado += (Convert.ToInt32(codigo)) + ",";
                    blnCorrecto = true;
                }
            }
            catch 
            {
                blnCorrecto = false;
            }

            return blnCorrecto;
        }

        public static object SetearComoParametro(decimal? prmValor)
        {
            if (prmValor == null) return DBNull.Value;

            return prmValor.Value;
        }

        public static object SetearComoParametro(int? prmValor) 
        {
            if (prmValor == null) return DBNull.Value;

            return prmValor.Value;
        }

        public static object SetearComoParametro(Int64? prmValor)
        {
            if (prmValor == null) return DBNull.Value;

            return prmValor.Value;
        }

        public static object SetearComoParametro(DateTime? prmValor)
        {
            if (prmValor == null) return DBNull.Value;

            return prmValor.Value;
        }

        public static object SetearComoParametro(string prmCadena, TipoDato prmTipoDatoRetorno){
            object oObjeto = DBNull.Value;

            if (String.IsNullOrEmpty(prmCadena))
                oObjeto = DBNull.Value;
            else
            {
                try
                {
                    switch (prmTipoDatoRetorno)
                    {
                        case TipoDato.Cadena:
                            oObjeto = prmCadena;
                            break;
                        case TipoDato.Decimal:
                            oObjeto = decimal.Parse(prmCadena);
                            break;
                        case TipoDato.Double:
                            oObjeto = double.Parse(prmCadena);
                            break;
                        case TipoDato.Entero:
                            oObjeto = Int32.Parse(prmCadena);
                            break;
                        case TipoDato.FechaLarga:
                            oObjeto = DateTime.ParseExact(prmCadena, Constantes.FORMATO_FECHALARGA, null);
                            break;
                        case TipoDato.FechaCorta:
                            oObjeto = DateTime.ParseExact(prmCadena, Constantes.FORMATO_FECHACORTA, null);
                            break;
                    }
                }
                catch {
                    oObjeto = DBNull.Value;
                }
            }

            return oObjeto;                                            
        }
                
        public static string ObtenerDatoComoCadena(object prmDato, TipoDato prmTipoDato) {
            string strDato = string.Empty;

            if (prmDato == null || prmDato.Equals(DBNull.Value)) return string.Empty;

            try
            {
                switch (prmTipoDato)
                {
                    case TipoDato.Cadena:
                        strDato = prmDato.ToString().Trim();
                        break;
                    case TipoDato.FechaCorta:
                        strDato = Convert.ToDateTime(prmDato).ToString(Constantes.FORMATO_FECHACORTA);
                        break;
                    case TipoDato.FechaLarga:
                        DateTime dt1 = Convert.ToDateTime(prmDato);//new DateTime(2009, 8, 18, 21, 30, 45, 17);
                        string strTimeZone = TimeZone.CurrentTimeZone.GetUtcOffset(dt1).ToString();
                        strTimeZone = strTimeZone.StartsWith("-") ? strTimeZone.Remove(6) : "+" + strTimeZone.Remove(5);
                        strDato = dt1.ToString("yyyy-MM-ddTHH:mm:ss:fff") + strTimeZone;
                        break;
                    case TipoDato.Image:
                        byte[] data = (byte[])prmDato;
                        strDato = Convert.ToBase64String(data);
                        break;
                }
            }
            catch {
                strDato = string.Empty;
            }

            return strDato;            
        }

        public static DateTime? ObtenerDateTimeNull(string strValor)
        {
            if (String.IsNullOrEmpty(strValor))
            {
                return null;
            }
            else
            {
                return DateTime.Parse(strValor);
            }
        }

        public static DateTime ObtenerDateTime(string strValor) 
        {
            return DateTime.Parse(strValor);
        }

        public static decimal? ObtenerDecimalNull(string strValor)
        {
            if (String.IsNullOrEmpty(strValor))
            {
                return null;
            }
            else
            {
                return decimal.Parse(strValor);
            }
        }

        public static int? ObtenerIntNull(string strValor)
        {
            if (String.IsNullOrEmpty(strValor))
            {
                return null;
            }
            else
            {
                return int.Parse(strValor);
            }
        }

        public static string ObtenerDatoComoString(string psValor, int piTamanio, char pcRelleno, string psValorNulo)
        {
            string sValorRetorno = string.Empty;

            sValorRetorno = (psValor != "" ? 
                psValor.ToString().Trim().PadLeft(piTamanio, pcRelleno) : 
                psValorNulo.PadLeft(piTamanio, pcRelleno));

            return sValorRetorno;
        }

        public static string ValidarCCI(string pstrCCIBeneficiario, out string strMensajeValidacion)
        {
            string strIndicador = "0";

            try
            {
                strMensajeValidacion = string.Empty;

                #region
                /*
              1.	Actualmente el servicio de LBTR identifica estas operaciones a partir del tipo de documento seg�n la siguiente l�gica:
              a.	DNI o CE: Consumer
              b.	RUC: Corporate.

              2.	Se debe reemplazar la l�gica para que esta se identifique en funci�n al siguiente algoritmo:

              Estructura del CCI:
              Ej: 00700100000475410713

              007: C�digo de banco
              001: C�digo de agencia del banco
              000004754107: Nro de cuenta
              13: digito de validaci�n

              La identificaci�n debe ser pro Nro de cuenta (punto 3) bajo la sgte regla:

              Base dela cuenta esta entre los Nros:

              Nros entre 49999 y 59999: CLIENTE CONSUMER
              Nros fuera del rango de 49999 Y 59999: CLIENTE CORPORATE

              3.En base a esta l�gica se actualizar� el campo ChrEntidad.
            */
                #endregion

                if (pstrCCIBeneficiario.Length <= 20)
                {
                    String strBaseNumber = pstrCCIBeneficiario.Substring(9, 6);

                    if (!string.IsNullOrEmpty(strBaseNumber))
                    {
                        Int32 nBasenumber = Convert.ToInt32(strBaseNumber);

                        if (nBasenumber >= Constantes.PARAM_RANGO_INFERIOR_BASENUMBER && nBasenumber <= Constantes.PARAM_RANGO_SUPERIOR_BASENUMBER)
                        {
                            strIndicador = "2";
                        }
                        else
                        {
                            strIndicador = "1";
                        }
                    }
                    else
                    {
                        strMensajeValidacion = "El Basenum correspondiente al CCI no puede ser comparado con el rango establecido";
                    }
                }
                else
                {
                    strMensajeValidacion = "El CCI No tiene el tama�o minimo permitido";
                }
            }
            catch (Exception)
            {
               strMensajeValidacion = "Error al tratar de obtener el indicardor de Entidad, revisar el valor del CCI Beneficiario";
            }
            return strIndicador;
        }

        //hh72295:20161104:I: ADECUACION PARA RECUPERAR PASSWORD DESDE DB STBSEGDB Y DESENCRIPTAR CON HSM 
        public static string ObtenerCadenaConexionSIXSEC()
        {
            string strHashcode = "";
            string strTipoRepositorioClaves = ConfigurationManager.AppSettings["TIPO_REPOSITORIO_CLAVE"];
            string strServidor = ConfigurationManager.AppSettings["SERVIDOR_SIXSEC"];
            string strBaseDatos = ConfigurationManager.AppSettings["BASE_DATOS_SIXSEC"];
            string strUsuarioBD = strTipoRepositorioClaves == TipoRepositorioClaves.PSAFE ? ConfigurationManager.AppSettings["USUARIOBD_SIXSEC"] : ConfigurationManager.AppSettings["USUARIOBD_SIXSEC_PAR"];
            string strClaveBD = Globales.PASSWORD_BD_MSSQL;
            //Verificando si se esta usando en la cadena de conexion los datos de contingencia.
            //Si se estuvieran usando, entonces, el api deberia conectar usando el usuario y password de contingencia
            if (!String.IsNullOrEmpty(Globales.CONTING_BD_USER_SYBASE) && !String.IsNullOrEmpty(Globales.CONTING_BD_PWD_SYBASE)
                && !String.IsNullOrEmpty(Globales.CONTING_BD_USER_MSSQL) && !String.IsNullOrEmpty(Globales.CONTING_BD_PWD_MSSQL)
                )
            {
                if (!String.IsNullOrEmpty(Globales.CADENA_CONEXION))
                {
                    if (Globales.CADENA_CONEXION.Contains(Globales.CONTING_BD_USER_MSSQL) &&
                        Globales.CADENA_CONEXION.Contains(Globales.CONTING_BD_PWD_MSSQL))
                    {
                        LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.SEGURIDAD, strHashcode,
                            "Utilitario.ObtenerCadenaConexionSIXSEC",
                            "Se procede a usar los datos de contingencia para conexion SIXSEC.", false);
                        strUsuarioBD = Globales.CONTING_BD_USER_MSSQL;
                        strClaveBD = Globales.CONTING_BD_PWD_MSSQL;
                    }
                }
            }
            //Antes de inicializar y conectar, verificamos si los datos de conexion estan completos
            if (String.IsNullOrEmpty(strUsuarioBD))
            {
                LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.SEGURIDAD, strHashcode,
                    "Utilitario.ObtenerCadenaConexionSIXSEC","El usuario de bd esta vacio.", false);
                return null;
            }
            if (String.IsNullOrEmpty(strClaveBD))
            {
                LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.SEGURIDAD, strHashcode,
                    "Utilitario.ObtenerCadenaConexionSIXSEC",
                    "El password de bd esta vacio.", false);
                return null;
            }
            StringBuilder sbCadena = new StringBuilder();
            sbCadena.Append("Data Source=");
            sbCadena.Append(strServidor);
            sbCadena.Append(";Initial Catalog=");
            sbCadena.Append(strBaseDatos);
            sbCadena.Append(";User Id=");
            sbCadena.Append(strUsuarioBD);
            sbCadena.Append(";Password=");
            sbCadena.Append(strClaveBD);
            sbCadena.Append(";");
            return sbCadena.ToString();
          }
        //hh72295:20161104:F: ADECUACION PARA RECUPERAR PASSWORD DESDE DB STBSEGDB Y DESENCRIPTAR CON HSM 
    }

    public enum TipoDato
    {
        Cadena = 0,
        Entero = 1,
        Decimal = 2,
        Double = 3,
        FechaLarga = 4,
        Image = 5,
        FechaCorta = 6
    }
        
    public enum EstadoServicioWindows
    {
        NO_INSTALADO = 0,
        INICIADO = 1,
        DETENIDO = 2
    }

    public struct TipoServicio_ID
    {
        public const String CONFIRMACION_ABONO = "CONFABONO";
        public const String CONFIRMACION_BCOSMOS = "CONFBCOSMOS";
        public const String OPE_RECIBIDAS = "OPEREC";
        public const String OPE_RECIBIDAS_CONTING = "OPERECCONTING";
        public const String ENVIO_OPERACION_BCOSMOS = "ENVIOBCOSMOS";
    }

    public enum TipoServicio
    {
        ENVIO_TRANSFERENCIAS = 0,
        SERVICIO_WINDOWS = 1,
        AVISO_AFECTACION = 2,
        CONFIRMACION_ABONO = 3,
        CONSULTAS_BCRP= 4,
        CONFIRMACION_BCOSMOS = 5,
        ANULACION_OPERACION = 6,
        CONSULTA_AUDITORIA = 7,
        REGISTRO_AUDITORIA = 8,
        SEGURIDAD = 9,
        PSAFE = 10,
        TRAZA = 11,
        AVISO_AFECTACION_CONTING = 12,
        ENVIO_OPERACION_BCOSMOS = 13,
        CONTINGENCIA = 14,
        SALIDAS_COMPRAVENTA = 15,
        CONFIRMACION_COMPRAVENTA = 16,
        PAR =17,
        ENVIO_OPERACION_CITISCREENING = 18 //hh72295:20170117:IF: ADECUACION CITISCREENING EN OPERACIONES DE ENTRADA
    }

    public struct TipoOperacion
    {
        public const string AvisoAfectacion = "AVISOAFECT";//Utilizado en Avisos de Afectacion solamente
        public const string Transferencias = "TRANSF";//Para consultas y auditoria
        public const string AvisoAfectacionOpeRec = "OPEREC";//Para consultas y auditoria
        public const string AvisoAfectacionOpeOtor = "OPEOTOR";//Para consultas y auditoria
        public const string ConsultaSaldosCtaCte = "SALCTACTE";//Para consultas y auditoria
        public const string CompraVenta = "COMPRAVENTA";//Para consultas y auditoria
    }

    public struct TipoErrorApiSeguridad
    {
        public const string Particular = "Particular";
        public const string General = "General";
    }

    public struct TipoColorRegistro
    {
        public const string Cavali = "A0001";
        public const string Consumer = "A0002";
        public const string BCosmos = "A0003";
    }

    public struct TipoMoneda
    {
        public const string Soles = "00";
        public const string Dolares = "03";
    }

    public struct TipoDocumento
    {
        public const string LIBELECT = "01";//Libreta Electoral
        public const string DNI = "02";
        public const string LIBMIL = "03";//Libreta Militar
        public const string PASAPORTE = "04";
        public const string CARNEEXTRANJ = "05";//Carne Extranjeria
        public const string RUC = "06";
    }

    public struct TipoError
    {
        public const string ERROR = "ERROR";
        public const string WARNINGBCOSMOS = "WARNINGBC";
        public const string WARNING = "WARNING";
        public const string ERRORNUMDOC = "ERRORNUMDOC";
        public const string ERRORNUMDOCITF = "ERRORNUMDOCITF";
        public const string ERROROPERCTA = "ERROROPERCTA";
    }

    public enum ErroresProcesoMQ
    {
        NO_SE_ENVIO_TRAMAMQ = -1,
        NO_SE_OBTUVO_MSGID_DE_ENVIO = -2,
        NO_SE_OBTUVO_MSGID_DE_RESPUESTA = -3,
        NO_SE_TIENE_ACCESO_BD = -4,
        NO_SE_OBTUVO_CONFIGURACIONMQ = -5,
        NO_SE_OBTUVO_TRAMA_DE_ENVIO = -6,
        LARGO_TRAMA_INCORRECTA = -7
    }

    public enum NivelMensajeLog
    {
        NINGUNO = 0,
        ERROR = 1,
        NOTIFICACION = 2
    }

    /*Inicio cambio (jr72296)*/
    public struct ServicioBCRP
    {
        public const string OperacionesRecibidas = "01";
        public const string CompraVenta = "02";
        //public const string nuevo1 = "03";
        //public const string nuevo2 = "04";
    }
    /*Fin cambio (jr72296)*/

    /*Inicio cambio JR72296 - 20140325*/
    public struct EstadoReinstateTDESA
    {
        public const string POR_ENVIAR_NOREINSTATE= "0";
        public const string POR_ENVIAR_REINSTATE = "1";
        public const string ENVIADO = "2";
    }

    public struct SistemaOrigen
    {
        public const string PAYLINK = "PAYLINK";
        public const string STP_FX = "STP-FX";
        public const string NINGUNO = "";
    }

    public struct FlagAccesoFxSTP
    {
        public const string ACTIVADO = "S";
        public const string DESTIVADO = "N";
    }
    /*Fin cambio JR72296*/
}
