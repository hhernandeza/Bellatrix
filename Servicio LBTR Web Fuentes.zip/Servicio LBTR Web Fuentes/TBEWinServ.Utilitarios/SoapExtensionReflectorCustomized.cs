using System;
using System.Collections.Generic;
using System.Text;
using System.Configuration;
using System.Web.Services.Description;
using System.Xml;

namespace TBEWinServ.Utilitarios
{
    public class SoapExtensionReflectorCustomized : SoapExtensionReflector
    {
        public override void ReflectMethod()
        {
            try
            {
                ServiceDescription sd = ReflectionContext.ServiceDescription;

                foreach (PortType oPortType in sd.PortTypes)
                {
                    if (oPortType.Name.Equals("LBTRAvisoOperacionesPortBinding"))
                    {
                        oPortType.Name = "LBTRAvisoOperaciones";

                        /*foreach (Operation oOperation in oPortType.Operations)
                        {
                            if (oOperation.Name.Equals("recibirAvisoOperacion")) { 
                                //oOperation.Messages[1].Message
                            }
                        }*/
                    }
                }

                foreach (Binding oBinding in sd.Bindings)
                {
                    oBinding.Type = new XmlQualifiedName("LBTRAvisoOperaciones", sd.TargetNamespace);
                }

                foreach (Service service in sd.Services)
                {
                    foreach (Port port in service.Ports)
                    {
                        if (port.Name.Equals("LBTRAvisoOperacionesPortBinding"))
                        {
                            port.Name = "LBTRAvisoOperacionesPort";

                            foreach (ServiceDescriptionFormatExtension extension in port.Extensions)
                            {

                                SoapAddressBinding address = (SoapAddressBinding)extension;
                                if (!String.IsNullOrEmpty(ConfigurationManager.AppSettings["WEBSERVICE_LOCATION"]))
                                    address.Location = ConfigurationManager.AppSettings["WEBSERVICE_LOCATION"].ToString();

                                //address.Location = RemapHttpReferencesToHttps(address.Location);
                            }
                        }
                    }
                }
            }
            catch { }
        }

        /*private string RemapHttpReferencesToHttps( string location )
        {
                return location.Replace("http:", "https:");
        }*/
    }
}


