﻿using System;
using System.Web;
using System.Collections;
using System.Web.Services;
using System.Web.Services.Protocols;
using System.Configuration;
using System.Text;
using System.Threading;
using System.IO;
using System.Xml.Serialization;
using TBEWinServ.EntidadesNegocio.OperacionesRecibidas;
using TBEWinServ.Utilitarios;

[WebService(Namespace = "http://lbtr.bcrp.gob.pe")]
[WebServiceBinding(ConformsTo = WsiProfiles.None)]
public class LBTRAvisoOperacionesService : ILBTRAvisoOperacionesPortBinding
{   
    public LBTRAvisoOperacionesService() { }

    void ILBTRAvisoOperacionesPortBinding.recibirAvisoOperacion(avisoOperacionLBTR avisoOperacion, string firma)
    {
        string strHashcode = HttpContext.Current.Request.GetHashCode().ToString();

        LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.AVISO_AFECTACION, strHashcode,
            "ServicioWeb.recibirAvisoOperacion",
            "Se invoca al metodo recibirAvisoOperacion del web service.", false);

        if (avisoOperacion == null)
        {
            LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.AVISO_AFECTACION, strHashcode,
                "ServicioWeb.recibirAvisoOperacion",
                "El aviso de operacion es NULL.", true);
        }
                
        BE_OperacionRecibida prmOperacionRecibida = ObtenerOperacionRecibida(avisoOperacion, strHashcode);

        if (prmOperacionRecibida != null)
        {
            prmOperacionRecibida.Firma = firma;
            prmOperacionRecibida.Hashcode = strHashcode;
            if (HttpContext.Current.Items.Contains("TRAMA"))
            {
                prmOperacionRecibida.Trama = HttpContext.Current.Items["TRAMA"].ToString();
            }

            ParameterizedThreadStart tstart = new ParameterizedThreadStart(RegistrarOperacionRecibida);
            Thread thr_OpeRec = new Thread(tstart);
            thr_OpeRec.Start(prmOperacionRecibida);
        }

        LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.AVISO_AFECTACION, strHashcode,
            "ServicioWeb.recibirAvisoOperacion",
            "Finaliza la invocacion del metodo recibirAvisoOperacion del web service.", false);
    }

    private void RegistrarOperacionRecibida(object prmOperacionRecibida) 
    {
        BE_OperacionRecibida oOperacionRecibida = (BE_OperacionRecibida)prmOperacionRecibida;

        LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.AVISO_AFECTACION, oOperacionRecibida.Hashcode,
            "ServicioWeb.RegistrarOperacionRecibida",
            "Aviso de Operacion [" + oOperacionRecibida.NumRefLBTR + "] recibido correctamente.", false);

        String strRutaRecepcion = ConfigurationManager.AppSettings["RUTA_RECEPCION_OPERACIONES"];

        if (!String.IsNullOrEmpty(strRutaRecepcion))
        {
            if (Directory.Exists(strRutaRecepcion))
            {
                try
                {
                    XmlSerializer serializer = new XmlSerializer(typeof(BE_OperacionRecibida));
                    StreamWriter w = new StreamWriter(strRutaRecepcion + "\\OPE_" + oOperacionRecibida.NumRefLBTR + ".xml");
                    serializer.Serialize(w, oOperacionRecibida);
                    w.Close();

                    LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.AVISO_AFECTACION, oOperacionRecibida.Hashcode,
                        "ServicioWeb.RegistrarOperacionRecibida",
                        "Aviso de afectacion [" + oOperacionRecibida.NumRefLBTR + "] serializado para su procesamiento desde el servicio windows.", false);
                }
                catch (Exception ex)
                {
                    LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.AVISO_AFECTACION, oOperacionRecibida.Hashcode,
                        "ServicioWeb.RegistrarOperacionRecibida",
                        "No se pudo serializar la operacion " + oOperacionRecibida.NumRefLBTR + " debido a: " + ex.Message, true); 
                }
                                
            }
            else
            {
                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.AVISO_AFECTACION, oOperacionRecibida.Hashcode,
                    "ServicioWeb.RegistrarOperacionRecibida",
                    "El directorio de recepcion de avisos de afectacion no existe: " + strRutaRecepcion, true);
            }
        }
        else
        {
            LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.AVISO_AFECTACION, oOperacionRecibida.Hashcode,
                "ServicioWeb.RegistrarOperacionRecibida",
                "El directorio de recepcion de avisos de afectacion no esta establecido", true);
        }
    }
                
    private BE_OperacionRecibida ObtenerOperacionRecibida(avisoOperacionLBTR prmAvisoOperacionLBTR, string prmHashcode)
    {
        BE_OperacionRecibida oOpeRecib = new BE_OperacionRecibida();

        try
        {
            oOpeRecib.CodBancoDestino = prmAvisoOperacionLBTR.codBancoDestino;
            oOpeRecib.CodBancoOrigen = prmAvisoOperacionLBTR.codBancoOrigen;
            oOpeRecib.CodConcepto = prmAvisoOperacionLBTR.codConcepto;
            oOpeRecib.CodMoneda = prmAvisoOperacionLBTR.codMoneda;
            oOpeRecib.CodServicio = prmAvisoOperacionLBTR.codServicio;
            oOpeRecib.CodigoSAB = prmAvisoOperacionLBTR.codigoSAB;            
            oOpeRecib.CuentaDestino = prmAvisoOperacionLBTR.cuentaDestino;
            oOpeRecib.CuentaInterbancariaSAB = prmAvisoOperacionLBTR.cuentaInterbancariaSAB;
            oOpeRecib.CuentaOrigen = prmAvisoOperacionLBTR.cuentaOrigen;
            oOpeRecib.StrDatosCliente = prmAvisoOperacionLBTR.datosCliente;
            oOpeRecib.EstadoLiquidacion = prmAvisoOperacionLBTR.estado;
            if (prmAvisoOperacionLBTR.fechaLiquidacionSpecified) oOpeRecib.FechaLiquidacion = prmAvisoOperacionLBTR.fechaLiquidacion.ToString("yyyyMMddHHmmss");
            if (prmAvisoOperacionLBTR.fechaNegociacionCavaliSpecified) oOpeRecib.FechaNegociacionCavali = prmAvisoOperacionLBTR.fechaNegociacionCavali.ToString("yyyyMMddHHmmss");
            if (prmAvisoOperacionLBTR.horaLiquidacionSpecified) oOpeRecib.HoraLiquidacion = prmAvisoOperacionLBTR.horaLiquidacion.ToString("yyyyMMddHHmmss");
            oOpeRecib.InstruccionesPago = prmAvisoOperacionLBTR.instruccionesPago;
            oOpeRecib.Modalidad = prmAvisoOperacionLBTR.modalidad;
            if (prmAvisoOperacionLBTR.montoDestinoSpecified) oOpeRecib.MontoOperacionDestino = Utilitario.EliminarCerosNoSignificativos(prmAvisoOperacionLBTR.montoDestino);
            if (prmAvisoOperacionLBTR.montoOrigenSpecified) oOpeRecib.MontoOperacionOrigen = Utilitario.EliminarCerosNoSignificativos(prmAvisoOperacionLBTR.montoOrigen);
            oOpeRecib.NumRefCavali = prmAvisoOperacionLBTR.numRefCavali;
            oOpeRecib.NumRefLBTR = prmAvisoOperacionLBTR.numRefLBTR;
            oOpeRecib.NumRefLBTREnlace = prmAvisoOperacionLBTR.numRefLBTREnlace;
            oOpeRecib.NumRefOrigen = prmAvisoOperacionLBTR.numRefOrigen;
            if (prmAvisoOperacionLBTR.tipoCambioSpecified) oOpeRecib.TipoCambio = Utilitario.EliminarCerosNoSignificativos(prmAvisoOperacionLBTR.tipoCambio);
            oOpeRecib.TipoParticipanteCavali = prmAvisoOperacionLBTR.tipoParticipanteCavali;
            oOpeRecib.TipoRegistro = prmAvisoOperacionLBTR.tipoRegistro;
        }
        catch (Exception ex)
        {
            oOpeRecib = null;
            LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.AVISO_AFECTACION, prmHashcode,
                "ServicioWeb.ObtenerOperacionRecibida",
                "Error los datos de la operacion recibida, mensaje: " + ex.Message + "; StackTrace: " + ex.StackTrace, true);
        }

        return oOpeRecib;
    }
        
}

