using System;
using System.Collections.Generic;
using System.Text;
using TBEWinServ.Utilitarios;

namespace TBEWinServ.AccesoDatos
{
    public class DA_Base
    {
        protected string strCadenaConexion = Globales.CADENA_CONEXION;
        
        public Exception Excepcion = null;

        protected string strHashcode;
        
        public DA_Base(){}

        protected void ManejarExcepcion(Exception ex)
        {
            Excepcion = ex;

            LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS, strHashcode, 
                "DA_Base",
                "Error en ejecucion de objeto de bd: " + ex.Message + "; StackTrace: " + ex.StackTrace, true);
        }

    }
}
