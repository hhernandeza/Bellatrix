using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using Sybase.Data.AseClient;
using System.Data.SqlClient;
using TBEWinServ.Utilitarios;

namespace TBEWinServ.AccesoDatos
{
    public class DA_PruebaConectividad
    {      

        public static bool ProbarConexionSybase(string prmCadenaConexion)
        {
            bool exito = false;
            AseConnection cnx = null;

            try
            {
                cnx = new AseConnection(prmCadenaConexion);
                cnx.Open();
                exito = true;
            }
            catch(Exception ex)
            {
                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.AVISO_AFECTACION, Globales.HASHCODE_thrInicioFinDia, 
                    "DA_PruebaConectividad",
                    "Error: " + ex.Message + "; StackTrace: " + ex.StackTrace, true);
            }
            finally
            {
                if (cnx != null && cnx.State != ConnectionState.Closed) cnx.Close();
            }

            return exito;
        }

        public static bool ProbarConexionMSSQL(string prmCadenaConexion)
        {
            bool exito = false;
            SqlConnection cnx = null;

            try
            {
                cnx = new SqlConnection(prmCadenaConexion);
                cnx.Open();
                exito = true;
            }
            catch (Exception ex)
            {
                LogWriter.EscribirLog(TipoLog.Resumido, TipoServicio.SERVICIO_WINDOWS, Globales.HASHCODE_thrInicioFinDia,
                    "DA_PruebaConectividad",
                    "Error: " + ex.Message + "; StackTrace: " + ex.StackTrace, true);
            }
            finally
            {
                if (cnx != null && cnx.State != ConnectionState.Closed) cnx.Close();
            }

            return exito;
        }

    }
}
