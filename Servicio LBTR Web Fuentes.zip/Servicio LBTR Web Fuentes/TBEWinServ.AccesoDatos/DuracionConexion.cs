using System;
using System.Collections.Generic;
using System.Text;

namespace TBEWinServ.AccesoDatos
{
    [Serializable]
    public enum DuracionConexion
    {        
        Corta = 120,
        Mediana = 300,
        Larga = 600
    }
}
