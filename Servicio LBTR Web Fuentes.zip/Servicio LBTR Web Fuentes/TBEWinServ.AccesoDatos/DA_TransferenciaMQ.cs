﻿using System;
using System.Collections.Generic;
using System.Text;
using Sybase.Data.AseClient;
using System.Data;
using TBEWinServ.Utilitarios;
using TBEWinServ.EntidadesNegocio.EnvioBCosmos;

namespace TBEWinServ.AccesoDatos
{
    public class DA_TransferenciaMQ : DA_Base
    {
        public DA_TransferenciaMQ(string prmHashcode) 
        {
            strHashcode = prmHashcode;
        }

        public Int64 Insertar_TransferenciaMQ(BE_TransferenciaMQ prmTransferenciaMQ)
        {
            AseConnection cnx = null;
            Int64 nSecuen = -1;

            try
            {
                cnx = new AseConnection(strCadenaConexion);
                AseCommand cmd = new AseCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "p_tbe_insertar_transferencia_mq";
                cmd.Connection = cnx;
                cmd.CommandTimeout = Convert.ToInt32(DuracionConexion.Corta);

                cmd.Parameters.Add("@BCRP_REFER", AseDbType.Char, 15).Direction = ParameterDirection.Input;
                cmd.Parameters["@BCRP_REFER"].Value = Utilitario.SetearComoParametro(prmTransferenciaMQ.BcrpRefer, TipoDato.Cadena);

                cmd.Parameters.Add("@n_token_id", AseDbType.Numeric, 10).Direction = ParameterDirection.Input;
                cmd.Parameters["@n_token_id"].Value = Utilitario.SetearComoParametro(prmTransferenciaMQ.TokenId);

                cmd.Parameters.Add("@dt_fecha_origen", AseDbType.DateTime).Direction = ParameterDirection.Input;
                cmd.Parameters["@dt_fecha_origen"].Value = Utilitario.SetearComoParametro(prmTransferenciaMQ.FechaOrigen);

                cmd.Parameters.Add("@s_trama_input", AseDbType.VarChar, 8000).Direction = ParameterDirection.Input;
                cmd.Parameters["@s_trama_input"].Value = Utilitario.SetearComoParametro(prmTransferenciaMQ.TramaInput, TipoDato.Cadena);

                cmd.Parameters.Add("@s_sist_origen", AseDbType.Char, 1).Direction = ParameterDirection.Input;
                cmd.Parameters["@s_sist_origen"].Value = Utilitario.SetearComoParametro(prmTransferenciaMQ.SistemaOrigen, TipoDato.Cadena);

                cnx.Open();

                nSecuen = Convert.ToInt64(cmd.ExecuteScalar());
            }
            catch (Exception ex)
            {
                nSecuen = -1;
                ManejarExcepcion(ex);
            }
            finally
            {
                if (cnx != null && cnx.State != ConnectionState.Closed) cnx.Close();
            }

            return nSecuen;
        }

        public bool Actualizar_TransferenciaMQ(BE_TransferenciaMQ prmTransferenciaMQ)
        {
            AseConnection cnx = null;
            bool blnEjecucion = false;

            try
            {
                cnx = new AseConnection(strCadenaConexion);
                AseCommand cmd = new AseCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "p_tbe_actualizar_transferencia_mq";
                cmd.Connection = cnx;
                cmd.CommandTimeout = Convert.ToInt32(DuracionConexion.Corta);

                cmd.Parameters.Add("@n_secuen", AseDbType.Numeric, 10).Direction = ParameterDirection.Input;
                cmd.Parameters["@n_secuen"].Value = Utilitario.SetearComoParametro(prmTransferenciaMQ.Secuencia);

                cmd.Parameters.Add("@n_token_id", AseDbType.Numeric, 10).Direction = ParameterDirection.Input;
                cmd.Parameters["@n_token_id"].Value = Utilitario.SetearComoParametro(prmTransferenciaMQ.TokenId);

                cmd.Parameters.Add("@s_resp_bcosmos", AseDbType.Char, 3).Direction = ParameterDirection.Input;
                cmd.Parameters["@s_resp_bcosmos"].Value = Utilitario.SetearComoParametro(prmTransferenciaMQ.RespBCosmos, TipoDato.Cadena);

                cmd.Parameters.Add("@dt_fecha_destino", AseDbType.DateTime).Direction = ParameterDirection.Input;
                cmd.Parameters["@dt_fecha_destino"].Value = Utilitario.SetearComoParametro(prmTransferenciaMQ.FechaDestino);

                cmd.Parameters.Add("@s_trama_output", AseDbType.VarChar, 8000).Direction = ParameterDirection.Input;
                cmd.Parameters["@s_trama_output"].Value = Utilitario.SetearComoParametro(prmTransferenciaMQ.TramaOuput, TipoDato.Cadena);

                cmd.Parameters.Add("@msgid", AseDbType.VarChar, 24).Direction = ParameterDirection.Input;
                cmd.Parameters["@msgid"].Value = Utilitario.SetearComoParametro(prmTransferenciaMQ.MessageId, TipoDato.Cadena);

                cnx.Open();

                cmd.ExecuteNonQuery();

                blnEjecucion = true;
            }
            catch (Exception ex)
            {
                blnEjecucion = false;
                ManejarExcepcion(ex);
            }
            finally
            {
                if (cnx != null && cnx.State != ConnectionState.Closed) cnx.Close();
            }

            return blnEjecucion;
        }
    }
}
