using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using Sybase.Data.AseClient;
using System.Configuration;
using System.Threading;
using TBEWinServ.EntidadesNegocio.ConsultasBCRP;
using TBEWinServ.EntidadesNegocio.Transferencia;
using TBEWinServ.Utilitarios;

namespace TBEWinServ.AccesoDatos
{
    public class DA_ConsultasBCRP : DA_Base
    {        
        public DA_ConsultasBCRP(string prmHashcode) {
            strHashcode = prmHashcode;
        }
        
        public bool Insertar_ConsultaOperacion(BE_OperacionRecibidaConsulta prmOperacion)
        {
            AseConnection cnx = null;
            bool blnEjecucion = false;

            try
            {
                cnx = new AseConnection(strCadenaConexion);
                AseCommand cmd = new AseCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "p_tbe_insertar_cons_ope_rec";
                cmd.Connection = cnx;
                cmd.CommandTimeout = Convert.ToInt32(DuracionConexion.Corta);

                //Con 32 parametros cae intermitentemente, con 31 se mantiene normal. Por ello, se deshabilito un parametro innecesario.
                cmd.Parameters.Add("@IDCONSULTA", AseDbType.VarChar, 30).Direction = ParameterDirection.Input;
                cmd.Parameters["@IDCONSULTA"].Value = Utilitario.SetearComoParametro(prmOperacion.IdConsulta, TipoDato.Cadena);

                cmd.Parameters.Add("@FECCONSULTA", AseDbType.Char, 8).Direction = ParameterDirection.Input;
                cmd.Parameters["@FECCONSULTA"].Value = Utilitario.SetearComoParametro(prmOperacion.FecConsulta, TipoDato.Cadena);

                cmd.Parameters.Add("@TIPO_CONSULTA", AseDbType.VarChar, 10).Direction = ParameterDirection.Input;
                cmd.Parameters["@TIPO_CONSULTA"].Value = Utilitario.SetearComoParametro(prmOperacion.TipoConsulta, TipoDato.Cadena);

                cmd.Parameters.Add("@CODBANCOORIGEN", AseDbType.Char, 4).Direction = ParameterDirection.Input;
                cmd.Parameters["@CODBANCOORIGEN"].Value = Utilitario.SetearComoParametro(prmOperacion.CodBancoOrigen, TipoDato.Cadena);

                cmd.Parameters.Add("@CODBANCODESTINO", AseDbType.Char, 4).Direction = ParameterDirection.Input;
                cmd.Parameters["@CODBANCODESTINO"].Value = Utilitario.SetearComoParametro(prmOperacion.CodBancoDestino, TipoDato.Cadena);

                cmd.Parameters.Add("@CODCONCEPTO", AseDbType.Char, 4).Direction = ParameterDirection.Input;
                cmd.Parameters["@CODCONCEPTO"].Value = Utilitario.SetearComoParametro(prmOperacion.CodConcepto, TipoDato.Cadena);

                cmd.Parameters.Add("@CODMONEDABCR", AseDbType.Char, 2).Direction = ParameterDirection.Input;
                cmd.Parameters["@CODMONEDABCR"].Value = Utilitario.SetearComoParametro(prmOperacion.CodMoneda, TipoDato.Cadena);

                cmd.Parameters.Add("@CUENTAORIGEN", AseDbType.VarChar, 20).Direction = ParameterDirection.Input;
                cmd.Parameters["@CUENTAORIGEN"].Value = Utilitario.SetearComoParametro(prmOperacion.CuentaOrigen, TipoDato.Cadena);

                cmd.Parameters.Add("@CUENTADESTINO", AseDbType.VarChar, 20).Direction = ParameterDirection.Input;
                cmd.Parameters["@CUENTADESTINO"].Value = Utilitario.SetearComoParametro(prmOperacion.CuentaDestino, TipoDato.Cadena);

                cmd.Parameters.Add("@MONTOOPERACION", AseDbType.VarChar, 25).Direction = ParameterDirection.Input;
                cmd.Parameters["@MONTOOPERACION"].Value = Utilitario.SetearComoParametro(prmOperacion.MontoOperacion, TipoDato.Cadena);

                cmd.Parameters.Add("@TIPOCAMBIO", AseDbType.VarChar, 15).Direction = ParameterDirection.Input;
                cmd.Parameters["@TIPOCAMBIO"].Value = Utilitario.SetearComoParametro(prmOperacion.TipoCambio, TipoDato.Cadena);
                
                cmd.Parameters.Add("@NUMREFORIGEN", AseDbType.VarChar, 30).Direction = ParameterDirection.Input;
                cmd.Parameters["@NUMREFORIGEN"].Value = Utilitario.SetearComoParametro(prmOperacion.NumRefOrigen, TipoDato.Cadena);

                cmd.Parameters.Add("@NUMREFENLACEOPERACION", AseDbType.VarChar, 15).Direction = ParameterDirection.Input;
                cmd.Parameters["@NUMREFENLACEOPERACION"].Value = Utilitario.SetearComoParametro(prmOperacion.NumRefEnlace, TipoDato.Cadena);

                cmd.Parameters.Add("@FECHALIQUIDACION", AseDbType.Char, 8).Direction = ParameterDirection.Input;
                cmd.Parameters["@FECHALIQUIDACION"].Value = Utilitario.SetearComoParametro(prmOperacion.FechaLiquidacion, TipoDato.Cadena);

                cmd.Parameters.Add("@HORALIQUIDACION", AseDbType.Char, 6).Direction = ParameterDirection.Input;
                if (!String.IsNullOrEmpty(prmOperacion.HoraLiquidacion))
                    cmd.Parameters["@HORALIQUIDACION"].Value = Utilitario.SetearComoParametro(prmOperacion.HoraLiquidacion.Replace(":",""), TipoDato.Cadena);
                else
                    cmd.Parameters["@HORALIQUIDACION"].Value = DBNull.Value;
                                
                cmd.Parameters.Add("@NUMREFLBTR", AseDbType.Char, 15).Direction = ParameterDirection.Input;
                cmd.Parameters["@NUMREFLBTR"].Value = Utilitario.SetearComoParametro(prmOperacion.NumRefLBTR, TipoDato.Cadena);

                cmd.Parameters.Add("@CONFIRMAABONO", AseDbType.Char, 1).Direction = ParameterDirection.Input;
                cmd.Parameters["@CONFIRMAABONO"].Value = Utilitario.SetearComoParametro(prmOperacion.ConfirmaAbono, TipoDato.Cadena);

                cmd.Parameters.Add("@ESTADOLIQUIDACION", AseDbType.Char, 1).Direction = ParameterDirection.Input;
                cmd.Parameters["@ESTADOLIQUIDACION"].Value = Utilitario.SetearComoParametro(prmOperacion.Estado, TipoDato.Cadena);

                cmd.Parameters.Add("@INSTRUCCIONESPAGO", AseDbType.VarChar, 250).Direction = ParameterDirection.Input;
                cmd.Parameters["@INSTRUCCIONESPAGO"].Value = Utilitario.SetearComoParametro(prmOperacion.InstruccionesPago, TipoDato.Cadena);

                cmd.Parameters.Add("@CCIORDENANTE", AseDbType.VarChar, 20).Direction = ParameterDirection.Input;
                cmd.Parameters["@CCIORDENANTE"].Value = Utilitario.SetearComoParametro(prmOperacion.DatosCliente.CCIOrdenante, TipoDato.Cadena);

                cmd.Parameters.Add("@NOMBREORDENANTE", AseDbType.VarChar, 80).Direction = ParameterDirection.Input;
                cmd.Parameters["@NOMBREORDENANTE"].Value = Utilitario.SetearComoParametro(prmOperacion.DatosCliente.NombreOrdenante, TipoDato.Cadena);

                cmd.Parameters.Add("@DIRECCIONORDENANTE", AseDbType.VarChar, 250).Direction = ParameterDirection.Input;
                cmd.Parameters["@DIRECCIONORDENANTE"].Value = Utilitario.SetearComoParametro(prmOperacion.DatosCliente.DireccionOrdenante, TipoDato.Cadena);

                cmd.Parameters.Add("@TIPODOCORDENANTE", AseDbType.Char, 2).Direction = ParameterDirection.Input;
                cmd.Parameters["@TIPODOCORDENANTE"].Value = Utilitario.SetearComoParametro(prmOperacion.DatosCliente.TipoDocOrdenante, TipoDato.Cadena);

                cmd.Parameters.Add("@NUMDOCORDENANTE", AseDbType.VarChar, 12).Direction = ParameterDirection.Input;
                cmd.Parameters["@NUMDOCORDENANTE"].Value = Utilitario.SetearComoParametro(prmOperacion.DatosCliente.NumDocOrdenante, TipoDato.Cadena);

                cmd.Parameters.Add("@CCIBENEFICIARIO", AseDbType.VarChar, 20).Direction = ParameterDirection.Input;
                cmd.Parameters["@CCIBENEFICIARIO"].Value = Utilitario.SetearComoParametro(prmOperacion.DatosCliente.CCIBeneficiario, TipoDato.Cadena);

                cmd.Parameters.Add("@NOMBREBENEFICIARIO", AseDbType.VarChar, 80).Direction = ParameterDirection.Input;
                cmd.Parameters["@NOMBREBENEFICIARIO"].Value = Utilitario.SetearComoParametro(prmOperacion.DatosCliente.NombreBeneficiario, TipoDato.Cadena);

                cmd.Parameters.Add("@DIRECCIONBENEFICIARIO", AseDbType.VarChar, 250).Direction = ParameterDirection.Input;
                cmd.Parameters["@DIRECCIONBENEFICIARIO"].Value = Utilitario.SetearComoParametro(prmOperacion.DatosCliente.DireccionBeneficiario, TipoDato.Cadena);

                cmd.Parameters.Add("@TIPODOCBENEFICIARIO", AseDbType.Char, 2).Direction = ParameterDirection.Input;
                cmd.Parameters["@TIPODOCBENEFICIARIO"].Value = Utilitario.SetearComoParametro(prmOperacion.DatosCliente.TipoDocBeneficiario, TipoDato.Cadena);

                cmd.Parameters.Add("@NUMDOCBENEFICIARIO", AseDbType.VarChar, 12).Direction = ParameterDirection.Input;
                cmd.Parameters["@NUMDOCBENEFICIARIO"].Value = Utilitario.SetearComoParametro(prmOperacion.DatosCliente.NumDocBeneficiario, TipoDato.Cadena);

                cmd.Parameters.Add("@INDICADORITF", AseDbType.Char, 1).Direction = ParameterDirection.Input;
                cmd.Parameters["@INDICADORITF"].Value = Utilitario.SetearComoParametro(prmOperacion.DatosCliente.IndicadorITF, TipoDato.Cadena);

                cmd.Parameters.Add("@OBSERVACIONES", AseDbType.VarChar, 250).Direction = ParameterDirection.Input;
                cmd.Parameters["@OBSERVACIONES"].Value = Utilitario.SetearComoParametro(prmOperacion.DatosCliente.Observaciones, TipoDato.Cadena);
                
                cmd.Parameters.Add("@MONTOOPERACIONDESTINO", AseDbType.VarChar, 25).Direction = ParameterDirection.Input;
                cmd.Parameters["@MONTOOPERACIONDESTINO"].Value = Utilitario.SetearComoParametro(prmOperacion.MontoOperacionDestino, TipoDato.Cadena);
                
                cmd.Parameters.Add("@COD_TRAMA_AUDITORIA", AseDbType.VarChar, 20).Direction = ParameterDirection.Input;
                cmd.Parameters["@COD_TRAMA_AUDITORIA"].Value = Utilitario.SetearComoParametro(prmOperacion.CodTramaAuditoria, TipoDato.Cadena);

                cmd.Parameters.Add("@MODALIDAD", AseDbType.Char, 1).Direction = ParameterDirection.Input;
                cmd.Parameters["@MODALIDAD"].Value = Utilitario.SetearComoParametro(prmOperacion.Modalidad, TipoDato.Cadena);
                                                
                cmd.Parameters.Add("@TIPOREGISTRO", AseDbType.Char, 1).Direction = ParameterDirection.Input;
                cmd.Parameters["@TIPOREGISTRO"].Value = Utilitario.SetearComoParametro(prmOperacion.TipoRegistro, TipoDato.Cadena);
                
                /*
                cmd.Parameters.Add("@PRIORIDAD", AseDbType.Integer).Direction = ParameterDirection.Input;
                cmd.Parameters["@PRIORIDAD"].Value = Utilitario.SetearComoParametro(prmOperacion.Prioridad, TipoDato.Entero);
                */ 

                //(new DA_General(strHashcode)).MostrarParametros(cmd);
                
                cnx.Open();

                cmd.ExecuteNonQuery();
                blnEjecucion = true;
            }
            catch (Exception ex)
            {
                blnEjecucion = false;
                ManejarExcepcion(ex);
            }
            finally
            {
                if (cnx != null && cnx.State != ConnectionState.Closed) cnx.Close();
            }

            return blnEjecucion;
        }

        public bool Insertar_SaldoCtaCte(BE_SaldoCtaCte prmSaldoCtaCte) 
        {
            AseConnection cnx = null;
            bool blnEjecucion = false;

            try
            {
                cnx = new AseConnection(strCadenaConexion);
                AseCommand cmd = new AseCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "p_tbe_insertar_cons_saldctacte";
                cmd.Connection = cnx;
                cmd.CommandTimeout = Convert.ToInt32(DuracionConexion.Corta);

                cmd.Parameters.Add("@IDCONSULTA", AseDbType.VarChar, 30).Direction = ParameterDirection.Input;
                cmd.Parameters["@IDCONSULTA"].Value = Utilitario.SetearComoParametro(prmSaldoCtaCte.IdConsulta, TipoDato.Cadena);

                cmd.Parameters.Add("@FECCONSULTA", AseDbType.Char, 8).Direction = ParameterDirection.Input;
                cmd.Parameters["@FECCONSULTA"].Value = Utilitario.SetearComoParametro(prmSaldoCtaCte.FecConsulta, TipoDato.Cadena);

                cmd.Parameters.Add("@FECHASALDO", AseDbType.Char, 8).Direction = ParameterDirection.Input;
                cmd.Parameters["@FECHASALDO"].Value = Utilitario.SetearComoParametro(prmSaldoCtaCte.FechaSaldo, TipoDato.Cadena);

                cmd.Parameters.Add("@CODENTIDAD", AseDbType.VarChar, 4).Direction = ParameterDirection.Input;
                cmd.Parameters["@CODENTIDAD"].Value = Utilitario.SetearComoParametro(prmSaldoCtaCte.CodEntidad, TipoDato.Cadena);

                cmd.Parameters.Add("@NUMCUENTA", AseDbType.VarChar, 20).Direction = ParameterDirection.Input;
                cmd.Parameters["@NUMCUENTA"].Value = Utilitario.SetearComoParametro(prmSaldoCtaCte.NumCuenta, TipoDato.Cadena);
                                
                cmd.Parameters.Add("@SALDOINICIAL", AseDbType.VarChar, 25).Direction = ParameterDirection.Input;
                cmd.Parameters["@SALDOINICIAL"].Value = Utilitario.SetearComoParametro(prmSaldoCtaCte.SaldoInicial, TipoDato.Cadena);

                cmd.Parameters.Add("@SALDOACTUAL", AseDbType.VarChar, 25).Direction = ParameterDirection.Input;
                cmd.Parameters["@SALDOACTUAL"].Value = Utilitario.SetearComoParametro(prmSaldoCtaCte.SaldoActual, TipoDato.Cadena);

                cmd.Parameters.Add("@TOTALCARGOS", AseDbType.VarChar, 25).Direction = ParameterDirection.Input;
                cmd.Parameters["@TOTALCARGOS"].Value = Utilitario.SetearComoParametro(prmSaldoCtaCte.TotalCargos, TipoDato.Cadena);

                cmd.Parameters.Add("@TOTALABONOS", AseDbType.VarChar, 25).Direction = ParameterDirection.Input;
                cmd.Parameters["@TOTALABONOS"].Value = Utilitario.SetearComoParametro(prmSaldoCtaCte.TotalAbonos, TipoDato.Cadena);

                //DA_General.MostrarParametros(cmd);
                
                cnx.Open();

                cmd.ExecuteNonQuery();
                blnEjecucion = true;
            }
            catch (Exception ex)
            {
                blnEjecucion = false;
                ManejarExcepcion(ex);
            }
            finally
            {
                if (cnx != null && cnx.State != ConnectionState.Closed) cnx.Close();
            }

            return blnEjecucion;        
        }

        public bool Insertar_ConsultaTransferencia(BE_Transferencia prmTransferencia)
        {
            AseConnection cnx = null;
            bool blnEjecucion = false;

            try
            {
                cnx = new AseConnection(strCadenaConexion);
                AseCommand cmd = new AseCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "p_tbe_insertar_cons_transf";
                cmd.Connection = cnx;
                cmd.CommandTimeout = Convert.ToInt32(DuracionConexion.Corta);

                cmd.Parameters.Add("@IDCONSULTA", AseDbType.VarChar, 30).Direction = ParameterDirection.Input;
                cmd.Parameters["@IDCONSULTA"].Value = Utilitario.SetearComoParametro(prmTransferencia.IdConsulta, TipoDato.Cadena);

                cmd.Parameters.Add("@FECCONSULTA", AseDbType.Char, 8).Direction = ParameterDirection.Input;
                cmd.Parameters["@FECCONSULTA"].Value = Utilitario.SetearComoParametro(prmTransferencia.FecConsulta, TipoDato.Cadena);

                cmd.Parameters.Add("@COD_TRAMA_AUDITORIA", AseDbType.VarChar, 20).Direction = ParameterDirection.Input;
                cmd.Parameters["@COD_TRAMA_AUDITORIA"].Value = Utilitario.SetearComoParametro(prmTransferencia.CodTramaAuditoria, TipoDato.Cadena);

                cmd.Parameters.Add("@COD_CONCEPTO", AseDbType.Char, 4).Direction = ParameterDirection.Input;
                cmd.Parameters["@COD_CONCEPTO"].Value = Utilitario.SetearComoParametro(prmTransferencia.CodConcepto, TipoDato.Cadena);

                cmd.Parameters.Add("@CUENTA_DESTINO", AseDbType.VarChar, 20).Direction = ParameterDirection.Input;
                cmd.Parameters["@CUENTA_DESTINO"].Value = Utilitario.SetearComoParametro(prmTransferencia.CuentaDestino, TipoDato.Cadena);

                cmd.Parameters.Add("@CUENTA_ORIGEN", AseDbType.VarChar, 20).Direction = ParameterDirection.Input;
                cmd.Parameters["@CUENTA_ORIGEN"].Value = Utilitario.SetearComoParametro(prmTransferencia.CuentaOrigen, TipoDato.Cadena);

                cmd.Parameters.Add("@FEC_LIQUIDACION", AseDbType.Char, 8).Direction = ParameterDirection.Input;
                if (prmTransferencia.FechaLiquidacion.HasValue)
                    cmd.Parameters["@FEC_LIQUIDACION"].Value = Utilitario.SetearComoParametro(prmTransferencia.FechaLiquidacion.Value.ToString("yyyyMMdd"), TipoDato.Cadena);
                else
                    cmd.Parameters["@FEC_LIQUIDACION"].Value = DBNull.Value;

                cmd.Parameters.Add("@FEC_REFLBTRENLACE", AseDbType.Char, 8).Direction = ParameterDirection.Input;
                if (prmTransferencia.FecRefLBTREnlace.HasValue)
                    cmd.Parameters["@FEC_REFLBTRENLACE"].Value = Utilitario.SetearComoParametro(prmTransferencia.FecRefLBTREnlace.Value.ToString("yyyyMMdd"), TipoDato.Cadena);
                else
                    cmd.Parameters["@FEC_REFLBTRENLACE"].Value = DBNull.Value;

                cmd.Parameters.Add("@INSTRUCCIONES_PAGO", AseDbType.VarChar, 250).Direction = ParameterDirection.Input;
                cmd.Parameters["@INSTRUCCIONES_PAGO"].Value = Utilitario.SetearComoParametro(prmTransferencia.InstruccionesPago, TipoDato.Cadena);

                cmd.Parameters.Add("@MODALIDAD", AseDbType.Char, 1).Direction = ParameterDirection.Input;
                cmd.Parameters["@MODALIDAD"].Value = Utilitario.SetearComoParametro(prmTransferencia.Modalidad, TipoDato.Cadena);
                
                cmd.Parameters.Add("@MONTOOPERACION", AseDbType.VarChar, 25).Direction = ParameterDirection.Input;
                if (prmTransferencia.Monto.HasValue)
                    cmd.Parameters["@MONTOOPERACION"].Value = prmTransferencia.Monto.Value.ToString();
                else
                    cmd.Parameters["@MONTOOPERACION"].Value = DBNull.Value;

                cmd.Parameters.Add("@NUMREFORIGEN", AseDbType.VarChar, 30).Direction = ParameterDirection.Input;
                cmd.Parameters["@NUMREFORIGEN"].Value = Utilitario.SetearComoParametro(prmTransferencia.NumRefOrigen, TipoDato.Cadena);

                cmd.Parameters.Add("@NUMREFLBTRENLACE", AseDbType.VarChar, 15).Direction = ParameterDirection.Input;
                cmd.Parameters["@NUMREFLBTRENLACE"].Value = Utilitario.SetearComoParametro(prmTransferencia.NumRefLBTREnlace, TipoDato.Cadena);
                
                /*cmd.Parameters.Add("@PRIORIDAD", AseDbType.Integer).Direction = ParameterDirection.Input;
                if (prmTransferencia.Prioridad.HasValue)
                    cmd.Parameters["@PRIORIDAD"].Value = prmTransferencia.Prioridad.Value;
                else
                    cmd.Parameters["@PRIORIDAD"].Value = DBNull.Value;*/
                
                cmd.Parameters.Add("@CCI_ORD", AseDbType.VarChar, 20).Direction = ParameterDirection.Input;
                cmd.Parameters["@CCI_ORD"].Value = Utilitario.SetearComoParametro(prmTransferencia.DatosCliente.CCIOrdenante, TipoDato.Cadena);

                cmd.Parameters.Add("@NOMBRE_ORD", AseDbType.VarChar, 80).Direction = ParameterDirection.Input;
                cmd.Parameters["@NOMBRE_ORD"].Value = Utilitario.SetearComoParametro(prmTransferencia.DatosCliente.NombreOrdenante, TipoDato.Cadena);

                cmd.Parameters.Add("@DIRECCION_ORD", AseDbType.VarChar, 250).Direction = ParameterDirection.Input;
                cmd.Parameters["@DIRECCION_ORD"].Value = Utilitario.SetearComoParametro(prmTransferencia.DatosCliente.DireccionOrdenante, TipoDato.Cadena);

                cmd.Parameters.Add("@TIPO_DOC_ORD", AseDbType.Char, 2).Direction = ParameterDirection.Input;
                cmd.Parameters["@TIPO_DOC_ORD"].Value = Utilitario.SetearComoParametro(prmTransferencia.DatosCliente.TipoDocOrdenante, TipoDato.Cadena);

                cmd.Parameters.Add("@NUM_DOC_ORD", AseDbType.VarChar, 12).Direction = ParameterDirection.Input;
                cmd.Parameters["@NUM_DOC_ORD"].Value = Utilitario.SetearComoParametro(prmTransferencia.DatosCliente.NumDocOrdenante, TipoDato.Cadena);

                cmd.Parameters.Add("@CCI_BEN", AseDbType.VarChar, 20).Direction = ParameterDirection.Input;
                cmd.Parameters["@CCI_BEN"].Value = Utilitario.SetearComoParametro(prmTransferencia.DatosCliente.CCIBeneficiario, TipoDato.Cadena);

                cmd.Parameters.Add("@NOMBRE_BEN", AseDbType.VarChar, 80).Direction = ParameterDirection.Input;
                cmd.Parameters["@NOMBRE_BEN"].Value = Utilitario.SetearComoParametro(prmTransferencia.DatosCliente.NombreBeneficiario, TipoDato.Cadena);

                cmd.Parameters.Add("@DIRECCION_BEN", AseDbType.VarChar, 250).Direction = ParameterDirection.Input;
                cmd.Parameters["@DIRECCION_BEN"].Value = Utilitario.SetearComoParametro(prmTransferencia.DatosCliente.DireccionBeneficiario, TipoDato.Cadena);

                cmd.Parameters.Add("@TIPO_DOC_BEN", AseDbType.Char, 2).Direction = ParameterDirection.Input;
                cmd.Parameters["@TIPO_DOC_BEN"].Value = Utilitario.SetearComoParametro(prmTransferencia.DatosCliente.TipoDocBeneficiario, TipoDato.Cadena);

                cmd.Parameters.Add("@NUM_DOC_BEN", AseDbType.VarChar, 12).Direction = ParameterDirection.Input;
                cmd.Parameters["@NUM_DOC_BEN"].Value = Utilitario.SetearComoParametro(prmTransferencia.DatosCliente.NumDocBeneficiario, TipoDato.Cadena);

                cmd.Parameters.Add("@INDICADOR_ITF", AseDbType.Char, 1).Direction = ParameterDirection.Input;
                cmd.Parameters["@INDICADOR_ITF"].Value = Utilitario.SetearComoParametro(prmTransferencia.DatosCliente.IndicadorITF, TipoDato.Cadena);

                cmd.Parameters.Add("@OBSERVACIONES", AseDbType.VarChar, 250).Direction = ParameterDirection.Input;
                cmd.Parameters["@OBSERVACIONES"].Value = Utilitario.SetearComoParametro(prmTransferencia.DatosCliente.Observaciones, TipoDato.Cadena);

                //(new DA_General(strHashcode)).MostrarParametros(cmd);

                cnx.Open();

                cmd.ExecuteNonQuery();
                blnEjecucion = true;
            }
            catch (Exception ex)
            {
                blnEjecucion = false;
                ManejarExcepcion(ex);
            }
            finally
            {
                if (cnx != null && cnx.State != ConnectionState.Closed) cnx.Close();
            }

            return blnEjecucion;
        }

    }
}
