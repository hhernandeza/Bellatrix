﻿using System;
using System.Collections.Generic;
using System.Text;
using Sybase.Data.AseClient;
using TBEWinServ.Utilitarios;
using System.Data;
using TBEWinServ.EntidadesNegocio.EnvioBCosmos;

namespace TBEWinServ.AccesoDatos
{
    public class DA_AvisoCredito : DA_Base
    {
        public DA_AvisoCredito(string prmHashcode) 
        {
            strHashcode = prmHashcode;
        }

        public bool Insertar_Aviso_Credito(BE_AvisoCredito oBEAvisoCredito)
        {
            AseConnection cnx = null;
            bool blnEjecucion = false;

            try
            {
                cnx = new AseConnection(strCadenaConexion);
                AseCommand cmd = new AseCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "p_tbe_insertar_avisos_credito";
                cmd.Connection = cnx;
                cmd.CommandTimeout = Convert.ToInt32(DuracionConexion.Corta);

                cmd.Parameters.Add("@num_ref", AseDbType.Char, 10).Direction = ParameterDirection.Input;
                cmd.Parameters["@num_ref"].Value = Utilitario.SetearComoParametro(oBEAvisoCredito.BcrpRef, TipoDato.Cadena);

                cmd.Parameters.Add("@nro_cta", AseDbType.Char, 10).Direction = ParameterDirection.Input;
                cmd.Parameters["@nro_cta"].Value = Utilitario.SetearComoParametro(oBEAvisoCredito.NroCta, TipoDato.Cadena);

                cmd.Parameters.Add("@base", AseDbType.Char, 6).Direction = ParameterDirection.Input;
                cmd.Parameters["@base"].Value = Utilitario.SetearComoParametro(oBEAvisoCredito.Base, TipoDato.Cadena);

                cmd.Parameters.Add("@moneda", AseDbType.Char, 3).Direction = ParameterDirection.Input;
                cmd.Parameters["@moneda"].Value = Utilitario.SetearComoParametro(oBEAvisoCredito.Moneda, TipoDato.Cadena);

                cmd.Parameters.Add("@mon_ext", AseDbType.Numeric, 15).Direction = ParameterDirection.Input;
                cmd.Parameters["@mon_ext"].Value = Utilitario.SetearComoParametro(oBEAvisoCredito.MonExt);

                cmd.Parameters.Add("@mon_loc", AseDbType.Numeric, 15).Direction = ParameterDirection.Input;
                cmd.Parameters["@mon_loc"].Value = Utilitario.SetearComoParametro(oBEAvisoCredito.MonLoc);

                cmd.Parameters.Add("@fecha", AseDbType.Char, 8).Direction = ParameterDirection.Input;
                cmd.Parameters["@fecha"].Value = Utilitario.SetearComoParametro(oBEAvisoCredito.Fecha, TipoDato.Cadena);

                cmd.Parameters.Add("@bco_orig", AseDbType.Char, 4).Direction = ParameterDirection.Input;
                cmd.Parameters["@bco_orig"].Value = Utilitario.SetearComoParametro(oBEAvisoCredito.BcoOrigen, TipoDato.Cadena);

                cnx.Open();

                cmd.ExecuteNonQuery();

                blnEjecucion = true;
            }
            catch (Exception ex)
            {
                blnEjecucion = false;
                ManejarExcepcion(ex);
            }
            finally
            {
                if (cnx != null && cnx.State != ConnectionState.Closed) cnx.Close();
            }

            return blnEjecucion;
        }

        public bool Actualizar_Avisos_Credito()
        {
            AseConnection cnx = null;
            bool blnEjecucion = false;

            try
            {
                cnx = new AseConnection(strCadenaConexion);
                AseCommand cmd = new AseCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "p_lbtr_ades_avisos";
                cmd.Connection = cnx;
                cmd.CommandTimeout = Convert.ToInt32(DuracionConexion.Corta);

                cnx.Open();

                cmd.ExecuteNonQuery();

                blnEjecucion = true;
            }
            catch (Exception ex)
            {
                blnEjecucion = false;
                ManejarExcepcion(ex);
            }
            finally
            {
                if (cnx != null && cnx.State != ConnectionState.Closed) cnx.Close();
            }

            return blnEjecucion;
        }

        public bool Eliminar_Avisos_Credito_Anteriores(string strFecha)
        {
            AseConnection cnx = null;
            bool blnEjecucion = false;

            try
            {
                cnx = new AseConnection(strCadenaConexion);
                AseCommand cmd = new AseCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "p_tbe_eliminar_avisos_credito_anteriores";
                cmd.Connection = cnx;
                cmd.CommandTimeout = Convert.ToInt32(DuracionConexion.Corta);

                cmd.Parameters.Add("@BCRP_FECHA", AseDbType.Char, 8).Direction = ParameterDirection.Input;
                cmd.Parameters["@BCRP_FECHA"].Value = Utilitario.SetearComoParametro(strFecha, TipoDato.Cadena);

                cnx.Open();

                cmd.ExecuteNonQuery();

                blnEjecucion = true;
            }
            catch (Exception ex)
            {
                blnEjecucion = false;
                ManejarExcepcion(ex);
            }
            finally
            {
                if (cnx != null && cnx.State != ConnectionState.Closed) cnx.Close();
            }

            return blnEjecucion;
        }
    }
}
