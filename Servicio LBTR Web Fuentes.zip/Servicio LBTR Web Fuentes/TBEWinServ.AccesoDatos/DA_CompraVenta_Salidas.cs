﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using Sybase.Data.AseClient;
using System.Data.SqlClient;
using System.Configuration;
using TBEWinServ.EntidadesNegocio.Generales;
using TBEWinServ.EntidadesNegocio.CompraVenta;
using TBEWinServ.Utilitarios;

namespace TBEWinServ.AccesoDatos
{
    public class DA_CompraVenta_Salidas : DA_Base
    {
        public DA_CompraVenta_Salidas(string prmHashcode) 
        {
            strHashcode = prmHashcode;
        }

        public BE_CompraVentaSalidas Obtener_Datos_Compra_Venta(BE_CompraVentaSalidas prmParametros)
        {
            BE_CompraVentaSalidas oBE_CompraVentaSalidas = null;
            AseConnection cnx = null;
            AseDataReader dr = null;
            this.Excepcion = null;

            try
            {
                cnx = new AseConnection(strCadenaConexion);
                AseCommand cmd = new AseCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "t_tbecompraventa_obtener_detalle_operaciones_enviar_BCRP";
                cmd.Connection = cnx;
                cmd.CommandTimeout = Convert.ToInt32(DuracionConexion.Larga);

                cmd.Parameters.Add("@ID_LBTR_SALIDAS", AseDbType.Numeric,10).Direction = ParameterDirection.Input;
                cmd.Parameters["@ID_LBTR_SALIDAS"].Value = Utilitario.SetearComoParametro(prmParametros.ID_LBTR_SALIDAS.ToString(), TipoDato.Cadena);

                cmd.Parameters.Add("@NUM_REF_ORIGEN", AseDbType.Char, 30).Direction = ParameterDirection.Input;
                cmd.Parameters["@NUM_REF_ORIGEN"].Value = Utilitario.SetearComoParametro(prmParametros.NUM_REF_ORIGEN, TipoDato.Cadena);

                cmd.Parameters.Add("@NUM_REF_LBTR", AseDbType.Char, 30).Direction = ParameterDirection.Input;
                cmd.Parameters["@NUM_REF_LBTR"].Value = Utilitario.SetearComoParametro(prmParametros.NUM_REF_LBTR, TipoDato.Cadena);

                cnx.Open();

                dr = cmd.ExecuteReader(CommandBehavior.CloseConnection);

                while (dr.Read())
                {
                    oBE_CompraVentaSalidas = new BE_CompraVentaSalidas();

                    #region Valores

                    //ID_LBTR_SALIDAS,  COD_SERVICIO, SID,  COD_CONCEPTO,  COD_BANCOORIGEN, COD_BANCODESTINO, CTABCO_CTADESTINO, CTABCO_CTAORIGEN, 
                    //FECHA_LIQUIDACION, INSTRUCCION_PAGO, MONTOME, MONTOMN, NUM_REF_ORIGEN, TIPO_CAMBIO, FECHA_CARGADO, FECHA_PROCESO_ENVIADO 
                    //FECHA_ENVIADO_ESPERA, FECHA_ENVIADO_ANULADO, FECHA_ENVIADO_ERROR, FECHA_REGISTRADO_BCRP, ESTADO_LBTR, ESTADO_ENVIO,
                    //NUM_REF_LBTR, TIPO_INGRESO

                    oBE_CompraVentaSalidas.ID_LBTR_SALIDAS = Utilitario.ObtenerIntNull(dr["ID_LBTR_SALIDAS"].ToString());
                    oBE_CompraVentaSalidas.COD_SERVICIO = Utilitario.ObtenerDatoComoCadena(dr["COD_SERVICIO"], TipoDato.Cadena);
                    oBE_CompraVentaSalidas.SID = Utilitario.ObtenerDatoComoCadena(dr["SID"], TipoDato.Cadena);
                    oBE_CompraVentaSalidas.COD_CONCEPTO = Utilitario.ObtenerDatoComoCadena(dr["COD_CONCEPTO"], TipoDato.Cadena);

                    oBE_CompraVentaSalidas.BCO_ORIGEN = Utilitario.ObtenerDatoComoCadena(dr["COD_BANCOORIGEN"], TipoDato.Cadena);
                    oBE_CompraVentaSalidas.BCO_DESTINO = Utilitario.ObtenerDatoComoCadena(dr["COD_BANCODESTINO"], TipoDato.Cadena);
                    oBE_CompraVentaSalidas.CTA_DESTINO = Utilitario.ObtenerDatoComoCadena(dr["CTABCO_CTADESTINO"], TipoDato.Cadena);
                    oBE_CompraVentaSalidas.CTA_ORIGEN = Utilitario.ObtenerDatoComoCadena(dr["CTABCO_CTAORIGEN"], TipoDato.Cadena);
                    oBE_CompraVentaSalidas.FECHA_LIQUIDACION = Utilitario.ObtenerDateTimeNull(dr["FECHA_LIQUIDACION"].ToString());
                    oBE_CompraVentaSalidas.INSTRUCCIONES_PAGO = Utilitario.ObtenerDatoComoCadena(dr["INSTRUCCION_PAGO"], TipoDato.Cadena);
                    oBE_CompraVentaSalidas.MONTO_ME = Utilitario.ObtenerDecimalNull(dr["MONTOME"].ToString());
                    oBE_CompraVentaSalidas.MONTO_MN = Utilitario.ObtenerDecimalNull(dr["MONTOMN"].ToString());
                    oBE_CompraVentaSalidas.NUM_REF_ORIGEN = Utilitario.ObtenerDatoComoCadena(dr["NUM_REF_ORIGEN"], TipoDato.Cadena);
                    oBE_CompraVentaSalidas.NUM_REF_LBTR_CV = Utilitario.ObtenerDatoComoCadena(dr["NUM_REF_LBTR_CV"], TipoDato.Cadena);
                    oBE_CompraVentaSalidas.TIPO_CAMBIO = Utilitario.ObtenerDecimalNull(dr["TIPO_CAMBIO"].ToString());
                    oBE_CompraVentaSalidas.FECHA_CARGADO = Utilitario.ObtenerDateTimeNull(dr["FECHA_CARGADO"].ToString());
                    oBE_CompraVentaSalidas.FECHA_PROCESO_ENVIADO = Utilitario.ObtenerDateTimeNull(dr["FECHA_PROCESO_ENVIADO"].ToString());
                    oBE_CompraVentaSalidas.FECHA_ENVIO_ESPERA = Utilitario.ObtenerDateTimeNull(dr["FECHA_ENVIADO_ESPERA"].ToString());
                    oBE_CompraVentaSalidas.FECHA_ENVIADO_ANULADO = Utilitario.ObtenerDateTimeNull(dr["FECHA_ENVIADO_ANULADO"].ToString());
                    oBE_CompraVentaSalidas.FECHA_ENVIADO_ERROR = Utilitario.ObtenerDateTimeNull(dr["FECHA_ENVIADO_ERROR"].ToString());
                    oBE_CompraVentaSalidas.FECHA_REGISTRADO_BCRP = Utilitario.ObtenerDateTimeNull(dr["FECHA_REGISTRADO_BCRP"].ToString());

                    oBE_CompraVentaSalidas.ESTADO_LBTR = Utilitario.ObtenerDatoComoCadena(dr["ESTADO_LBTR"], TipoDato.Cadena);
                    oBE_CompraVentaSalidas.ESTADO_ENVIO = Utilitario.ObtenerDatoComoCadena(dr["ESTADO_ENVIO"], TipoDato.Cadena);
                    oBE_CompraVentaSalidas.NUM_REF_LBTR = Utilitario.ObtenerDatoComoCadena(dr["NUM_REF_LBTR"], TipoDato.Cadena);
                    oBE_CompraVentaSalidas.TIPO_INGRESO = Utilitario.ObtenerDatoComoCadena(dr["TIPO_INGRESO"], TipoDato.Cadena);

                    #endregion
                }
            }
            catch (Exception ex)
            {
                oBE_CompraVentaSalidas = null;
                ManejarExcepcion(ex);
            }
            finally
            {
                if (dr != null && !dr.IsClosed) dr.Close();
                if (cnx != null && cnx.State != ConnectionState.Closed) cnx.Close();
            }

            return oBE_CompraVentaSalidas;
        }

        public List<BE_CompraVentaSalidas> Obtener_Operaciones_Enviar_BCRP(DateTime? pdtFechaHoraCorte, string pEstadoEnvio, string pstrListaErrores)
        {
            List<BE_CompraVentaSalidas> lstCompraVentaSalidas = new List<BE_CompraVentaSalidas>();
            AseConnection cnx = null;
            AseDataReader dr = null;
            this.Excepcion = null;

            try
            {
                cnx = new AseConnection(strCadenaConexion);
                AseCommand cmd = new AseCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "p_tbecompraventa_obtener_operaciones_enviar_BCRP_new";
                cmd.Connection = cnx;
                cmd.CommandTimeout = Convert.ToInt32(DuracionConexion.Larga);

                cmd.Parameters.Add("@fechahora", AseDbType.DateTime).Direction = ParameterDirection.Input;
                if (pdtFechaHoraCorte == null)
                    cmd.Parameters["@fechahora"].Value = DBNull.Value;
                else
                    cmd.Parameters["@fechahora"].Value = pdtFechaHoraCorte.Value; 

                cmd.Parameters.Add("@estado_envio", AseDbType.Char, 1).Direction = ParameterDirection.Input;
                cmd.Parameters["@estado_envio"].Value = pEstadoEnvio;

                cmd.Parameters.Add("@lista_errores", AseDbType.VarChar, 300).Direction = ParameterDirection.Input;
                cmd.Parameters["@lista_errores"].Value = pstrListaErrores;

                cnx.Open();
                dr = cmd.ExecuteReader(CommandBehavior.CloseConnection);

                while (dr.Read())
                {
                    lstCompraVentaSalidas.Add(new BE_CompraVentaSalidas() { ID_LBTR_SALIDAS = Convert.ToInt32(dr["ID_LBTR_SALIDAS"].ToString()), NUM_REF_ORIGEN = dr["NUM_REF_ORIGEN"].ToString() });
                }
            }
            catch (Exception ex)
            {
                ManejarExcepcion(ex);
            }
            finally
            {
                if (dr != null && !dr.IsClosed) dr.Close();
                if (cnx != null && cnx.State != ConnectionState.Closed) cnx.Close();
            }

            return lstCompraVentaSalidas;
        }

        public bool Actualizar_CompraVentaSalidas(BE_CompraVentaSalidas prmCompraVentaSalidas)
        {
            AseConnection cnx = null;
            bool blnEjecucion = false;
            this.Excepcion = null;

            try
            {
                cnx = new AseConnection(strCadenaConexion);
                AseCommand cmd = new AseCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "p_tbecompraventa_actualizar_SalidasCompraVenta";
                cmd.Connection = cnx;
                cmd.CommandTimeout = Convert.ToInt32(DuracionConexion.Corta);

                cmd.Parameters.Add("@ID_LBTR_SALIDAS", AseDbType.Numeric,10).Direction = ParameterDirection.Input;
                cmd.Parameters["@ID_LBTR_SALIDAS"].Value = Utilitario.SetearComoParametro(prmCompraVentaSalidas.ID_LBTR_SALIDAS.ToString(), TipoDato.Cadena);

                cmd.Parameters.Add("@NUM_REF_ORIGEN", AseDbType.VarChar, 30).Direction = ParameterDirection.Input;
                cmd.Parameters["@NUM_REF_ORIGEN"].Value = Utilitario.SetearComoParametro(prmCompraVentaSalidas.NUM_REF_ORIGEN, TipoDato.Cadena);

                cmd.Parameters.Add("@ESTADO_LBTR", AseDbType.Char, 1).Direction = ParameterDirection.Input;
                cmd.Parameters["@ESTADO_LBTR"].Value = Utilitario.SetearComoParametro(prmCompraVentaSalidas.ESTADO_LBTR, TipoDato.Cadena);

                cmd.Parameters.Add("@ESTADO_ENVIO", AseDbType.Char, 1).Direction = ParameterDirection.Input;
                cmd.Parameters["@ESTADO_ENVIO"].Value = Utilitario.SetearComoParametro(prmCompraVentaSalidas.ESTADO_ENVIO, TipoDato.Cadena);

                cmd.Parameters.Add("@NUM_REF_LBTR", AseDbType.VarChar, 30).Direction = ParameterDirection.Input;
                cmd.Parameters["@NUM_REF_LBTR"].Value = Utilitario.SetearComoParametro(prmCompraVentaSalidas.NUM_REF_LBTR, TipoDato.Cadena);

                cmd.Parameters.Add("@FECHA_ENVIADO_ESPERA", AseDbType.DateTime).Direction = ParameterDirection.Input;
                if (prmCompraVentaSalidas.FECHA_ENVIO_ESPERA == null)
                    cmd.Parameters["@FECHA_ENVIADO_ESPERA"].Value = DBNull.Value;
                else
                    cmd.Parameters["@FECHA_ENVIADO_ESPERA"].Value = prmCompraVentaSalidas.FECHA_ENVIO_ESPERA.Value;

                cmd.Parameters.Add("@FECHA_ENVIADO_ANULADO", AseDbType.DateTime).Direction = ParameterDirection.Input;
                if (prmCompraVentaSalidas.FECHA_ENVIADO_ANULADO == null)
                    cmd.Parameters["@FECHA_ENVIADO_ANULADO"].Value = DBNull.Value;
                else
                    cmd.Parameters["@FECHA_ENVIADO_ANULADO"].Value = prmCompraVentaSalidas.FECHA_ENVIADO_ANULADO.Value;

                cmd.Parameters.Add("@FECHA_ENVIADO_ERROR", AseDbType.DateTime).Direction = ParameterDirection.Input;
                if (prmCompraVentaSalidas.FECHA_ENVIADO_ERROR == null)
                    cmd.Parameters["@FECHA_ENVIADO_ERROR"].Value = DBNull.Value;
                else
                    cmd.Parameters["@FECHA_ENVIADO_ERROR"].Value = prmCompraVentaSalidas.FECHA_ENVIADO_ERROR.Value;

                cmd.Parameters.Add("@MENSAJE_LBTR", AseDbType.VarChar, 1000).Direction = ParameterDirection.Input;
                cmd.Parameters["@MENSAJE_LBTR"].Value = Utilitario.SetearComoParametro(prmCompraVentaSalidas.MENSAJE_LBTR, TipoDato.Cadena);

                cmd.Parameters.Add("@CODIGO_ERROR_LBTR", AseDbType.Char, 5).Direction = ParameterDirection.Input;
                cmd.Parameters["@CODIGO_ERROR_LBTR"].Value = Utilitario.SetearComoParametro(prmCompraVentaSalidas.CODIGO_ERROR_LBTR, TipoDato.Cadena);

                //cmd.Parameters.Add("@TIPO_INGRESO", AseDbType.Char, 1).Direction = ParameterDirection.Input;
                //cmd.Parameters["@TIPO_INGRESO"].Value = Utilitario.SetearComoParametro(prmCompraVentaSalidas.TIPO_INGRESO, TipoDato.Cadena);

                cnx.Open();

                cmd.ExecuteNonQuery();
                blnEjecucion = true;
            }
            catch (Exception ex)
            {
                blnEjecucion = false;
                ManejarExcepcion(ex);
            }
            finally
            {
                if (cnx != null && cnx.State != ConnectionState.Closed) cnx.Close();
            }

            return blnEjecucion;
        }
    }
}
