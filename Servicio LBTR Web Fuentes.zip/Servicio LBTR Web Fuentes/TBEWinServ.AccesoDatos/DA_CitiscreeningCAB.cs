﻿//hh72295:20170117:I: ADECUACION CITISCREENING EN OPERACIONES DE ENTRADA
using System;
using System.Collections.Generic;
using System.Text;
using Sybase.Data.AseClient;
using TBEWinServ.Utilitarios;
using System.Data;
using TBEWinServ.EntidadesNegocio.EnvioBCosmos;
using TBEWinServ.EntidadesNegocio.EnvioCitiscreening;

namespace TBEWinServ.AccesoDatos
{
    public class DA_CitiscreeningCAB : DA_Base
    {
        public DA_CitiscreeningCAB(string prmHashcode) 
        {
            strHashcode = prmHashcode;
        }

        public bool Insertar(BE_CitiscreeningCAB oBE_CitiscreeningCAB)
        {
            AseConnection cnx = null;
            bool blnEjecucion = false;

            try
            {
                cnx = new AseConnection(strCadenaConexion);
                AseCommand cmd = new AseCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "p_tbe_insertar_citiscreening_cab";
                cmd.Connection = cnx;
                cmd.CommandTimeout = Convert.ToInt32(DuracionConexion.Corta);

                cmd.Parameters.Add("@secuencia", AseDbType.Char, 10).Direction = ParameterDirection.Input;
                cmd.Parameters["@secuencia"].Value = Utilitario.SetearComoParametro(oBE_CitiscreeningCAB.SECUENCIA, TipoDato.Cadena);

                cmd.Parameters.Add("@tramainput", AseDbType.Text).Direction = ParameterDirection.Input;
                cmd.Parameters["@tramainput"].Value = Utilitario.SetearComoParametro(oBE_CitiscreeningCAB.TRAMAINPUT, TipoDato.Cadena);

                cmd.Parameters.Add("@estadocs", AseDbType.Char, 1).Direction = ParameterDirection.Input;
                cmd.Parameters["@estadocs"].Value = Utilitario.SetearComoParametro(oBE_CitiscreeningCAB.ESTADOCS, TipoDato.Cadena);

                cnx.Open();

                cmd.ExecuteNonQuery();

                blnEjecucion = true;
            }
            catch (Exception ex)
            {
                blnEjecucion = false;
                ManejarExcepcion(ex);
            }
            finally
            {
                if (cnx != null && cnx.State != ConnectionState.Closed) cnx.Close();
            }

            return blnEjecucion;
        }

        public bool Actualizar()
        {
            return true;
        }

        public bool Eliminar(string strFecha)
        {
            return true;
        }
    }
}
//hh72295:20170117:F: ADECUACION CITISCREENING EN OPERACIONES DE ENTRADA
