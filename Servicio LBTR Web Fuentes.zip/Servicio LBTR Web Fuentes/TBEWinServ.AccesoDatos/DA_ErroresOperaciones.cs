﻿using System;
using System.Collections.Generic;
using System.Text;
using Sybase.Data.AseClient;
using System.Data;
using TBEWinServ.Utilitarios;

namespace TBEWinServ.AccesoDatos
{
    public class DA_ErroresOperaciones : DA_Base
    {
        public DA_ErroresOperaciones(string prmHashcode) 
        {
            strHashcode = prmHashcode;
        }

        public bool Insertar_Log_Error(string strBcrpRef, string strFecha, string strError, string strGrupo)
        {
            AseConnection cnx = null;
            bool blnRespuesta = false;

            try
            {
                cnx = new AseConnection(strCadenaConexion);
                AseCommand cmd = new AseCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "p_tbe_insertar_log_error";
                cmd.Connection = cnx;
                cmd.CommandTimeout = Convert.ToInt32(DuracionConexion.Corta);

                cmd.Parameters.Add("@IDOPERACION", AseDbType.VarChar, 30).Direction = ParameterDirection.Input;
                cmd.Parameters["@IDOPERACION"].Value = Utilitario.SetearComoParametro(strBcrpRef, TipoDato.Cadena);

                cmd.Parameters.Add("@FECHA", AseDbType.Char, 8).Direction = ParameterDirection.Input;
                cmd.Parameters["@FECHA"].Value = Utilitario.SetearComoParametro(strFecha, TipoDato.Cadena);

                cmd.Parameters.Add("@DESCRIPCION", AseDbType.VarChar, 1000).Direction = ParameterDirection.Input;
                cmd.Parameters["@DESCRIPCION"].Value = Utilitario.SetearComoParametro(strError, TipoDato.Cadena);

                cmd.Parameters.Add("@INCLUIRULTGRUPO", AseDbType.Char, 1).Direction = ParameterDirection.Input;
                cmd.Parameters["@INCLUIRULTGRUPO"].Value = Utilitario.SetearComoParametro(strGrupo, TipoDato.Cadena);

                cmd.Parameters.Add("@TIPOERROR", AseDbType.VarChar, 15).Direction = ParameterDirection.Input;
                cmd.Parameters["@TIPOERROR"].Value = Utilitario.SetearComoParametro("", TipoDato.Cadena);

                cnx.Open();

                cmd.ExecuteNonQuery();

                blnRespuesta = true;
            }
            catch (Exception ex)
            {
                ManejarExcepcion(ex);
                blnRespuesta = false;
            }
            finally
            {
                if (cnx != null && cnx.State != ConnectionState.Closed) cnx.Close();
            }

            return blnRespuesta;
        }

        public bool Actualizar_Log_Error(string strBcrpRef, string strFecha)
        {
            AseConnection cnx = null;
            bool blnRespuesta = false;

            try
            {
                cnx = new AseConnection(strCadenaConexion);
                AseCommand cmd = new AseCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "p_tbe_actualizar_log_error";
                cmd.Connection = cnx;
                cmd.CommandTimeout = Convert.ToInt32(DuracionConexion.Corta);

                cmd.Parameters.Add("@BCRP_REFER", AseDbType.VarChar, 30).Direction = ParameterDirection.Input;
                cmd.Parameters["@BCRP_REFER"].Value = Utilitario.SetearComoParametro(strBcrpRef, TipoDato.Cadena);

                cmd.Parameters.Add("@BCRP_FECHA", AseDbType.Char, 8).Direction = ParameterDirection.Input;
                cmd.Parameters["@BCRP_FECHA"].Value = Utilitario.SetearComoParametro(strFecha, TipoDato.Cadena);

                cnx.Open();

                cmd.ExecuteNonQuery();

                blnRespuesta = true;
            }
            catch (Exception ex)
            {
                ManejarExcepcion(ex);
                blnRespuesta = false;
            }
            finally
            {
                if (cnx != null && cnx.State != ConnectionState.Closed) cnx.Close();
            }

            return blnRespuesta;
        }

        public Int64 Obtener_Cantidad_Log_Error(string strBcrpRef)
        {
            AseConnection cnx = null;
            Int64 nCantidad = -1;

            try
            {
                cnx = new AseConnection(strCadenaConexion);
                AseCommand cmd = new AseCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "p_tbe_obtener_cantidad_log_error";
                cmd.Connection = cnx;
                cmd.CommandTimeout = Convert.ToInt32(DuracionConexion.Corta);

                cmd.Parameters.Add("@BCRP_REFER", AseDbType.VarChar, 30).Direction = ParameterDirection.Input;
                cmd.Parameters["@BCRP_REFER"].Value = Utilitario.SetearComoParametro(strBcrpRef, TipoDato.Cadena);

                cnx.Open();

                nCantidad = Convert.ToInt64(cmd.ExecuteScalar());
            }
            catch (Exception ex)
            {
                nCantidad = -1;
                ManejarExcepcion(ex);
            }
            finally
            {
                if (cnx != null && cnx.State != ConnectionState.Closed) cnx.Close();
            }

            return nCantidad;
        }
    }
}
