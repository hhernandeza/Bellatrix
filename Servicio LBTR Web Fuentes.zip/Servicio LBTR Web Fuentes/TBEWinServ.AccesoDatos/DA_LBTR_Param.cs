using System.Data;
using Sybase.Data.AseClient;
using System.Text;
using System.Collections.Generic;
using TBEWinServ.Utilitarios;
using TBEWinServ.EntidadesNegocio.Generales;
using System;

namespace TBEWinServ.AccesoDatos
{
    public class DA_LBTR_Param : DA_Base
    {
        public DA_LBTR_Param(string prmHashcode) 
        {
            strHashcode = prmHashcode;
        }

        public bool Actualizar_LBTR_Param(BE_LBTR_PARAM prmLBTRParam)
        {
            AseConnection cnx = null;
            bool blnEjecucion = false;

            try
            {
                cnx = new AseConnection(strCadenaConexion);
                AseCommand cmd = new AseCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "p_tbe_actualizar_lbtr_param";
                cmd.Connection = cnx;
                cmd.CommandTimeout = Convert.ToInt32(DuracionConexion.Corta);

                cmd.Parameters.Add("@COD_PARAM", AseDbType.Char, 4).Direction = ParameterDirection.Input;
                cmd.Parameters["@COD_PARAM"].Value = prmLBTRParam.CodParam;

                cmd.Parameters.Add("@VAL_PARAM", AseDbType.VarChar, 8000).Direction = ParameterDirection.Input;
                cmd.Parameters["@VAL_PARAM"].Value = Utilitario.SetearComoParametro(prmLBTRParam.Valor, TipoDato.Cadena);

                cmd.Parameters.Add("@FECHA", AseDbType.Char, 14).Direction = ParameterDirection.Input;
                cmd.Parameters["@FECHA"].Value = Utilitario.SetearComoParametro(prmLBTRParam.Fecha, TipoDato.Cadena);

                cmd.Parameters.Add("@IND_KPRI_CITI", AseDbType.Integer).Direction = ParameterDirection.Input;
                cmd.Parameters["@IND_KPRI_CITI"].Value = Utilitario.SetearComoParametro(prmLBTRParam.IndiceKPriCiti);

                cnx.Open();

                cmd.ExecuteNonQuery();
                blnEjecucion = true;
            }
            catch (Exception ex)
            {
                blnEjecucion = false;
                ManejarExcepcion(ex);
            }
            finally
            {
                if (cnx != null && cnx.State != ConnectionState.Closed) cnx.Close();
            }

            return blnEjecucion;
        }

        public BE_LBTR_PARAM Obtener_LBTR_Param(string prmCodParam)
        {
            BE_LBTR_PARAM oParam = null;
            AseConnection cnx = null;
            AseDataReader dr = null;

            try
            {
                cnx = new AseConnection(strCadenaConexion);
                AseCommand cmd = new AseCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "p_tbe_obtener_lbtr_param";
                cmd.Connection = cnx;
                cmd.CommandTimeout = Convert.ToInt32(DuracionConexion.Mediana);

                cmd.Parameters.Add("@COD_PARAM", AseDbType.Char, 4).Direction = ParameterDirection.Input;
                cmd.Parameters["@COD_PARAM"].Value = prmCodParam;

                cnx.Open();

                dr = cmd.ExecuteReader(CommandBehavior.CloseConnection);

                while (dr.Read())
                {
                    oParam = new BE_LBTR_PARAM();

                    #region Valores

                    oParam.CodParam = Utilitario.ObtenerDatoComoCadena(dr["COD_PARAM"], TipoDato.Cadena);
                    oParam.Valor = Utilitario.ObtenerDatoComoCadena(dr["VAL_PARAM"], TipoDato.Cadena);
                    oParam.Fecha = Utilitario.ObtenerDatoComoCadena(dr["FECHA"], TipoDato.Cadena);
                    oParam.IndiceKPriCiti = Utilitario.ObtenerIntNull(dr["IND_KPRI_CITI"].ToString());

                    #endregion

                }

            }
            catch (Exception ex)
            {
                oParam = null;
                ManejarExcepcion(ex);
            }
            finally
            {
                if (dr != null && !dr.IsClosed) dr.Close();
                if (cnx != null && cnx.State != ConnectionState.Closed) cnx.Close();
            }

            return oParam;
        }

    }
}
