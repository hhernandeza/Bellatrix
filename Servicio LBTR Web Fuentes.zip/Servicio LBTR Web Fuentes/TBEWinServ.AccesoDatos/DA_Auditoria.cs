using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using Sybase.Data.AseClient;
using TBEWinServ.EntidadesNegocio.Auditoria;
using TBEWinServ.Utilitarios;

namespace TBEWinServ.AccesoDatos
{
    public class DA_Auditoria : DA_Base
    {
        public DA_Auditoria(string prmHashcode) 
        {
            strHashcode = prmHashcode;
        }

        public bool Actualizar_Auditoria(BE_Auditoria prmAuditoria)
        {
            AseConnection cnx = null;
            bool blnEjecucion = false;

            try
            {
                cnx = new AseConnection(strCadenaConexion);
                AseCommand cmd = new AseCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "p_tbe_actualizar_auditoria";
                cmd.Connection = cnx;
                cmd.CommandTimeout = Convert.ToInt32(DuracionConexion.Corta);

                cmd.Parameters.Add("@COD_TRAMA_AUDITORIA", AseDbType.VarChar, 20).Direction = ParameterDirection.Input;
                cmd.Parameters["@COD_TRAMA_AUDITORIA"].Value = Utilitario.SetearComoParametro(prmAuditoria.CodTramaAuditoria, TipoDato.Cadena);

                cmd.Parameters.Add("@TRAMA", AseDbType.VarChar, 8000).Direction = ParameterDirection.Input;
                cmd.Parameters["@TRAMA"].Value = Utilitario.SetearComoParametro(prmAuditoria.Trama, TipoDato.Cadena);

                cnx.Open();

                cmd.ExecuteNonQuery();
                blnEjecucion = true;
            }
            catch (Exception ex)
            {
                blnEjecucion = false;
                ManejarExcepcion(ex);
            }
            finally
            {
                if (cnx != null && cnx.State != ConnectionState.Closed) cnx.Close();
            }

            return blnEjecucion;
        }

        public bool Registrar_Auditoria(BE_Auditoria prmAuditoria)
        {
            AseConnection cnx = null;
            bool blnEjecucion = false;

            try
            {
                cnx = new AseConnection(strCadenaConexion);
                AseCommand cmd = new AseCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "p_tbe_insertar_auditoria";
                cmd.Connection = cnx;
                cmd.CommandTimeout = Convert.ToInt32(DuracionConexion.Corta);

                cmd.Parameters.Add("@COD_TRAMA_AUDITORIA", AseDbType.VarChar, 20).Direction = ParameterDirection.Input;
                cmd.Parameters["@COD_TRAMA_AUDITORIA"].Value = Utilitario.SetearComoParametro(prmAuditoria.CodTramaAuditoria, TipoDato.Cadena);

                cmd.Parameters.Add("@FECHA_OPERACION", AseDbType.DateTime).Direction = ParameterDirection.Input;
                cmd.Parameters["@FECHA_OPERACION"].Value = prmAuditoria.FecOperacion;

                cmd.Parameters.Add("@TIPO_OPERACION", AseDbType.VarChar, 10).Direction = ParameterDirection.Input;
                cmd.Parameters["@TIPO_OPERACION"].Value = Utilitario.SetearComoParametro(prmAuditoria.TipoOperacion, TipoDato.Cadena);

                cmd.Parameters.Add("@TRAMA", AseDbType.VarChar, 8000).Direction = ParameterDirection.Input;
                cmd.Parameters["@TRAMA"].Value = Utilitario.SetearComoParametro(prmAuditoria.Trama, TipoDato.Cadena);

                cmd.Parameters.Add("@TRAMA_EN_CLARO", AseDbType.VarChar, 8000).Direction = ParameterDirection.Input;
                cmd.Parameters["@TRAMA_EN_CLARO"].Value = Utilitario.SetearComoParametro(prmAuditoria.TramaEnClaro, TipoDato.Cadena);

                cmd.Parameters.Add("@IND_KPUB_BANCO", AseDbType.Integer).Direction = ParameterDirection.Input;
                cmd.Parameters["@IND_KPUB_BANCO"].Value = Utilitario.SetearComoParametro(prmAuditoria.IndiceKPubBanco);

                cmd.Parameters.Add("@IND_KPUB_BCRP", AseDbType.Integer).Direction = ParameterDirection.Input;
                cmd.Parameters["@IND_KPUB_BCRP"].Value = Utilitario.SetearComoParametro(prmAuditoria.IndiceKPubBCRP);

                cmd.Parameters.Add("@IND_KPRI_CITI", AseDbType.Integer).Direction = ParameterDirection.Input;
                cmd.Parameters["@IND_KPRI_CITI"].Value = Utilitario.SetearComoParametro(prmAuditoria.IndiceKPriCiti);

                cmd.Parameters.Add("@COD_BANCO_ORI", AseDbType.Char, 4).Direction = ParameterDirection.Input;
                cmd.Parameters["@COD_BANCO_ORI"].Value = Utilitario.SetearComoParametro(prmAuditoria.CodBancoOri, TipoDato.Cadena);

                cmd.Parameters.Add("@COD_BANCO_DEST", AseDbType.Char, 4).Direction = ParameterDirection.Input;
                cmd.Parameters["@COD_BANCO_DEST"].Value = Utilitario.SetearComoParametro(prmAuditoria.CodBancoDest, TipoDato.Cadena);

                cmd.Parameters.Add("@FIRMA", AseDbType.VarChar, 8000).Direction = ParameterDirection.Input;
                cmd.Parameters["@FIRMA"].Value = Utilitario.SetearComoParametro(prmAuditoria.Firma, TipoDato.Cadena);

                cnx.Open();

                cmd.ExecuteNonQuery();
                blnEjecucion = true;
            }
            catch (Exception ex)
            {
                blnEjecucion = false;
                ManejarExcepcion(ex);
            }
            finally
            {
                if (cnx != null && cnx.State != ConnectionState.Closed) cnx.Close();
            }

            return blnEjecucion;
        }

        public List<BE_Auditoria> Consultar_Auditoria(BE_Auditoria prmAuditoria)
        {
            List<BE_Auditoria> lstAuditoria = new List<BE_Auditoria>();
            AseConnection cnx = null;
            AseDataReader dr = null;

            try
            {
                cnx = new AseConnection(strCadenaConexion);
                AseCommand cmd = new AseCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "p_tbe_obtener_auditoria";
                cmd.Connection = cnx;
                cmd.CommandTimeout = Convert.ToInt32(DuracionConexion.Mediana);

                cmd.Parameters.Add("@COD_TRAMA_AUDITORIA", AseDbType.VarChar, 20).Direction = ParameterDirection.Input;
                cmd.Parameters["@COD_TRAMA_AUDITORIA"].Value = Utilitario.SetearComoParametro(prmAuditoria.CodTramaAuditoria, TipoDato.Cadena);

                cmd.Parameters.Add("@FECHA_OPERACION_INI", AseDbType.DateTime).Direction = ParameterDirection.Input;
                cmd.Parameters["@FECHA_OPERACION_INI"].Value = Utilitario.SetearComoParametro(prmAuditoria.FecOperacionIni);

                cmd.Parameters.Add("@FECHA_OPERACION_FIN", AseDbType.DateTime).Direction = ParameterDirection.Input;
                cmd.Parameters["@FECHA_OPERACION_FIN"].Value = Utilitario.SetearComoParametro(prmAuditoria.FecOperacionFin);

                cmd.Parameters.Add("@TIPO_OPERACION", AseDbType.VarChar, 10).Direction = ParameterDirection.Input;
                cmd.Parameters["@TIPO_OPERACION"].Value = Utilitario.SetearComoParametro(prmAuditoria.TipoOperacion, TipoDato.Cadena);

                cmd.Parameters.Add("@COD_BANCO_ORI", AseDbType.Char, 4).Direction = ParameterDirection.Input;
                cmd.Parameters["@COD_BANCO_ORI"].Value = Utilitario.SetearComoParametro(prmAuditoria.CodBancoOri, TipoDato.Cadena);

                cmd.Parameters.Add("@COD_BANCO_DEST", AseDbType.Char, 4).Direction = ParameterDirection.Input;
                cmd.Parameters["@COD_BANCO_DEST"].Value = Utilitario.SetearComoParametro(prmAuditoria.CodBancoDest, TipoDato.Cadena);

                cnx.Open();

                dr = cmd.ExecuteReader(CommandBehavior.CloseConnection);

                while (dr.Read())
                {
                    BE_Auditoria oAuditoria = new BE_Auditoria();

                    #region Valores

                    oAuditoria.CodTramaAuditoria = Utilitario.ObtenerDatoComoCadena(dr["COD_TRAMA_AUDITORIA"], TipoDato.Cadena);
                    oAuditoria.FecOperacion = Utilitario.ObtenerDateTime(dr["FECHA_OPERACION"].ToString());
                    oAuditoria.TipoOperacion = Utilitario.ObtenerDatoComoCadena(dr["TIPO_OPERACION"], TipoDato.Cadena);
                    oAuditoria.CodBancoOri = Utilitario.ObtenerDatoComoCadena(dr["COD_BANCO_ORI"], TipoDato.Cadena);
                    oAuditoria.CodBancoDest = Utilitario.ObtenerDatoComoCadena(dr["COD_BANCO_DEST"], TipoDato.Cadena);
                    oAuditoria.IndiceKPriCiti = Utilitario.ObtenerIntNull(dr["IND_KPRI_CITI"].ToString());
                    oAuditoria.IndiceKPubBanco = Utilitario.ObtenerIntNull(dr["IND_KPUB_BANCO"].ToString());
                    oAuditoria.IndiceKPubBCRP = Utilitario.ObtenerIntNull(dr["IND_KPUB_BCRP"].ToString());
                    oAuditoria.Trama = Utilitario.ObtenerDatoComoCadena(dr["TRAMA"], TipoDato.Cadena);
                    oAuditoria.TramaEnClaro = Utilitario.ObtenerDatoComoCadena(dr["TRAMA_EN_CLARO"], TipoDato.Cadena);

                    #endregion

                    lstAuditoria.Add(oAuditoria);
                }

            }
            catch (Exception ex)
            {
                lstAuditoria = null;
                ManejarExcepcion(ex);
            }
            finally
            {
                if (dr != null && !dr.IsClosed) dr.Close();
                if (cnx != null && cnx.State != ConnectionState.Closed) cnx.Close();
            }

            return lstAuditoria;
        }

    }
}
