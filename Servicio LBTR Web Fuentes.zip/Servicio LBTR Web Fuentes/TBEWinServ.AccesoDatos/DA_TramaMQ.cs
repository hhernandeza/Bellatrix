﻿using System;
using System.Collections.Generic;
using System.Text;
using TBEWinServ.EntidadesNegocio.EnvioBCosmos;
using Sybase.Data.AseClient;
using System.Data;
using TBEWinServ.Utilitarios;

namespace TBEWinServ.AccesoDatos
{
    public class DA_TramaMQ : DA_Base
    {
        public DA_TramaMQ(string prmHashcode)
        {
            strHashcode = prmHashcode;
        }

        public Int64 Insertar_TramaMQ(BE_TramaMQ prmTramaMQ)
        {
            AseConnection cnx = null;
            Int64 nTokenId = -1;

            try
            {
                cnx = new AseConnection(strCadenaConexion);
                AseCommand cmd = new AseCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "p_insertar_trama";
                cmd.Connection = cnx;
                cmd.CommandTimeout = Convert.ToInt32(DuracionConexion.Corta);

                cmd.Parameters.Add("@n_token_id", AseDbType.Numeric, 10).Direction = ParameterDirection.Input;
                cmd.Parameters["@n_token_id"].Value = Utilitario.SetearComoParametro(prmTramaMQ.TokenId);

                cmd.Parameters.Add("@s_origen_token", AseDbType.Char, 1).Direction = ParameterDirection.Input;
                cmd.Parameters["@s_origen_token"].Value = Utilitario.SetearComoParametro(prmTramaMQ.OrigenToken, TipoDato.Cadena);

                cmd.Parameters.Add("@dt_fecha_origen", AseDbType.DateTime).Direction = ParameterDirection.Input;
                cmd.Parameters["@dt_fecha_origen"].Value = Utilitario.SetearComoParametro(prmTramaMQ.FechaOrigen);

                cmd.Parameters.Add("@s_trama", AseDbType.VarChar, 8000).Direction = ParameterDirection.Input;
                cmd.Parameters["@s_trama"].Value = Utilitario.SetearComoParametro(prmTramaMQ.Trama, TipoDato.Cadena);

                cmd.Parameters.Add("@s_sist_origen", AseDbType.Char, 1).Direction = ParameterDirection.Input;
                cmd.Parameters["@s_sist_origen"].Value = Utilitario.SetearComoParametro(prmTramaMQ.SistemaOrigen, TipoDato.Cadena);

                cmd.Parameters.Add("@msgid", AseDbType.VarChar, 24).Direction = ParameterDirection.Input;
                cmd.Parameters["@msgid"].Value = Utilitario.SetearComoParametro(prmTramaMQ.MsgId, TipoDato.Cadena);

                cnx.Open();

                nTokenId = Convert.ToInt64(cmd.ExecuteScalar());
            }
            catch (Exception ex)
            {
                nTokenId = -1;
                ManejarExcepcion(ex);
            }
            finally
            {
                if (cnx != null && cnx.State != ConnectionState.Closed) cnx.Close();
            }

            return nTokenId;
        }

        public bool Actualizar_TramaMQ(BE_TramaMQ prmTramaMQ)
        {
            AseConnection cnx = null;
            bool blnEjecucion = false;

            try
            {
                cnx = new AseConnection(strCadenaConexion);
                AseCommand cmd = new AseCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "p_actualizar_trama";
                cmd.Connection = cnx;
                cmd.CommandTimeout = Convert.ToInt32(DuracionConexion.Corta);

                cmd.Parameters.Add("@n_token_id", AseDbType.Numeric, 10).Direction = ParameterDirection.Input;
                cmd.Parameters["@n_token_id"].Value = Utilitario.SetearComoParametro(prmTramaMQ.TokenId);

                cmd.Parameters.Add("@s_origen_token", AseDbType.Char, 1).Direction = ParameterDirection.Input;
                cmd.Parameters["@s_origen_token"].Value = Utilitario.SetearComoParametro(prmTramaMQ.OrigenToken, TipoDato.Cadena);

                cmd.Parameters.Add("@msgid", AseDbType.VarChar, 24).Direction = ParameterDirection.Input;
                cmd.Parameters["@msgid"].Value = Utilitario.SetearComoParametro(prmTramaMQ.MsgId, TipoDato.Cadena);

                cnx.Open();

                cmd.ExecuteNonQuery();

                blnEjecucion = true;
            }
            catch (Exception ex)
            {
                blnEjecucion = false;
                ManejarExcepcion(ex);
            }
            finally
            {
                if (cnx != null && cnx.State != ConnectionState.Closed) cnx.Close();
            }

            return blnEjecucion;
        }

        public BE_TramaMQ Obtener_TramaMQ(BE_TramaMQ prmTramaMQ)
        {
            BE_TramaMQ oTramaMQ = new BE_TramaMQ();
            AseConnection cnx = null;
            AseDataReader dr = null;

            try
            {
                cnx = new AseConnection(strCadenaConexion);
                AseCommand cmd = new AseCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "p_obtener_trama";
                cmd.Connection = cnx;
                cmd.CommandTimeout = Convert.ToInt32(DuracionConexion.Mediana);

                cmd.Parameters.Add("@n_token_id", AseDbType.Numeric, 10).Direction = ParameterDirection.Input;
                cmd.Parameters["@n_token_id"].Value = Utilitario.SetearComoParametro(prmTramaMQ.TokenId);

                cmd.Parameters.Add("@s_origen_token", AseDbType.Char, 1).Direction = ParameterDirection.Input;
                cmd.Parameters["@s_origen_token"].Value = Utilitario.SetearComoParametro(prmTramaMQ.OrigenToken, TipoDato.Cadena);

                cnx.Open();

                dr = cmd.ExecuteReader(CommandBehavior.CloseConnection);

                while (dr.Read())
                {
                    oTramaMQ = new BE_TramaMQ();

                    #region Valores

                    oTramaMQ.TokenId = Utilitario.ObtenerIntNull(dr["n_token_id"].ToString());
                    oTramaMQ.OrigenToken = Utilitario.ObtenerDatoComoCadena(dr["s_origen_token"], TipoDato.Cadena);
                    oTramaMQ.FechaOrigen = Utilitario.ObtenerDateTimeNull(dr["dt_fecha_origen"].ToString());
                    oTramaMQ.Trama = Utilitario.ObtenerDatoComoCadena(dr["s_trama"], TipoDato.Cadena);
                    oTramaMQ.SistemaOrigen = Utilitario.ObtenerDatoComoCadena(dr["s_sist_origen"], TipoDato.Cadena);
                    oTramaMQ.MsgId = Utilitario.ObtenerDatoComoCadena(dr["msgid"], TipoDato.Cadena);

                    #endregion
                }

            }
            catch (Exception ex)
            {
                oTramaMQ = null;
                ManejarExcepcion(ex);
            }
            finally
            {
                if (dr != null && !dr.IsClosed) dr.Close();
                if (cnx != null && cnx.State != ConnectionState.Closed) cnx.Close();
            }

            return oTramaMQ;
        }
    }
}
