using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using Sybase.Data.AseClient;
using System.Configuration;
using TBEWinServ.Utilitarios;

namespace TBEWinServ.AccesoDatos
{
    public class DA_ConfirmacionBCosmos : DA_Base
    {
        private bool blnTimeoutException = true;

        public bool TimeoutException
        {
            get { return blnTimeoutException; }
            set { blnTimeoutException = value; }
        }

        public DA_ConfirmacionBCosmos(string prmHashcode) {
            strHashcode = prmHashcode;
        }

        public bool Sincronizar_ConfirmacionAbono_BCosmos()
        {
            LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.CONFIRMACION_BCOSMOS, strHashcode,
                "DA_ConfirmacionBCosmos.Sincronizar_ConfirmacionAbono_BCosmos",
                "Se ejecutara el sp de sincronizacion con BCOSMOS para confirmacion abono.", false);

            AseConnection cnx = null;
            bool blnEjecucion = false;

            try
            {
                cnx = new AseConnection(strCadenaConexion);
                AseCommand cmd = new AseCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "SP_RESPUESTA_ADES";
                cmd.Connection = cnx;
                cmd.CommandTimeout = Globales.SYNCBCOSMOS_TIMEOUT;
                                
                cnx.Open();

                cmd.ExecuteNonQuery();
                blnEjecucion = true;
                LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.CONFIRMACION_BCOSMOS, strHashcode,
                    "DA_ConfirmacionBCosmos.Sincronizar_ConfirmacionAbono_BCosmos",
                    "Finaliza ejecucion del sp de sincronizacion con BCOSMOS para confirmacion abono.", false);
            }
            catch (Exception ex)
            {
                blnEjecucion = false;
                ManejarExcepcion(ex);

                /*if (ex.Message.ToLower().Contains("timeout") || ex.Message.ToLower().Contains("tiempo de espera"))
                {
                    blnTimeoutException = true;
                }*/
            }
            finally
            {
                if (cnx != null && cnx.State != ConnectionState.Closed) cnx.Close();
            }

            return blnEjecucion;
        }               

    }
}
