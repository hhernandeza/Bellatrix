using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using Sybase.Data.AseClient;
using System.Configuration;
using TBEWinServ.EntidadesNegocio.Generales;
using TBEWinServ.EntidadesNegocio.ConfirmacionAbono;
using TBEWinServ.Utilitarios;

namespace TBEWinServ.AccesoDatos
{
    public class DA_ConfirmacionAbono : DA_Base
    {
        public DA_ConfirmacionAbono(string prmHashcode) 
        {
            strHashcode = prmHashcode;
        }
                
        public List<BE_ConfirmacionAbono> Obtener_Operaciones_Confirmar(BE_ConfirmacionAbono prmOperacion)
        {
            List<BE_ConfirmacionAbono> lstOperacion = new List<BE_ConfirmacionAbono>();
            AseConnection cnx = null;
            AseDataReader dr = null;

            try
            {
                cnx = new AseConnection(strCadenaConexion);
                AseCommand cmd = new AseCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "p_tbe_obtener_ope_confirm";
                cmd.Connection = cnx;
                cmd.CommandTimeout = Convert.ToInt32(DuracionConexion.Larga);

                cmd.Parameters.Add("@BCRP_FECHA", AseDbType.Char, 8).Direction = ParameterDirection.Input;
                cmd.Parameters["@BCRP_FECHA"].Value = Utilitario.SetearComoParametro(prmOperacion.FechaLiquidacion, TipoDato.Cadena);

                cmd.Parameters.Add("@ESTADO", AseDbType.Char, 1).Direction = ParameterDirection.Input;
                cmd.Parameters["@ESTADO"].Value = Utilitario.SetearComoParametro(prmOperacion.Estado, TipoDato.Cadena);

                cnx.Open();

                dr = cmd.ExecuteReader(CommandBehavior.CloseConnection);

                while (dr.Read())
                {
                    BE_ConfirmacionAbono oOperacion = new BE_ConfirmacionAbono();

                    #region Valores

                    oOperacion.NumRefLBTR = Utilitario.ObtenerDatoComoCadena(dr["BCRP_REFER"], TipoDato.Cadena);
                    oOperacion.Estado = Utilitario.ObtenerDatoComoCadena(dr["ESTADO"], TipoDato.Cadena);
                    oOperacion.EstadoOriginal = oOperacion.Estado;

                    #endregion

                    lstOperacion.Add(oOperacion);
                }

            }
            catch (Exception ex)
            {
                lstOperacion = null;
                ManejarExcepcion(ex);
            }
            finally
            {
                if (dr != null && !dr.IsClosed) dr.Close();
                if (cnx != null && cnx.State != ConnectionState.Closed) cnx.Close();
            }

            return lstOperacion;
        }

        public bool Actualizar_Operacion(BE_ConfirmacionAbono prmOperacion)
        {
            AseConnection cnx = null;
            bool blnEjecucion = false;

            try
            {
                cnx = new AseConnection(strCadenaConexion);
                AseCommand cmd = new AseCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "p_tbe_actualizar_ope_confirm";
                cmd.Connection = cnx;
                cmd.CommandTimeout = Convert.ToInt32(DuracionConexion.Corta);

                cmd.Parameters.Add("@BCRP_REFER", AseDbType.Char, 15).Direction = ParameterDirection.Input;
                cmd.Parameters["@BCRP_REFER"].Value = Utilitario.SetearComoParametro(prmOperacion.NumRefLBTR, TipoDato.Cadena);

                cmd.Parameters.Add("@ESTADO", AseDbType.Char, 1).Direction = ParameterDirection.Input;
                cmd.Parameters["@ESTADO"].Value = Utilitario.SetearComoParametro(prmOperacion.Estado, TipoDato.Cadena);

                cmd.Parameters.Add("@CONFIRMAABONO", AseDbType.Char, 1).Direction = ParameterDirection.Input;
                cmd.Parameters["@CONFIRMAABONO"].Value = Utilitario.SetearComoParametro(prmOperacion.ConfirmaAbono, TipoDato.Cadena);

                cnx.Open();

                cmd.ExecuteNonQuery();
                blnEjecucion = true;
            }
            catch (Exception ex)
            {
                blnEjecucion = false;
                ManejarExcepcion(ex);
            }
            finally
            {
                if (cnx != null && cnx.State != ConnectionState.Closed) cnx.Close();
            }

            return blnEjecucion;
        }
        
    }
}
