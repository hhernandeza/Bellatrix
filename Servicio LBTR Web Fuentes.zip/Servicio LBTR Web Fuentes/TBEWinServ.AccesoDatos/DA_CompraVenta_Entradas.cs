﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using Sybase.Data.AseClient;
using System.Data.SqlClient;
using System.Configuration;
using TBEWinServ.EntidadesNegocio.Generales;
using TBEWinServ.EntidadesNegocio.CompraVenta;
using TBEWinServ.EntidadesNegocio.OperacionesRecibidas;
using TBEWinServ.Utilitarios;
namespace TBEWinServ.AccesoDatos
{
    public class DA_CompraVenta_Entradas : DA_Base
    {
        public DA_CompraVenta_Entradas(string prmHashcode)
        {
            strHashcode = prmHashcode;
        }

        public bool Insertar_Operacion_Recibida(BE_OperacionRecibida prmOperacionRecibida, out bool blnHayInternalError)
        {
            AseConnection cnx = null;
            bool blnEjecucion = false;
            blnHayInternalError = false;

            try
            {
                cnx = new AseConnection(strCadenaConexion);
                AseCommand cmd = new AseCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "p_tbe_insertar_LBTR_ENTRADAS";
                cmd.Connection = cnx;
                cmd.CommandTimeout = Convert.ToInt32(DuracionConexion.Corta);

                //cmd.Parameters.Add("@ID", AseDbType.Char, 15).Direction = ParameterDirection.Input;
                //cmd.Parameters["@ID"].Value = Utilitario.SetearComoParametro(prmOperacionRecibida.ID, TipoDato.Cadena);
                cmd.Parameters.Add("@COD_BANCO_DESTINO", AseDbType.Char, 6).Direction = ParameterDirection.Input;
                cmd.Parameters["@COD_BANCO_DESTINO"].Value = Utilitario.SetearComoParametro(prmOperacionRecibida.CodBancoDestino, TipoDato.Cadena);
                cmd.Parameters.Add("@COD_BANCO_ORIGEN", AseDbType.Char, 6).Direction = ParameterDirection.Input;
                cmd.Parameters["@COD_BANCO_ORIGEN"].Value = Utilitario.SetearComoParametro(prmOperacionRecibida.CodBancoOrigen, TipoDato.Cadena);
                cmd.Parameters.Add("@COD_CONCEPTO", AseDbType.Char, 4).Direction = ParameterDirection.Input;
                cmd.Parameters["@COD_CONCEPTO"].Value = Utilitario.SetearComoParametro(prmOperacionRecibida.CodConcepto, TipoDato.Cadena);
                cmd.Parameters.Add("@COD_MONEDA", AseDbType.Char, 7).Direction = ParameterDirection.Input;
                cmd.Parameters["@COD_MONEDA"].Value = Utilitario.SetearComoParametro(prmOperacionRecibida.CodMoneda, TipoDato.Cadena);
                cmd.Parameters.Add("@COD_SAB", AseDbType.VarChar, 25).Direction = ParameterDirection.Input;
                cmd.Parameters["@COD_SAB"].Value = Utilitario.SetearComoParametro(prmOperacionRecibida.CodigoSAB, TipoDato.Cadena);
                cmd.Parameters.Add("@COD_SERVICIO", AseDbType.Char, 2).Direction = ParameterDirection.Input;
                cmd.Parameters["@COD_SERVICIO"].Value = Utilitario.SetearComoParametro(prmOperacionRecibida.CodServicio, TipoDato.Cadena);
                cmd.Parameters.Add("@CUENTA_DESTINO", AseDbType.VarChar, 20).Direction = ParameterDirection.Input;
                cmd.Parameters["@CUENTA_DESTINO"].Value = Utilitario.SetearComoParametro(prmOperacionRecibida.CuentaDestino, TipoDato.Cadena);
                cmd.Parameters.Add("@CUENTA_ORIGEN", AseDbType.VarChar, 20).Direction = ParameterDirection.Input;
                cmd.Parameters["@CUENTA_ORIGEN"].Value = Utilitario.SetearComoParametro(prmOperacionRecibida.CuentaOrigen, TipoDato.Cadena);
                cmd.Parameters.Add("@ESTADO_LBTR", AseDbType.Char, 1).Direction = ParameterDirection.Input;
                cmd.Parameters["@ESTADO_LBTR"].Value = Utilitario.SetearComoParametro(prmOperacionRecibida.EstadoLiquidacion, TipoDato.Cadena);
                cmd.Parameters.Add("@FECHA_LIQUIDACION", AseDbType.Char, 8).Direction = ParameterDirection.Input;
                cmd.Parameters["@FECHA_LIQUIDACION"].Value = Utilitario.SetearComoParametro(prmOperacionRecibida.FechaLiquidacion, TipoDato.Cadena);
                cmd.Parameters.Add("@HORA_LIQUIDACION", AseDbType.Char, 6).Direction = ParameterDirection.Input;
                cmd.Parameters["@HORA_LIQUIDACION"].Value = Utilitario.SetearComoParametro(prmOperacionRecibida.HoraLiquidacion, TipoDato.Cadena);
                cmd.Parameters.Add("@INSTRUCCIONES_PAGO", AseDbType.VarChar, 20).Direction = ParameterDirection.Input;
                cmd.Parameters["@INSTRUCCIONES_PAGO"].Value = Utilitario.SetearComoParametro(prmOperacionRecibida.InstruccionesPago, TipoDato.Cadena);
                cmd.Parameters.Add("@MODALIDAD", AseDbType.VarChar, 20).Direction = ParameterDirection.Input;
                cmd.Parameters["@MODALIDAD"].Value = Utilitario.SetearComoParametro(prmOperacionRecibida.Modalidad, TipoDato.Cadena);
                cmd.Parameters.Add("@MONTO_DESTINO", AseDbType.VarChar, 25).Direction = ParameterDirection.Input;
                cmd.Parameters["@MONTO_DESTINO"].Value = Utilitario.SetearComoParametro(prmOperacionRecibida.MontoOperacionDestino, TipoDato.Cadena);
                cmd.Parameters.Add("@MONTO_ORIGEN", AseDbType.VarChar, 25).Direction = ParameterDirection.Input;
                cmd.Parameters["@MONTO_ORIGEN"].Value = Utilitario.SetearComoParametro(prmOperacionRecibida.MontoOperacionOrigen, TipoDato.Cadena);
                cmd.Parameters.Add("@NUM_REF_LBTR", AseDbType.VarChar, 20).Direction = ParameterDirection.Input;
                cmd.Parameters["@NUM_REF_LBTR"].Value = Utilitario.SetearComoParametro(prmOperacionRecibida.NumRefLBTR, TipoDato.Cadena);
                cmd.Parameters.Add("@NUM_REF_LBTRENLACE", AseDbType.VarChar, 20).Direction = ParameterDirection.Input;
                cmd.Parameters["@NUM_REF_LBTRENLACE"].Value = Utilitario.SetearComoParametro(prmOperacionRecibida.NumRefLBTREnlace, TipoDato.Cadena);
                cmd.Parameters.Add("@NUM_REF_ORIGEN", AseDbType.VarChar, 20).Direction = ParameterDirection.Input;
                cmd.Parameters["@NUM_REF_ORIGEN"].Value = Utilitario.SetearComoParametro(prmOperacionRecibida.NumRefOrigen, TipoDato.Cadena);
                cmd.Parameters.Add("@TIPO_CAMBIO", AseDbType.VarChar, 15).Direction = ParameterDirection.Input;
                cmd.Parameters["@TIPO_CAMBIO"].Value = Utilitario.SetearComoParametro(prmOperacionRecibida.TipoCambio, TipoDato.Cadena);
                cmd.Parameters.Add("@TIPO_REGISTRO", AseDbType.VarChar, 20).Direction = ParameterDirection.Input;
                cmd.Parameters["@TIPO_REGISTRO"].Value = Utilitario.SetearComoParametro(prmOperacionRecibida.TipoRegistro, TipoDato.Cadena);
                cmd.Parameters.Add("@DATOS_CLIENTE", AseDbType.VarChar, 20).Direction = ParameterDirection.Input;
                if (prmOperacionRecibida.DatosCliente!= null)
                { cmd.Parameters["@DATOS_CLIENTE"].Value = Utilitario.SetearComoParametro("S", TipoDato.Cadena); }
                else
                { cmd.Parameters["@DATOS_CLIENTE"].Value = Utilitario.SetearComoParametro("N", TipoDato.Cadena); }
                cmd.Parameters.Add("@ESTADO_ENVIO", AseDbType.Char, 1).Direction = ParameterDirection.Input;
                cmd.Parameters["@ESTADO_ENVIO"].Value = Utilitario.SetearComoParametro(Estados.REGISTRADO, TipoDato.Cadena);

                cnx.Open();
                cmd.ExecuteNonQuery();
                blnEjecucion = true;
            }
            catch (Exception ex)
            {
                if (ex.Message.Contains("Internal Error: 30002") ||
                    ex.Message.Contains("Internal Error: 30016"))
                {
                    blnHayInternalError = true;
                }
                blnEjecucion = false;
                ManejarExcepcion(ex);
            }
            return blnEjecucion;
        }
    }
}
