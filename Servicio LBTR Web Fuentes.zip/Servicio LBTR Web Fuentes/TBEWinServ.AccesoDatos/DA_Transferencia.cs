using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using Sybase.Data.AseClient;
using System.Data.SqlClient;
using System.Configuration;
using TBEWinServ.EntidadesNegocio.Generales;
using TBEWinServ.EntidadesNegocio.Transferencia;
using TBEWinServ.Utilitarios;

namespace TBEWinServ.AccesoDatos
{
    public class DA_Transferencia : DA_Base
    {        
        public DA_Transferencia(string prmHashcode) 
        {
            strHashcode = prmHashcode;
        }
        
        public BE_Transferencia Obtener_Datos_Transferencia(BE_Transferencia prmParametros)
        {
            BE_Transferencia oTransferencia = null;
            AseConnection cnx = null;
            AseDataReader dr = null;
            this.Excepcion = null;

            try
            {
                cnx = new AseConnection(strCadenaConexion);
                AseCommand cmd = new AseCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "p_tbe_obtener_transferencia";
                cmd.Connection = cnx;
                cmd.CommandTimeout = Convert.ToInt32(DuracionConexion.Larga);

                cmd.Parameters.Add("@TRANSACT", AseDbType.Char, 10).Direction = ParameterDirection.Input;
                cmd.Parameters["@TRANSACT"].Value = Utilitario.SetearComoParametro(prmParametros.TRANSACT, TipoDato.Cadena);

                cmd.Parameters.Add("@SEC", AseDbType.Char, 3).Direction = ParameterDirection.Input;
                cmd.Parameters["@SEC"].Value = Utilitario.SetearComoParametro(prmParametros.SEC, TipoDato.Cadena);

                cmd.Parameters.Add("@NUM_REF_LBTR", AseDbType.Char, 15).Direction = ParameterDirection.Input;
                cmd.Parameters["@NUM_REF_LBTR"].Value = Utilitario.SetearComoParametro(prmParametros.NumRefLBTR, TipoDato.Cadena);

                cnx.Open();

                dr = cmd.ExecuteReader(CommandBehavior.CloseConnection);

                while (dr.Read())
                {
                    oTransferencia = new BE_Transferencia();

                    #region Valores
                    oTransferencia.TRANSACT = Utilitario.ObtenerDatoComoCadena(dr["TRANSACT"], TipoDato.Cadena);
                    oTransferencia.SEC = Utilitario.ObtenerDatoComoCadena(dr["SEC"], TipoDato.Cadena);
                    oTransferencia.CodBancoDestino = Utilitario.ObtenerDatoComoCadena(dr["COD_BCO_DEST"], TipoDato.Cadena);
                    oTransferencia.Estado = Utilitario.ObtenerDatoComoCadena(dr["ESTADO"], TipoDato.Cadena);
                    oTransferencia.EstadoOriginal = Utilitario.ObtenerDatoComoCadena(dr["ESTADO"], TipoDato.Cadena);
                    oTransferencia.CodConcepto = Utilitario.ObtenerDatoComoCadena(dr["COD_CONCEPTO"], TipoDato.Cadena);
                    oTransferencia.FechaLiquidacion = Utilitario.ObtenerDateTimeNull(dr["FEC_LIQ"].ToString());
                    oTransferencia.CuentaOrigen = Utilitario.ObtenerDatoComoCadena(dr["CUENTA_ORIGEN"], TipoDato.Cadena);
                    oTransferencia.CuentaDestino = Utilitario.ObtenerDatoComoCadena(dr["CUENTA_DESTINO"], TipoDato.Cadena);
                    oTransferencia.Monto = Utilitario.ObtenerDecimalNull(dr["MONTO"].ToString());
                    oTransferencia.NumRefOrigen = Utilitario.ObtenerDatoComoCadena(dr["NUM_REF_ORIGEN"], TipoDato.Cadena);
                    oTransferencia.InstruccionesPago = Utilitario.ObtenerDatoComoCadena(dr["INSTRUCCIONES_PAGO"], TipoDato.Cadena);
                    oTransferencia.Modalidad = Utilitario.ObtenerDatoComoCadena(dr["MODALIDAD"], TipoDato.Cadena);
                    oTransferencia.Prioridad = Utilitario.ObtenerIntNull(dr["PRIORIDAD"].ToString());
                    
                    oTransferencia.DatosCliente = new BE_DatosCliente();
                    oTransferencia.DatosCliente.CCIOrdenante = Utilitario.ObtenerDatoComoCadena(dr["CCI_ORD"], TipoDato.Cadena);
                    oTransferencia.DatosCliente.NombreOrdenante = Utilitario.ObtenerDatoComoCadena(dr["NOMBRE_ORD"], TipoDato.Cadena);
                    oTransferencia.DatosCliente.DireccionOrdenante = Utilitario.ObtenerDatoComoCadena(dr["DIRECCION_ORD"], TipoDato.Cadena);
                    oTransferencia.DatosCliente.TipoDocOrdenante = Utilitario.ObtenerDatoComoCadena(dr["TIPO_DOC_ORD"], TipoDato.Cadena);
                    oTransferencia.DatosCliente.NumDocOrdenante = Utilitario.ObtenerDatoComoCadena(dr["NUM_DOC_ORD"], TipoDato.Cadena);
                    oTransferencia.DatosCliente.CCIBeneficiario = Utilitario.ObtenerDatoComoCadena(dr["CCI_BEN"], TipoDato.Cadena);
                    oTransferencia.DatosCliente.NombreBeneficiario = Utilitario.ObtenerDatoComoCadena(dr["NOMBRE_BEN"], TipoDato.Cadena);
                    oTransferencia.DatosCliente.DireccionBeneficiario = Utilitario.ObtenerDatoComoCadena(dr["DIRECCION_BEN"], TipoDato.Cadena);
                    oTransferencia.DatosCliente.TipoDocBeneficiario = Utilitario.ObtenerDatoComoCadena(dr["TIPO_DOC_BEN"], TipoDato.Cadena);
                    oTransferencia.DatosCliente.NumDocBeneficiario = Utilitario.ObtenerDatoComoCadena(dr["NUM_DOC_BEN"], TipoDato.Cadena);
                    oTransferencia.DatosCliente.IndicadorITF = Utilitario.ObtenerDatoComoCadena(dr["ITF"], TipoDato.Cadena);
                    oTransferencia.DatosCliente.Observaciones = Utilitario.ObtenerDatoComoCadena(dr["OBSERVACIONES"], TipoDato.Cadena);                   

                    oTransferencia.NumRefLBTR = Utilitario.ObtenerDatoComoCadena(dr["NUM_REF_LBTR"], TipoDato.Cadena);
                    oTransferencia.FecRefLBTREnlace = Utilitario.ObtenerDateTimeNull(dr["FEC_REF_LBTR_ENLACE"].ToString());
                    oTransferencia.NumRefLBTREnlace = Utilitario.ObtenerDatoComoCadena(dr["NUM_REF_LBTR_ENLACE"], TipoDato.Cadena);
                    oTransferencia.FechaEnviado = Utilitario.ObtenerDateTimeNull(dr["FECHA_ENVIADO"].ToString());

                    #endregion
                }
            }
            catch (Exception ex)
            {
                oTransferencia = null;
                ManejarExcepcion(ex);
            }
            finally
            {
                if (dr!=null && !dr.IsClosed) dr.Close();
                if (cnx != null && cnx.State != ConnectionState.Closed) cnx.Close();                
            }

            return oTransferencia;
        }

        public bool Actualizar_Transferencia(BE_Transferencia prmTransferencia)
        {
            AseConnection cnx = null;
            bool blnEjecucion = false;
            this.Excepcion = null;

            try
            {
                cnx = new AseConnection(strCadenaConexion);
                AseCommand cmd = new AseCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "p_tbe_actualizar_transferencia";
                cmd.Connection = cnx;
                cmd.CommandTimeout = Convert.ToInt32(DuracionConexion.Corta);

                cmd.Parameters.Add("@TRANSACT", AseDbType.Char, 10).Direction = ParameterDirection.Input;
                cmd.Parameters["@TRANSACT"].Value = Utilitario.SetearComoParametro(prmTransferencia.TRANSACT, TipoDato.Cadena);

                cmd.Parameters.Add("@SEC", AseDbType.Char, 3).Direction = ParameterDirection.Input;
                cmd.Parameters["@SEC"].Value = Utilitario.SetearComoParametro(prmTransferencia.SEC, TipoDato.Cadena);

                cmd.Parameters.Add("@ESTADO", AseDbType.Char, 1).Direction = ParameterDirection.Input;
                cmd.Parameters["@ESTADO"].Value = Utilitario.SetearComoParametro(prmTransferencia.Estado, TipoDato.Cadena);

                cmd.Parameters.Add("@NUM_REF_LBTR", AseDbType.Char, 15).Direction = ParameterDirection.Input;
                cmd.Parameters["@NUM_REF_LBTR"].Value = Utilitario.SetearComoParametro(prmTransferencia.NumRefLBTR, TipoDato.Cadena);

                cmd.Parameters.Add("@FECHA_REGISTRADO_BCRP", AseDbType.DateTime).Direction = ParameterDirection.Input;
                if (prmTransferencia.FechaRegistradoBCRP == null)
                    cmd.Parameters["@FECHA_REGISTRADO_BCRP"].Value = DBNull.Value;
                else
                    cmd.Parameters["@FECHA_REGISTRADO_BCRP"].Value = prmTransferencia.FechaRegistradoBCRP.Value;

                cmd.Parameters.Add("@FECHA_EN_ESPERA", AseDbType.DateTime).Direction = ParameterDirection.Input;
                if (prmTransferencia.FechaEnEspera == null)
                    cmd.Parameters["@FECHA_EN_ESPERA"].Value = DBNull.Value;
                else
                    cmd.Parameters["@FECHA_EN_ESPERA"].Value = prmTransferencia.FechaEnEspera.Value;

                cmd.Parameters.Add("@FECHA_ENVIADO", AseDbType.DateTime).Direction = ParameterDirection.Input;
                if (prmTransferencia.FechaEnviado == null)
                    cmd.Parameters["@FECHA_ENVIADO"].Value = DBNull.Value;
                else
                    cmd.Parameters["@FECHA_ENVIADO"].Value = prmTransferencia.FechaEnviado.Value;

                cmd.Parameters.Add("@FECHA_REENVIADO", AseDbType.DateTime).Direction = ParameterDirection.Input;
                if (prmTransferencia.FechaReEnviado == null)
                    cmd.Parameters["@FECHA_REENVIADO"].Value = DBNull.Value;
                else
                    cmd.Parameters["@FECHA_REENVIADO"].Value = prmTransferencia.FechaReEnviado.Value;

                cmd.Parameters.Add("@FECHA_ACEPTADO", AseDbType.DateTime).Direction = ParameterDirection.Input;
                if (prmTransferencia.FechaAceptado == null)
                    cmd.Parameters["@FECHA_ACEPTADO"].Value = DBNull.Value;
                else
                    cmd.Parameters["@FECHA_ACEPTADO"].Value = prmTransferencia.FechaAceptado.Value;

                cmd.Parameters.Add("@FECHA_ANULADO", AseDbType.DateTime).Direction = ParameterDirection.Input;
                if (prmTransferencia.FechaAnulado == null)
                    cmd.Parameters["@FECHA_ANULADO"].Value = DBNull.Value;
                else
                    cmd.Parameters["@FECHA_ANULADO"].Value = prmTransferencia.FechaAnulado.Value;

                cmd.Parameters.Add("@FECHA_ERROR_TRX", AseDbType.DateTime).Direction = ParameterDirection.Input;
                if (prmTransferencia.FechaErrorTrx == null)
                    cmd.Parameters["@FECHA_ERROR_TRX"].Value = DBNull.Value;
                else
                    cmd.Parameters["@FECHA_ERROR_TRX"].Value = prmTransferencia.FechaErrorTrx.Value;

                cmd.Parameters.Add("@CONFIRMAABONO", AseDbType.Char, 1).Direction = ParameterDirection.Input;
                cmd.Parameters["@CONFIRMAABONO"].Value = Utilitario.SetearComoParametro(prmTransferencia.ConfirmaAbono, TipoDato.Cadena);

                cmd.Parameters.Add("@COD_TRAMA_AUDITORIA", AseDbType.VarChar, 20).Direction = ParameterDirection.Input;
                cmd.Parameters["@COD_TRAMA_AUDITORIA"].Value = Utilitario.SetearComoParametro(prmTransferencia.CodTramaAuditoria, TipoDato.Cadena);

                cmd.Parameters.Add("@ENVIADOPOR", AseDbType.VarChar, 50).Direction = ParameterDirection.Input;
                if (!String.IsNullOrEmpty(prmTransferencia.TransferidoPor))
                {
                    if (prmTransferencia.TransferidoPor.Length > 50)
                    {
                        prmTransferencia.TransferidoPor = prmTransferencia.TransferidoPor.Substring(0, 50);
                    }
                }
                cmd.Parameters["@ENVIADOPOR"].Value = Utilitario.SetearComoParametro(prmTransferencia.TransferidoPor, TipoDato.Cadena);

                cmd.Parameters.Add("@TIPO_INGRESO", AseDbType.Char, 1).Direction = ParameterDirection.Input;
                if (prmTransferencia.TipoIngreso == null)
                    cmd.Parameters["@TIPO_INGRESO"].Value = DBNull.Value;
                else
                    cmd.Parameters["@TIPO_INGRESO"].Value = prmTransferencia.TipoIngreso;
                
                cnx.Open();

                cmd.ExecuteNonQuery();
                blnEjecucion = true;
            }
            catch (Exception ex)
            {
                blnEjecucion = false;
                ManejarExcepcion(ex);
            }
            finally
            {
                if (cnx != null && cnx.State != ConnectionState.Closed) cnx.Close();
            }

            return blnEjecucion;
        }
                        
        public bool Actualizar_Operacion_Paylink(string pstrCodigoOperacionPaylink, string pstrEstadoTBE)
        {
            SqlConnection cnx = null;
            bool blnEjecucion = false;
            this.Excepcion = null;

            try
            {
                cnx = new SqlConnection(Globales.CADENA_CONEXION_PLB);
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "sp_actualizar_tbe";
                cmd.Connection = cnx;
                cmd.CommandTimeout = Convert.ToInt32(DuracionConexion.Corta);

                cmd.Parameters.Add("@s_cod_operacion", SqlDbType.Char, 10).Direction = ParameterDirection.Input;
                cmd.Parameters["@s_cod_operacion"].Value = pstrCodigoOperacionPaylink;

                cmd.Parameters.Add("@s_estado_tbe", SqlDbType.Char, 1).Direction = ParameterDirection.Input;
                cmd.Parameters["@s_estado_tbe"].Value = pstrEstadoTBE;

                cnx.Open();

                cmd.ExecuteNonQuery();
                blnEjecucion = true;
            }
            catch (Exception ex)
            {
                blnEjecucion = false;
                ManejarExcepcion(ex);
            }
            finally
            {
                if (cnx != null && cnx.State != ConnectionState.Closed) cnx.Close();
            }

            return blnEjecucion;
        }

        public string Obtener_Codigo_Paylink(string pstrTransact, string pstrSEC)
        {
            String strCodigoPaylink = null;
            AseConnection cnx = null;
            AseDataReader dr = null;
            this.Excepcion = null;

            try
            {
                cnx = new AseConnection(strCadenaConexion);
                AseCommand cmd = new AseCommand();
                cmd.CommandType = CommandType.Text;
                //inicio cambio jr72296 20/08/2013
                //cmd.CommandText = "select NUM_REF_OPE from T_DESA where TRANSACT = @transact and SEC = @sec and TIPO_INGRESO = 'C'";
                cmd.CommandText = "select NUM_REF_OPE from T_DESA where TRANSACT = @transact and SEC = @sec";
                //fin cambio jr72296 20/08/2013*/
                cmd.Connection = cnx;
                cmd.CommandTimeout = Convert.ToInt32(DuracionConexion.Mediana);

                cmd.Parameters.Add("@transact", AseDbType.Char, 10).Direction = ParameterDirection.Input;
                cmd.Parameters["@transact"].Value = pstrTransact;

                cmd.Parameters.Add("@sec", AseDbType.Char, 3).Direction = ParameterDirection.Input;
                cmd.Parameters["@sec"].Value = pstrSEC;

                cnx.Open();

                dr = cmd.ExecuteReader(CommandBehavior.CloseConnection);

                while (dr.Read())
                {
                    strCodigoPaylink = Utilitario.ObtenerDatoComoCadena(dr["NUM_REF_OPE"], TipoDato.Cadena);
                }

            }
            catch (Exception ex)
            {
                ManejarExcepcion(ex);
            }
            finally
            {
                if (dr != null && !dr.IsClosed) dr.Close();
                if (cnx != null && cnx.State != ConnectionState.Closed) cnx.Close();
            }

            return strCodigoPaylink;
        }

        public List<BE_Transferencia> Obtener_Operaciones_Enviar_BCRP(DateTime? pdtFechaHoraCorte)
        {
            List<BE_Transferencia> lstTransferencias = new List<BE_Transferencia>();
            AseConnection cnx = null;
            AseDataReader dr = null;
            this.Excepcion = null;

            try
            {
                cnx = new AseConnection(strCadenaConexion);
                AseCommand cmd = new AseCommand();
                cmd.CommandType = CommandType.Text;
                /*Inicio Modificacion Jr72296: hora de corte solo aplica a operaciones Paylink*/
                cmd.CommandText = @"select TRANSACT, SEC from T_DESA where ESTADO='3' and TIPO_INGRESO='C' AND ORIGEN_OPE='PAYLINK'
                                    and (@fechahora is null or FECHA_PROCESO_CARGADO<=@fechahora)
                                    UNION
                                    select TRANSACT, SEC from T_DESA where ESTADO='3' and TIPO_INGRESO='C' AND ORIGEN_OPE!='PAYLINK'
 			                        and (@fechahora is null or convert(varchar(8),FECHA_PROCESO_CARGADO,112)<=convert(varchar(8),@fechahora,112))";
                /*FIn Modificacion Jr72296: hora de corte solo aplica a operaciones Paylink*/
                cmd.Connection = cnx;
                cmd.CommandTimeout = Convert.ToInt32(DuracionConexion.Larga);

                cmd.Parameters.Add("@fechahora", AseDbType.DateTime).Direction = ParameterDirection.Input;
                if (pdtFechaHoraCorte == null)
                    cmd.Parameters["@fechahora"].Value = DBNull.Value;
                else
                    cmd.Parameters["@fechahora"].Value = pdtFechaHoraCorte.Value;

                cnx.Open();

                dr = cmd.ExecuteReader(CommandBehavior.CloseConnection);

                while (dr.Read())
                {
                    lstTransferencias.Add(new BE_Transferencia() { TRANSACT = dr["TRANSACT"].ToString(), SEC = dr["SEC"].ToString() });
                }

            }
            catch (Exception ex)
            {
                ManejarExcepcion(ex);
            }
            finally
            {
                if (dr != null && !dr.IsClosed) dr.Close();
                if (cnx != null && cnx.State != ConnectionState.Closed) cnx.Close();
            }

            return lstTransferencias;
        }

        //hh72295:20161104:I: ADECUACION PARA RECUPERAR PASSWORD DESDE DB STBSEGDB Y DESENCRIPTAR CON HSM 
        public void Obtener_SecurityData_LogonLBTR(out string ostrPasswordCifradoLogonLBTR, out string ostrClaveDESCifradoLogonLBTR)
        {
            AseConnection cnx = null;
            this.Excepcion = null;
            AseDataReader drs = null;
            ostrPasswordCifradoLogonLBTR = "";
            ostrClaveDESCifradoLogonLBTR = "";
            string sVal_param = "";
            try
            {
                cnx = new AseConnection(strCadenaConexion);
                AseCommand cmd = new AseCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "select VAL_PARAM from T_LBTR_PARAM where COD_PARAM = '0002' AND ESTADO_MC='A' ";
                cmd.Connection = cnx;
                cmd.CommandTimeout = Convert.ToInt32(DuracionConexion.Mediana);
                cnx.Open();
                drs = cmd.ExecuteReader(CommandBehavior.CloseConnection);
                while (drs.Read())
                {
                    sVal_param = Utilitario.ObtenerDatoComoCadena(drs["VAL_PARAM"], TipoDato.Cadena);
                }
                string[] arrVal_param = sVal_param.Split(',');
                ostrPasswordCifradoLogonLBTR = arrVal_param[0];
                ostrClaveDESCifradoLogonLBTR = arrVal_param[1];
            }
            catch (Exception ex)
            {
                ManejarExcepcion(ex);
            }
            finally
            {
                if (drs != null && !drs.IsClosed) drs.Close();
                if (cnx != null && cnx.State != ConnectionState.Closed) cnx.Close();
            }

            return;
        }
        //hh72295:20161104:F: ADECUACION PARA RECUPERAR PASSWORD DESDE DB STBSEGDB Y DESENCRIPTAR CON HSM 

    }
}
