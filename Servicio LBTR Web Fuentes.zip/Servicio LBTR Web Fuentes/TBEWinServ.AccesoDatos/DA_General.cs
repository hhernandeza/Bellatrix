using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using Sybase.Data.AseClient;
using System.Configuration;
using TBEWinServ.EntidadesNegocio.Generales;
using TBEWinServ.Utilitarios;

namespace TBEWinServ.AccesoDatos
{
    public class DA_General : DA_Base
    {
        public DA_General(string prmHashcode) 
        {
            strHashcode = prmHashcode;
        }

        public BE_FILE01 BuscarBaseNumber(String prmBaseNumber)
        {
            BE_FILE01 oFile01 = null;
            AseConnection cnx = null;
            AseDataReader dr = null;
            this.Excepcion = null;

            try
            {
                cnx = new AseConnection(strCadenaConexion);
                AseCommand cmd = new AseCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "p_tbe_buscar_basenumber";
                cmd.Connection = cnx;
                cmd.CommandTimeout = Convert.ToInt32(DuracionConexion.Corta);

                cmd.Parameters.Add("@BASENUMBER", AseDbType.Char, 6).Direction = ParameterDirection.Input;
                cmd.Parameters["@BASENUMBER"].Value = Utilitario.SetearComoParametro(prmBaseNumber, TipoDato.Cadena);

                cnx.Open();

                dr = cmd.ExecuteReader(CommandBehavior.CloseConnection);

                while (dr.Read())
                {
                    oFile01 = new BE_FILE01();
                    oFile01.BaseNumber = Utilitario.ObtenerDatoComoCadena(dr["BASENUMBER"], TipoDato.Cadena);
                    oFile01.RUC = Utilitario.ObtenerDatoComoCadena(dr["RUC"], TipoDato.Cadena);
                }
            }
            catch (Exception ex)
            {
                ManejarExcepcion(ex);
            }
            finally
            {
                if (dr != null && !dr.IsClosed) dr.Close();
                if (cnx != null && cnx.State != ConnectionState.Closed) cnx.Close();
            }

            return oFile01;
        }

        public List<BE_Concepto> Obtener_Conceptos(BE_Concepto prmConcepto)
        {
            List<BE_Concepto> lstConceptos = new List<BE_Concepto>();
            AseConnection cnx = null;
            AseDataReader dr = null;
            this.Excepcion = null;

            try
            {
                cnx = new AseConnection(strCadenaConexion);
                AseCommand cmd = new AseCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "p_tbe_obtener_conceptos";
                cmd.Connection = cnx;
                cmd.CommandTimeout = Convert.ToInt32(DuracionConexion.Corta);

                cmd.Parameters.Add("@CODCONCEPTO", AseDbType.Char, 4).Direction = ParameterDirection.Input;
                cmd.Parameters["@CODCONCEPTO"].Value = Utilitario.SetearComoParametro(prmConcepto.CodConcepto, TipoDato.Cadena);

                cnx.Open();

                dr = cmd.ExecuteReader(CommandBehavior.CloseConnection);

                while (dr.Read())
                {
                    BE_Concepto oConcepto = new BE_Concepto();

                    #region Valores

                    oConcepto.CodConcepto = Utilitario.ObtenerDatoComoCadena(dr["COD_CONCEPTO"], TipoDato.Cadena);
                    oConcepto.Descripcion = Utilitario.ObtenerDatoComoCadena(dr["DESCONCEPTO"], TipoDato.Cadena);
                    oConcepto.MonCod = Utilitario.ObtenerDatoComoCadena(dr["C_MONCOD"], TipoDato.Cadena);  
                    oConcepto.CodServicio = Utilitario.ObtenerDatoComoCadena(dr["COD_SERVICIO"], TipoDato.Cadena);  
                    
                    string strUsaDatosCliente = Utilitario.ObtenerDatoComoCadena(dr["USA_DATOSCLIENTE"], TipoDato.Cadena);
                    string strUsaBcosmos = Utilitario.ObtenerDatoComoCadena(dr["USA_BCOSMOS"], TipoDato.Cadena);
                    string strEsCavali = Utilitario.ObtenerDatoComoCadena(dr["IND_CAVALI"], TipoDato.Cadena);

                    if (!String.IsNullOrEmpty(strUsaDatosCliente) && strUsaDatosCliente.ToUpper().Equals("S"))
                    {
                        oConcepto.UsaDatosCliente = true;
                    }

                    if (!String.IsNullOrEmpty(strUsaBcosmos) && strUsaBcosmos.ToUpper().Equals("S"))
                    {
                        oConcepto.UsaBCosmos = true;
                    }

                    if (!String.IsNullOrEmpty(strEsCavali) && strEsCavali.ToUpper().Equals("S"))
                    {
                        oConcepto.EsCavali = true;
                    }

                    #endregion

                    lstConceptos.Add(oConcepto);
                }
            }
            catch (Exception ex)
            {
                lstConceptos = null;
                ManejarExcepcion(ex);
            }
            finally
            {
                if (dr != null && !dr.IsClosed) dr.Close();
                if (cnx != null && cnx.State != ConnectionState.Closed) cnx.Close();
            }

            return lstConceptos;
        }

        public List<BE_Banco> Obtener_Bancos(BE_Banco prmBanco)
        {
            List<BE_Banco> lstBancos = new List<BE_Banco>();
            AseConnection cnx = null;
            AseDataReader dr = null;
            this.Excepcion = null;

            try
            {
                cnx = new AseConnection(strCadenaConexion);
                AseCommand cmd = new AseCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "p_tbe_obtener_bancos";
                cmd.Connection = cnx;
                cmd.CommandTimeout = Convert.ToInt32(DuracionConexion.Corta);

                cmd.Parameters.Add("@CODBANCO", AseDbType.Char, 4).Direction = ParameterDirection.Input;
                cmd.Parameters["@CODBANCO"].Value = Utilitario.SetearComoParametro(prmBanco.CodBanco, TipoDato.Cadena);

                cnx.Open();

                dr = cmd.ExecuteReader(CommandBehavior.CloseConnection);

                while (dr.Read())
                {
                    BE_Banco oBanco = new BE_Banco();

                    #region Valores

                    oBanco.CodBanco = Utilitario.ObtenerDatoComoCadena(dr["COD_BCR"], TipoDato.Cadena);
                    oBanco.NomBancoBCR = Utilitario.ObtenerDatoComoCadena(dr["NOM_BCR"], TipoDato.Cadena);
                    oBanco.NomBancoCit = Utilitario.ObtenerDatoComoCadena(dr["NOM_CIT"], TipoDato.Cadena);
                    oBanco.IndiceKPub = Utilitario.ObtenerIntNull(dr["IND_KPUB"].ToString());
                    oBanco.IndiceKPri = Utilitario.ObtenerIntNull(dr["IND_KPRI"].ToString());
                    oBanco.CuentaMatriz = Utilitario.ObtenerDatoComoCadena(dr["CTA_MATRIZ"], TipoDato.Cadena);

                    #endregion

                    lstBancos.Add(oBanco);
                }

            }
            catch (Exception ex)
            {
                lstBancos = null;
                ManejarExcepcion(ex);
            }
            finally
            {
                if (dr != null && !dr.IsClosed) dr.Close();
                if (cnx != null && cnx.State != ConnectionState.Closed) cnx.Close();
            }

            return lstBancos;
        }
                
        public string Obtener_Estado_Equivalente(string prmEstadoBCRP, String prmTipoEstadoBCRP)
        {
            string strValor = null;
            AseConnection cnx = null;
            AseDataReader dr = null;
            this.Excepcion = null;

            try
            {
                cnx = new AseConnection(strCadenaConexion);
                AseCommand cmd = new AseCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "p_tbe_obtener_equiv_estado";
                cmd.Connection = cnx;
                cmd.CommandTimeout = Convert.ToInt32(DuracionConexion.Corta);

                cmd.Parameters.Add("@ESTADOBCRP", AseDbType.VarChar, 2).Direction = ParameterDirection.Input;
                cmd.Parameters["@ESTADOBCRP"].Value = Utilitario.SetearComoParametro(prmEstadoBCRP, TipoDato.Cadena);

                cmd.Parameters.Add("@TIPOESTADO", AseDbType.Char, 1).Direction = ParameterDirection.Input;
                cmd.Parameters["@TIPOESTADO"].Value = Utilitario.SetearComoParametro(prmTipoEstadoBCRP, TipoDato.Cadena);
                                
                cnx.Open();

                dr = cmd.ExecuteReader(CommandBehavior.CloseConnection);

                while (dr.Read())
                {
                    strValor = Utilitario.ObtenerDatoComoCadena(dr["COD_ESTADO"], TipoDato.Cadena);
                }

            }
            catch (Exception ex)
            {
                ManejarExcepcion(ex);
            }
            finally
            {
                if (dr != null && !dr.IsClosed) dr.Close();
                if (cnx != null && cnx.State != ConnectionState.Closed) cnx.Close();
            }

            return strValor;
        }

        public string Obtener_Param(string prmCodigo)
        {
            string strValor = null;
            AseConnection cnx = null;
            AseDataReader dr = null;
            this.Excepcion = null;

            try
            {
                cnx = new AseConnection(strCadenaConexion);
                AseCommand cmd = new AseCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "p_tbe_obtener_param";
                cmd.Connection = cnx;
                cmd.CommandTimeout = Convert.ToInt32(DuracionConexion.Corta);

                cmd.Parameters.Add("@codigo", AseDbType.Char, 4).Direction = ParameterDirection.Input;
                cmd.Parameters["@codigo"].Value = Utilitario.SetearComoParametro(prmCodigo, TipoDato.Cadena);

                cnx.Open();

                dr = cmd.ExecuteReader(CommandBehavior.CloseConnection);

                while (dr.Read())
                {
                    strValor = Utilitario.ObtenerDatoComoCadena(dr["VALOR"], TipoDato.Cadena);
                }

            }
            catch (Exception ex)
            {
                ManejarExcepcion(ex);
            }
            finally
            {
                if (dr != null && !dr.IsClosed) dr.Close();
                if (cnx != null && cnx.State != ConnectionState.Closed) cnx.Close();
            }

            return strValor;
        }

        public string Obtener_Config(string prmCodAgrupacion, string prmCodigo)
        {
            string strValor = null;
            AseConnection cnx = null;
            AseDataReader dr = null;
            this.Excepcion = null;

            try
            {
                cnx = new AseConnection(strCadenaConexion);
                AseCommand cmd = new AseCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "p_tbe_obtener_config";
                cmd.Connection = cnx;
                cmd.CommandTimeout = Convert.ToInt32(DuracionConexion.Corta);

                cmd.Parameters.Add("@codigo", AseDbType.VarChar, 20).Direction = ParameterDirection.Input;
                cmd.Parameters["@codigo"].Value = Utilitario.SetearComoParametro(prmCodigo, TipoDato.Cadena);

                cmd.Parameters.Add("@agrupacion", AseDbType.VarChar, 20).Direction = ParameterDirection.Input;
                cmd.Parameters["@agrupacion"].Value = Utilitario.SetearComoParametro(prmCodAgrupacion, TipoDato.Cadena);
                                                
                cnx.Open();

                dr = cmd.ExecuteReader(CommandBehavior.CloseConnection);

                while (dr.Read())
                {
                    strValor = Utilitario.ObtenerDatoComoCadena(dr["Valor"], TipoDato.Cadena);
                }

            }
            catch (Exception ex)
            {
                ManejarExcepcion(ex);
            }
            finally
            {
                if (dr != null && !dr.IsClosed) dr.Close();
                if (cnx != null && cnx.State != ConnectionState.Closed) cnx.Close();
            }

            return strValor;
        }

        public bool Actualizar_Config(string prmCodAgrupacion, string prmCodigo, string prmValor)
        {
            AseConnection cnx = null;
            bool blnEjecucion = false;
            this.Excepcion = null;

            try
            {
                cnx = new AseConnection(strCadenaConexion);
                AseCommand cmd = new AseCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "p_tbe_actualizar_config";
                cmd.Connection = cnx;
                cmd.CommandTimeout = Convert.ToInt32(DuracionConexion.Corta);

                cmd.Parameters.Add("@agrupacion", AseDbType.VarChar, 20).Direction = ParameterDirection.Input;
                cmd.Parameters["@agrupacion"].Value = Utilitario.SetearComoParametro(prmCodAgrupacion, TipoDato.Cadena);

                cmd.Parameters.Add("@codigo", AseDbType.VarChar, 20).Direction = ParameterDirection.Input;
                cmd.Parameters["@codigo"].Value = Utilitario.SetearComoParametro(prmCodigo, TipoDato.Cadena);

                cmd.Parameters.Add("@valor", AseDbType.VarChar, 50).Direction = ParameterDirection.Input;
                cmd.Parameters["@valor"].Value = Utilitario.SetearComoParametro(prmValor, TipoDato.Cadena);

                cnx.Open();

                cmd.ExecuteNonQuery();
                blnEjecucion = true;
            }
            catch (Exception ex)
            {
                blnEjecucion = false;
                ManejarExcepcion(ex);
            }
            finally
            {
                if (cnx != null && cnx.State != ConnectionState.Closed) cnx.Close();
            }

            return blnEjecucion;
        }

        public bool Insertar_Log_Error(string prmIdOperacion, string prmDescripcion, string prmTipoError, bool prmIncluirEnUltimoGrupo)
        {
            AseConnection cnx = null;
            bool blnEjecucion = false;
            this.Excepcion = null;

            try
            {
                cnx = new AseConnection(strCadenaConexion);
                AseCommand cmd = new AseCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "p_tbe_insertar_log_error";
                cmd.Connection = cnx;
                cmd.CommandTimeout = Convert.ToInt32(DuracionConexion.Corta);

                cmd.Parameters.Add("@IDOPERACION", AseDbType.VarChar, 30).Direction = ParameterDirection.Input;
                cmd.Parameters["@IDOPERACION"].Value = Utilitario.SetearComoParametro(prmIdOperacion, TipoDato.Cadena);

                cmd.Parameters.Add("@FECHA", AseDbType.Char, 8).Direction = ParameterDirection.Input;
                cmd.Parameters["@FECHA"].Value = DateTime.Today.ToString("yyyyMMdd");

                cmd.Parameters.Add("@DESCRIPCION", AseDbType.VarChar, 1000).Direction = ParameterDirection.Input;

                if (String.IsNullOrEmpty(prmDescripcion)) prmDescripcion = "";
                if (prmDescripcion.Length > 1000)
                {
                    prmDescripcion = prmDescripcion.Substring(0, 1000);
                }

                cmd.Parameters["@DESCRIPCION"].Value = Utilitario.SetearComoParametro(prmDescripcion, TipoDato.Cadena);


                cmd.Parameters.Add("@INCLUIRULTGRUPO", AseDbType.Char, 1).Direction = ParameterDirection.Input;
                if (prmIncluirEnUltimoGrupo)
                    cmd.Parameters["@INCLUIRULTGRUPO"].Value = Utilitario.SetearComoParametro("1", TipoDato.Cadena);
                else
                    cmd.Parameters["@INCLUIRULTGRUPO"].Value = Utilitario.SetearComoParametro("0", TipoDato.Cadena);

                cmd.Parameters.Add("@TIPOERROR", AseDbType.VarChar, 15).Direction = ParameterDirection.Input;
                cmd.Parameters["@TIPOERROR"].Value = Utilitario.SetearComoParametro(prmTipoError, TipoDato.Cadena);

                cnx.Open();

                cmd.ExecuteNonQuery();
                blnEjecucion = true;
            }
            catch (Exception ex)
            {
                blnEjecucion = false;
                ManejarExcepcion(ex);
            }
            finally
            {
                if (cnx != null && cnx.State != ConnectionState.Closed) cnx.Close();
            }

            return blnEjecucion;
        }

        public bool EsFeriado(DateTime prmFecha)
        {
            bool blnEsFeriado = false;
            AseConnection cnx = null;
            this.Excepcion = null;

            try
            {
                cnx = new AseConnection(strCadenaConexion);
                AseCommand cmd = new AseCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "p_tbe_es_feriado";
                cmd.Connection = cnx;
                cmd.CommandTimeout = Convert.ToInt32(DuracionConexion.Corta);

                cmd.Parameters.Add("@fecha", AseDbType.Char, 8).Direction = ParameterDirection.Input;
                cmd.Parameters["@fecha"].Value = prmFecha.ToString("yyyyMMdd");

                cnx.Open();

                if (Convert.ToInt32(cmd.ExecuteScalar()) > 0) 
                {
                    blnEsFeriado = true;
                }

            }
            catch (Exception ex)
            {
                ManejarExcepcion(ex);
            }
            finally
            {
                if (cnx != null && cnx.State != ConnectionState.Closed) cnx.Close();
            }

            return blnEsFeriado;
        }

        public void MostrarParametros(AseCommand prmCommand){
            string strComando = null;

            if (prmCommand != null) 
            {
                strComando = prmCommand.CommandText + " ";

                foreach (AseParameter parametro in prmCommand.Parameters)
                {
                    if (parametro.AseDbType == AseDbType.Char || parametro.AseDbType == AseDbType.VarChar)
                        strComando += parametro.ParameterName + " = '" + parametro.Value + "', ";
                    else
                        strComando += parametro.ParameterName + " = " + parametro.Value + ", ";
                }

                if (strComando.EndsWith(", ")) 
                {
                    strComando = strComando.Substring(0, strComando.Length - 2);
                }
            }

            LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.SERVICIO_WINDOWS, strHashcode, 
                "DA_General.MostrarParametros",
                "se ejecutara: " + strComando, false);
        }

        public bool Actualizar_Param(string prmCodigo, string prmValor)
        {
            AseConnection cnx = null;
            bool blnEjecucion = false;
            this.Excepcion = null;

            try
            {
                cnx = new AseConnection(strCadenaConexion);
                AseCommand cmd = new AseCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "p_tbe_actualizar_param";
                cmd.Connection = cnx;
                cmd.CommandTimeout = Convert.ToInt32(DuracionConexion.Corta);

                cmd.Parameters.Add("@codigo", AseDbType.Char, 4).Direction = ParameterDirection.Input;
                cmd.Parameters["@codigo"].Value = Utilitario.SetearComoParametro(prmCodigo, TipoDato.Cadena);

                cmd.Parameters.Add("@valor", AseDbType.VarChar, 100).Direction = ParameterDirection.Input;
                cmd.Parameters["@valor"].Value = Utilitario.SetearComoParametro(prmValor, TipoDato.Cadena);

                cnx.Open();

                cmd.ExecuteNonQuery();
                blnEjecucion = true;
            }
            catch (Exception ex)
            {
                blnEjecucion = false;
                ManejarExcepcion(ex);
            }
            finally
            {
                if (cnx != null && cnx.State != ConnectionState.Closed) cnx.Close();
            }

            return blnEjecucion;
        }

        public string Obtener_Correo(string prmCodigo)
        {
            string strValor = null;
            AseConnection cnx = null;
            AseDataReader dr = null;
            this.Excepcion = null;

            try
            {
                cnx = new AseConnection(strCadenaConexion);
                AseCommand cmd = new AseCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "p_obtener_correo";
                cmd.Connection = cnx;
                cmd.CommandTimeout = Convert.ToInt32(DuracionConexion.Corta);

                cmd.Parameters.Add("@CODIGO", AseDbType.Char, 4).Direction = ParameterDirection.Input;
                cmd.Parameters["@CODIGO"].Value = Utilitario.SetearComoParametro(prmCodigo, TipoDato.Cadena);

                cnx.Open();

                dr = cmd.ExecuteReader(CommandBehavior.CloseConnection);

                while (dr.Read())
                {
                    strValor = Utilitario.ObtenerDatoComoCadena(dr["VALOR"], TipoDato.Cadena);
                }

            }
            catch (Exception ex)
            {
                ManejarExcepcion(ex);
            }
            finally
            {
                if (dr != null && !dr.IsClosed) dr.Close();
                if (cnx != null && cnx.State != ConnectionState.Closed) cnx.Close();
            }

            return strValor;
        }
    }

    public enum OrigenParametro
    {
        T_CONFIG = 0,
        T_PARAM = 1
    }
    
}
