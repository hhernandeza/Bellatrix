using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using Sybase.Data.AseClient;
using System.Configuration;
using TBEWinServ.EntidadesNegocio.OperacionesRecibidas;
using TBEWinServ.Utilitarios;

namespace TBEWinServ.AccesoDatos
{
    public class DA_OperacionesRecibidas : DA_Base
    {        
        public DA_OperacionesRecibidas(string prmHashcode) {
            strHashcode = prmHashcode;
        }

        public bool RegistrarOperacionRecibida(BE_OperacionRecibida prmOperacionRecibida, out bool blnMostrarDataCliente)
        {
            bool blnInserto = false; 
            bool blnHayInternalErrorInsertar = false;//Para identificar si el problema de que no se haya insertado es el 30002
            bool blnCompleto = true;//Para identificar si toda la operacion ha sido grabada en la bd
            blnMostrarDataCliente = false;

            blnInserto = Insertar_Operacion_Recibida(prmOperacionRecibida, out blnHayInternalErrorInsertar);

            if (blnInserto)
            {
                if (!Actualizar_Operacion_Recibida_Sec1(prmOperacionRecibida))
                {
                    blnCompleto = false;
                }
                if (!Actualizar_Operacion_Recibida_Sec2(prmOperacionRecibida))
                {
                    blnCompleto = false;
                }
                if (!Actualizar_Operacion_Recibida_Sec3(prmOperacionRecibida, blnCompleto))
                {
                    blnCompleto = false;
                }
            }

            if (!blnCompleto || blnHayInternalErrorInsertar)
            {
                blnMostrarDataCliente = true;
            }

            return blnInserto;
        }

        private bool Insertar_Operacion_Recibida(BE_OperacionRecibida prmOperacionRecibida, out bool blnHayInternalError)
        {
            AseConnection cnx = null;
            bool blnEjecucion = false;
            blnHayInternalError = false;

            try
            {
                cnx = new AseConnection(strCadenaConexion);
                AseCommand cmd = new AseCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "p_tbe_insertar_ope_recibida";
                cmd.Connection = cnx;
                cmd.CommandTimeout = Convert.ToInt32(DuracionConexion.Corta);

                #region Parametros

                cmd.Parameters.Add("@BCRP_REFER", AseDbType.Char, 15).Direction = ParameterDirection.Input;
                cmd.Parameters["@BCRP_REFER"].Value = Utilitario.SetearComoParametro(prmOperacionRecibida.NumRefLBTR, TipoDato.Cadena);
                cmd.Parameters.Add("@BCRP_FECHA", AseDbType.Char, 8).Direction = ParameterDirection.Input;
                cmd.Parameters["@BCRP_FECHA"].Value = Utilitario.SetearComoParametro(prmOperacionRecibida.FechaLiquidacion, TipoDato.Cadena);
                cmd.Parameters.Add("@BCRP_HORA", AseDbType.Char, 6).Direction = ParameterDirection.Input;
                cmd.Parameters["@BCRP_HORA"].Value = Utilitario.SetearComoParametro(prmOperacionRecibida.HoraLiquidacion, TipoDato.Cadena);
                cmd.Parameters.Add("@BCOORIG", AseDbType.Char, 4).Direction = ParameterDirection.Input;
                cmd.Parameters["@BCOORIG"].Value = Utilitario.SetearComoParametro(prmOperacionRecibida.CodBancoOrigen, TipoDato.Cadena);
                cmd.Parameters.Add("@BCOORIG_REFSEC", AseDbType.Char, 7).Direction = ParameterDirection.Input;
                long lnRefSec = long.Parse(prmOperacionRecibida.NumRefLBTR.Substring(8)) - 1;
                cmd.Parameters["@BCOORIG_REFSEC"].Value = Utilitario.SetearComoParametro(lnRefSec.ToString(), TipoDato.Cadena);

                //Cuenta Cargo
                cmd.Parameters.Add("@CTADEST_NROCTA", AseDbType.Char, 20).Direction = ParameterDirection.Input;
                if (!String.IsNullOrEmpty(prmOperacionRecibida.DatosCliente.CCIOrdenante) &&
                    prmOperacionRecibida.DatosCliente.CCIOrdenante.Length == 20)
                {
                    String strCtaCargo = prmOperacionRecibida.DatosCliente.CCIOrdenante;
                    strCtaCargo = strCtaCargo.Substring(6, 12);
                    cmd.Parameters["@CTADEST_NROCTA"].Value = Utilitario.SetearComoParametro(strCtaCargo, TipoDato.Cadena);
                }
                else
                    cmd.Parameters["@CTADEST_NROCTA"].Value = DBNull.Value;

                cmd.Parameters.Add("@CTADEST_BCOCTA", AseDbType.Char, 4).Direction = ParameterDirection.Input;
                cmd.Parameters["@CTADEST_BCOCTA"].Value = Utilitario.SetearComoParametro(prmOperacionRecibida.CuentaOrigen.Substring(6, 4), TipoDato.Cadena);
                cmd.Parameters.Add("@OPER_COD", AseDbType.Char, 4).Direction = ParameterDirection.Input;
                cmd.Parameters["@OPER_COD"].Value = Utilitario.SetearComoParametro(prmOperacionRecibida.CodConcepto, TipoDato.Cadena);

                cmd.Parameters.Add("@OPER_CTA", AseDbType.Char, 20).Direction = ParameterDirection.Input;
                if (prmOperacionRecibida.UsarCuentaTramite)
                {
                    cmd.Parameters["@OPER_CTA"].Value = Utilitario.SetearComoParametro(prmOperacionRecibida.CuentaTramite, TipoDato.Cadena);
                }
                else
                {
                    if (!String.IsNullOrEmpty(prmOperacionRecibida.DatosCliente.CCIBeneficiario) &&
                        prmOperacionRecibida.DatosCliente.CCIBeneficiario.Length == 20)
                    {
                        String strOperCta = prmOperacionRecibida.DatosCliente.CCIBeneficiario;
                        strOperCta = strOperCta.Substring(8, 10);
                        cmd.Parameters["@OPER_CTA"].Value = Utilitario.SetearComoParametro(strOperCta, TipoDato.Cadena);
                    }
                    else
                        cmd.Parameters["@OPER_CTA"].Value = DBNull.Value;
                }

                cmd.Parameters.Add("@OPER_MONTO", AseDbType.VarChar, 25).Direction = ParameterDirection.Input;
                cmd.Parameters["@OPER_MONTO"].Value = Utilitario.SetearComoParametro(prmOperacionRecibida.MontoOperacionOrigen, TipoDato.Cadena);
                cmd.Parameters.Add("@OPER_MONTO_DESTINO", AseDbType.VarChar, 25).Direction = ParameterDirection.Input;
                cmd.Parameters["@OPER_MONTO_DESTINO"].Value = Utilitario.SetearComoParametro(prmOperacionRecibida.MontoOperacionDestino, TipoDato.Cadena);
                cmd.Parameters.Add("@CODMONEDA", AseDbType.Char, 2).Direction = ParameterDirection.Input;
                cmd.Parameters["@CODMONEDA"].Value = Utilitario.SetearComoParametro(prmOperacionRecibida.CodMoneda, TipoDato.Cadena);
                cmd.Parameters.Add("@CUENTAORIGEN", AseDbType.VarChar, 20).Direction = ParameterDirection.Input;
                cmd.Parameters["@CUENTAORIGEN"].Value = Utilitario.SetearComoParametro(prmOperacionRecibida.CuentaOrigen, TipoDato.Cadena);
                cmd.Parameters.Add("@CUENTADESTINO", AseDbType.VarChar, 20).Direction = ParameterDirection.Input;
                cmd.Parameters["@CUENTADESTINO"].Value = Utilitario.SetearComoParametro(prmOperacionRecibida.CuentaDestino, TipoDato.Cadena);
                cmd.Parameters.Add("@ESTADOLIQUIDACION", AseDbType.Char, 1).Direction = ParameterDirection.Input;
                cmd.Parameters["@ESTADOLIQUIDACION"].Value = Utilitario.SetearComoParametro(prmOperacionRecibida.EstadoLiquidacion, TipoDato.Cadena);
                cmd.Parameters.Add("@TIPO_REGISTRO", AseDbType.Char, 1).Direction = ParameterDirection.Input;
                cmd.Parameters["@TIPO_REGISTRO"].Value = Utilitario.SetearComoParametro(prmOperacionRecibida.TipoRegistro, TipoDato.Cadena);
                cmd.Parameters.Add("@INDICADORITF", AseDbType.Char, 1).Direction = ParameterDirection.Input;
                cmd.Parameters["@INDICADORITF"].Value = Utilitario.SetearComoParametro(prmOperacionRecibida.DatosCliente.IndicadorITF, TipoDato.Cadena);
                cmd.Parameters.Add("@COD_TRAMA_AUDITORIA", AseDbType.VarChar, 20).Direction = ParameterDirection.Input;
                cmd.Parameters["@COD_TRAMA_AUDITORIA"].Value = Utilitario.SetearComoParametro(prmOperacionRecibida.CodTramaAuditoria, TipoDato.Cadena);

                #endregion

                cnx.Open();
                cmd.ExecuteNonQuery();
                blnEjecucion = true;
            }
            catch (Exception ex)
            {
                if (ex.Message.Contains("Internal Error: 30002") ||
                    ex.Message.Contains("Internal Error: 30016"))
                {
                    blnHayInternalError = true;
                }
                blnEjecucion = false;
                ManejarExcepcion(ex);
            }
            finally
            {
                if (cnx != null && cnx.State != ConnectionState.Closed) cnx.Close();
            }

            return blnEjecucion;
        }

        private bool Actualizar_Operacion_Recibida_Sec1(BE_OperacionRecibida prmOperacionRecibida)
        {
            AseConnection cnx = null;
            bool blnEjecucion = false;

            try
            {
                cnx = new AseConnection(strCadenaConexion);
                AseCommand cmd = new AseCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "p_tbe_actualizar_ope_rec_sec1";
                cmd.Connection = cnx;
                cmd.CommandTimeout = Convert.ToInt32(DuracionConexion.Corta);

                #region Parametros

                cmd.Parameters.Add("@BCRP_REFER", AseDbType.Char, 15).Direction = ParameterDirection.Input;
                cmd.Parameters["@BCRP_REFER"].Value = Utilitario.SetearComoParametro(prmOperacionRecibida.NumRefLBTR, TipoDato.Cadena);
                cmd.Parameters.Add("@MODALIDAD", AseDbType.Char, 1).Direction = ParameterDirection.Input;
                cmd.Parameters["@MODALIDAD"].Value = Utilitario.SetearComoParametro(prmOperacionRecibida.Modalidad, TipoDato.Cadena);
                cmd.Parameters.Add("@COD_SERVICIO", AseDbType.Char, 2).Direction = ParameterDirection.Input;
                cmd.Parameters["@COD_SERVICIO"].Value = Utilitario.SetearComoParametro(prmOperacionRecibida.CodServicio, TipoDato.Cadena);
                cmd.Parameters.Add("@CCIORDENANTE", AseDbType.VarChar, 20).Direction = ParameterDirection.Input;
                cmd.Parameters["@CCIORDENANTE"].Value = Utilitario.SetearComoParametro(prmOperacionRecibida.DatosCliente.CCIOrdenante, TipoDato.Cadena);
                cmd.Parameters.Add("@NOMBREORDENANTE", AseDbType.VarChar, 80).Direction = ParameterDirection.Input;
                cmd.Parameters["@NOMBREORDENANTE"].Value = Utilitario.SetearComoParametro(prmOperacionRecibida.DatosCliente.NombreOrdenante, TipoDato.Cadena);
                cmd.Parameters.Add("@TIPODOCORDENANTE", AseDbType.Char, 2).Direction = ParameterDirection.Input;
                cmd.Parameters["@TIPODOCORDENANTE"].Value = Utilitario.SetearComoParametro(prmOperacionRecibida.DatosCliente.TipoDocOrdenante, TipoDato.Cadena);
                cmd.Parameters.Add("@NUMDOCORDENANTE", AseDbType.VarChar, 12).Direction = ParameterDirection.Input;
                cmd.Parameters["@NUMDOCORDENANTE"].Value = Utilitario.SetearComoParametro(prmOperacionRecibida.DatosCliente.NumDocOrdenante, TipoDato.Cadena);
                cmd.Parameters.Add("@DIRECCIONORDENANTE", AseDbType.VarChar, 250).Direction = ParameterDirection.Input;
                cmd.Parameters["@DIRECCIONORDENANTE"].Value = Utilitario.SetearComoParametro(prmOperacionRecibida.DatosCliente.DireccionOrdenante, TipoDato.Cadena);
                cmd.Parameters.Add("@COLORREGISTRO", AseDbType.VarChar, 10).Direction = ParameterDirection.Input;
                cmd.Parameters["@COLORREGISTRO"].Value = Utilitario.SetearComoParametro(prmOperacionRecibida.ColorRegistro, TipoDato.Cadena);

                cmd.Parameters.Add("@OPER_MODO_TRANS", AseDbType.Char, 1).Direction = ParameterDirection.Input;
                string strModoTransf = "";
                if (prmOperacionRecibida.CodConcepto == "C101" || prmOperacionRecibida.CodConcepto == "C170")
                    strModoTransf = "1";
                else if (prmOperacionRecibida.CodConcepto == "A101" || prmOperacionRecibida.CodConcepto == "B101" ||
                    prmOperacionRecibida.CodConcepto == "A170" || prmOperacionRecibida.CodConcepto == "B170")
                    strModoTransf = "2";
                else if (prmOperacionRecibida.CodConcepto == "D101" || prmOperacionRecibida.CodConcepto == "E101" || prmOperacionRecibida.CodConcepto == "F101" ||
                    prmOperacionRecibida.CodConcepto == "D170" || prmOperacionRecibida.CodConcepto == "E170" || prmOperacionRecibida.CodConcepto == "F170")
                    strModoTransf = "3";
                cmd.Parameters["@OPER_MODO_TRANS"].Value = Utilitario.SetearComoParametro(strModoTransf, TipoDato.Cadena);

                cmd.Parameters.Add("@CODBANCODESTINO", AseDbType.Char, 4).Direction = ParameterDirection.Input;
                cmd.Parameters["@CODBANCODESTINO"].Value = Utilitario.SetearComoParametro(prmOperacionRecibida.CodBancoDestino, TipoDato.Cadena);
                cmd.Parameters.Add("@TIPOCAMBIO", AseDbType.VarChar, 15).Direction = ParameterDirection.Input;
                cmd.Parameters["@TIPOCAMBIO"].Value = Utilitario.SetearComoParametro(prmOperacionRecibida.TipoCambio, TipoDato.Cadena);
                cmd.Parameters.Add("@IND_CORPORATIVO", AseDbType.Char, 1).Direction = ParameterDirection.Input;
                cmd.Parameters["@IND_CORPORATIVO"].Value = Utilitario.SetearComoParametro(prmOperacionRecibida.IndCorporativo, TipoDato.Cadena);
                cmd.Parameters.Add("@IND_CORE", AseDbType.Char, 1).Direction = ParameterDirection.Input;
                cmd.Parameters["@IND_CORE"].Value = Utilitario.SetearComoParametro(prmOperacionRecibida.IndCORE, TipoDato.Cadena);
                cmd.Parameters.Add("@IND_FLUJO", AseDbType.Char, 1).Direction = ParameterDirection.Input;
                cmd.Parameters["@IND_FLUJO"].Value = Utilitario.SetearComoParametro(prmOperacionRecibida.strFlujoRegistro, TipoDato.Cadena);

                #endregion

                cnx.Open();
                cmd.ExecuteNonQuery();
                blnEjecucion = true;
            }
            catch (Exception ex)
            {
                blnEjecucion = false;
                ManejarExcepcion(ex);
            }
            finally
            {
                if (cnx != null && cnx.State != ConnectionState.Closed) cnx.Close();
            }

            return blnEjecucion;
        }

        private bool Actualizar_Operacion_Recibida_Sec2(BE_OperacionRecibida prmOperacionRecibida)
        {
            AseConnection cnx = null;
            bool blnEjecucion = false;

            try
            {
                cnx = new AseConnection(strCadenaConexion);
                AseCommand cmd = new AseCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "p_tbe_actualizar_ope_rec_sec2";
                cmd.Connection = cnx;
                cmd.CommandTimeout = Convert.ToInt32(DuracionConexion.Corta);

                #region Parametros

                cmd.Parameters.Add("@BCRP_REFER", AseDbType.Char, 15).Direction = ParameterDirection.Input;
                cmd.Parameters["@BCRP_REFER"].Value = Utilitario.SetearComoParametro(prmOperacionRecibida.NumRefLBTR, TipoDato.Cadena);
                cmd.Parameters.Add("@NUMREFORIGEN", AseDbType.VarChar, 30).Direction = ParameterDirection.Input;
                cmd.Parameters["@NUMREFORIGEN"].Value = Utilitario.SetearComoParametro(prmOperacionRecibida.NumRefOrigen, TipoDato.Cadena);
                cmd.Parameters.Add("@NUMREFLBTRENLACE", AseDbType.VarChar, 15).Direction = ParameterDirection.Input;
                cmd.Parameters["@NUMREFLBTRENLACE"].Value = Utilitario.SetearComoParametro(prmOperacionRecibida.NumRefLBTREnlace, TipoDato.Cadena);
                cmd.Parameters.Add("@CCIBENEFICIARIO", AseDbType.VarChar, 20).Direction = ParameterDirection.Input;
                cmd.Parameters["@CCIBENEFICIARIO"].Value = Utilitario.SetearComoParametro(prmOperacionRecibida.DatosCliente.CCIBeneficiario, TipoDato.Cadena);
                cmd.Parameters.Add("@NOMBREBENEFICIARIO", AseDbType.VarChar, 80).Direction = ParameterDirection.Input;
                cmd.Parameters["@NOMBREBENEFICIARIO"].Value = Utilitario.SetearComoParametro(prmOperacionRecibida.DatosCliente.NombreBeneficiario, TipoDato.Cadena);
                cmd.Parameters.Add("@TIPODOCBENEFICIARIO", AseDbType.Char, 2).Direction = ParameterDirection.Input;
                cmd.Parameters["@TIPODOCBENEFICIARIO"].Value = Utilitario.SetearComoParametro(prmOperacionRecibida.DatosCliente.TipoDocBeneficiario, TipoDato.Cadena);
                cmd.Parameters.Add("@NUMDOCBENEFICIARIO", AseDbType.VarChar, 12).Direction = ParameterDirection.Input;
                cmd.Parameters["@NUMDOCBENEFICIARIO"].Value = Utilitario.SetearComoParametro(prmOperacionRecibida.DatosCliente.NumDocBeneficiario, TipoDato.Cadena);
                cmd.Parameters.Add("@DIRECCIONBENEFICIARIO", AseDbType.VarChar, 250).Direction = ParameterDirection.Input;
                cmd.Parameters["@DIRECCIONBENEFICIARIO"].Value = Utilitario.SetearComoParametro(prmOperacionRecibida.DatosCliente.DireccionBeneficiario, TipoDato.Cadena);
                cmd.Parameters.Add("@FEC_RECEPCION", AseDbType.Char, 14).Direction = ParameterDirection.Input;
                cmd.Parameters["@FEC_RECEPCION"].Value = Utilitario.SetearComoParametro(prmOperacionRecibida.strFechaHoraRecepcion, TipoDato.Cadena);
                cmd.Parameters.Add("@CAV_CODIGOSAB", AseDbType.Char, 4).Direction = ParameterDirection.Input;
                cmd.Parameters["@CAV_CODIGOSAB"].Value = Utilitario.SetearComoParametro(prmOperacionRecibida.CodigoSAB, TipoDato.Cadena);
                cmd.Parameters.Add("@CAV_CTAINTERSAB", AseDbType.Char, 20).Direction = ParameterDirection.Input;
                cmd.Parameters["@CAV_CTAINTERSAB"].Value = Utilitario.SetearComoParametro(prmOperacionRecibida.CuentaInterbancariaSAB, TipoDato.Cadena);
                cmd.Parameters.Add("@CAV_FECNEGOCIACION", AseDbType.Char, 8).Direction = ParameterDirection.Input;
                cmd.Parameters["@CAV_FECNEGOCIACION"].Value = Utilitario.SetearComoParametro(prmOperacionRecibida.FechaNegociacionCavali, TipoDato.Cadena);
                cmd.Parameters.Add("@CAV_NUMREFCAVALI", AseDbType.VarChar, 30).Direction = ParameterDirection.Input;
                cmd.Parameters["@CAV_NUMREFCAVALI"].Value = Utilitario.SetearComoParametro(prmOperacionRecibida.NumRefCavali, TipoDato.Cadena);
                cmd.Parameters.Add("@CAV_TIPOPARTICIPANTE", AseDbType.Char, 1).Direction = ParameterDirection.Input;
                cmd.Parameters["@CAV_TIPOPARTICIPANTE"].Value = Utilitario.SetearComoParametro(prmOperacionRecibida.TipoParticipanteCavali, TipoDato.Cadena);
                cmd.Parameters.Add("@C_ENTIDAD", AseDbType.Char, 1).Direction = ParameterDirection.Input;
                cmd.Parameters["@C_ENTIDAD"].Value = Utilitario.SetearComoParametro(prmOperacionRecibida.DatosCliente.ChrEntidad, TipoDato.Cadena);
                #endregion

                cnx.Open();
                cmd.ExecuteNonQuery();
                blnEjecucion = true;
            }
            catch (Exception ex)
            {
                blnEjecucion = false;
                ManejarExcepcion(ex);
            }
            finally
            {
                if (cnx != null && cnx.State != ConnectionState.Closed) cnx.Close();
            }

            return blnEjecucion;
        }

        private bool Actualizar_Operacion_Recibida_Sec3(BE_OperacionRecibida prmOperacionRecibida, bool prmDatosGrabadosCompletos)
        {
            AseConnection cnx = null;
            bool blnEjecucion = false;

            try
            {
                cnx = new AseConnection(strCadenaConexion);
                AseCommand cmd = new AseCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "p_tbe_actualizar_ope_rec_sec3";
                cmd.Connection = cnx;
                cmd.CommandTimeout = Convert.ToInt32(DuracionConexion.Corta);

                #region Parametros

                cmd.Parameters.Add("@BCRP_REFER", AseDbType.Char, 15).Direction = ParameterDirection.Input;
                cmd.Parameters["@BCRP_REFER"].Value = Utilitario.SetearComoParametro(prmOperacionRecibida.NumRefLBTR, TipoDato.Cadena);
                cmd.Parameters.Add("@ADES", AseDbType.Char, 1).Direction = ParameterDirection.Input;
                if (prmDatosGrabadosCompletos)
                    cmd.Parameters["@ADES"].Value = Utilitario.SetearComoParametro(prmOperacionRecibida.ADES, TipoDato.Cadena);
                else
                    cmd.Parameters["@ADES"].Value = Utilitario.SetearComoParametro("0", TipoDato.Cadena);

                cmd.Parameters.Add("@OBS_CLI", AseDbType.VarChar, 250).Direction = ParameterDirection.Input;
                cmd.Parameters["@OBS_CLI"].Value = Utilitario.SetearComoParametro(prmOperacionRecibida.DatosCliente.Observaciones, TipoDato.Cadena);
                cmd.Parameters.Add("@OPER_OBS", AseDbType.VarChar, 250).Direction = ParameterDirection.Input;
                cmd.Parameters["@OPER_OBS"].Value = Utilitario.SetearComoParametro(prmOperacionRecibida.InstruccionesPago, TipoDato.Cadena);

                #endregion

                cnx.Open();
                cmd.ExecuteNonQuery();
                blnEjecucion = true;
            }
            catch (Exception ex)
            {
                blnEjecucion = false;
                ManejarExcepcion(ex);
            }
            finally
            {
                if (cnx != null && cnx.State != ConnectionState.Closed) cnx.Close();
            }

            return blnEjecucion;
        }

        public List<BE_OperacionRecibida> Obtener_Operaciones_Recibidas(BE_OperacionRecibida prmOperacionRecibida)
        {
            List<BE_OperacionRecibida> lstOperacion = new List<BE_OperacionRecibida>();
            AseConnection cnx = null;
            AseDataReader dr = null;

            try
            {
                cnx = new AseConnection(strCadenaConexion);
                AseCommand cmd = new AseCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "p_tbe_obtener_ope_rec";
                cmd.Connection = cnx;
                cmd.CommandTimeout = Convert.ToInt32(DuracionConexion.Mediana);

                cmd.Parameters.Add("@BCRP_REFER", AseDbType.Char, 15).Direction = ParameterDirection.Input;
                cmd.Parameters["@BCRP_REFER"].Value = Utilitario.SetearComoParametro(prmOperacionRecibida.NumRefLBTR, TipoDato.Cadena);

                cnx.Open();

                dr = cmd.ExecuteReader(CommandBehavior.CloseConnection);

                while (dr.Read())
                {
                    BE_OperacionRecibida oOperacion = new BE_OperacionRecibida();

                    #region Valores

                    oOperacion.NumRefLBTR = Utilitario.ObtenerDatoComoCadena(dr["BCRP_REFER"], TipoDato.Cadena);
                    oOperacion.FechaLiquidacion = Utilitario.ObtenerDatoComoCadena(dr["BCRP_FECHA"], TipoDato.Cadena);
                    oOperacion.HoraLiquidacion = Utilitario.ObtenerDatoComoCadena(dr["BCRP_HORA"], TipoDato.Cadena);
                    oOperacion.CodTramaAuditoria = Utilitario.ObtenerDatoComoCadena(dr["COD_TRAMA_AUDITORIA"], TipoDato.Cadena);
                    oOperacion.EstadoLiquidacion = Utilitario.ObtenerDatoComoCadena(dr["ESTADOLIQUIDACION"], TipoDato.Cadena);
                    oOperacion.ConfirmaAbono = Utilitario.ObtenerDatoComoCadena(dr["CONFIRMAABONO"], TipoDato.Cadena);

                    #endregion

                    lstOperacion.Add(oOperacion);
                }

            }
            catch (Exception ex)
            {
                lstOperacion = null;
                ManejarExcepcion(ex);
            }
            finally
            {
                if (dr != null && !dr.IsClosed) dr.Close();
                if (cnx != null && cnx.State != ConnectionState.Closed) cnx.Close();
            }

            return lstOperacion;        
        }

    }
}
