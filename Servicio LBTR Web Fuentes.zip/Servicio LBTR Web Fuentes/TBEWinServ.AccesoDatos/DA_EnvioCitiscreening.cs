﻿//hh72295:20170117:I: ADECUACION CITISCREENING EN OPERACIONES DE ENTRADA
using System;
using System.Collections.Generic;
using System.Text;
using Sybase.Data.AseClient;
using TBEWinServ.EntidadesNegocio.EnvioBCosmos;
using System.Data;
using TBEWinServ.Utilitarios;
using TBEWinServ.EntidadesNegocio.EnvioCitiscreening;

namespace TBEWinServ.AccesoDatos
{
    public class DA_EnvioCitiscreening : DA_Base
    {
        public DA_EnvioCitiscreening(string prmHashcode) 
        {
            strHashcode = prmHashcode;
        }

        public List<BE_EnvioCitiscreening> Obtener_Operaciones_A_Enviar_Citiscreening(string strFecha)
        {
            List<BE_EnvioCitiscreening> lstOperacion = new List<BE_EnvioCitiscreening>();
            AseConnection cnx = null;
            AseDataReader dr = null;

            try
            {
                cnx = new AseConnection(strCadenaConexion);
                AseCommand cmd = new AseCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "p_tbe_obtener_ope_envio_citiscreening";
                cmd.Connection = cnx;
                cmd.CommandTimeout = Convert.ToInt32(DuracionConexion.Mediana);

                cmd.Parameters.Add("@BCRP_FECHA", AseDbType.Char, 8).Direction = ParameterDirection.Input;
                cmd.Parameters["@BCRP_FECHA"].Value = Utilitario.SetearComoParametro(strFecha, TipoDato.Cadena);

                cnx.Open();

                dr = cmd.ExecuteReader(CommandBehavior.CloseConnection);

                while (dr.Read())
                {
                    BE_EnvioCitiscreening oOperacion = new BE_EnvioCitiscreening();

                    #region Valores

                    oOperacion.BcrpRefer = Utilitario.ObtenerDatoComoCadena(dr["BCRP_REFER"], TipoDato.Cadena);
                    oOperacion.Fecha = Utilitario.ObtenerDatoComoCadena(dr["BCRP_FECHA"], TipoDato.Cadena);
                    oOperacion.BcoOrig = Utilitario.ObtenerDatoComoCadena(dr["BCOORIG"], TipoDato.Cadena);
                    oOperacion.OperMonto = Utilitario.ObtenerDatoComoCadena(dr["OPER_MONTO"], TipoDato.Cadena);
                    oOperacion.IndicadorItf = Utilitario.ObtenerDatoComoCadena(dr["INDICADORITF"], TipoDato.Cadena);
                    oOperacion.NumDocOrdenante = Utilitario.ObtenerDatoComoCadena(dr["NUMDOCORDENANTE"], TipoDato.Cadena);
                    oOperacion.TipoDocOrdenante = Utilitario.ObtenerDatoComoCadena(dr["TIPODOCORDENANTE"], TipoDato.Cadena);
                    oOperacion.CodMoneda = Utilitario.ObtenerDatoComoCadena(dr["CODMONEDA"], TipoDato.Cadena);
                    oOperacion.OperCta = Utilitario.ObtenerDatoComoCadena(dr["OPER_CTA"], TipoDato.Cadena);
                    oOperacion.NroCta = Utilitario.ObtenerDatoComoCadena(dr["NRO_CUENTA"], TipoDato.Cadena);
                    oOperacion.OperCtaTmp = Utilitario.ObtenerDatoComoCadena(dr["OPER_CTATMP"], TipoDato.Cadena);
                    oOperacion.IndOmitValnDoc = Utilitario.ObtenerDatoComoCadena(dr["IND_OMITVALNDOC"], TipoDato.Cadena);
                    oOperacion.Entidad = Utilitario.ObtenerDatoComoCadena(dr["C_ENTIDAD"], TipoDato.Cadena);
                    //MAS CAMPOS
                    oOperacion.BcrpHora = Utilitario.ObtenerDatoComoCadena(dr["BCRP_HORA"], TipoDato.Cadena);
                    oOperacion.BcoOrigRef = Utilitario.ObtenerDatoComoCadena(dr["BCOORIG_REF"], TipoDato.Cadena);
                    oOperacion.BcoOrigRefSec = Utilitario.ObtenerDatoComoCadena(dr["BCOORIG_REFSEC"], TipoDato.Cadena);
                    oOperacion.CtaDestNroCta = Utilitario.ObtenerDatoComoCadena(dr["CTADEST_NROCTA"], TipoDato.Cadena);
                    oOperacion.CtaDestBcoCta = Utilitario.ObtenerDatoComoCadena(dr["CTADEST_BCOCTA"], TipoDato.Cadena);
                    oOperacion.CtaDestSubCta = Utilitario.ObtenerDatoComoCadena(dr["CTADEST_SUBCTA"], TipoDato.Cadena);
                    oOperacion.CtaDestMonCta = Utilitario.ObtenerDatoComoCadena(dr["CTADEST_MONCTA"], TipoDato.Cadena);
                    oOperacion.OperCod = Utilitario.ObtenerDatoComoCadena(dr["OPER_COD"], TipoDato.Cadena);
                    oOperacion.OperSBS = Utilitario.ObtenerDatoComoCadena(dr["OPER_OBS"], TipoDato.Cadena);
                    oOperacion.OperFirma = Utilitario.ObtenerDatoComoCadena(dr["OPER_FIRMA"], TipoDato.Cadena);
                    oOperacion.OperModoTrans = Utilitario.ObtenerDatoComoCadena(dr["OPER_MODO_TRANS"], TipoDato.Cadena);
                    oOperacion.OperProcedencia = Utilitario.ObtenerDatoComoCadena(dr["OPER_PROCEDENCIA"], TipoDato.Cadena);
                    oOperacion.ADES = Utilitario.ObtenerDatoComoCadena(dr["ADES"], TipoDato.Cadena);
                    oOperacion.GeneroADES = Utilitario.ObtenerDatoComoCadena(dr["GENERO_ADES"], TipoDato.Cadena);
                    oOperacion.CodBancoDestino = Utilitario.ObtenerDatoComoCadena(dr["CODBANCODESTINO"], TipoDato.Cadena);
                    oOperacion.CuentaOrigen = Utilitario.ObtenerDatoComoCadena(dr["CUENTAORIGEN"], TipoDato.Cadena);
                    oOperacion.CuentaDestino = Utilitario.ObtenerDatoComoCadena(dr["CUENTADESTINO"], TipoDato.Cadena);
                    oOperacion.TipoCambio = Utilitario.ObtenerDatoComoCadena(dr["TIPOCAMBIO"], TipoDato.Cadena);
                    oOperacion.NumRefOrigen = Utilitario.ObtenerDatoComoCadena(dr["NUMREFORIGEN"], TipoDato.Cadena);
                    oOperacion.NumRefLBTREnlace = Utilitario.ObtenerDatoComoCadena(dr["NUMREFLBTRENLACE"], TipoDato.Cadena);
                    oOperacion.Prioridad = Utilitario.ObtenerDatoComoCadena(dr["PRIORIDAD"], TipoDato.Cadena);
                    oOperacion.ConfirmaAbono = Utilitario.ObtenerDatoComoCadena(dr["CONFIRMAABONO"], TipoDato.Cadena);
                    oOperacion.EstadoLiquidacion = Utilitario.ObtenerDatoComoCadena(dr["ESTADOLIQUIDACION"], TipoDato.Cadena);
                    oOperacion.CCIOrdenante = Utilitario.ObtenerDatoComoCadena(dr["CCIORDENANTE"], TipoDato.Cadena);
                    oOperacion.NombreOrdenante = Utilitario.ObtenerDatoComoCadena(dr["NOMBREORDENANTE"], TipoDato.Cadena);
                    oOperacion.DireccionOrdenante = Utilitario.ObtenerDatoComoCadena(dr["DIRECCIONORDENANTE"], TipoDato.Cadena);
                    oOperacion.CCIBeneficiario = Utilitario.ObtenerDatoComoCadena(dr["CCIBENEFICIARIO"], TipoDato.Cadena);
                    oOperacion.NombreBeneficiario = Utilitario.ObtenerDatoComoCadena(dr["NOMBREBENEFICIARIO"], TipoDato.Cadena);
                    oOperacion.DireccionBeneficiario = Utilitario.ObtenerDatoComoCadena(dr["DIRECCIONBENEFICIARIO"], TipoDato.Cadena);
                    oOperacion.TipoDocBeneficiario = Utilitario.ObtenerDatoComoCadena(dr["TIPODOCBENEFICIARIO"], TipoDato.Cadena);
                    oOperacion.NumDocBeneficiario = Utilitario.ObtenerDatoComoCadena(dr["NUMDOCBENEFICIARIO"], TipoDato.Cadena);
                    oOperacion.OperMontoDestino = Utilitario.ObtenerDatoComoCadena(dr["OPER_MONTO_DESTINO"], TipoDato.Cadena);
                    oOperacion.CodTramaAuditoria = Utilitario.ObtenerDatoComoCadena(dr["COD_TRAMA_AUDITORIA"], TipoDato.Cadena);
                    oOperacion.EstadoDebito = Utilitario.ObtenerDatoComoCadena(dr["ESTADO_DEBITO"], TipoDato.Cadena);
                    oOperacion.EstadoCredito = Utilitario.ObtenerDatoComoCadena(dr["ESTADO_CREDITO"], TipoDato.Cadena);
                    oOperacion.NFecTime = Utilitario.ObtenerDatoComoCadena(dr["N_FECTIME"], TipoDato.Cadena);
                    oOperacion.CodServicio = Utilitario.ObtenerDatoComoCadena(dr["COD_SERVICIO"], TipoDato.Cadena);
                    oOperacion.TipoRegistro = Utilitario.ObtenerDatoComoCadena(dr["TIPO_REGISTRO"], TipoDato.Cadena);
                    oOperacion.AbonoManual = Utilitario.ObtenerDatoComoCadena(dr["ABONO_MANUAL"], TipoDato.Cadena);
                    oOperacion.Modalidad = Utilitario.ObtenerDatoComoCadena(dr["MODALIDAD"], TipoDato.Cadena);
                    oOperacion.CavCodigoSAB = Utilitario.ObtenerDatoComoCadena(dr["CAV_CODIGOSAB"], TipoDato.Cadena);
                    oOperacion.CavCtaInterSAB = Utilitario.ObtenerDatoComoCadena(dr["CAV_CTAINTERSAB"], TipoDato.Cadena);
                    oOperacion.CavFecNegociacion = Utilitario.ObtenerDatoComoCadena(dr["CAV_FECNEGOCIACION"], TipoDato.Cadena);
                    oOperacion.CavNumRefCavali = Utilitario.ObtenerDatoComoCadena(dr["CAV_NUMREFCAVALI"], TipoDato.Cadena);
                    oOperacion.CavTipoParticipante = Utilitario.ObtenerDatoComoCadena(dr["CAV_TIPOPARTICIPANTE"], TipoDato.Cadena);
                    oOperacion.ColorRegistro = Utilitario.ObtenerDatoComoCadena(dr["COLORREGISTRO"], TipoDato.Cadena);
                    oOperacion.IndCorporativo = Utilitario.ObtenerDatoComoCadena(dr["IND_CORPORATIVO"], TipoDato.Cadena);
                    oOperacion.IndCore = Utilitario.ObtenerDatoComoCadena(dr["IND_CORE"], TipoDato.Cadena);
                    oOperacion.ValNdocJustif = Utilitario.ObtenerDatoComoCadena(dr["VALNDOC_JUSTIF"], TipoDato.Cadena);
                    oOperacion.FecRecepcion = Utilitario.ObtenerDatoComoCadena(dr["FEC_RECEPCION"], TipoDato.Cadena);
                    oOperacion.FecRegistro = Utilitario.ObtenerDatoComoCadena(dr["FEC_REGISTRO"], TipoDato.Cadena);
                    oOperacion.IndFlujo = Utilitario.ObtenerDatoComoCadena(dr["IND_FLUJO"], TipoDato.Cadena);
                    oOperacion.ObsCli = Utilitario.ObtenerDatoComoCadena(dr["OBS_CLI"], TipoDato.Cadena);
                    oOperacion.CierreBatch = Utilitario.ObtenerDatoComoCadena(dr["CIERRE_BATCH"], TipoDato.Cadena);
                    oOperacion.Citiscreening = Utilitario.ObtenerDatoComoCadena(dr["CITISCREENING"], TipoDato.Cadena);
                    oOperacion.SecCitiscreening = Utilitario.ObtenerDatoComoCadena(dr["SEC_CITISCREENING"], TipoDato.Cadena);
                    #endregion

                    lstOperacion.Add(oOperacion);
                }
            }
            catch (Exception ex)
            {
                lstOperacion = null;
                ManejarExcepcion(ex);
            }
            finally
            {
                if (dr != null && !dr.IsClosed) dr.Close();
                if (cnx != null && cnx.State != ConnectionState.Closed) cnx.Close();
            }

            return lstOperacion;
        }

        public bool Actualizar_Operaciones_Enviadas_BCosmos(string strBcrpRef, string strGeneroAdes, Int64 nFecTime)
        {
            AseConnection cnx = null;
            bool blnEjecucion = false;

            try
            {
                cnx = new AseConnection(strCadenaConexion);
                AseCommand cmd = new AseCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "p_tbe_actualizar_ope_envio_bcosmos";
                cmd.Connection = cnx;
                cmd.CommandTimeout = Convert.ToInt32(DuracionConexion.Corta);

                cmd.Parameters.Add("@BCRP_REFER", AseDbType.Char, 15).Direction = ParameterDirection.Input;
                cmd.Parameters["@BCRP_REFER"].Value = Utilitario.SetearComoParametro(strBcrpRef, TipoDato.Cadena);

                cmd.Parameters.Add("@GENERO_ADES", AseDbType.Char, 1).Direction = ParameterDirection.Input;
                cmd.Parameters["@GENERO_ADES"].Value = Utilitario.SetearComoParametro(strGeneroAdes, TipoDato.Cadena);

                cmd.Parameters.Add("@N_FECTIME", AseDbType.Numeric, 14).Direction = ParameterDirection.Input;
                cmd.Parameters["@N_FECTIME"].Value = Utilitario.SetearComoParametro(nFecTime);

                cnx.Open();

                cmd.ExecuteNonQuery();

                blnEjecucion = true;
            }
            catch (Exception ex)
            {
                blnEjecucion = false;
                ManejarExcepcion(ex);
            }
            finally
            {
                if (cnx != null && cnx.State != ConnectionState.Closed) cnx.Close();
            }

            return blnEjecucion;
        }

        public bool Actualizar_Operaciones_Devueltas_BCosmos(string strBcrpRef, string strDebito, string strCredito, string strConfirmaAbono)
        {
            AseConnection cnx = null;
            bool blnEjecucion = false;

            try
            {
                cnx = new AseConnection(strCadenaConexion);
                AseCommand cmd = new AseCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "p_tbe_actualizar_ope_respuesta_bcosmos";
                cmd.Connection = cnx;
                cmd.CommandTimeout = Convert.ToInt32(DuracionConexion.Corta);

                cmd.Parameters.Add("@BCRP_REFER", AseDbType.Char, 15).Direction = ParameterDirection.Input;
                cmd.Parameters["@BCRP_REFER"].Value = Utilitario.SetearComoParametro(strBcrpRef, TipoDato.Cadena);

                cmd.Parameters.Add("@ESTADO_DEBITO", AseDbType.Char, 1).Direction = ParameterDirection.Input;
                cmd.Parameters["@ESTADO_DEBITO"].Value = Utilitario.SetearComoParametro(strDebito, TipoDato.Cadena);

                cmd.Parameters.Add("@ESTADO_CREDITO", AseDbType.Char, 1).Direction = ParameterDirection.Input;
                cmd.Parameters["@ESTADO_CREDITO"].Value = Utilitario.SetearComoParametro(strCredito, TipoDato.Cadena);

                cmd.Parameters.Add("@CONFIRMAABONO", AseDbType.Char, 1).Direction = ParameterDirection.Input;
                cmd.Parameters["@CONFIRMAABONO"].Value = Utilitario.SetearComoParametro(strConfirmaAbono, TipoDato.Cadena);

                cnx.Open();

                cmd.ExecuteNonQuery();

                blnEjecucion = true;
            }
            catch (Exception ex)
            {
                blnEjecucion = false;
                ManejarExcepcion(ex);
            }
            finally
            {
                if (cnx != null && cnx.State != ConnectionState.Closed) cnx.Close();
            }

            return blnEjecucion;
        }

        public string Obtener_Operacion_Speed_Collect(string strNroCta)
        {
            string strRespuesta = "";
            AseConnection cnx = null;
            AseDataReader dr = null;

            try
            {
                cnx = new AseConnection(strCadenaConexion);
                AseCommand cmd = new AseCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "p_tbe_operacion_speed_collect";
                cmd.Connection = cnx;
                cmd.CommandTimeout = Convert.ToInt32(DuracionConexion.Mediana);

                cmd.Parameters.Add("@NRO_CTA", AseDbType.VarChar, 25).Direction = ParameterDirection.Input;
                cmd.Parameters["@NRO_CTA"].Value = Utilitario.SetearComoParametro(strNroCta, TipoDato.Cadena);

                cnx.Open();

                dr = cmd.ExecuteReader(CommandBehavior.CloseConnection);

                while (dr.Read())
                {
                    strRespuesta = Utilitario.ObtenerDatoComoCadena(dr["PROOF_CHART"], TipoDato.Cadena);
                }

            }
            catch (Exception ex)
            {
                strRespuesta = "";
                ManejarExcepcion(ex);
            }
            finally
            {
                if (dr != null && !dr.IsClosed) dr.Close();
                if (cnx != null && cnx.State != ConnectionState.Closed) cnx.Close();
            }

            return strRespuesta;
        }

        public int Verificar_Conceptos_BCosmos()
        {
            AseConnection cnx = null;
            int nConcepto = -1;

            try
            {
                cnx = new AseConnection(strCadenaConexion);
                AseCommand cmd = new AseCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "p_tbe_verificar_conceptos_bcosmos";
                cmd.Connection = cnx;
                cmd.CommandTimeout = Convert.ToInt32(DuracionConexion.Corta);

                cnx.Open();

                nConcepto = Convert.ToInt32(cmd.ExecuteScalar());
            }
            catch (Exception ex)
            {
                nConcepto = -1;
                ManejarExcepcion(ex);
            }
            finally
            {
                if (cnx != null && cnx.State != ConnectionState.Closed) cnx.Close();
            }

            return nConcepto;
        }

        public string Obtener_Error_BCosmos(string strCodigo)
        {
            string strDescripcion = "";
            AseConnection cnx = null;
            AseDataReader dr = null;

            try
            {
                cnx = new AseConnection(strCadenaConexion);
                AseCommand cmd = new AseCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "p_tbe_obtener_error_bcosmos";
                cmd.Connection = cnx;
                cmd.CommandTimeout = Convert.ToInt32(DuracionConexion.Mediana);

                cmd.Parameters.Add("@s_corr_id", AseDbType.Char, 3).Direction = ParameterDirection.Input;
                cmd.Parameters["@s_corr_id"].Value = Utilitario.SetearComoParametro(strCodigo, TipoDato.Cadena);

                cnx.Open();

                dr = cmd.ExecuteReader(CommandBehavior.CloseConnection);

                while (dr.Read())
                {
                    strDescripcion = Utilitario.ObtenerDatoComoCadena(dr["s_desc_err_lat8"], TipoDato.Cadena);
                }

            }
            catch (Exception ex)
            {
                strDescripcion = "";
                ManejarExcepcion(ex);
            }
            finally
            {
                if (dr != null && !dr.IsClosed) dr.Close();
                if (cnx != null && cnx.State != ConnectionState.Closed) cnx.Close();
            }

            return strDescripcion;
        }

        public BE_DatosOperacion Obtener_Datos_Operaciones_Recibidas(string strBcrpRefer)
        {
            BE_DatosOperacion oOperacion = new BE_DatosOperacion();
            AseConnection cnx = null;
            AseDataReader dr = null;

            try
            {
                cnx = new AseConnection(strCadenaConexion);
                AseCommand cmd = new AseCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "p_tbe_obtener_datos_operacion";
                cmd.Connection = cnx;
                cmd.CommandTimeout = Convert.ToInt32(DuracionConexion.Mediana);

                cmd.Parameters.Add("@BCRP_REFER", AseDbType.Char, 15).Direction = ParameterDirection.Input;
                cmd.Parameters["@BCRP_REFER"].Value = Utilitario.SetearComoParametro(strBcrpRefer, TipoDato.Cadena);

                cnx.Open();

                dr = cmd.ExecuteReader(CommandBehavior.CloseConnection);

                while (dr.Read())
                {
                    oOperacion = new BE_DatosOperacion();

                    #region Valores

                    oOperacion.BcrpRefer = Utilitario.ObtenerDatoComoCadena(dr["REFBCR"], TipoDato.Cadena);
                    oOperacion.Fecha = Utilitario.ObtenerDatoComoCadena(dr["FECHA"], TipoDato.Cadena);
                    oOperacion.Hora = Utilitario.ObtenerDatoComoCadena(dr["HORA"], TipoDato.Cadena);
                    oOperacion.BcoOrig = Utilitario.ObtenerDatoComoCadena(dr["BCOORIG"], TipoDato.Cadena);
                    oOperacion.Moneda = Utilitario.ObtenerDatoComoCadena(dr["MONEDA"], TipoDato.Cadena);
                    oOperacion.Monto = Utilitario.ObtenerDatoComoCadena(dr["MONTO"], TipoDato.Cadena);
                    oOperacion.OperCta = Utilitario.ObtenerDatoComoCadena(dr["OPERCTA"], TipoDato.Cadena);
                    oOperacion.Clasificacion = Utilitario.ObtenerDatoComoCadena(dr["CLASIFICACION"], TipoDato.Cadena);
                    oOperacion.Concepto = Utilitario.ObtenerDatoComoCadena(dr["CONCEPTO"], TipoDato.Cadena);
                    oOperacion.Ordenante = Utilitario.ObtenerDatoComoCadena(dr["ORDENANTE"], TipoDato.Cadena);                    
                    oOperacion.Beneficiario = Utilitario.ObtenerDatoComoCadena(dr["BENEFICIARIO"], TipoDato.Cadena);
                    oOperacion.TipoDocBeneficiario = Utilitario.ObtenerDatoComoCadena(dr["TIPODOCBENEFICIARIO"], TipoDato.Cadena);//TIPODOCBENEFICIARIO
                    oOperacion.NumDocBeneficiario = Utilitario.ObtenerDatoComoCadena(dr["NUMDOCBENEFICIARIO"], TipoDato.Cadena);//NUMDOCBENEFICIARIO
                    oOperacion.BcoOrigRef = Utilitario.ObtenerDatoComoCadena(dr["BCOORIREF"], TipoDato.Cadena);
                    oOperacion.BcoOrigRefSec = Utilitario.ObtenerDatoComoCadena(dr["BCOORIREFSEC"], TipoDato.Cadena);
                    oOperacion.CciBeneficiario = Utilitario.ObtenerDatoComoCadena(dr["CCIBENEFICIARIO"], TipoDato.Cadena);
                    oOperacion.IndicadorItf = Utilitario.ObtenerDatoComoCadena(dr["INDICADORITF"], TipoDato.Cadena);
                    oOperacion.RefTBE = Utilitario.ObtenerDatoComoCadena(dr["REFTBE"], TipoDato.Cadena);//REFTBE
                    oOperacion.Observacion = Utilitario.ObtenerDatoComoCadena(dr["OBSERVACIONES"], TipoDato.Cadena);//OBSERVACIONES
                    #endregion
                }

            }
            catch (Exception ex)
            {
                oOperacion = null;
                ManejarExcepcion(ex);
            }
            finally
            {
                if (dr != null && !dr.IsClosed) dr.Close();
                if (cnx != null && cnx.State != ConnectionState.Closed) cnx.Close();
            }

            return oOperacion;
        }

        public bool Verificar_Tipo_Cambio_BCosmos()
        {
            AseConnection cnx = null;
            bool blnRespuesta = false;

            try
            {
                cnx = new AseConnection(strCadenaConexion);
                AseCommand cmd = new AseCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "p_tbe_verificar_tipo_cambio";
                cmd.Connection = cnx;
                cmd.CommandTimeout = Convert.ToInt32(DuracionConexion.Corta);

                cnx.Open();

                blnRespuesta = cmd.ExecuteScalar().ToString().Trim() == "1" ? true : false;
            }
            catch (Exception ex)
            {
                blnRespuesta = false;
                ManejarExcepcion(ex);
            }
            finally
            {
                if (cnx != null && cnx.State != ConnectionState.Closed) cnx.Close();
            }

            return blnRespuesta;
        }

        public bool Actualizar_Operaciones_Recibidas(string strBcrpRef, string strCierreBatch)
        {
            AseConnection cnx = null;
            bool blnEjecucion = false;

            try
            {
                cnx = new AseConnection(strCadenaConexion);
                AseCommand cmd = new AseCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "p_tbe_actualizar_oper_recibidas";
                cmd.Connection = cnx;
                cmd.CommandTimeout = Convert.ToInt32(DuracionConexion.Corta);

                cmd.Parameters.Add("@BCRP_REFER", AseDbType.Char, 15).Direction = ParameterDirection.Input;
                cmd.Parameters["@BCRP_REFER"].Value = Utilitario.SetearComoParametro(strBcrpRef, TipoDato.Cadena);

                cmd.Parameters.Add("@CIERRE_BATCH", AseDbType.Char, 1).Direction = ParameterDirection.Input;
                cmd.Parameters["@CIERRE_BATCH"].Value = Utilitario.SetearComoParametro(strCierreBatch, TipoDato.Cadena);

                cnx.Open();

                cmd.ExecuteNonQuery();

                blnEjecucion = true;
            }
            catch (Exception ex)
            {
                blnEjecucion = false;
                ManejarExcepcion(ex);
            }
            finally
            {
                if (cnx != null && cnx.State != ConnectionState.Closed) cnx.Close();
            }

            return blnEjecucion;
        }

        public bool Actualizar_Estado_Citiscreening(string strBcrpRef, string strEstadoCitiscreening)
        {
            AseConnection cnx = null;
            bool blnEjecucion = false;
            try
            {
                cnx = new AseConnection(strCadenaConexion);
                
                AseCommand cmd = new AseCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "p_tbe_actualizar_estado_citiscreening";
                cmd.Connection = cnx;
                cmd.CommandTimeout = Convert.ToInt32(DuracionConexion.Corta);
                cmd.Parameters.Add("@BCRP_REFER", AseDbType.Char, 15).Direction = ParameterDirection.Input;
                cmd.Parameters["@BCRP_REFER"].Value = Utilitario.SetearComoParametro(strBcrpRef, TipoDato.Cadena);
                cmd.Parameters.Add("@CITISCREENING", AseDbType.Char, 1).Direction = ParameterDirection.Input;
                cmd.Parameters["@CITISCREENING"].Value = Utilitario.SetearComoParametro(strEstadoCitiscreening, TipoDato.Cadena);
                cnx.Open();
                cmd.ExecuteNonQuery();
                blnEjecucion = true;
            }
            catch (Exception ex)
            {
                blnEjecucion = false;
                ManejarExcepcion(ex);
            }
            finally
            {
                if (cnx != null && cnx.State != ConnectionState.Closed) cnx.Close();
            }
            return blnEjecucion;
        }
    }
}
//hh72295:20170117:F: ADECUACION CITISCREENING EN OPERACIONES DE ENTRADA
