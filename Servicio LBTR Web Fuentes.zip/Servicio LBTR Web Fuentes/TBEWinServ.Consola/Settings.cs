namespace TBEWinServ.Consola.Properties {
    
    
    // Esta clase le permite controlar eventos especificos en la clase de configuracion:
    //  El evento SettingChanging se desencadena antes de cambiar un valor de configuracion.
    //  El evento PropertyChanged se desencadena despues de cambiar el valor de configuracion.
    //  El evento SettingsLoaded se desencadena despues de cargar los valores de configuracion.
    //  El evento SettingsSaving se desencadena antes de guardar los valores de configuracion.
    internal sealed partial class Settings {
        
        public Settings() {
            // // Para agregar los controladores de eventos para guardar y cambiar la configuracion, quite la marca de comentario de las lineas:
            //
            // this.SettingChanging += this.SettingChangingEventHandler;
            //
            // this.SettingsSaving += this.SettingsSavingEventHandler;
            //
        }
        
        private void SettingChangingEventHandler(object sender, System.Configuration.SettingChangingEventArgs e) {
            // Agregar codigo para administrar aqui el evento SettingChangingEvent.
        }
        
        private void SettingsSavingEventHandler(object sender, System.ComponentModel.CancelEventArgs e) {
            // Agregar codigo para administrar aqui el evento SettingsSaving.
        }
    }
}
