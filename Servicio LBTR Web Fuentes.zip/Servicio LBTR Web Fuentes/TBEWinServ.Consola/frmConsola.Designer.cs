﻿namespace TBEWinServ.Consola
{
    partial class frmConsola
    {
        /// <summary>
        /// Variable del diseñador requerida.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén utilizando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben eliminar; false en caso contrario, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido del método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmConsola));
            this.notifyIcon1 = new System.Windows.Forms.NotifyIcon(this.components);
            this.cmsMenu = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.tsmMostrarPanel = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmSeparador2 = new System.Windows.Forms.ToolStripSeparator();
            this.tsmiIniciar = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiDetener = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmSeparador3 = new System.Windows.Forms.ToolStripSeparator();
            this.tsmiSalir = new System.Windows.Forms.ToolStripMenuItem();
            this.lblStatus = new System.Windows.Forms.Label();
            this.lblMensaje = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.tsbIniciar = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.tsbDetener = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.tslModo = new System.Windows.Forms.ToolStripLabel();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.tsbSalir = new System.Windows.Forms.ToolStripButton();
            this.pbxStatus = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtUsuarioFuncional = new System.Windows.Forms.TextBox();
            this.txtPasswordBD = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtPasswordLogon = new System.Windows.Forms.TextBox();
            this.btnAyuda = new System.Windows.Forms.Button();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.chkLogonBCRP = new System.Windows.Forms.CheckBox();
            this.cmsMenu.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxStatus)).BeginInit();
            this.SuspendLayout();
            // 
            // notifyIcon1
            // 
            this.notifyIcon1.ContextMenuStrip = this.cmsMenu;
            this.notifyIcon1.DoubleClick += new System.EventHandler(this.notifyIcon1_DoubleClick);
            // 
            // cmsMenu
            // 
            this.cmsMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmMostrarPanel,
            this.tsmSeparador2,
            this.tsmiIniciar,
            this.tsmiDetener,
            this.tsmSeparador3,
            this.tsmiSalir});
            this.cmsMenu.Name = "contextMenuStrip1";
            this.cmsMenu.Size = new System.Drawing.Size(165, 104);
            // 
            // tsmMostrarPanel
            // 
            this.tsmMostrarPanel.Image = global::TBEWinServ.Consola.resImagenes.png_panel;
            this.tsmMostrarPanel.Name = "tsmMostrarPanel";
            this.tsmMostrarPanel.Size = new System.Drawing.Size(164, 22);
            this.tsmMostrarPanel.Text = "Mostrar Panel";
            this.tsmMostrarPanel.Click += new System.EventHandler(this.tsmMostrarPanel_Click);
            // 
            // tsmSeparador2
            // 
            this.tsmSeparador2.Name = "tsmSeparador2";
            this.tsmSeparador2.Size = new System.Drawing.Size(161, 6);
            // 
            // tsmiIniciar
            // 
            this.tsmiIniciar.Image = global::TBEWinServ.Consola.resImagenes.png_play;
            this.tsmiIniciar.Name = "tsmiIniciar";
            this.tsmiIniciar.Size = new System.Drawing.Size(164, 22);
            this.tsmiIniciar.Text = "Iniciar Servicio";
            this.tsmiIniciar.Click += new System.EventHandler(this.IniciarServicio);
            // 
            // tsmiDetener
            // 
            this.tsmiDetener.Image = global::TBEWinServ.Consola.resImagenes.png_stop;
            this.tsmiDetener.Name = "tsmiDetener";
            this.tsmiDetener.Size = new System.Drawing.Size(164, 22);
            this.tsmiDetener.Text = "Detener Servicio";
            this.tsmiDetener.Click += new System.EventHandler(this.DetenerServicio);
            // 
            // tsmSeparador3
            // 
            this.tsmSeparador3.Name = "tsmSeparador3";
            this.tsmSeparador3.Size = new System.Drawing.Size(161, 6);
            // 
            // tsmiSalir
            // 
            this.tsmiSalir.Image = ((System.Drawing.Image)(resources.GetObject("tsmiSalir.Image")));
            this.tsmiSalir.Name = "tsmiSalir";
            this.tsmiSalir.Size = new System.Drawing.Size(164, 22);
            this.tsmiSalir.Text = "Salir";
            this.tsmiSalir.Click += new System.EventHandler(this.SalirAplicacion);
            // 
            // lblStatus
            // 
            this.lblStatus.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStatus.Location = new System.Drawing.Point(37, 338);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(267, 26);
            this.lblStatus.TabIndex = 1;
            this.lblStatus.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblMensaje
            // 
            this.lblMensaje.AutoSize = true;
            this.lblMensaje.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMensaje.Location = new System.Drawing.Point(35, 197);
            this.lblMensaje.Name = "lblMensaje";
            this.lblMensaje.Size = new System.Drawing.Size(274, 16);
            this.lblMensaje.TabIndex = 2;
            this.lblMensaje.Text = "El servicio no se encuentra instalado";
            this.lblMensaje.Visible = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(58, 156);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(223, 23);
            this.label1.TabIndex = 3;
            this.label1.Text = "Estado del Servicio:";
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbIniciar,
            this.toolStripSeparator1,
            this.tsbDetener,
            this.toolStripSeparator2,
            this.tslModo,
            this.toolStripSeparator3,
            this.tsbSalir});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Padding = new System.Windows.Forms.Padding(0);
            this.toolStrip1.Size = new System.Drawing.Size(334, 25);
            this.toolStrip1.TabIndex = 4;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // tsbIniciar
            // 
            this.tsbIniciar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbIniciar.Image = global::TBEWinServ.Consola.resImagenes.png_play;
            this.tsbIniciar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbIniciar.Name = "tsbIniciar";
            this.tsbIniciar.Size = new System.Drawing.Size(23, 22);
            this.tsbIniciar.Text = "toolStripButton1";
            this.tsbIniciar.ToolTipText = "Iniciar el servicio";
            this.tsbIniciar.Click += new System.EventHandler(this.IniciarServicio);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // tsbDetener
            // 
            this.tsbDetener.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbDetener.Image = global::TBEWinServ.Consola.resImagenes.png_stop;
            this.tsbDetener.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbDetener.Name = "tsbDetener";
            this.tsbDetener.Size = new System.Drawing.Size(23, 22);
            this.tsbDetener.Text = "toolStripButton2";
            this.tsbDetener.ToolTipText = "Detener el servicio";
            this.tsbDetener.Click += new System.EventHandler(this.DetenerServicio);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // tslModo
            // 
            this.tslModo.Name = "tslModo";
            this.tslModo.Size = new System.Drawing.Size(78, 22);
            this.tslModo.Text = "toolStripLabel1";
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 25);
            // 
            // tsbSalir
            // 
            this.tsbSalir.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbSalir.Image = ((System.Drawing.Image)(resources.GetObject("tsbSalir.Image")));
            this.tsbSalir.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbSalir.Name = "tsbSalir";
            this.tsbSalir.Size = new System.Drawing.Size(23, 22);
            this.tsbSalir.Text = "toolStripButton3";
            this.tsbSalir.ToolTipText = "Salir";
            this.tsbSalir.Click += new System.EventHandler(this.SalirAplicacion);
            // 
            // pbxStatus
            // 
            this.pbxStatus.Location = new System.Drawing.Point(104, 207);
            this.pbxStatus.Name = "pbxStatus";
            this.pbxStatus.Size = new System.Drawing.Size(128, 128);
            this.pbxStatus.TabIndex = 5;
            this.pbxStatus.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(8, 42);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(113, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "Usuario Funcional BD:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(8, 68);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(118, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "Contraseña de Usuario:";
            // 
            // txtUsuarioFuncional
            // 
            this.txtUsuarioFuncional.Location = new System.Drawing.Point(147, 35);
            this.txtUsuarioFuncional.Name = "txtUsuarioFuncional";
            this.txtUsuarioFuncional.Size = new System.Drawing.Size(118, 20);
            this.txtUsuarioFuncional.TabIndex = 8;
            // 
            // txtPasswordBD
            // 
            this.txtPasswordBD.Location = new System.Drawing.Point(147, 61);
            this.txtPasswordBD.Name = "txtPasswordBD";
            this.txtPasswordBD.PasswordChar = '*';
            this.txtPasswordBD.Size = new System.Drawing.Size(118, 20);
            this.txtPasswordBD.TabIndex = 9;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(9, 119);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(129, 13);
            this.label4.TabIndex = 10;
            this.label4.Text = "Contraseña Logon BCRP:";
            // 
            // txtPasswordLogon
            // 
            this.txtPasswordLogon.Enabled = false;
            this.txtPasswordLogon.Location = new System.Drawing.Point(147, 112);
            this.txtPasswordLogon.Name = "txtPasswordLogon";
            this.txtPasswordLogon.PasswordChar = '*';
            this.txtPasswordLogon.Size = new System.Drawing.Size(118, 20);
            this.txtPasswordLogon.TabIndex = 10;
            // 
            // btnAyuda
            // 
            this.btnAyuda.Image = global::TBEWinServ.Consola.resImagenes.Icono_ayuda;
            this.btnAyuda.Location = new System.Drawing.Point(271, 42);
            this.btnAyuda.Name = "btnAyuda";
            this.btnAyuda.Size = new System.Drawing.Size(58, 50);
            this.btnAyuda.TabIndex = 11;
            this.btnAyuda.UseVisualStyleBackColor = true;
            this.btnAyuda.Click += new System.EventHandler(this.btnAyuda_Click);
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton1.Image")));
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton1.Text = "toolStripButton1";
            // 
            // chkLogonBCRP
            // 
            this.chkLogonBCRP.AutoSize = true;
            this.chkLogonBCRP.Location = new System.Drawing.Point(14, 93);
            this.chkLogonBCRP.Name = "chkLogonBCRP";
            this.chkLogonBCRP.Size = new System.Drawing.Size(178, 17);
            this.chkLogonBCRP.TabIndex = 12;
            this.chkLogonBCRP.Text = "Enviar Contraseña Logon BCRP";
            this.chkLogonBCRP.UseVisualStyleBackColor = true;
            this.chkLogonBCRP.CheckedChanged += new System.EventHandler(this.chkLogonBCRP_CheckedChanged);
            // 
            // frmConsola
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.WhiteSmoke;
            this.ClientSize = new System.Drawing.Size(334, 375);
            this.Controls.Add(this.chkLogonBCRP);
            this.Controls.Add(this.btnAyuda);
            this.Controls.Add(this.txtPasswordLogon);
            this.Controls.Add(this.txtPasswordBD);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtUsuarioFuncional);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.pbxStatus);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblStatus);
            this.Controls.Add(this.lblMensaje);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "frmConsola";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Load += new System.EventHandler(this.frmConsola_Load);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmConsola_FormClosing);
            this.Resize += new System.EventHandler(this.frmConsola_Resize);
            this.cmsMenu.ResumeLayout(false);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxStatus)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        
        #endregion

        private System.Windows.Forms.NotifyIcon notifyIcon1;
        private System.Windows.Forms.ContextMenuStrip cmsMenu;
        private System.Windows.Forms.ToolStripMenuItem tsmiIniciar;
        private System.Windows.Forms.ToolStripMenuItem tsmiDetener;
        private System.Windows.Forms.ToolStripSeparator tsmSeparador2;
        private System.Windows.Forms.ToolStripMenuItem tsmiSalir;
        private System.Windows.Forms.Label lblStatus;
        private System.Windows.Forms.Label lblMensaje;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton tsbIniciar;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripButton tsbDetener;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripButton tsbSalir;
        private System.Windows.Forms.ToolStripMenuItem tsmMostrarPanel;
        private System.Windows.Forms.PictureBox pbxStatus;
        private System.Windows.Forms.ToolStripSeparator tsmSeparador3;
        private System.Windows.Forms.ToolStripLabel tslModo;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtUsuarioFuncional;
        private System.Windows.Forms.TextBox txtPasswordBD;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtPasswordLogon;
        private System.Windows.Forms.Button btnAyuda;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.CheckBox chkLogonBCRP;
    }
}