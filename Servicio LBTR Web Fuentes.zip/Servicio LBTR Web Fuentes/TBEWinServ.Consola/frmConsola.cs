using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using Sybase.Data.AseClient;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.ServiceProcess;
using System.Threading;
using System.Diagnostics;
using System.Xml;
using System.IO;
using TBEWinServ.Utilitarios;

namespace TBEWinServ.Consola
{
    public partial class frmConsola : FrmBase
    {
        private string strNombreServicioMQ = ConfigurationManager.AppSettings["NOMBRE_SERVICIO"];
        private string strNombreDescriptivoServicioMQ = ConfigurationManager.AppSettings["NOMBRE_DESCRIPTIVO_SERVICIO"];
        private string strNombreAplicacion = ConfigurationManager.AppSettings["NOMBRE_APLICACION"];
        private string strServidorSybase = ConfigurationManager.AppSettings["SERVIDOR_SYBASE"];
        private string strBDSybaseGENDB = ConfigurationManager.AppSettings["BASE_DATOS_GENDB"];
        private string strBDSybaseICODB = ConfigurationManager.AppSettings["BASE_DATOS_ICODB"];
        private string strBDSybaseSTBDB = ConfigurationManager.AppSettings["BASE_DATOS_STBDB"];
        private string strPuertoSybase = ConfigurationManager.AppSettings["PUERTO_SYBASE"];
        private string strServidorMSSQL = ConfigurationManager.AppSettings["SERVIDOR_SIXSEC"];
        private string strBaseDatosMSSQL = ConfigurationManager.AppSettings["BASE_DATOS_SIXSEC"];
        private string strUsarSG = ConfigurationManager.AppSettings["USARSG"];
        private string strTiempoEsperaServDetenido = ConfigurationManager.AppSettings["TIEMPO_ESPERA_SERVDETENIDO"];
        private double dbTiempoEsperaServDetenido = 10;//en minutos
        private Thread m_Hilo;
        private System.Timers.Timer timer1;
        private EstadoServicio estadoServicioActual;
        private EstadoServicio estadoServicioAnterior;
        private SecurityGateway.USerInformation oUserInfo = new SecurityGateway.USerInformation();
        private bool blnLogueado = false;
        private bool blnOpcionInicioAccedido = false;
        
        public frmConsola()
        {
            InitializeComponent();

            double.TryParse(strTiempoEsperaServDetenido, out dbTiempoEsperaServDetenido);
            
            SecurityGateway.UseSG = false;            
            if (!String.IsNullOrEmpty(strUsarSG))
            {
                if (strUsarSG.ToLower().Equals("true"))
                {
                    SecurityGateway.UseSG = true;
                }
            }
            
            this.Text = strNombreDescriptivoServicioMQ;
            this.Icon = global::TBEWinServ.Consola.resImagenes.icono_semaforo;
            this.notifyIcon1.Icon = global::TBEWinServ.Consola.resImagenes.icono_semaforo;
            //ListarServiciosEnMenu();
        }

        #region Eventos del formulario

        private void frmConsola_Load(object sender, EventArgs e)
        {
            if (SecurityGateway.UseSG)
            {
                tslModo.Text = "Configurado con Security Gateway";
                txtUsuarioFuncional.Enabled = false;
                txtPasswordBD.Enabled = false;
            }
            else
            {
                tslModo.Text = "Configurado sin Security Gateway";
                txtUsuarioFuncional.Enabled = true;
                txtPasswordBD.Enabled = true;
            }
            EstablecerAccesosMenu(); 
            VerificarEstadoDeServicioMQ();

            this.timer1 = new System.Timers.Timer(1000);
            this.timer1.Elapsed += new System.Timers.ElapsedEventHandler(timer1_Elapsed);
            this.timer1.Start();            
        }
                
        private void LimpiarRecursos()
        {
            if (this.m_Hilo != null && this.m_Hilo.IsAlive) this.m_Hilo.Abort();
            this.timer1.Stop();
            this.timer1.Close();

            if(blnLogueado)
            {
                if (blnOpcionInicioAccedido)
                {
                    SecurityGateway.Opcion = tsmiIniciar.Tag.ToString();
                    SecurityGateway.f2b();
                }
                else
                {
                    SecurityGateway.Opcion = "0*0";
                    SecurityGateway.f3();
                }
                
            }
        }

        void frmConsola_FormClosing(object sender, System.Windows.Forms.FormClosingEventArgs e)
        {
            string strPregunta = "�Est� Ud. seguro de salir de la aplicaci�n?";

            if (MessageBox.Show(strPregunta, "Mensaje", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                LimpiarRecursos();
            }
            else
                e.Cancel = true;            
        }

        void frmConsola_Resize(object sender, System.EventArgs e)
        {
            if (this.WindowState == FormWindowState.Minimized) {
                this.Hide();
                notifyIcon1.Visible = true;                
            }

        }

        private void notifyIcon1_DoubleClick(object sender, EventArgs e)
        {
            tsmMostrarPanel_Click(null, null);
        }

        #endregion

        #region Manejador del proceso en forma continua sin interrumpir el proceso principal

        void timer1_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
        {
            this.timer1.Stop();
            
            if (m_Hilo==null || !m_Hilo.IsAlive)
            {
                if (m_Hilo!=null) m_Hilo.Abort();
                m_Hilo = new Thread(VerificarEstadoDeServicioMQ);
                m_Hilo.Start();                
            }
            
            this.timer1.Start();
        }

        #endregion

        #region Valida el estado del servicio windows

        private void VerificarEstadoDeServicioMQ() {
            this.ValidarEstadoDeServicioMQ();            
        }

        private delegate void delegadoVerificarEstadoDeServicio();

        private void ValidarEstadoDeServicioMQ() {
            if (this.InvokeRequired) {
                delegadoVerificarEstadoDeServicio d = new delegadoVerificarEstadoDeServicio(ValidarEstadoDeServicioMQ);
                this.Invoke(d);
            } else {
                this.ActualizarEstadoServicio();
            }
        
        }

        private void ActualizarEstadoServicio()
        {

            if (ExisteServicioMQ())
            {
                ServiceController objServiceController = new ServiceController(strNombreServicioMQ);

                this.pbxStatus.Visible = true;
                this.lblStatus.Visible = true;
                this.lblMensaje.Visible = false;

                switch (objServiceController.Status)
                {
                    case ServiceControllerStatus.StartPending:
                    case ServiceControllerStatus.StopPending:
                        if (objServiceController.Status == ServiceControllerStatus.StartPending)
                        {
                            estadoServicioActual = EstadoServicio.INICIANDO;
                            this.pbxStatus.Image = global::TBEWinServ.Consola.resImagenes.png_estado_iniciado;
                            this.lblStatus.Text = "INICIANDO...";
                            this.notifyIcon1.Icon = global::TBEWinServ.Consola.resImagenes.icono_verde;
                            this.notifyIcon1.Text = strNombreDescriptivoServicioMQ + " - Iniciando";
                        }
                        else
                        {
                            estadoServicioActual = EstadoServicio.DETENIENDO;
                            this.pbxStatus.Image = global::TBEWinServ.Consola.resImagenes.png_estado_detenido;
                            this.lblStatus.Text = "DETENIENDO...";
                            this.notifyIcon1.Icon = global::TBEWinServ.Consola.resImagenes.icono_rojo;
                            this.notifyIcon1.Text = strNombreDescriptivoServicioMQ + " - Deteniendo";
                        }
                                                
                        this.tsbDetener.Enabled = false;
                        this.tsmiDetener.Enabled = false;
                        this.tsbIniciar.Enabled = false;
                        this.tsmiIniciar.Enabled = false;
                        
                        if (estadoServicioAnterior != estadoServicioActual)
                        {
                            if (objServiceController.Status == ServiceControllerStatus.StartPending)
                                MostrarBurbujaEnTaskBar(strNombreDescriptivoServicioMQ, strNombreDescriptivoServicioMQ + " inici�ndose.");
                            else
                                MostrarBurbujaEnTaskBar(strNombreDescriptivoServicioMQ, strNombreDescriptivoServicioMQ + " deteni�ndose.");

                            estadoServicioAnterior = estadoServicioActual;
                        }

                        break;
                    case ServiceControllerStatus.Running:
                        estadoServicioActual = EstadoServicio.INICIADO;
                        this.pbxStatus.Image = global::TBEWinServ.Consola.resImagenes.png_estado_iniciado;                        
                        this.tsbDetener.Enabled = true;
                        this.tsmiDetener.Enabled = true;                        
                        this.tsbIniciar.Enabled = false;
                        this.tsmiIniciar.Enabled = false;                        
                        this.lblStatus.Text = "INICIADO";
                        this.notifyIcon1.Icon = global::TBEWinServ.Consola.resImagenes.icono_verde;
                        this.notifyIcon1.Text = strNombreDescriptivoServicioMQ + " - Iniciado";

                        if (estadoServicioAnterior != estadoServicioActual)
                        {
                            MostrarBurbujaEnTaskBar(strNombreDescriptivoServicioMQ, strNombreDescriptivoServicioMQ + " ha sido iniciado.");
                            estadoServicioAnterior = estadoServicioActual;
                        }

                        break;
                    case ServiceControllerStatus.Stopped:
                        estadoServicioActual = EstadoServicio.DETENIDO;
                        this.pbxStatus.Image = global::TBEWinServ.Consola.resImagenes.png_estado_detenido;                        
                        this.tsbDetener.Enabled = false;
                        this.tsmiDetener.Enabled = false;                        
                        this.tsbIniciar.Enabled = true;
                        this.tsmiIniciar.Enabled = true;
                        this.lblStatus.Text = "DETENIDO";
                        this.notifyIcon1.Icon = global::TBEWinServ.Consola.resImagenes.icono_rojo;
                        this.notifyIcon1.Text = strNombreDescriptivoServicioMQ + " - Detenido";

                        if (estadoServicioAnterior != estadoServicioActual)
                        {
                            MostrarBurbujaEnTaskBar(strNombreDescriptivoServicioMQ, strNombreDescriptivoServicioMQ + " ha sido detenido.");
                            estadoServicioAnterior = estadoServicioActual;
                        }

                        break;
                }

            }
            else
            {
                estadoServicioActual = EstadoServicio.NO_INSTALADO;
                this.pbxStatus.Visible = false;
                this.lblStatus.Text = "";
                this.lblStatus.Visible = false;
                this.lblMensaje.Visible = true;                
                this.tsbDetener.Enabled = false;
                this.tsmiDetener.Enabled = false;                
                this.tsbIniciar.Enabled = false;                
                this.tsmiIniciar.Enabled = false;
                this.notifyIcon1.Icon = global::TBEWinServ.Consola.resImagenes.icono_semaforo;
                this.notifyIcon1.Text = strNombreDescriptivoServicioMQ;

                if (estadoServicioAnterior != estadoServicioActual)
                {
                    MostrarBurbujaEnTaskBar(strNombreDescriptivoServicioMQ, "El servicio " + strNombreDescriptivoServicioMQ + " no se encuentra instalado.");
                    estadoServicioAnterior = estadoServicioActual;
                }
                
            }
            
        }

        private void MostrarBurbujaEnTaskBar(string prmTitulo, string prmTexto) {
            this.notifyIcon1.ShowBalloonTip(5000, prmTitulo, prmTexto, ToolTipIcon.Info);        
        }

        private bool ExisteServicioMQ() {
            bool blnExiste = false;

            ServiceController[] lstServiceController = ServiceController.GetServices();

            for (int i = 0; i < lstServiceController.Length; i++)
            {
                if (lstServiceController[i].ServiceName == strNombreServicioMQ)
                {
                    blnExiste = true;
                    break;
                }
            }

            return blnExiste;        
        }
        
        #endregion

        #region Eventos del menu
        
        private void tsmMostrarPanel_Click(object sender, EventArgs e)
        {
            this.Show();
            this.WindowState = FormWindowState.Normal;
            notifyIcon1.Visible = false;
        }
        
        private void SalirAplicacion(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void DetenerServicio(object sender, EventArgs e)
        {
            try
            {
                LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.CONTINGENCIA,
                Utilitario.RetornaHashCode(Thread.CurrentThread.GetHashCode()),
                "DetenerServicio()", "Se procede a detener el servicio " + strNombreServicioMQ + ".", false);

                ServiceController objServiceController = new ServiceController(strNombreServicioMQ);
                objServiceController.Stop();
            }
            catch (Exception ex) 
            {
                LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.CONTINGENCIA,
                Utilitario.RetornaHashCode(Thread.CurrentThread.GetHashCode()),
                "DetenerServicio()", "El servicio no pudo ser detenido debido a: \r\n" + ex.Message + "\r\n" + ex.StackTrace, false);

                MessageBox.Show("El servicio no pudo ser detenido debido a: \r\n" + ex.Message + "\r\n" + ex.StackTrace, strNombreDescriptivoServicioMQ, MessageBoxButtons.OK, MessageBoxIcon.Information);            
            }
        }

        private void IniciarServicio(object sender, EventArgs e)
        {            
            try
            {
                ToolStripItem tsiMenuOpcion = null;

                if (sender.GetType().Equals(typeof(ToolStripButton)))
                    tsiMenuOpcion = (ToolStripButton)sender;
                else if (sender.GetType().Equals(typeof(ToolStripMenuItem)))
                    tsiMenuOpcion = (ToolStripMenuItem)sender;

                if (SecurityGateway.UseSG)
                {
                    oUserInfo.lApplicationId = 6417; //Codigo Aplicacion
                    oUserInfo.sAppName = ConfigurationManager.AppSettings.Get("NOMBRE_APLICACION"); ;
                    oUserInfo.sAppPath = ConfigurationManager.AppSettings.Get("CONFIGSG"); ;

                    SecurityGateway.Userinfo = oUserInfo;
                    SecurityGateway.Opcion = "0*0";

                    if (SecurityGateway.f1() == 1) //Opcion de Login en SECURITY
                    {
                        blnLogueado = true;

                        if (TienePermiso(tsiMenuOpcion.Tag.ToString()))//verificar si es necesario
                        {
                            blnOpcionInicioAccedido = true;

                            if (ValidarConexiones(SecurityGateway.Userinfo.sLoginId, SecurityGateway.Userinfo.sPassword))
                            {
                                LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.CONTINGENCIA,
                                Utilitario.RetornaHashCode(Thread.CurrentThread.GetHashCode()),
                                "IniciarServicio()", "Se procede a iniciar el servicio " + strNombreServicioMQ + " con SG.", false);

                                ServiceController objServiceController1 = new ServiceController(strNombreServicioMQ);
                                string[] arrParametros1 = { SecurityGateway.Userinfo.sLoginId, SecurityGateway.Userinfo.sPassword, txtPasswordLogon.Text.Trim() };
                                objServiceController1.Start(arrParametros1);                                
                            }
                        }
                        else
                        {
                            MessageBox.Show("No tiene acceso para iniciar el servicio windows.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        }
                    }
                }
                else //usuario BaseDatos
                {
                    oUserInfo.sLoginId = txtUsuarioFuncional.Text.Trim();//"StbLbtrWeb";
                    oUserInfo.sPassword = txtPasswordBD.Text.Trim(); //"StbLbtrWeb001";
                    SecurityGateway.Userinfo = oUserInfo;

                    if (String.IsNullOrEmpty(SecurityGateway.Userinfo.sLoginId) ||
                        String.IsNullOrEmpty(SecurityGateway.Userinfo.sPassword))
                    {
                        MessageBox.Show("Usuario Funcional y su contrase�a son requeridos.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    }
                    else
                    {
                        if (ValidarConexiones(SecurityGateway.Userinfo.sLoginId, SecurityGateway.Userinfo.sPassword))
                        {
                            LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.CONTINGENCIA,
                            Utilitario.RetornaHashCode(Thread.CurrentThread.GetHashCode()),
                            "IniciarServicio()", "Se procede a iniciar el servicio " + strNombreServicioMQ + " sin SG.", false);

                            ServiceController objServiceController2 = new ServiceController(strNombreServicioMQ);
                            string[] arrParametros2 = { SecurityGateway.Userinfo.sLoginId, SecurityGateway.Userinfo.sPassword, txtPasswordLogon.Text.Trim() };
                            objServiceController2.Start(arrParametros2);
                        }
                    }
                }
            }
            catch (Exception ex) 
            {
                LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.CONTINGENCIA,
                Utilitario.RetornaHashCode(Thread.CurrentThread.GetHashCode()),
                "IniciarServicio()", "El servicio no pudo ser iniciado debido a: \r\n" + ex.Message + "\r\n" + ex.StackTrace, false);

                MessageBox.Show("El servicio no pudo ser iniciado debido a: \r\n" + ex.Message + "\r\n" + ex.StackTrace, strNombreDescriptivoServicioMQ, MessageBoxButtons.OK, MessageBoxIcon.Information);            
            }
        }
                
        #endregion

        #region Manejo de las aplicaciones (servicios) para comunicar con el servicio

        /*
        private void LimpiarServiciosEnMenu() {
            this.tsmServicios.DropDownItems.Clear();
            this.tsddbServicios.DropDownItems.Clear();
        }

        private void ListarServiciosEnMenu() {
            List<BEE_Servicio> lstServicios = null;

            try
            {
                LimpiarServiciosEnMenu();

                lstServicios = (new BL_AdministradorServicio(strRutaArchivoServicios)).LeerServiciosXML();

                if (lstServicios != null)
                {

                    foreach (BEE_Servicio oServicio in lstServicios)
                    {
                        //Items para el menu contextual
                        ToolStripMenuItem tsmServicio = new ToolStripMenuItem();
                        tsmServicio.Text = oServicio.Nombre;
                        tsmServicio.CheckOnClick = true;
                        tsmServicio.Checked = oServicio.Habilitado;
                        tsmServicio.Name = "tsm1_" + oServicio.Codigo;
                        tsmServicio.Tag = Constantes.IdOpcionDeshabilitarProcesos;
                        tsmServicio.CheckedChanged += new EventHandler(tsmServicio_CheckedChanged);
                        this.tsmServicios.DropDownItems.Add(tsmServicio);

                        //Items para el menu del panel
                        ToolStripMenuItem tsmServicio2 = new ToolStripMenuItem();
                        tsmServicio2.Text = oServicio.Nombre;
                        tsmServicio2.CheckOnClick = true;
                        tsmServicio2.Checked = oServicio.Habilitado;
                        tsmServicio2.Name = "tsm2_" + oServicio.Codigo;
                        tsmServicio2.Tag = Constantes.IdOpcionDeshabilitarProcesos;
                        tsmServicio2.CheckedChanged += new EventHandler(tsmServicio_CheckedChanged);
                        this.tsddbServicios.DropDownItems.Add(tsmServicio2);
                    }

                }
            }
            catch (FileNotFoundException ex) {
                MessageBox.Show("El archivo de servicios no se ha encontrado. Ninguna trama ser� procesada\r\n\r\n" + ex.Message, strNombreDescriptivoServicioMQ, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error en la aplicaci�n debido a: \r\n" + ex.Message + "\r\n" + ex.StackTrace, strNombreDescriptivoServicioMQ, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private bool blnEjecutarEvento1 = true;

        void tsmServicio_CheckedChanged(object sender, EventArgs e)
        {
            if (!blnEjecutarEvento1) {
                blnEjecutarEvento1 = true;
                return;
            }

            ToolStripMenuItem tsmServicio = (ToolStripMenuItem)sender;

            if (TienePermiso(tsmServicio.Tag.ToString()))
            {                
                string[] arrCadena = tsmServicio.Name.Split(new Char[] { '_' });

                BEE_Servicio oServicio = new BEE_Servicio();
                oServicio.Codigo = arrCadena[1];
                oServicio.Habilitado = tsmServicio.Checked;

                try
                {
                    (new BL_AdministradorServicio(strRutaArchivoServicios)).ActualizarServicioXML(oServicio);
                }
                catch
                {
                    blnEjecutarEvento1 = false;
                    tsmServicio.Checked = !tsmServicio.Checked;
                    return;
                }

                EnviarParametroAlServicioMQ();
                ListarServiciosEnMenu();
            }
            else
            {
                blnEjecutarEvento1 = false;
                tsmServicio.Checked = !tsmServicio.Checked;
            }
        }
                
        private void EnviarParametroAlServicioMQ() {
                        
            try
            {
                ServiceController objServiceController = new ServiceController(strNombreServicioMQ);
                objServiceController.ExecuteCommand(Constantes.ACTUALIZAR_SERVICIOSHABILITADOS);                
            }
            catch (Exception ex)
            {
                if (ex.InnerException != null && ex.InnerException.Message.Equals("The service has not been started")) { 
                    //controlar excepcion si es necesario
                }
                else
                    MessageBox.Show("No se pudieron actualizar los  servicios habilitados en el servicio MQ debido a: \r\n" + ex.Message + "\r\n" + ex.StackTrace, strNombreDescriptivoServicioMQ, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        */

        #endregion

        private bool ValidarConexiones(string prmUsuario, string prmPassword)
        {
            string strMensajeErrorICODB = "";
            string strMensajeErrorGENDB = "";
            string strMensajeErrorSTBDB = "";
            string strMensajeErrorSTBSEGDB = "";
            bool blnCorrectoSybaseICODB = false;
            bool blnCorrectoSybaseGENDB = false;
            bool blnCorrectoSybaseSTBDB = false;
            bool blnCorrectoSqlSTBSEGDB = false;
            bool blnCorrectoPwdLogon = false;

            string strCnxSybaseSTBDB = this.ObtenerCadenaConexion(true, strServidorSybase,
                                                                    strBDSybaseSTBDB,
                                                                    strPuertoSybase,
                                                                    prmUsuario, prmPassword);

            string strCnxSybaseICODB = this.ObtenerCadenaConexion(true, strServidorSybase,
                                                                    strBDSybaseICODB,
                                                                    strPuertoSybase,
                                                                    prmUsuario, prmPassword);

            string strCnxSybaseGENDB = this.ObtenerCadenaConexion(true, strServidorSybase,
                                                                    strBDSybaseGENDB,
                                                                    strPuertoSybase,
                                                                    prmUsuario, prmPassword);

            string strCnxSqlSTBSEGDB = this.ObtenerCadenaConexion(false, strServidorMSSQL,
                                                                    strBaseDatosMSSQL,
                                                                    "",
                                                                    prmUsuario, prmPassword);

            if (!chkLogonBCRP.Checked)
            {
                blnCorrectoPwdLogon = true;
            }

            blnCorrectoSybaseSTBDB = this.ProbarConexion(true, strCnxSybaseSTBDB, out strMensajeErrorSTBDB);
            blnCorrectoSybaseICODB = this.ProbarConexion(true, strCnxSybaseICODB, out strMensajeErrorICODB);
            blnCorrectoSybaseGENDB = this.ProbarConexion(true, strCnxSybaseGENDB, out strMensajeErrorGENDB);
            blnCorrectoSqlSTBSEGDB = this.ProbarConexion(false, strCnxSqlSTBSEGDB, out strMensajeErrorSTBSEGDB);
            
            if (chkLogonBCRP.Checked)
            {
                if (txtPasswordLogon.Text.Trim().Equals(string.Empty))
                {
                    blnCorrectoPwdLogon = false;
                }
                else
                {
                    blnCorrectoPwdLogon = true;
                }
            }

            if (!blnCorrectoSybaseSTBDB)
            {
                string strMensaje1 = "No se pudo establecer conexion con [" + strBDSybaseSTBDB + "] por : [" + strMensajeErrorSTBDB + "]";
                LogWriter.Notificar("ToolContingenciaConexionLBTRWeb", strMensaje1);
                MessageBox.Show(strMensaje1, strNombreDescriptivoServicioMQ, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }

            if (!blnCorrectoSybaseICODB)
            {
                string strMensaje2 = "No se pudo establecer conexion con [" + strBDSybaseICODB + "] por : [" + strMensajeErrorICODB + "]";
                LogWriter.Notificar("ToolContingenciaConexionLBTRWeb", strMensaje2);
                MessageBox.Show(strMensaje2, strNombreDescriptivoServicioMQ, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }

            if (!blnCorrectoSybaseGENDB)
            {
                string strMensaje3 = "No se pudo establecer conexion con [" + strBDSybaseGENDB + "] por : [" + strMensajeErrorGENDB + "]";
                LogWriter.Notificar("ToolContingenciaConexionLBTRWeb", strMensaje3);
                MessageBox.Show(strMensaje3, strNombreDescriptivoServicioMQ, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }

            if (!blnCorrectoSqlSTBSEGDB)
            {
                string strMensaje4 = "No se pudo establecer conexion con [" + strBaseDatosMSSQL + "] por : [" + strMensajeErrorSTBSEGDB + "]";
                LogWriter.Notificar("ToolContingenciaConexionLBTRWeb", strMensaje4);
                MessageBox.Show(strMensaje4, strNombreDescriptivoServicioMQ, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }

            if (!blnCorrectoPwdLogon)
            {
                MessageBox.Show("El password para logon en BCRP es requerido.", strNombreDescriptivoServicioMQ, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }

            //Verificar si se exigira conexion con ICODB y GENDB que son bd secundarias
            string strExigir = ConfigurationManager.AppSettings["BD_SECUNDARIA_ES_REQUERIDA"];

            if (!String.IsNullOrEmpty(strExigir))
            {
                if (strExigir.Trim().ToLower().Equals("true"))
                {
                    return (blnCorrectoSybaseSTBDB && blnCorrectoSybaseICODB && blnCorrectoSybaseGENDB && blnCorrectoSqlSTBSEGDB && blnCorrectoPwdLogon);                    
                }
            }

            return (blnCorrectoSybaseSTBDB && blnCorrectoSqlSTBSEGDB && blnCorrectoPwdLogon);
        }

        private void EstablecerAccesosMenu()
        {
            tsbIniciar.Tag = "2*60";
            tsmiIniciar.Tag = "2*60";
            //tsbDetener.Tag = "";
            //tsmiDetener.Tag = "";
        }

        private void btnAyuda_Click(object sender, EventArgs e)
        {
            string strMensaje = "1) Si la aplicaci�n contingencia ha sido configurado:\r\n- Con Security Gateway, entonces, se usar� el usuario y password retornado por �l para la conexi�n a base de datos: \r\n   [Sybase: " + strBDSybaseSTBDB + ", " + strBDSybaseICODB + ", " + strBDSybaseGENDB + "]";
            strMensaje += " y [MSSQL: " + strBaseDatosMSSQL + "]\r\n- Sin Security Gateway, entonces, se deber� ingresar un usuario funcional de base de datos y su contrase�a.";
            strMensaje += "\r\n2) Adem�s, se podr� establecer la contrase�a para el Inicio de D�a o Logon en el sistema LBTR Web del BCRP. �sta se almacenar� como contingencia de logon BCRP.";
            strMensaje += "\r\n3) Para hacer uso de la contingencia, proceder a Detener el servicio. Esperar aproximadamente 1 minuto hasta que se haya detenido.";
            strMensaje += "\r\n4) Luego, presionar el bot�n para Iniciar el servicio. En dicho evento se estar� iniciando el servicio con los datos provistos.";
            strMensaje += "\r\n   Si est� configurado para Security Gateway, solicitar� usuario y contrase�a. De lo contrario, se deber� ingresar el usuario funcional y su contrase�a";
            strMensaje += "\r\n\r\n*Si la contrase�a de logon BCRP es vac�o, en el servicio se usar� el que se tenga almacenado actualmente como contingencia, \r\nde lo contrario,";
            strMensaje += " si no est� almacenado no se podr� iniciar el d�a en el BCRP ya que no habr�a un valor correcto establecido para el password de logon.";

            MessageBox.Show(strMensaje, "Indicaciones", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private string ObtenerCadenaConexion(bool esSybase, string prmServidor, string prmBaseDatos, 
                                                string prmPuerto, string prmUsuario, string prmPassword)
        {
            StringBuilder sbCadena = new StringBuilder();

            if (esSybase)
            {
                sbCadena.Append("Data Source=");
                sbCadena.Append(prmServidor);
                sbCadena.Append(";Port=");
                sbCadena.Append(prmPuerto);
                sbCadena.Append(";Database=");
                sbCadena.Append(prmBaseDatos);
                sbCadena.Append(";Uid=");
                sbCadena.Append(prmUsuario);
                sbCadena.Append(";Pwd=");
                sbCadena.Append(prmPassword);
                sbCadena.Append(";");
            }
            else
            {
                sbCadena.Append("Data Source=");
                sbCadena.Append(prmServidor);
                sbCadena.Append(";Initial Catalog=");
                sbCadena.Append(prmBaseDatos);
                sbCadena.Append(";User Id=");
                sbCadena.Append(prmUsuario);
                sbCadena.Append(";Password=");
                sbCadena.Append(prmPassword);
                sbCadena.Append(";");
            }

            return sbCadena.ToString();
        }

        public bool ProbarConexion(bool esSybase, string prmCadenaConexion, out string prmMensajeError)
        {
            bool exito = false;
            AseConnection cnx1 = null;
            SqlConnection cnx2 = null;
            prmMensajeError = "";

            try
            {
                if (esSybase)
                {
                    cnx1 = new AseConnection(prmCadenaConexion);
                    cnx1.Open();
                }
                else
                {
                    cnx2 = new SqlConnection(prmCadenaConexion);
                    cnx2.Open();
                }
                exito = true;
            }
            catch (Exception ex)
            {
                prmMensajeError = "Error al abrir la conexion: " + ex.Message;
                exito = false;
            }
            finally
            {
                if (cnx1 != null && cnx1.State != ConnectionState.Closed) cnx1.Close();
                if (cnx2 != null && cnx2.State != ConnectionState.Closed) cnx2.Close();
            }

            return exito;
        }

        private void chkLogonBCRP_CheckedChanged(object sender, EventArgs e)
        {
            txtPasswordLogon.Text = "";
            txtPasswordLogon.Enabled = chkLogonBCRP.Checked;
        }

        public void ReiniciarServicio()
        {
            StringBuilder sbMensaje = new StringBuilder();            
            sbMensaje.AppendLine("Se ha invocado al m�todo ReiniciarServicio de la aplicaci�n de contingencia para reiniciar el servicio Windows LBTRWebListener.");

            ServiceController objServiceController = null;

            try
            {
                objServiceController = new ServiceController(strNombreServicioMQ);
                if (objServiceController.Status != ServiceControllerStatus.Stopped)
                {
                    sbMensaje.AppendLine("Se procede a detener el servicio windows...");
                    objServiceController.Stop();
                }
                else
                {
                    sbMensaje.AppendLine("El servicio windows se encuentra detenido por lo tanto se proceder� a iniciarlo.");
                }

                LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.CONTINGENCIA,
                Utilitario.RetornaHashCode(Thread.CurrentThread.GetHashCode()),
                "ReiniciarServicio()", sbMensaje.ToString(), false);

                LogWriter.Notificar("ToolContingenciaConexionLBTRWeb", sbMensaje.ToString());
                
                sbMensaje = new StringBuilder();
                sbMensaje.AppendLine("La aplicaci�n de contingencia esperar� a que el servicio Windows LBTRWebListener sea detenido:");

                DateTime dtInicio = DateTime.Now;
                DateTime dtFin = DateTime.Now;
                TimeSpan tsDuracion;
                double dbMinutos = 0;

                while (true)
                {
                    objServiceController = new ServiceController(strNombreServicioMQ);

                    sbMensaje.AppendLine("El servicio windows LBTRWebListener se encuentra en estado [" + objServiceController.Status.ToString() + "] a las " + DateTime.Now.ToString("HH:mm:ss"));

                    if (objServiceController.Status == ServiceControllerStatus.Stopped)
                    {
                        sbMensaje.AppendLine("El servicio windows LBTRWebListener se detuvo por lo tanto se proceder� a iniciarlo a las " + DateTime.Now.ToString("HH:mm:ss") + ". Finalizar� la app.");
                        objServiceController.Start();
                        break;
                    }

                    dtFin = DateTime.Now;
                    tsDuracion = dtFin - dtInicio;
                    dbMinutos = tsDuracion.TotalMinutes;
                    if (dbMinutos >= dbTiempoEsperaServDetenido)
                    {
                        sbMensaje.AppendLine("La aplicaci�n de contingencia no pudo iniciar el servicio windows LBTRWebListener a las " + DateTime.Now.ToString("HH:mm:ss") + " a pesar del tiempo esperado [" + dbTiempoEsperaServDetenido.ToString() + "] minutos para que sea detenido. Finaliza la app.");
                        break;
                    }

                    Thread.Sleep(1000);
                }

                LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.CONTINGENCIA,
                Utilitario.RetornaHashCode(Thread.CurrentThread.GetHashCode()),
                "ReiniciarServicio()", sbMensaje.ToString(), false);

                LogWriter.Notificar("ToolContingenciaConexionLBTRWeb", sbMensaje.ToString());
            }
            catch (Exception ex)
            {
                LogWriter.EscribirLog(TipoLog.Detallado, TipoServicio.CONTINGENCIA,
                Utilitario.RetornaHashCode(Thread.CurrentThread.GetHashCode()),
                "ReiniciarServicio()", 
                "Error al reiniciar el servicio: \r\n" + ex.Message + "\r\n" + ex.StackTrace + "\r\n\r\nLog de secuencia:\r\n" + sbMensaje.ToString(), false);

                LogWriter.Notificar("ToolContingenciaConexionLBTRWeb", "Error al reiniciar el servicio: \r\n" + ex.Message + "\r\n" + ex.StackTrace + "\r\n\r\nLog de secuencia:\r\n" + sbMensaje.ToString());
            }
        }
                                        
    }

    public enum EstadoServicio
    {
        NO_INSTALADO = 0,
        INICIADO = 1,
        DETENIDO = 2,
        INICIANDO = 3,
        DETENIENDO = 4
    }
             
}