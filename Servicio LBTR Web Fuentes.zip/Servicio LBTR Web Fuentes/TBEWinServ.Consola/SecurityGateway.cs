using System;
using System.Collections.Generic;
//using System.Configuration;
//using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace TBEWinServ.Consola
{
    public class SecurityGateway
    {
        //Use Security Gateway
        public static bool UseSG;

        private static string _Af;
        private static string _Amf;
        private static string _Opcion;

        private static USerInformation _UserInfo;
        //private static string response = "";
        private static int returnValue = -1;

        private static string Af
        {
            get { return _Af; }
            set { _Af = value; }
        }

        private static string Amf
        {
            get { return _Amf; }
            set { _Amf = value; }
        }

        public static string Opcion
        {
            get { return _Opcion; }
            set { _Opcion = value; }
        }

        public static USerInformation Userinfo
        {
            get { return _UserInfo; }
            set { _UserInfo = value; }
        }

        [DllImport("SGWAY.dll", CharSet = CharSet.Auto, SetLastError = false)]
        private static extern int RsmsLogin(ref USerInformation RUserInfo);

        [DllImport("SGWAY.dll", CharSet = CharSet.Auto, SetLastError = false)]
        private static extern string AccFunctions(string str);

        [DllImport("SGWAY.dll", CharSet = CharSet.Ansi, SetLastError = false)]
        private static extern string AccModFuncIds(string str);

        [DllImport("SGWAY.dll", CharSet = CharSet.Auto, SetLastError = false)]
        private static extern string ChangePass(string sAppName, string sLoginId, string sPassword);

        [DllImport("SGWAY.dll", CharSet = CharSet.Ansi, SetLastError = false)]
        private static extern short AuditLog(short cSystemId, short cModuleId, short cFunctionId,
                                             string csAuditText, string csDataText, string csLoginId, string csPassword);

        [DllImport("SGWAY.dll", CharSet = CharSet.Auto, SetLastError = false)]
        private static extern string OraLogin(string pbstrOriginal);

        [DllImport("SGWAY.dll", CharSet = CharSet.Auto, SetLastError = false)]
        private static extern string OraChangePass(string pbstrOriginal);

        public static short Login()
        {
            //if (Convert.ToBoolean(ConfigurationManager.AppSettings.Get("NewSGVersion")))
            //{
                //SGInterface sgInterface = FactorySGInstance.getInstanceInterface();
                //returnValue = sgInterface.RsmsLogin(Convert.ToString(_UserInfo.lApplicationId), _UserInfo.sAppName,
                //                                    _UserInfo.sAppPath, out response);

                //if (returnValue == 1)
                //{
                //    char[] delimiterChars = {'|'};
                //    _UserInfo.sLoginId = response.Split(delimiterChars)[0];
                //    _UserInfo.sPassword = response.Split(delimiterChars)[1];
                //    Af = sgInterface.AccFunctions();
                //    Amf = sgInterface.AccModFuncIds();
                //}
            //}
            //else
            //{
                _UserInfo.sLoginId = " ";
                _UserInfo.sPassword = " ";
                _UserInfo.sShortName = " ";
                _UserInfo.sLongName = " ";
                _UserInfo.lenLogin = 0;
                _UserInfo.lenPwd = 0;
                returnValue = RsmsLogin(ref _UserInfo);
                if (returnValue == 1)
                {
                    Af = AccFunctions("").Trim();
                    Amf = AccModFuncIds("").Trim();
                }
            //}

            return Convert.ToInt16(returnValue);
        }

        public static short f1()
        {
            if (Login() == -1)
            {
                return -1;
            }
            else
            {
                List<object> oLista = new List<object>();
                oLista.Add(_Opcion);
                oLista.Add("OK");
                oLista.Add("Inicio de la Aplicaci�n");

                RegistraAuditoria(oLista);

                return 1;
            }
        }

        public static bool f2a()
        {
            if (UseSG == false)
                return true;

            if (_Amf.IndexOf(_Opcion + "*") != -1)
            {
                List<object> oLista = new List<object>();
                oLista.Add(_Opcion);
                oLista.Add("OK");
                oLista.Add("Inicio de Opci�n");

                RegistraAuditoria(oLista);
                return true;
            }
            else
            {
                MessageBox.Show("No est� permitido el acceso a �sta opci�n", "Aviso", MessageBoxButtons.OK,
                                MessageBoxIcon.Hand);
                return false;
            }
        }

        public static void f2b()
        {
            if (UseSG == false)
                return;

            List<object> oLista = new List<object>();
            oLista.Add(_Opcion);
            oLista.Add("OK");
            oLista.Add("Fin de Opci�n");

            RegistraAuditoria(oLista);
        }

        public static void f3()
        {
            if (UseSG == false)
                return;

            List<object> oLista = new List<object>();
            oLista.Add(_Opcion);
            oLista.Add("OK");
            oLista.Add("Fin de la Aplicaci�n");

            RegistraAuditoria(oLista);
            //if (Convert.ToBoolean(ConfigurationManager.AppSettings.Get("NewSGVersion")))
            //{
                //SGInterface sgInterface = FactorySGInstance.getInstanceInterface();
                ////sgInterface.Logout();
            //}
        }

        public static void RegistraAuditoria(object oListaParams)
        {
            List<object> oLista = (List<object>)oListaParams;
            short ai_moduleid = 0;
            short ai_functionid = 0;
            string ModuloFuncionID = (string)oLista[0];
            //Obtener Modulo y Funci�n
            string[] split = ModuloFuncionID.Split(new Char[] { '*' });
            if (split.Length > 1)
            {
                ai_moduleid = Convert.ToInt16(split[0]);
                ai_functionid = Convert.ToInt16(split[1]);
            }
            string as_description = (string)oLista[1];
            string as_event = (string)oLista[2];
            if (f_sgauditlog(ai_moduleid, ai_functionid, as_description, as_event) == -1)
            {
                // MessageBox.Show("No se ha podido registrar la acci�n", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }

        public static short f_sgauditlog(short ai_moduleid, short ai_functionid, string as_description, string as_event)
        {
            short li_rc;

            li_rc = 1;

            if ((_UserInfo.sLoginId) == null | (_UserInfo.sPassword) == null)
            {
                li_rc = -1;
            }
            else
            {
                //if (Convert.ToBoolean(ConfigurationManager.AppSettings.Get("NewSGVersion")))
                //{
                    //SGInterface sgInterface = FactorySGInstance.getInstanceInterface();
                    //if (
                    //    sgInterface.AuditLog(_UserInfo.lApplicationId, ai_moduleid, ai_functionid, as_description,
                    //                         as_event) != 0)
                    //{
                    //    li_rc = -1;
                    //}
                //}
                //else
                //{
                    if (AuditLog(_UserInfo.lApplicationId, ai_moduleid, ai_functionid, as_description,
                                 as_event, _UserInfo.sLoginId, _UserInfo.sPassword) != 0)
                    {
                        li_rc = -1;
                    }
                //}
            }
            return li_rc;
        }

        #region Nested type: USerInformation

        public struct USerInformation
        {
            public short lApplicationId;
            public short lUserId;
            public short lenLogin;
            public short lenPwd;
            public string sLoginId;
            public string sPassword;
            public string sShortName;
            public string sLongName;
            public string sAppName;
            public string sAppPath;
        }

        #endregion
    }
}