﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace TBEWinServ.Consola
{
    public class FrmBase : Form
    {
        public bool TienePermiso(string Opcion)
        {
            SecurityGateway.Opcion = Opcion;
            return SecurityGateway.f2a();
        }
    }
}
