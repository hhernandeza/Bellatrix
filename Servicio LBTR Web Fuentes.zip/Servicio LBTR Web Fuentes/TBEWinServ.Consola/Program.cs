﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Configuration;

namespace TBEWinServ.Consola
{
    static class Program
    {
        /// <summary>
        /// Punto de entrada principal para la aplicacion.
        /// </summary>
        [STAThread]
        static void Main(string[] args)
        {
            string strComando = "";

            if (args != null)
            {
                if (args.Length == 1)
                {
                    strComando = args[0];
                }
            }

            if (strComando.Equals("REINICIAR"))
            {
                frmConsola oFrmConsola = new frmConsola();
                oFrmConsola.ReiniciarServicio();
            }
            else
            {
                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                Application.Run(new frmConsola());
            }
        }
    }
}